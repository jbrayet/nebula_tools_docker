package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Iterator;
import java.util.NoSuchElementException;

import src.lib.Constants;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;


/**
 * @version $Revision: 1790 $
 * @author 
 *
 */
public class ExonerateIterator implements Iterator<AlignedRead>{

	private static boolean display_version = true;
	BufferedReader br = null;
	int linecount = 0;
	private Log_Buffer LB;
	
	public ExonerateIterator(Log_Buffer log_file, String source_file) {
		LB = log_file;
		if (display_version) {
			LB.Version("ExonerateIterator", "$Revision: 1790 $");
			display_version = false;
		}
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else {
				br = new BufferedReader(new FileReader(source_file));
			}
			//two lines of header
			br.readLine();
			br.readLine();
		} catch (IOException io) {
			LB.error("Can't open Exonerate file " + source_file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}	
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	} 
	
	public void close() {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close Buffered File Reader");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	
	/** 
	 * Read in next line of the Exonerate file
	 * @return AlignedRead object
	 */
	// ESCA-JAVA0076:
	public AlignedRead next() {
		String line = null;
		try {
			line = br.readLine();
			if ( line != null && line.length() > 0 && line.charAt(0) != '-') {
				linecount++;
				String tmp = null;
				//example lines: kims
				//6_191_103_899:AATGCCAAAAAATGGGCGGAGCTAAAAGATAAAGAC 1 34 + V|ZC317.7 1276 1309 + 102 M 33 33
				//6_191_103_976:AAAAGATGATCAAGAAACTTCTCTACAACTTCAAAG 0 36 + IV|K07H8.6c.3 2227 2263 + 117 M 36 36 9*

				//sample line: Simon
				// 202JYAAXX_7_7_9_791_149 0 36 + ENSE00001527057 315 279 - 117 M 36 36

				String[] fields = line.split(" ");
				
				tmp 				= fields[0];
				String name = null;
				String Sequence = null;
				if (tmp.indexOf(':') != -1) {
					name		 		= tmp.substring(0, tmp.indexOf(':'));
					Sequence 			= tmp.substring(tmp.indexOf(':') + 1);
				} else {
					name		 		= tmp;
				}

				tmp 				= fields[4];
				String chromosome = null;
				String alignName = null;
				 /*the original code worked for C.elegans, but will not work for
				 bovine, since it doesn't have the chromosome number, and has
				 3 parameters instead: Gene Name|Gene Family|Transcript Name.*/
				if (tmp.indexOf('|') != -1) {
					chromosome		= tmp.substring(0, tmp.indexOf('|'));
					 /*by setting the alignName to the lastIndexof('|'), we'll be
					 able to set this up to be compatible with the Bovine and
					 C.elegans data sets. Unfortunately, the Bovine code will have
					 to deal with the values being passed in the incorrect
					 variables. This should be fixed by altering the information
					 stored in the bovine fasta file of the transcriptome.*/
					alignName			= tmp.substring(tmp.lastIndexOf('|') + 1);
				} else {
					chromosome = "1";
					alignName			= tmp;
				}

				//fields 7, 9 and 11 are unused 
				//ignore information for fields 12 and beyond (multimatch information)
				
				AlignedRead a = null;
				try {
					new AlignedRead(
								fields[3].charAt(0),			/*direction*/
								name,
								Sequence,
								Integer.valueOf(fields[8]),		/*score*/
								Integer.valueOf(fields[1]),		/*seqStart*/
								Integer.valueOf(fields[2]),		/*seqEnd*/
								alignName,
								chromosome,
								Integer.valueOf(fields[5]),		/*alignStart*/
								Integer.valueOf(fields[6]),		/*alignEnd*/
								0,								/*percent*/
								0,								/*P*/
								null,							/*alignseq*/
								0,								/*mismatches*/
								Integer.valueOf(fields[8]),		/*sort_score*/
								(Sequence != null) ? Sequence.length() : 0, /*queryLength*/
								Integer.valueOf(fields[10]),	/*alignLength*/
								0,								/*contigStart*/
								0,								/*contigEnd*/
								0,								/*identity*/
								null,							/*Match*/
								0,								/*matches_noError*/
								0,								/*matches_1error*/
								0,								/*matches_2error*/
								null,							/*N_reads*/	
								null,							/*error1*/
								null,							/*error2*/
								null);							/*quality*/
				} catch (UnexpectedResultException URE) {
					LB.error("Line " + linecount + " has an invalid read:");
					LB.error(URE.getMessage());
				}
				return a;
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
				//LB.error("\nnext failed on line " + linecount + " .");
			}
		} catch (IOException io) {
			LB.error("Error occured on line " + linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return null;
	}

	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of ExonerateIterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}
	
	public final int getLinesRead() {
		return this.linecount;
	}

}

		
package src.lib;

import java.util.HashMap;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.Log_Buffer;

/**
 * @version $Revision: 1594 $
 * @author 
 */
public class CommandLine {

	private CommandLine() {}
	
/** GENERIC JAVA LIBRARIES **/
	
	/**
	 * Process command line interface strings.
	 * Returns null if nothing is passed.
	 * Converts keys to lower case
	 * @param args
	 * @return
	 * @throws CommandLineProcessingException
	 */
	public static HashMap<String, String> process_CLI(String[] args) throws CommandLineProcessingException {
		if (args.length == 0) {
			return null;
		}
		HashMap<String, String> Variables = new HashMap<String, String>();
		String key = null;
		String value = null;
		int x = 0;
		while (x < args.length) {	
			if (args[x].startsWith("-")) {
				key = args[x].substring(1);
				value = "";
				while (x+1 < args.length  && !args[x+1].startsWith("-")) {
					value = value.concat(args[x+1]);
					x++;
					if (x+1 < args.length && !args[x+1].startsWith("-")) {
						value = value.concat(",");
					}
				}
				x++;
			} else {
				throw new CommandLineProcessingException("expected arg to start with '-'.  could not process arg #"
						+ (x + 1) + " : " + args[x]);				
			}
			
			assert(key != null);
			Variables.put(key.toLowerCase(), value);
		}
		return Variables;
	}
	
	static int get_parameter_count(String parm) {
		if (parm.length() == 0) {
			return 0;
		}
		String[] st = parm.split(",");
		return st.length;	
	}
	
	public static boolean test_parameter_count(Log_Buffer LB, String parm_name, String parm_value, int expected_count) {
		if (get_parameter_count(parm_value) != expected_count) {
			LB.error("Unexpected number of parameters for -" + parm_name + ": " + parm_value);
			LB.die();
			return false;
		}
		return true;
	}
	
	public static boolean test_parameter_count_min(Log_Buffer LB, String parm_name, String parm_value, int expected_count) {
		if (get_parameter_count(parm_value) < expected_count) {
			LB.error("Unexpected number of parameters for -" + parm_name + ": " + parm_value);
			LB.die();
			return false;
		}
		return true;
	}
	
	// ESCA-JAVA0266:
	public static void help_message(Log_Buffer LB) {
		LB.notice("");
		LB.notice("Help for the Vancouver Short Read Analysis Package and FindPeaks can be found at:");
		LB.notice("   http://vancouvershortr.wiki.sourceforge.net/");
		LB.notice("   and");
		LB.notice("   http://vancouvershortr.wiki.sourceforge.net/FindPeaks4");
		LB.notice("");
		LB.notice("For support, please send email to: vancouvershortr-findpeaks@lists.sourceforge.net");
		LB.notice("If you're not a curent subscriber to the mailing list, please indicate your" +
				" preference to be cc'd on the reply.");
		LB.die();
	}

}

package src.lib.ioInterfaces;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Vector;

/**
 * @version $Revision: 1643 $
 * @author
 */
public class Log_Buffer implements Runnable {

	/**
	 * Single instance of the Log_Buffer
	 */
	private static Log_Buffer LB;

	protected Vector<String> logfiles = null;
	protected StringBuffer buffer = null;

	private boolean terminate = false;
	private Vector<PrintStream> listStream;

	private final String lineSeparator;

	private Log_Buffer() {
		listStream = new Vector<PrintStream>();
		logfiles = new Vector<String>();
		buffer = new StringBuffer();
		lineSeparator = System.getProperty("line.separator");
	}

	/**
	 * Singleton access to the Log_Buffer
	 * 
	 * @return
	 */
	public static Log_Buffer getLogBufferInstance() {
		if (LB == null) {
			LB = new Log_Buffer();
		}
		return LB;
	}

	/**
	 * 
	 * @param filename
	 */
	private void add_filename(String filename) {
		logfiles.add(filename);
	}

	/**
	 * 
	 * @return true if there are more messages, else: false
	 */
	public boolean has_messages() {
		synchronized (buffer) {
			if (buffer.length() == 0) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 
	 * @param str
	 */
	public void notice(String str) {
		synchronized (buffer) {
			buffer.append("Info:    ");
			appendString(str);
		}
	}

	/**
	 * 
	 * @param str
	 */
	public void query(String str) {
		synchronized (buffer) {
			buffer.append("Q:    \n");
			appendString(str);
		}
	}

	
	/**
	 * 
	 * @param str
	 */
	public void debug(String str) {
		synchronized (buffer) {
			buffer.append("Debug:   ");
			appendString(str);
		}
	}
	
	
	/**
	 * 
	 * @param str
	 */
	public void package_announce(String str) {
		synchronized (buffer) {
			buffer.append("Version: ");
			appendString(str);
		}
	}
	
	
	/**
	 * This class should be used to print out the name of a class and it's
	 * version as it's initialized. This will allow us to track what's been
	 * used.
	 * 
	 * @param class_name
	 * @param ver
	 */
	public void Version(String class_name, String ver) {
		String n = " Initializing class " + class_name;
		for (int x = 33; x > class_name.length(); x--) {
			n = n.concat(" ");
		}
		synchronized (buffer) {
			buffer.append("Version:");	
			appendString(n + " " + ver);
		}
	}
	
	/**
	 * 
	 * @param str
	 */
	public void warning(String str) {
		synchronized (buffer) {
			buffer.append("Warning:  ");
			appendString(str);
		}
	}

	/**
	 * 
	 * @param str
	 */
	public void error(String str) {
		synchronized (buffer) {
			buffer.append("Error:     ");
			appendString(str);
		}
	}

	private void appendString(String str) {
		synchronized (buffer) {
			buffer.append(str);
			buffer.append(lineSeparator);
			buffer.notifyAll();
		}
	}

	/**
	 * 
	 */
	// ESCA-JAVA0266:
	public void run() {
		appendString("Version: Initializing class Log_Buffer                        " + "$Revision: 1643 $");
		while (!terminate) {
			try {
				synchronized (buffer) {
					buffer.wait();
				}
			} catch (InterruptedException e) {
				System.out.println("Something went bad in the wait state.");
				System.out.println(e.getMessage());
			}
			if (this.has_messages()) {
				clear_buffer();
			}
		}
		shutdown();
	}

	/**
	 * Add a new log file to the log buffer. If the file is not found the
	 * program dies
	 * 
	 * @param file
	 */
	public void addLogFile(String file) {
		synchronized (listStream) {
			try {
				listStream.add(new PrintStream(file));
			} catch (FileNotFoundException e) {
				// ESCA-JAVA0266:
				System.out.println("Error: Coundn't create log file : " + file);
				die();
			}
		}
		this.add_filename(file);
	}

	/**
	 * Add an open PrintStream to the LogBuffer list of stream.
	 * 
	 * @param p
	 *            An open PrintStream.
	 */
	public void addPrintStream(PrintStream p) {
		synchronized (listStream) {
			listStream.add(p);
		}
	}

	/**
	 * 
	 */
	private void clear_buffer() {
		while (this.has_messages()) {
			PrintStream[] tmp_ps = new PrintStream[0]; 
			synchronized (listStream) {
				tmp_ps = listStream.toArray(tmp_ps);
			}
			synchronized (buffer) {
				for (PrintStream ps : tmp_ps) {
					ps.print(buffer.toString());
				}
				buffer.delete(0, buffer.length());
			}
		}
	}

	/**
	 * Remove and close all PrintStream in the list except for System.out which
	 * is only removed.
	 */
	private void shutdown() {
		clear_buffer();
		synchronized (listStream) {
			for (PrintStream ps : listStream) {
				if (!ps.equals(System.out)) {
					ps.close();
				}
			}
			listStream.removeAllElements();
		}
	}

	/**
	 * Close the LogBuffer.
	 */
	public void close() {
		terminate = true;
		synchronized (buffer) {
			buffer.notifyAll();
		}
	}

	/**
	 * Performs a close, and then kills the running program.
	 */
	public void die() {
		close();
		System.exit(0);
	}

	/**
	 * Unsupported Object method clone
	 * 
	 * @return
	 * @throws CloneNotSupportedException
	 */
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
		// Can't clone a Singleton
	}

}

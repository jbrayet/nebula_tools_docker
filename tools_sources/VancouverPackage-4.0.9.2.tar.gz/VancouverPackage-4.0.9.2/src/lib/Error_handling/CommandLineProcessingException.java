package src.lib.Error_handling;

/**
 * @author GPL Software
 * @version "$Revision: 558 $"
 */

public class CommandLineProcessingException extends Exception {

	/**
	 * Generated serialVersion.  I have no idea how this works.
	 */
	private static final long serialVersionUID = 8654831096327188354L;

	public CommandLineProcessingException(String message) {
		super(message);
	}
	
}

package src.projects.findPeaks.objects;

/**
 * @version $Revision: 1501 $
 * @author 
 */
public class MinPeakDesc {
	private final int length;			//length of the region
	private final int max_loc;		
	private final int offset;
	private final float height;

	/**
	 * 
	 * This object is the "common currency" of peak descriptions for the
	 * saturation module, holding the bare minimum necessary amount of
	 * information about a peak description.
	 * 
	 * @param offset
	 *            genomic coordinates
	 * @param length
	 *            relative to the offset (start position.)
	 * @param max_loc
	 *            relative to the offset (start position.)
	 * @param height
	 */
	public MinPeakDesc(int offset, int length, int max_loc, float height) {
		this.length = length;
		this.max_loc = max_loc;
		this.offset = offset;
		this.height = height;
	}
	
	
	/**
	 * Getters - end
	 * 
	 * @return end position of peak relative to the start of the int[]
	 */
	public final int get_length() {
		return this.length;
	}

	/**
	 * Getters - max_loc
	 * 
	 * @return the location of the maxima in this peak (or set of peaks if
	 *         -subpeaks is not being used)
	 */
	public final int get_max_loc() {
		return this.max_loc;
	}

	
	/**
	 * Getters - peak location
	 * 
	 * @return the location of the peak, in absolutie coordinates
	 */
	public int get_peak_location() {
		return this.get_max_loc() + this.get_offset(); 
	}

	
	/**
	 * Getters - offset
	 * 
	 * @return the location of the offset of the start of the int array
	 */
	public final int get_offset() {
		return this.offset;
	}
	
	
	/**
	 * Getters - height
	 * 
	 * @return height of the peak at the maximum 
	 */
	public final float get_height() {
		return this.height;
	}

	
	public final String toString() {
		StringBuffer sb  = new StringBuffer();
		sb.append("offset/start: "+ this.offset);
		sb.append("\tlength: " + this.length);
		sb.append("\tmax loc: " + this.max_loc);
		sb.append("\theight: " + this.height);
		sb.append("\n");
		return sb.toString();
		
	}
	
}

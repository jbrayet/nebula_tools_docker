package src.unittests;

import junit.framework.TestCase;

import org.junit.Test;

import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.MAQmapIterator;
import src.lib.objects.AlignedRead;


public class Test_maq_iterator extends TestCase{

	
/*	Info:    1:1-1_+        CATGTGCTGTGACTGCTTGTAGATGGCCATGGCGCGGACGCGGGTGCCGG      17      7519148 +
	Info:    1:1-2_+        CATGTGCTGTGACTGCTTGTAGATGGCCATGGCGCGGACGCGGGTGCCGG      17      7519148 -
	
	{xhost07}/home/pubseq/BioSw/Maq/maq-0.7.1_x86_64-linux> maq mapview /home/afejes/workspace/Vancouver_Package/testdata/p53.map
	
	java -cp .:../lib/junit.jar junit.textui.TestRunner src.unittests.Test_maq_iterator
*/
	
	
	// ESCA-JAVA0266: Ignore system out printstream.
	/**
	 * Prints out the (minimal) string representation of the test case map file.
	 * @param args
	 */
	public static void main(final String[] args) {
		final Log_Buffer LB = Log_Buffer.getLogBufferInstance();
		LB.addPrintStream(System.out);
		final Thread th = new Thread(LB);
		th.start();
		final MAQmapIterator it = new MAQmapIterator(LB, "test", "../testdata/p53.map", 0, 128, 0 );
		AlignedRead ar=it.next();
		if (ar == null) {
			LB.die();
		} else {
			LB.notice(ar.toString());
			ar = it.next();
			LB.notice(ar.toString());
			LB.die();
		}
	}
	
	// ESCA-JAVA0285:
	// ESCA-JAVA0076:
	@Test public static void test_maq_reads() {
		final Log_Buffer LB = Log_Buffer.getLogBufferInstance();
		final Thread th = new Thread(LB);
		th.start();
		final MAQmapIterator it = new MAQmapIterator(LB, "test", "../testdata/p53.map", 0, 128, 0 );
		
		AlignedRead ar=it.next();
		if (ar == null) {
			LB.die();
		}
		
		assertTrue("AlignedRead found to be null", ar != null);	
		assertTrue("First read name", ar.get_name().compareTo("1:1-1_+") == 0);
		assertTrue("First read sequence", ar.get_sequence().compareTo("CATGTGCTGTGACTGCTTGTAGATGGCCATGGCGCGGACGCGGGTGCCGG") == 0);
		assertTrue("First read chromosome", ar.get_chromosome().compareTo("17") == 0);
		assertTrue("First read start position", ar.get_alignStart() == 7519148);
		assertTrue("First read direction incorrect", ar.get_direction() == '+');
		//assertTrue(ar.get_alignName())
			
		ar=it.next();
		assertTrue("alignedRead found to be null", ar != null);	
		assertTrue("Second read name", ar.get_name().compareTo("1:1-2_+") == 0);
		assertTrue("Second read sequence", ar.get_sequence().compareTo("CATGTGCTGTGACTGCTTGTAGATGGCCATGGCGCGGACGCGGGTGCCGG") == 0);
		assertTrue("Second read chromosome", ar.get_chromosome().compareTo("17") == 0);
		assertTrue("Second read start position", ar.get_alignStart() == 7519148);
		assertTrue("Second read direction incorrect", ar.get_direction() == '-');
		LB.die();
		
	}
	
}

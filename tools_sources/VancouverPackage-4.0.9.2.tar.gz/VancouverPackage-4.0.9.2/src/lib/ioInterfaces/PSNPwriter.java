package src.lib.ioInterfaces;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import src.lib.Constants;
import src.lib.objects.SNP;


/**
 * @version $Revision: 1482 $
 * @author 
 */
public class PSNPwriter {
	private static boolean display_version = true;

	private final Log_Buffer LB;
	private BufferedWriter psnpfile;
	private final String filepath;
	
	
	/**
	 * Open the file name, and initialize the log buffer.  PSNPFile will be ready for use.
	 * @param filename
	 * @param log_buffer
	 */
	public PSNPwriter(String filename, Log_Buffer log_buffer) {
		LB = log_buffer;
		if (display_version) {
			LB.Version("PSNPWriter", "$Revision: 1482 $");
			display_version = false;
		}
		filepath = filename;
		try {
			psnpfile = new BufferedWriter(new FileWriter(filepath));
		} catch (IOException io) {
			LB.error("Can't create psnpfile : " + filepath);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		} 
	}
	
	
	/**
	 * Close the open file handle held by the PSNPwriter
	 */	
	public void close() {
		try {
			psnpfile.close();
		} catch (IOException io) {
			LB.warning("Can't close file : " + filepath);
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	
	
	
	
	
	/**
	 * Function to write changes to the psnp file when there's no protein coding
	 * change. This is basically an abbreviated version of the
	 * write_allsnp_file_change function, with fewer fields.
	 * 
	 * @param chromosome
	 * @param snp
	 * @param Accession
	 * @param Display
	 * @param snp_status
	 */
	public void write_allsnp_file_nochange(String chromosome, SNP snp, String Accession,
			String Display, String snp_status){
		try {
			
			psnpfile.write(chromosome + "\t");
			psnpfile.write(snp.get_position() + "\t");
			psnpfile.write(snp.get_snp_cannonical() + "\t");
			psnpfile.write(snp.get_new_base() + "\t");
			psnpfile.write(Accession + "\t"); 
			psnpfile.write(Display + "\t");
			psnpfile.write(snp.get_coverage_snp() + "\t");
			psnpfile.write(snp.get_total_coverage() + "\t");
			psnpfile.write(snp_status + "\t");
			psnpfile.write("\t\t");
			psnpfile.newLine();
		} catch (IOException io) {
			LB.error("Can't write to SNP file : " + chromosome + ".psnps");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	// ESCA-JAVA0138:
	/**
	 * Extended write version, which provides a lot more information for writing out psnp data
	 * @param chromosome
	 * @param snp
	 * @param Accession
	 * @param Display
	 * @param snp_status
	 * @param peptide
	 * @param Mod_peptide
	 * @param AA_loc
	 */
	public void write_allsnp_file_change(String chromosome, SNP snp, String Accession,
			String Display, String snp_status, String peptide, String Mod_peptide, int AA_loc){
		try {
			
			psnpfile.write(chromosome + "\t");
			psnpfile.write(snp.get_position() + "\t");
			psnpfile.write(snp.get_snp_cannonical() + "\t");
			psnpfile.write(snp.get_new_base() + "\t");
			psnpfile.write(Accession + "\t"); 
			psnpfile.write(Display + "\t");
			psnpfile.write(snp.get_coverage_snp() + "\t");
			psnpfile.write(snp.get_total_coverage() + "\t");
			psnpfile.write(snp_status + "\t");
			psnpfile.write((AA_loc + 1) + "\t");
			psnpfile.write(peptide.charAt(AA_loc) + ">>>");
			psnpfile.write(Mod_peptide.charAt(AA_loc) + "\t");
			int r = ((AA_loc < Constants.PRINT_FLANK_SIZE) ? 0 : AA_loc - Constants.PRINT_FLANK_SIZE );
			while (r < AA_loc) {
				psnpfile.write(peptide.charAt(r));
				r++;
			}
			psnpfile.write("*" + peptide.charAt(AA_loc) + "*");
			for (r = AA_loc + 1; (r <= (AA_loc + 26) && (r < Mod_peptide
					.length())); r++) {
				psnpfile.write(peptide.charAt(r));
			}
			psnpfile.newLine();
		} catch (IOException io) {
			LB.error("Can't write to SNP file : " + chromosome	+ ".psnps");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	
	
	
}

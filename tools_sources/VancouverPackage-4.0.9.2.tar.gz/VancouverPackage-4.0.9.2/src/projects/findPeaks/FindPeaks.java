package src.projects.findPeaks;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.CurrentVersion;
import src.lib.Histogram;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.BedGraphWriter;
import src.lib.ioInterfaces.FileOut;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.WigwriterBuffered;
import src.lib.objects.Tuple;

import src.projects.findPeaks.FDR.ApplyCompare;
import src.projects.findPeaks.FDR.ApplyControl;
import src.projects.findPeaks.FDR.HyperbolicControl;
import src.projects.findPeaks.FDR.LanderWatermanTheory;
import src.projects.findPeaks.FDR.MC_Simulation;
import src.projects.findPeaks.filewriters.PeakWriter;
import src.projects.findPeaks.objects.Compare;
import src.projects.findPeaks.objects.MinPeakDesc;
import src.projects.findPeaks.objects.Parameters;
import src.projects.findPeaks.objects.PeakStats;



/**
 * @version $Revision: 1797 $
 * @author 
 */
public class FindPeaks {
	protected static Runnable Logman = null;
	private static Log_Buffer LB;
	private static float[] saturation_values = {0.1f,0.2f,0.3f,0.4f,0.5f,0.6f,0.7f,0.8f,0.9f};
	
	private FindPeaks() {}
	
	private static void initialize_bedgraph_files(Parameters param, BedGraphWriter bgw) {
		initialize_bedgraph_files(param, bgw, null);
	}
	
	
	
	/**
	 * Initialises and writes headers for bedgraph and peak files.
	 * 
	 * @param param
	 * @param bgw
	 * @param chromosome
	 *            Optional field to provide chromosome name for naming bedgraph
	 *            tracks, so it doesn't overwrite the others produced at the
	 *            same time.
	 */
	private static void initialize_bedgraph_files(Parameters param, BedGraphWriter bgw, String chromosome) {
			
		String ucsc_description = param.get_name();
		if (ucsc_description.indexOf("/") > -1) {
			ucsc_description = ucsc_description.substring(ucsc_description.indexOf("/"));
		}
		if (ucsc_description.lastIndexOf(".") > -1) {
			ucsc_description = ucsc_description.substring(0, ucsc_description.lastIndexOf("."));
		}
		if ( chromosome!= null) {
			ucsc_description = ucsc_description.concat("_chr_" + chromosome);
		}
		String simpleName = ucsc_description;
		ucsc_description += "_FL:" + param.run;
		if (param.get_filterDupes()) {
			ucsc_description += "_no_dupes";
			simpleName = simpleName.concat("_no_duplicates_" + param.type + "_len_" + param.run);
		} else {
			ucsc_description += "_dupe_rds_inc";
			simpleName = simpleName.concat("_duplicates_" + param.type + "_len_" + param.run);
		}
		bgw.header(simpleName,ucsc_description );
	}
	
	/**
	 * 
	 * @param param
	 */
	private static void peaks_file_error(Parameters param) {
		LB.error("Can't create peaks file!");
		LB.error("file name: " + param.file_start + ".peaks");
		LB.error("Please check that the path is valid and that you have write permissions to that directory.");
		LB.die();
	}

	// ESCA-JAVA0049:
	/**
	 * Core routine that process more than one file.
	 * This routine is used when Eland file are processed. (1 file per chr)
	 * @param param
	 * @param dist
	 */
	private static void core_routine_many_files(Parameters param, Distribution dist) {				
		String parm_aligner = param.get_aligner();
		WigwriterBuffered wig	= null;
		BedGraphWriter bgw  	= null;
		boolean out_init 		= false;
		PeakWriter PW			= null;
		float control_min 		= 0;

		if (!param.get_saturation()) {
			try {
				PW = new PeakWriter(LB, param.file_start + ".peaks");
				if (param.get_peaks_header()) {
					PW.Peaksfileheader();
				}
			} catch (IOException io) {
				peaks_file_error(param);
			}
		}

		List<String> chr_file_samples = param.get_sample_files();
		List<String> chr_file_control = null;
		if (param.get_control()) {
			chr_file_control = param.get_control_files();
		} else if (param.get_compare()) {
			chr_file_control = param.get_compare_files();
		}
		for (int x = 0; x < chr_file_samples.size(); x++) {	
			LB.notice("Running Peak Processor");
			Generic_AlignRead_Iterator it_sample = new Generic_AlignRead_Iterator(LB, parm_aligner,
					"source", chr_file_samples.get(x), param.get_qualityfilter(), 
					param.get_maq_file_format(), param.get_PET_flags_raw(),
					param.get_max_PET_size(),param.get_silence_warning());
			//Only use this if you have a control!
			Generic_AlignRead_Iterator it_control = null;
			Generic_AlignRead_Iterator it_compare = null;
			if (param.get_control()) {
				assert(chr_file_control != null);
				it_control = new Generic_AlignRead_Iterator(LB, parm_aligner,
						"source", chr_file_control.get(x), param.get_qualityfilter(), 
						param.get_maq_file_format(), param.get_PET_flags_raw(),
						param.get_max_PET_size(),param.get_silence_warning());
			}
			if (param.get_compare()) { 
				assert(chr_file_control != null);
				it_compare = new Generic_AlignRead_Iterator(LB, parm_aligner,
						"source", chr_file_control.get(x), param.get_qualityfilter(), 
						param.get_maq_file_format(), param.get_PET_flags_raw(),
						param.get_max_PET_size(),param.get_silence_warning());
			}
			/*iterative peak calling - the new core of FindPeaks */
			PeakDataSetParent sample = null;
			
			//TODO: These should become user parameters.
			int sat_iterations = 3;
			MinPeakDesc[][][] peaks_sat = null;
			Histogram[][] histograms = null;
			int[][] coverages = null;
			Tuple<int[][],int[][]> sums_LW = null;
			int[][] peaks_used_sat = null;
			float[][] thresholds_sat = null;
			float[][] thresholds_MC = null;
			
			if (param.get_saturation()) {
				sample = new PeakDataSetParent (LB, param, it_sample, dist, saturation_values, sat_iterations);
				thresholds_sat = new float[saturation_values.length][sat_iterations];
				peaks_used_sat = new int[saturation_values.length][sat_iterations];
			} else {
				sample = new PeakDataSetParent(LB, param, it_sample, dist);	
			}
			
			if (sample.is_null() || sample.is_empty()) {
				LB.notice("No valid reads found in file:" + chr_file_samples.get(x) );
				LB.notice("Moving on to next file.");
				continue;
			}
			PeakStats peaks_stats = new PeakStats(LB, sample, param.get_number_of_bins(), param.get_hist_precision());
			PeakDataSetParent control = null;
			PeakDataSetParent compare = null;
			ApplyControl applycont = null;
			float normalize = 1;
			
			/* Set up for controls, MC or LW without saturation */
			if (!param.get_saturation()) {
				if (param.get_control() && it_control != null) {			//New version - uses thresholding to set mininum
					control = new PeakDataSetParent(LB, param, it_control, dist); // Get Control Dataset
					Compare comp =  null;
					if (param.get_control_type() == 0) {					
						ApplyCompare ac = new ApplyCompare(LB, sample, control,
								param.file_start + "_" + sample.get_chromosome() + ".regions", 
								param.get_min_ht(), param.get_window_size(), param.get_alpha(),
								param.get_log_transform(), param.get_regression_trim());
						comp = ac.get_compare();
					} else {
						HyperbolicControl ic = new HyperbolicControl(LB, sample, control, 
								param.file_start + "_" + sample.get_chromosome() + ".regions",
								sample.get_chromosome(), param.get_min_ht(), param.get_window_size(),
								param.get_alpha(), param.get_log_transform());
						comp = ic.get_compare();
					}
					control_min = comp.get_lowest_sample_ht();
					//normalize = ac.get_slope();
					LB.notice("threshold for sample estimated (control) at: " + control_min);
					applycont = new ApplyControl(LB, sample, control); 
					comp.write_out_regions(param.file_start +"_"+ sample.get_chromosome() + ".regions", 
							sample, control, sample.get_chromosome(), param.get_min_ht(),	//write out some sort of file. 
							param.get_window_size(), param.get_alpha());
					comp.write_out_filtered_peaks(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".peaks",
							sample, control, sample.get_chromosome());
					comp.write_out_filtered_wigs(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".wig.gz",
							sample, control, sample.get_chromosome(), param);
				} else if (param.get_MC_iterations() > 0) {
					int chr_size = peaks_stats.get_chromosome_end();
					PeakStats[] chr_pkstats = MC_Simulation.Sim(peaks_stats.get_coverage(),
								dist, param, chr_size, sample.get_chromosome(), param.get_MC_iterations(), true);
					if (chr_pkstats == null) {
						continue;
					}
					FP_Output.calculate_FDR(chr_pkstats, peaks_stats, param.get_number_of_bins(),
							param.get_hist_precision(),	sample.get_chromosome(), param.get_MCFileOut());
					
				} else if (param.get_landerWaterman() > 0)	{
					control_min = (float)calculateLanderWatermanFDR(peaks_stats.get_LW_pair(), peaks_stats.get_histogram(),
							dist, param, sample.get_chromosome());
					LB.notice("threshold for sample estimated (LW) at: " + control_min);
				}
			}
			
			/* Perform saturation with control */
			if (param.get_saturation() && param.get_control()) {
				control = new PeakDataSetParent(LB, param, it_control, dist); // Get Control Dataset
				LB.notice("Performing Saturation Analysis");
				peaks_sat = sample.return_peak_descs();
				for (int w = 0; w < saturation_values.length; w++) {
					for (int y = 0; y < sat_iterations; y++) {				//New version - uses thresholding to set mininum
						ApplyCompare ac = new ApplyCompare(LB, peaks_sat[w][y], control, param.get_min_ht(),	
								param.get_window_size(), param.get_alpha(), param.get_log_transform(), 
								param.get_regression_trim());
						Compare comp = ac.get_compare();
						thresholds_sat[w][y] = comp.get_lowest_sample_ht();
						peaks_used_sat[w][y] = comp.size();
						LB.notice("threshold for sample estimated at: " + comp.get_lowest_sample_ht());							
					}
				}
				write_out_saturation2(param, peaks_used_sat, sample.get_chromosome(), sat_iterations);
				
			/* Perform saturation with Monte Carlo */	
			} else if (param.get_saturation() && param.get_MC_iterations() > 0) {
				thresholds_MC = new float[saturation_values.length][param.get_MC_iterations() * sat_iterations];
				float[] thresholds_per_row = new float[saturation_values.length];
				int chr_size = peaks_stats.get_chromosome_end();
				Tuple<int[][], int[][]> lw_pairs = sample.return_LW_stats();
				histograms = sample.return_histograms(param.get_number_of_bins(), param.get_hist_precision());
//				PeakStats[] chr_pkstats = MC_Simulation.Sim(peaks_stats.get_coverage(),
//							dist, param, chr_size, sample.get_chromosome(), param.get_MC_iterations(), true);
				coverages = sample.return_peak_coverages();
				int [][] s_reads_used = sample.return_reads_used();
				LB.notice("Performing Saturation Analysis");
				for (int y = 0; y < saturation_values.length; y++) {
					int avg_cov =0;
					for (int q = 0; q < sat_iterations; q++) {		//calculate average coverage for each set.
						avg_cov += coverages[y][q];
					}
					avg_cov = Math.round(((float) avg_cov /sat_iterations));
					if (avg_cov == 0) {
						LB.notice("Insufficient coverage at this saturation level (" + y + ").  Skipping");
						continue;
					}
					PeakStats[] chr_pkstats = MC_Simulation.Sim(avg_cov,
							dist, param, chr_size, sample.get_chromosome(), param.get_MC_iterations(), true);
					for (int q = 0; q < param.get_MC_iterations(); q++) {
						for (int w = 0; w < sat_iterations; w++)
						{
							ApplyControl applycont_child = new ApplyControl(LB, 
									chr_pkstats[q].get_reads_used(), s_reads_used[y][w]);
							thresholds_MC[y][q * sat_iterations + w] = applycont_child.generate_histogram(
									histograms[y][w],
									chr_pkstats[q].get_histogram(),
									new Tuple<Integer, Integer>(lw_pairs.get_first()[y][w], lw_pairs.get_second()[y][w]),
									chr_pkstats[q].get_LW_pair(), param.get_autothresh());
						}
					}
					//Process each row of thresholds.
					thresholds_per_row[y] = 0;
					int number_items = sat_iterations * param.get_MC_iterations();
					for (int q = 0; q < sat_iterations * param.get_MC_iterations(); q++) {
						if (thresholds_MC[y][q] != -1) {
							thresholds_per_row[y] += thresholds_MC[y][q];
						} else {
							number_items -= 1;
						}
					}
					thresholds_per_row[y] /= number_items;
					float stddev = 0;
					for (int q = 0; q < param.get_MC_iterations() * sat_iterations; q++) {
						if (thresholds_MC[y][q] != -1) {
							stddev += thresholds_MC[y][q] - thresholds_per_row[y];
						}
					}
					if (param.get_MC_iterations() > 1) {
						stddev /= param.get_MC_iterations() -1;
						LB.notice("Standard Deviation of threshold for this set is: " + stddev);
					}					
				}
				write_out_saturation3(param, histograms, thresholds_per_row, saturation_values, 
						sample.get_chromosome(), sat_iterations);

				/*perform saturation with LanderWaterman */
			} else if (param.get_saturation() && param.get_landerWaterman() > 0) {
				histograms = sample.return_histograms(param.get_number_of_bins(), param.get_hist_precision());
				sums_LW = sample.return_LW_stats();				
				for (int w = 0; w < saturation_values.length; w++) {
					for (int y = 0; y < sat_iterations; y++) {
						thresholds_sat[w][y] = (float)calculateLanderWatermanFDR(
								new Tuple<Integer,Integer>(
										sums_LW.get_first()[w][y],
										sums_LW.get_second()[w][y]),
								histograms[w][y], dist, param, sample.get_chromosome());
//						LB.notice("threshold calculated = " + thresholds_sat[w][y]);  
					}
				}
				LB.notice("Lander waterman thresholds are returned as floats/doubles, but histograms are used with int-sized " +
						"bins - Values provided near the threshold may not be reliable.");
				write_out_saturation(param, histograms, thresholds_sat, saturation_values, sample.get_chromosome(), sat_iterations);
			} else if (param.get_saturation()) {
				LB.error("Forgot to set a -" + Parameters.CONTROL_PARAM + ", -"
						+ Parameters.MC_ITER_PARAM + " or -"
						+ Parameters.LANDERWATERMAN_PARAM + " flag");
				LB.die();
			}
				
			if (param.get_compare() && it_compare != null) {
				compare = new PeakDataSetParent(LB, param, it_compare, dist); // Get Control Dataset
				Compare comp = null;
				if (param.get_control_type() == 0) {
					ApplyCompare ac = new ApplyCompare(LB, sample, compare,
							param.file_start + "_" + sample.get_chromosome() + ".regions", sample.get_chromosome(),
							param.get_min_ht(), param.get_window_size(), param.get_alpha(), 
							param.get_filterCompare(), param.get_log_transform(), param.get_regression_trim());
					comp = ac.get_compare();
				} else {
					HyperbolicControl ic = new HyperbolicControl(LB, sample, compare, 
							param.file_start + "_" + sample.get_chromosome() + ".regions", sample.get_chromosome(),
							param.get_min_ht(), param.get_window_size(), param.get_alpha(),	param.get_log_transform());
					comp = ic.get_compare();
				}
				comp.write_out_filtered_peaks(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".peaks",
						sample, compare, sample.get_chromosome());
				comp.write_out_filtered_wigs(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".wig.gz",
						sample, compare, sample.get_chromosome(), param);
			}
			
			/*Initialize filewriter after we've finished inputing the chromosome */
			if (param.get_one_file_per()) {
				if (param.get_bedgraph()) {
					bgw = new BedGraphWriter(LB, param.file_start + "_" + sample.get_chromosome() + ".bedgraph.gz", param.prepend);
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".bedgraph.gz");
					initialize_bedgraph_files(param, bgw);
				} else {
					wig = new WigwriterBuffered(LB, param.file_start +"_"+ sample.get_chromosome() + ".wig.gz", 
							param.prepend, param.get_wig_step_size(), param.get_min_coverage());
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".wig.gz");
					wig.initialize_wig_files(param.get_name(), param.type,
							param.run, param.get_filterDupes(), sample.get_chromosome()); 			// All reads
				}
			} else if (!out_init) {
				if (param.get_bedgraph()) {
					bgw = new BedGraphWriter(LB, param.file_start + ".bedgraph.gz", param.prepend);
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".bedgraph.gz");
					initialize_bedgraph_files(param, bgw); // All reads
				} else {
					wig = new WigwriterBuffered(LB, param.file_start + ".wig.gz", 
							param.prepend, param.get_wig_step_size(), param.get_min_coverage());
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".wig.gz");
					wig.initialize_wig_files(param.get_name(), param.type, param.run, param.get_filterDupes()); // All reads
				}
				out_init = true;
			}
			if (!param.get_saturation()) {
				if (applycont != null) {
					sample.write_out_files(dist, PW, wig, bgw,
							(control_min > 0) ? control_min : param.get_min_ht(), 
							applycont, normalize);	
				} else {
					sample.write_out_files(dist, PW, wig, bgw, (control_min > 0 ) ? control_min: param.get_min_ht());
				}
			}
			

			if (param.get_one_file_per()) {
				close_files(bgw, wig);
			}
			
			it_sample.close();
			if (it_control != null) {
				it_control.close();
			}
			if (it_compare != null) {
				it_compare.close();
			}
		}

		if (!param.get_one_file_per()) {					//if we've been using one file for the whole run,
			if (wig!=null) {								//we'll close things up at this point.
				wig.close();
				LB.notice("Wrote to:" + param.file_start + ".wig.gz");
			}
			if (bgw!=null) {
				bgw.close();
				LB.notice("Wrote to:" + param.file_start + ".bedgraph.gz");
			}
		}
		if (PW != null) {
			try {	
				PW.close();											//always one peaks file per run.  Close it now.
			} catch (IOException io) {
				LB.warning("Warning, can't close output files - continuing anyhow");
			}
		}
	}

	/**
	 * 
	 * @param LW_stats
	 * @param s_hist
	 * @param dist
	 * @param param
	 * @param chromosome
	 * @return the threshold for the lander-waterman calculation. 
	 */
	private static double calculateLanderWatermanFDR(Tuple<Integer,Integer> LW_stats, Histogram s_hist, Distribution dist,
			Parameters param, String chromosome)	{
		
		double[] cumExpectedPeak = LanderWatermanTheory.randomlyExpectedPeaks(
				LW_stats,
				param.get_number_of_bins(), 
				dist,
				10000,
				param.get_hist_precision());
		FP_Output.calculate_FDR(cumExpectedPeak, s_hist, 
				param.get_number_of_bins(), param.get_hist_precision(),chromosome,param.get_LWFileOut());
		return LanderWatermanTheory.getHeightForFDR(cumExpectedPeak, s_hist, param.get_number_of_bins(),
			param.get_hist_precision(), param.get_landerWaterman());

	}

	/**
	 * 
	 * @param param
	 * @param dist
	 */
	private static void core_routine_one_file(Parameters param, Distribution dist) {		
		String parm_aligner = param.get_aligner();
		WigwriterBuffered wig	= null;
		BedGraphWriter bgw		= null;
		boolean out_init 		= false;
		PeakWriter PW			= null;
		float control_min		= 0;

		if (!param.get_saturation()) {
			try {
				PW = new PeakWriter(LB, param.file_start + ".peaks");	
				if (param.get_peaks_header()) {
					PW.Peaksfileheader();
				}
			} catch (IOException io) {
				peaks_file_error(param);
			}
		}
		
		List<String> chr_file_samples = param.get_sample_files();
		Generic_AlignRead_Iterator it_sample = new Generic_AlignRead_Iterator(LB, parm_aligner,
				"source", chr_file_samples.get(0), param.get_qualityfilter(), 
				param.get_maq_file_format(), param.get_PET_flags_raw(),
				param.get_max_PET_size(),param.get_silence_warning());

		List<String> chr_file_control = null;
		List<String> chr_file_compare = null;
		Generic_AlignRead_Iterator it_control  = null;
		Generic_AlignRead_Iterator it_compare  = null;
		if (param.get_control()) {
			chr_file_control = param.get_control_files();
			it_control = new Generic_AlignRead_Iterator(LB, parm_aligner,
				"source", chr_file_control.get(0), param.get_qualityfilter(), 
				param.get_maq_file_format(), param.get_PET_flags_raw(),
				param.get_max_PET_size(),param.get_silence_warning());
		} else if (param.get_compare()) {
			chr_file_compare = param.get_compare_files();
			it_compare = new Generic_AlignRead_Iterator(LB, parm_aligner,
					"source", chr_file_compare.get(0), param.get_qualityfilter(), 
					param.get_maq_file_format(), param.get_PET_flags_raw(),
					param.get_max_PET_size(),param.get_silence_warning());
		}

		
		PeakDataSetParent compare_temp = null;
		boolean compare_temp_used = false;
		PeakDataSetParent control_temp= null;
		boolean control_temp_used = false;
	
		while (it_sample.hasNext()) { //comes back here at each chromosome.
			/*iterative peak calling - the new core of FindPeaks */
			LB.notice("Running Peak Processor");
			PeakDataSetParent sample = null;

			
			//TODO: These should become user parameters.
			int sat_iterations = 3;
			MinPeakDesc[][][] peaks_sat = null;
			int[][] peaks_used_sat = null;
			Histogram[][] histograms = null;
			int[][] coverages = null;
			Tuple<int[][], int[][]> sums_LW = null;
			float[][] thresholds_sat = null;
			float[][] thresholds_MC = null;
			
			if (param.get_saturation()) {
				sample = new PeakDataSetParent(LB, param, it_sample, dist, saturation_values, sat_iterations);
				thresholds_sat = new float[saturation_values.length][sat_iterations];
				peaks_used_sat = new int[saturation_values.length][sat_iterations];
			} else {
				sample = new PeakDataSetParent(LB, param, it_sample, dist);	
			}
						
			if (sample.is_null() || sample.is_empty()) {
				LB.notice("No valid reads found for chromosome - moving to next");
				continue;
			}
			PeakStats peaks_stats = new PeakStats(LB, sample, param.get_number_of_bins(), param.get_hist_precision());
			PeakDataSetParent control = null;
			PeakDataSetParent compare = null;
			ApplyControl applycont = null;
			float normalize = 1;
			
			if (!param.get_saturation()) {
				if (param.get_control() && it_control != null) {			//New version - uses thresholding to set mininum
					
					//code for skipping chromosomes with controls 
					if (control_temp_used) { 
						control = control_temp;
						control_temp_used = false;
					} else {
						control = new PeakDataSetParent(LB, param, it_control, dist); // Get Control Dataset
					}
					
					if (control.get_chromosome() == null) {
						LB.notice("There are no more control chromosomes.  No further chromosomes can be processed.");
						break;
					}
					
					if (!sample.get_chromosome().contentEquals(control.get_chromosome())) {
						LB.notice("Chromosomes don't match.");
						if (sample.get_chromosome().contains("_random")) {
							LB.notice("Sample chromosome contains the word \"random\".  Moving on to next Chromosome");
							control_temp_used = true;
							control_temp = control;			//store compare in a temp variable, and then recover on next pass.
							continue;
						}
						int c = sample.get_chromosome().compareTo(control.get_chromosome());
						while (c > 0) {
							LB.notice("sample chromosome comes after control. Getting Next Chromosome");
							control = new PeakDataSetParent(LB, param, it_control, dist); // Get Control Dataset
							c = sample.get_chromosome().compareTo(control.get_chromosome());
						}	
						if (c < 0) {
							LB.notice("control chromosome comes after sample. Moving on to next Chromosome");
							control_temp_used = true;
							control_temp = control;			//store control in a temp variable, and then recover on next pass.
							continue;
						}
					}
					Compare comp = null;
					if (param.get_control_type() == 0) {
						ApplyCompare ac = new ApplyCompare(LB, sample, control, 
								param.file_start + "_" + sample.get_chromosome() + ".regions",
								param.get_min_ht(),	param.get_window_size(), param.get_alpha(), param.get_log_transform(),
								param.get_regression_trim());
						comp = ac.get_compare();
					} else {
						HyperbolicControl ic = new HyperbolicControl(LB, sample, control, 
								param.file_start + "_" + sample.get_chromosome() + ".regions", sample.get_chromosome(),
								param.get_min_ht(), param.get_window_size(), param.get_alpha(),	param.get_log_transform());
						comp = ic.get_compare();
					}
					control_min = comp.get_lowest_sample_ht();
					//normalize = ac.get_slope();
					LB.notice("threshold for sample estimated (control) at: " + control_min);
					applycont = new ApplyControl(LB, sample, control);
					comp.write_out_regions(param.file_start +"_"+ sample.get_chromosome() + ".regions", 
							sample, control, sample.get_chromosome(), param.get_min_ht(),	//write out some sort of file. 
							param.get_window_size(), param.get_alpha());
					comp.write_out_filtered_peaks(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".peaks",
							sample, control, sample.get_chromosome());
					comp.write_out_filtered_wigs(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".wig.gz",
							sample, control, sample.get_chromosome(), param);
				} else if (param.get_MC_iterations() > 0) {
					int chr_size = peaks_stats.get_chromosome_end();
					PeakStats[] chr_pkstats = MC_Simulation.Sim(peaks_stats.get_coverage(),
								dist, param, chr_size, sample.get_chromosome(), param.get_MC_iterations(), true);
					if (chr_pkstats == null) { continue; }
					FP_Output.calculate_FDR(chr_pkstats, peaks_stats, param.get_number_of_bins(), 
							param.get_hist_precision(), sample.get_chromosome(), param.get_MCFileOut());
				} else if (param.get_landerWaterman() > 0)	{
					control_min = (float)calculateLanderWatermanFDR(peaks_stats.get_LW_pair(), peaks_stats.get_histogram(),
							dist, param, sample.get_chromosome());
					LB.notice("threshold for sample estimated (LW) at: " + control_min);
				}
			}
				
			/* Perform saturation with control */
			if (param.get_saturation() && param.get_control()) {
				LB.notice("Performing Saturation Analysis");
				peaks_sat = sample.return_peak_descs();
				for (int w = 0; w < saturation_values.length; w++) {
					for (int y = 0; y < sat_iterations; y++) {
						control = new PeakDataSetParent(LB, param, it_control, dist); // Get Control Dataset
						ApplyCompare ac = new ApplyCompare(LB, peaks_sat[w][y], control, param.get_min_ht(),	
								param.get_window_size(), param.get_alpha(), param.get_log_transform(),
								param.get_regression_trim());
						Compare comp = ac.get_compare();
						thresholds_sat[w][y] = comp.get_lowest_sample_ht();
						peaks_used_sat[w][y] = comp.size();
						LB.notice("threshold for sample estimated at: " + comp.get_lowest_sample_ht());							
					}
				}
				write_out_saturation2(param, peaks_used_sat, sample.get_chromosome(), sat_iterations);
				
			/* Perform saturation with Monte Carlo */	
			} else if (param.get_saturation() && param.get_MC_iterations() > 0) {
				thresholds_MC = new float[saturation_values.length][param.get_MC_iterations() * sat_iterations];
				float[] thresholds_per_row = new float[saturation_values.length];
				int chr_size = peaks_stats.get_chromosome_end();
				Tuple<int[][], int[][]> lw_pairs = sample.return_LW_stats();
				histograms = sample.return_histograms(param.get_number_of_bins(), param.get_hist_precision());
//				PeakStats[] chr_pkstats = MC_Simulation.Sim(peaks_stats.get_coverage(),
//							dist, param, chr_size, sample.get_chromosome(), param.get_MC_iterations(), true);
				coverages = sample.return_peak_coverages();
				int [][] s_reads_used = sample.return_reads_used();
				LB.notice("Performing Saturation Analysis");
				for (int y = 0; y < saturation_values.length; y++) {
					int avg_cov =0;
					for (int q = 0; q < sat_iterations; q++) {		//calculate average coverage for each set.
						avg_cov += coverages[y][q];
					}
					avg_cov = Math.round(((float) avg_cov /sat_iterations));
					PeakStats[] chr_pkstats = MC_Simulation.Sim(avg_cov,
							dist, param, chr_size, sample.get_chromosome(), param.get_MC_iterations(), true);
					for (int q = 0; q < param.get_MC_iterations(); q++) {
						for (int w = 0; w < sat_iterations; w++) {
							ApplyControl applycont_child = new ApplyControl(LB,
									chr_pkstats[q].get_reads_used(),
									s_reads_used[y][w]);
							thresholds_MC[y][q * sat_iterations + w] = applycont_child.generate_histogram(
									histograms[y][w],
									chr_pkstats[q].get_histogram(),
									new Tuple<Integer,Integer>(lw_pairs.get_first()[y][w], lw_pairs.get_second()[y][w]),
									chr_pkstats[q].get_LW_pair(), param.get_autothresh());
						}
					}
					//Process each row of thresholds.
					thresholds_per_row[y] = 0;
					int number_items = sat_iterations * param.get_MC_iterations();
					for (int q = 0; q < sat_iterations * param.get_MC_iterations(); q++) {
						if (thresholds_MC[y][q] != -1) {
							thresholds_per_row[y] += thresholds_MC[y][q];
						} else {
							number_items -= 1;
						}
					}
					thresholds_per_row[y] /= number_items;
					float stddev = 0;
					for (int q = 0; q < param.get_MC_iterations() * sat_iterations; q++) {
						if (thresholds_MC[y][q] != -1) {
							stddev += thresholds_MC[y][q] - thresholds_per_row[y];
						}
					}
					if (param.get_MC_iterations() > 1) {
						stddev /= param.get_MC_iterations() -1;
						LB.notice("Standard Deviation of threshold for this set is: " + stddev);
					}					
				}
				write_out_saturation3(param, histograms, thresholds_per_row, saturation_values, 
						sample.get_chromosome(), sat_iterations);

			/*perform saturation with LanderWaterman */
			} else if (param.get_saturation() && param.get_landerWaterman() > 0) {
				histograms = sample.return_histograms(param.get_number_of_bins(), param.get_hist_precision());
				sums_LW = sample.return_LW_stats();

				for (int w = 0; w < saturation_values.length; w++) {
					for (int y = 0; y < sat_iterations; y++) {
						thresholds_sat[w][y] = (float) calculateLanderWatermanFDR(
								new Tuple<Integer, Integer>(
										sums_LW.get_first()[w][y], 
										sums_LW.get_second()[w][y]),
								histograms[w][y], dist, param, sample.get_chromosome()); 
					}
				}
				LB.notice("Lander waterman thresholds are returned as floats/doubles, but histograms are used with int-sized " +
						"bins - Values provided near the threshold may not be reliable.");
				write_out_saturation(param, histograms, thresholds_sat, saturation_values, sample.get_chromosome(), sat_iterations);
			} else if (param.get_saturation()) {
				LB.error("Forgot to set a -" + Parameters.CONTROL_PARAM + ", -"
						+ Parameters.MC_ITER_PARAM + " or -"
						+ Parameters.LANDERWATERMAN_PARAM + " flag");
				LB.die();
			}
		
			
			if (param.get_compare() && it_compare != null) {		//code for skipping over chromosomes with no pair.
				if (compare_temp_used) { 
					compare = compare_temp;
					compare_temp_used = false;
				} else {
					compare = new PeakDataSetParent(LB, param, it_compare, dist); // Get Control Dataset
				}
				if (compare.get_chromosome() == null) {
					LB.notice("There are no more compare chromosomes.  No further chromosomes can be processed.");
					break;
				}
				if (!sample.get_chromosome().contentEquals(compare.get_chromosome())) {
					LB.notice("Chromosomes don't match.");
					if (sample.get_chromosome().contains("_random")) {
						LB.notice("Sample chromosome contains the word \"random\".  Moving on to next Chromosome");
						compare_temp_used = true;
						compare_temp = compare;			//store compare in a temp variable, and then recover on next pass.
						continue;
					}
					int c = sample.get_chromosome().compareTo(compare.get_chromosome());
					while (c > 0) {
						LB.notice("sample chromosome comes after compare. Getting Next Chromosome");
						compare = new PeakDataSetParent(LB, param, it_compare, dist); // Get Control Dataset
						if (compare.get_chromosome() == null) {
							LB.notice("There are no more compare chromosomes.  No further chromosomes can be processed.");
							break;
						}
						c = sample.get_chromosome().compareTo(compare.get_chromosome());
					}	
					if (c < 0) {
						LB.notice("compare chromosome comes after sample. Moving on to next Chromosome");
						compare_temp_used = true;
						compare_temp = compare;			//store compare in a temp variable, and then recover on next pass.
						continue;
					}
				}
				PeakStats compare_stats = new PeakStats(LB, compare, param.get_number_of_bins(), param.get_hist_precision());
				Compare comp = null;
				if (param.get_control_type() == 0) {
					ApplyCompare ac = new ApplyCompare(LB, sample, compare,
							param.file_start + "_" + sample.get_chromosome()+ ".regions", 
							sample.get_chromosome(), param.get_min_ht(), param.get_window_size(), 
							param.get_alpha(), param.get_filterCompare(), param.get_log_transform(),
							param.get_regression_trim());
					comp = ac.get_compare();
				} else {
					HyperbolicControl ic = new HyperbolicControl(LB, sample, compare, 
							param.file_start + "_" + sample.get_chromosome() + ".regions", sample.get_chromosome(),
							param.get_min_ht(), param.get_window_size(), param.get_alpha(),	param.get_log_transform());
					comp = ic.get_compare();
				}
				comp.write_out_filtered_peaks(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".peaks",
						sample, compare, sample.get_chromosome());
				comp.write_out_filtered_wigs(param.file_start + "_" + sample.get_chromosome() + "_filtered", ".wig.gz",
						sample, compare, sample.get_chromosome(), param);
				}
			
			/*Initialize filewriter after we've finished inputing the chromosome */
			if (param.get_one_file_per()) {
				if (param.get_bedgraph()) {
					bgw = new BedGraphWriter(LB, param.file_start +"_"+ sample.get_chromosome() + ".bedgraph.gz", param.prepend);
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".bedgraph.gz");
					initialize_bedgraph_files(param, bgw, sample.get_chromosome() ); // All reads
				} else {
					wig = new WigwriterBuffered(LB, param.file_start +"_"+ sample.get_chromosome() + ".wig.gz", 
							param.prepend, param.get_wig_step_size(), param.get_min_coverage());
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".wig.gz");
					wig.initialize_wig_files(param.get_name(), param.type, param.run, 
							param.get_filterDupes(), sample.get_chromosome()); // All reads
				}
			} else if (!out_init) {
				if (param.get_bedgraph()) {
					bgw = new BedGraphWriter(LB, param.file_start + ".bedgraph.gz", param.prepend);
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".bedgraph.gz");
					initialize_bedgraph_files(param, bgw); // All reads
				} else {
					wig = new WigwriterBuffered(LB, param.file_start + ".wig.gz", 
							param.prepend, param.get_wig_step_size(), param.get_min_coverage());
					LB.notice("writing to : " + param.file_start +"_"+ sample.get_chromosome() + ".wig.gz");
					wig.initialize_wig_files(param.get_name(), param.type, param.run, param.get_filterDupes()); 
				}
				out_init = true;
			}
			
			if (!param.get_saturation()) {
				if (applycont != null) {
					sample.write_out_files(dist, PW, wig, bgw,
							(control_min > 0) ? control_min : param.get_min_ht(),
							applycont, normalize);	
				} else {
					sample.write_out_files(dist, PW, wig, bgw, (control_min > 0 ) ? control_min: param.get_min_ht());
				}
			}
			
			if (param.get_one_file_per()) {
				close_files(bgw, wig);
			}
			sample.clear();
			peaks_stats.clear();
		}
	
		if (!param.get_one_file_per()) {
			if (wig!=null) {
				wig.close();
				LB.notice("Wrote to:" + param.file_start + ".wig.gz");
			}
			if (bgw!=null) {
				bgw.close();
				LB.notice("Wrote to:" + param.file_start + ".bedgraph.gz");
			}
			
		}
		if (PW != null) {
			try {
				PW.close();
			} catch (IOException io) {
				LB.warning("Warning, can't close output files - continuing anyhow");
			}
		}
		it_sample.close();
		if (it_control != null) {
			it_control.close();
		}
		if (it_compare != null) {
			it_compare.close();
		}
	}

	
	private static void close_files(BedGraphWriter bgw, WigwriterBuffered wig) {
		if (bgw != null) {
			bgw.close();
		}
		if (wig != null) {
			wig.close();
		}
	}
	
	// ESCA-JAVA0138:
	private static void write_out_saturation(Parameters param,
			Histogram[][] histograms, float[][] thresholds, float[] array_tmp,
			String chromosome, int iterations) {

		FileOut sat_file = new FileOut(LB, param.file_start + "_" + chromosome + "_saturation.tsv", false);
		
		for (int x = 0; x < array_tmp.length; x++) {
			StringBuffer sb = new StringBuffer();
			sb.append(array_tmp[x]);
			for (int y = 0; y < iterations; y++) {
				sb.append("\t" +  histograms[x][y].count_greater_than_value(thresholds[x][y])); 				
			LB.notice(sb.toString());
			}
			sat_file.writeln(sb.toString());
		}
		
		sat_file.close();
	}	
	
	// ESCA-JAVA0138:
	private static void write_out_saturation3(Parameters param,
			Histogram[][] histograms, float[] thresholds, float[] array_tmp,
			String chromosome, int iterations) {

		FileOut sat_file = new FileOut(LB, param.file_start + "_" + chromosome + "_saturation.tsv", false);
		
		for (int x = 0; x < array_tmp.length; x++) {
			StringBuffer sb = new StringBuffer();
			sb.append(array_tmp[x]);
			for (int y = 0; y < iterations; y++) {
				sb.append("\t" +  histograms[x][y].count_greater_than_value(thresholds[x])); 				
			}
			LB.notice(sb.toString());
			sat_file.writeln(sb.toString());
		}
		
		sat_file.close();
		LB.notice("Wrote to: " + param.file_start + "_" + chromosome + "_saturation.tsv");
	}	
	
	
	
	// ESCA-JAVA0138:
	private static void write_out_saturation2 (Parameters param, int[][] pk_counts,			
			String chromosome, int iterations) {

		FileOut sat_file = new FileOut(LB, param.file_start + "_" + chromosome + "_saturation.tsv", false);
		
		for (int x = 0; x < saturation_values.length; x++) {
			StringBuffer sb = new StringBuffer();
			sb.append(saturation_values[x]);
			for (int y = 0; y < iterations; y++) {
				sb.append("\t" +  pk_counts[x][y]); 				
			}
			LB.notice(sb.toString());
			sat_file.writeln(sb.toString());
		}
		
		sat_file.close();
		LB.notice("Wrote to: " + param.file_start + "_" + chromosome + "_saturation.tsv");
	}	
	
	
	private static void test_for_help(String[] args) {
		for (String s: args) {
			if (s.equalsIgnoreCase("-help")) {
				CommandLine.help_message(LB);
			}
		}
		
	}
	
	
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		
		/* test for help */
		test_for_help(args);
		
		Thread th = new Thread(LB);
		th.start();
		new CurrentVersion(LB);
		LB.Version("FindPeaks", "$Revision: 1797 $");		
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}		
		Parameters param = new Parameters(LB, Variables);	//interprets command line args.
		
		/*Construct Distribution*/
		Distribution dist = new Distribution(LB, param);

		boolean many = false;									//checks if will be iterating over multiple files.
		if (param.get_sample_files().size() > 1) {
			if (param.get_aligner().equalsIgnoreCase(Constants.FILE_TYPE_BED) ||
				param.get_aligner().equalsIgnoreCase(Constants.FILE_TYPE_ELAND) ||
				param.get_aligner().equalsIgnoreCase(Constants.FILE_TYPE_ELANDII) ||
				param.get_aligner().equalsIgnoreCase(Constants.FILE_TYPE_GFF) ||
				param.get_aligner().equalsIgnoreCase(Constants.FILE_TYPE_VULGAR) ) {
				many = true;
			}
		}

		//run only one - select based upon which ever is required by aligner passed in.
		if (many) {
			core_routine_many_files(param, dist);
		} else {
			core_routine_one_file(param, dist);
		}
		param.close();
		LB.close();
	}

}

package src.projects.findPeaks;

import src.lib.ioInterfaces.Log_Buffer;
import src.projects.findPeaks.objects.Parameters;

/**
 * creates the distribution used for probabilistic read lengths
 * Options: mode 0 - fixed length distribution
 * 			mode 1 - triangle distribution (not idea)
 * 			mode 2 - adaptive length distribution.  Uses triangle distribution to identify peaks,
 * 					 then switches to use sample based distribution
 * 			mode 3 - "native" distribution.  Use the length of the sequence itself.
 * @version $Revision: 1834 $
 * @author Genome Sciences Centre
 */
public class Distribution {
	//CONSTANTS
	private static Log_Buffer LB;
	private boolean intbased;
	private int dist_type;
	
	//object variables	
	private float[] ld;	
	private float avg_length;
	private float one_read_area;
			
	/**
	 * Sets up the distribution type to be used.
	 * @param logbuffer
	 * @param param
	 */
	public Distribution(Log_Buffer logbuffer, Parameters param) {
		
		//this is the only place in which param.get_max_len() should legitimately be used.
		
		dist_type = param.get_dist_type();
		LB = logbuffer;
		this.ld = null;
		this.avg_length = 0;
		if (dist_type == 0 ) {
			
			LB.notice("Inititing fixed width with max_len : " + param.get_max_len());
			
			init_fixed_width_distribution(param.get_max_len());
			init_avg_len();
			this.one_read_area = calculate_area();
		} else if (dist_type == 1) {
			init_triangle_distribution(param);
			init_avg_len();
			this.one_read_area = calculate_area();
		} else if (dist_type == 2) {		//adaptive
			/* nothing to do, really */
		} else if (dist_type == 3) {		//native mode
			intbased = true;
			this.one_read_area = 0;
		} else {
			LB.error("Unknown Distribution type initialized.");
			LB.die();
		}
		
		if (dist_type != 3 && param.get_min_coverage() > 0) {
			ld = trim_distribution(param.get_min_coverage()); 
		}
		
	}
	
	/**
	 * reset the distribution.  Shouldn't really be needed unless distribution changes between rums
	 */
	public void reset() {
		ld = null;
		avg_length = 0; 
	}
	
	/**
	 * Provide access to the value of the distribution at a given point from the end of a fragment
	 * @param a
	 * @return
	 */
	public float value_at(int a) {
		return ld[a];
	}
	
	
	/**
	 * creates a triangle distribution. for live length reads
	 * 
	 * Uses a triangular distribution to create a cumulative distribution function.<br>
	 *<pre>
	 *       ^
	 *      /|\
	 *     / | \
	 *    /  |  \
	 *   /   |   \
	 *  /    |    \
	 * O-----o-----o
	 * left  max   right</pre>
	 * 
	 * @param param
	 * 
	 */
	public void init_triangle_distribution(Parameters param) {
		
		intbased = false;
		
		int left = param.get_triangle_low();
		int right = param.get_triangle_high();
		int max = param.get_triangle_median();
		
		float h = 2/(float)(right-left);						//gives normalized height
		ld = new float[right];
		float slope1 = (h/(float)(max - left));
		float slope2 = (0-h/(float)(right - max));
		float b1 = - (slope1 * left);
		float b2 = - (slope2 * right);
		float hx = 0;
		for (int x = 0; x < left; x++) {
			ld[x] = 1f;
		}
		for (int x = left; x <= max; x++) {
			hx = slope1 * x + b1;
			ld[x] = 1 - ((hx * (x-left)) /2);
		}
		float left_area = (h*(float)(max-left))/2;
		float right_area = (h*(float)(right-max)/2);
		for (int x = max+1; x < right; x++) {
			hx = slope2 * x + b2;
			ld[x] = (1 - left_area); 
			ld[x] -= (right_area - (hx * (float)(right-x) /2));
		}
		for (int x = right; x<right; x++) {
			ld[x] = 0;
		}
		
	}
	
	
	/**
	 * Cumulative distribution, assuming that all fragments are exactly "size" in length.
	 * @param size
	 */
	public void init_fixed_width_distribution(int size) {
		this.intbased = true;
		this.ld = new float[size];									//simplest possible distribution.
		for (int x = 0; x < size; x++) {
			this.ld[x] = 1f;
		}			
	}
	
	public void init_avg_len() {
		float sum = 0;
		float wt = 0;
		for (int x = 1; x < ld.length; x++) {
			sum += ld[x] * x;
			wt += ld[x];
		}
		avg_length = sum/wt;
	}
	
	private float calculate_area() {
		float sum = 0;
		for (float i : this.ld ) {
			sum += i;
		}
		return sum;
	}
	
	public final float get_avg_length() {
		return avg_length;
	}
	
	
	/**
	 * Returns the maxmimum fragment (extension length) from the start of the read.
	 * @return
	 */
	public final int get_max_ext_len() {
		return ld.length;
	}

	/**
	 * Sets the maximum fragment (extentsion) length from the start of the
	 * fragment. Should not be used except by Parameters.java and during
	 * adaptive distribution use.
	 * 
	 * @param max_len
	 */
	public final void set_max_ext_len(int max_len) {
		
		float[] t = new float[max_len];
		for (int x = 0; x < max_len; x++) {
			if (x < ld.length) {
				t[x] = ld[x];
			} else {
				t[x] = 0;
			}
		}
		ld = t;
	}
	
	/**
	 * returns a boolean value that describes whether the distribution used is int based or float based.
	 * @return
	 */
	public final boolean intbased() {
		return intbased;
	}
	/**
	 * returns the type of distribution that is used by the object
	 * @return
	 */
	public final int get_dist_type() {
		return dist_type;
	}

	/**
	 * function to get area of a single read. (When subpeaks is off, this number
	 * times the number of reads is the area of the peak.
	 * @return
	 */
	public final float get_area() {
		return this.one_read_area;
	}
	
	
	private float[] trim_distribution(float min_ht){
		int first_bad_pos = 0;
		int x = 0;
	
		while (x < ld.length) {
			if (ld[x] < min_ht) {
				first_bad_pos = x;
				break;
			}
			x += 1;
		}
		if (first_bad_pos != 0) {
			float[] t = new float[first_bad_pos];
			for (int y = 0; y < first_bad_pos; y++) {
				t[y] = ld[y];
			}
			for (int y = 0; y < first_bad_pos; y++) {
				t[y] = ld[y];
			}
			return t;
		}
		return ld;
	}
	
	
	
}
package src.projects.SNP_Database.objects;

// ESCA-JAVA0100:
// ESCA-JAVA0136:
public class Library {

	private int library_id;
	private String name;
	private String seq_type; 
	private int read_length;
	private int read_length_alt; 
	private String sample_type;
	private String sample_desc;
	private String sample_organ;
	private String sample_notes;
	private String sample_cell_type; 
	
	// ESCA-JAVA0138:
	public Library(int library_id, String name, String seq_type,
			int read_length, int read_length_alt, String sample_type,
			String sample_desc, String sample_organ, String sample_notes,
			String sample_cell_type) {

		this.set_Library_id(library_id);
		this.set_Name(name);
		this.set_Seq_type(seq_type); 
		this.set_Read_length(read_length);
		this.set_Read_length_alt(read_length_alt); 
		this.set_Sample_type(sample_type);
		this.set_Sample_desc(sample_desc);
		this.set_Sample_organ(sample_organ);
		this.set_Sample_notes(sample_notes);
		this.set_Sample_cell_type(sample_cell_type);
		
	}

	public void set_Library_id(int library_id) {
		this.library_id = library_id;
	}

	public int get_Library_id() {
		return library_id;
	}

	public void set_Name(String name) {
		this.name = name;
	}

	public String get_Name() {
		return name;
	}

	public void set_Seq_type(String seq_type) {
		this.seq_type = seq_type;
	}

	public String get_Seq_type() {
		return seq_type;
	}

	public void set_Read_length(int read_length) {
		this.read_length = read_length;
	}

	public int get_Read_length() {
		return read_length;
	}

	public void set_Read_length_alt(int read_length_alt) {
		this.read_length_alt = read_length_alt;
	}

	public int get_Read_length_alt() {
		return read_length_alt;
	}

	public void set_Sample_type(String sample_type) {
		this.sample_type = sample_type;
	}

	public String get_Sample_type() {
		return sample_type;
	}

	public void set_Sample_desc(String sample_desc) {
		this.sample_desc = sample_desc;
	}

	public String get_Sample_desc() {
		return sample_desc;
	}

	public void set_Sample_organ(String sample_organ) {
		this.sample_organ = sample_organ;
	}

	public String get_Sample_organ() {
		return sample_organ;
	}

	public void set_Sample_notes(String sample_notes) {
		this.sample_notes = sample_notes;
	}

	public String get_Sample_notes() {
		return sample_notes;
	}

	public void set_Sample_cell_type(String sample_cell_type) {
		this.sample_cell_type = sample_cell_type;
	}

	public String get_Sample_cell_type() {
		return sample_cell_type;
	}
	
	
	
}

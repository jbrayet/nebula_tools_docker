package src.projects.SNP_Database.SnpIterators;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import src.lib.Constants;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;

/**
 * @version $Revision: 1543 $
 * @author 
 */
public class VCFIterator implements Iterator<SNP>, SNPIterator {
	private static boolean display_version = true;
	private static Log_Buffer LB;

	BufferedReader br = null;
	int linecount = 0;
	final String filename;
	
	LinkedList<SNP> buffer = null;
	
	
	public VCFIterator(Log_Buffer logbuffer, String source_file) {
		LB = logbuffer;
		this.filename = source_file;
		if (display_version) {
			LB.Version("AndySnpIterator", "$Revision: 1543 $");
			display_version = false;
		}
		try {
			br = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException e) {
			LB.error("Can't find file " + filename);
			LB.die();
		}
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		LB.notice(filename + " closed successfully");
		
	}
	
	
	/** 
	 * Read in next line of the SNP file
	 * 
	 * Expected format:
	 *			There are 8 fixed fields per record, all tab delimited. Fixed fields are:
	 *
	 *	1. CHROM chromosome: an identifier from the reference fasta file
	 *	2. POS position (1st base has position 1). Positions are sorted 
	 *			numerically, in increasing order, within each reference 
	 *			sequence CHROM.
	 *	3. ID A unique identifier where available, else '.'. If this is
	 *			a dbSNP variant it is encouraged to use the rs number.
	 *	4. REF reference base. One of A,C,G,T,N
	 *	5. ALT comma separated list of alternate non-reference alleles 
	 *			called on at least one of the samples. Options are 
	 *			A,C,G,T,Dn (for delete n bases starting with the base 
	 *			at POS), I<seq> where <seq> is a list of ACGT bases to 
	 *			be inserted just after the base at POS, '.' (period 
	 *			character) if there are not alternate alleles.
	 *	6. QUAL phred-scaled quality score for the assertion made in ALT.
	 *			i.e. give -10log_10 prob(call in ALT is wrong). If ALT 
	 *			is '.' (no variant) then this is -10log_10 p(variant), and
	 *			if ALT is not '.' this is -10log_10 p(no variant). High 
	 *			QUAL scores indicate high confidence calls. Although 
	 *			traditionally people use integer phred scores, we agreed to 
	 *			permit floating point scores to enable higher resolution 
	 *			for low confidence calls if desired.
	 *	7. FILTER filter: 0 if this position is not filtered, i.e. a call 
	 *			is made at this position. Otherwise a semicolon-separated 
	 *			list of codes for filters that fail. e.g. “q10;s50” might 
	 *			indicate that at this site the quality is below 10 and the 
	 *			number of samples with data is below 50% of the total number 
	 *			of samples
	 *	8. INFO additional information, encoded as a comma-separated series 
	 *			of 2-character keys with optional values in the format: 
	 *			<key>=<data>[,data]*. Fields could be e.g.:
	 *
	 *
	 * 				* AA ancestral allele, encoded as REF and ALT
	 * 				* AC allele count in genotypes, for each ALT allele,  
	 * 					in the same order as listed
	 * 				* AN total number of alleles in called genotypes
	 * 				* AF allele frequency for each ALT allele in the same  
	 * 					order as listed: use this when estimated from  
	 * 					primary data, not called genotypes
	 * 				* DP depth, e.g. D=154
	 * 				* MQ RMS mapping quality, e.g. MQ=52
	 * 				* BQ RMS base quality at this position
	 * 				* SB strand bias at this position
	 * 				* DB dbSNP membership
	 * 				* H2 membership in hapmap2
	 * 
	 * @return SNP object
	 */
	public SNP next() {
		String line = null;
		SNP S = null;
		if (!buffer.isEmpty()) {
			S = buffer.get(0);
			buffer.remove(0);
			return S;
		}
		//TODO: use the above format to write iterator.
		try {
			if ((line = br.readLine()) != null) {
				this.linecount++;	
				
				String[] elements = line.split("\t");				
				if (elements.length !=  8) {
					LB.error("VCF requires 8 tab delimited fields: " + elements.length + " found.");
					LB.die();
				}
				String chromosome	= elements[0];
				int position 		= Integer.valueOf(elements[1]);
			//	String id			= elements[2];
				char ref 			= elements[3].charAt(0);		
				String alt_obs		= elements[4];  //comma separated list of snps.
				String qual			= elements[5];
			//	String filter		= elements[6];
				String info			= elements[7];
				String[] tmp 		= info.split(",");
					//handle AC, AN, DP, BQ
				HashMap<String, String> keys = new HashMap<String, String>();
				for (String t : tmp) {
					String[] kv = t.split("=");
					keys.put(kv[0], kv[1]);
				}
	
				
				String[] alt_snps = alt_obs.split(",");					//handle list of SNPs at this position.
				if (alt_snps.length > 1) {
					int all_alt_cov = 0;
					if (keys.containsKey("AC")) {
						String[] alt_cov = keys.get("AC").split(",");
						for (int c = alt_snps.length -1; c > 0; c--) {
							all_alt_cov += Integer.valueOf(alt_cov[c]);
						}
					}
					
					for (int x = alt_snps.length -1; x > 0; x--) {
						
						//do SNP stuff
						/*SNP(String chr, int pos, char alt, char cannon, int obs_snp, int obs_ref, int total,
								int misc, double quality, int hetrozygous, String id) {*/
						
						 S = new SNP(chromosome, position, alt_snps[x].charAt(0), ref,
								(keys.containsKey("AC")) ? Integer.valueOf((keys.get("AC").split(","))[x]) : -1, 
								(keys.containsKey("AC") && keys.containsKey("DP")) ? 		//depth - allel
										(Integer.valueOf(keys.get("DP")) - all_alt_cov) : -1,
								(keys.containsKey("DP")) ? Integer.valueOf(keys.get("DP")) : -1,
								-1, Double.valueOf(qual), -1, null);
						buffer.add(S);
						
					}
					
					
				} else {
					 S = new SNP(chromosome, position, alt_obs.charAt(0), ref,
								(keys.containsKey("AC")) ? Integer.valueOf(keys.get("AC")) : -1, 
								(keys.containsKey("AC") && keys.containsKey("DP")) ? 		//depth - allel
										(Integer.valueOf(keys.get("DP")) - Integer.valueOf(keys.get("AC"))) : -1,
								(keys.containsKey("DP")) ? Integer.valueOf(keys.get("DP")) : -1,
								-1, Double.valueOf(qual), -1, null);
					 return S;
				}
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
			}
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		
		return S;
	}
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of SNPIterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

}

		
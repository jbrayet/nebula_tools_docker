package src.projects.maq_utilities;

import java.io.DataInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.NoSuchElementException;

import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.CurrentVersion;
import src.lib.IterableIterator;

import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;

import src.lib.objects.AlignedRead;


/**
 * @version $Revision: 1567 $
 * @author 
 */
// ESCA-JAVA0100:
public class QualityReport {

	 /*input variables*/
	private static String input_file;
	private static String output_path;
	private static String aligner;
	private static int maq_read_size;
	private static int qualityfilter;
	
	/*run statistics*/
	static int reads_used = 0;
	static HashMap<String, Integer> map_transcript_exon;
	
	private QualityReport() {}
	
	private static Log_Buffer LB = null;
	
	/**
	 * Processing command line arguments for program.
	 * 
	 * @param Variables
	 *            Command line arguments: input path, output path, Species,
	 *            Chromosome(s), min snp percent, min snp observed.
	 */
	private static void parse_input(HashMap<String, String> Variables) {

		if (Variables == null) {
			usage();
		}
		
		assert (Variables != null);
		
		if (Variables.containsKey("help")) {
			usage();
		}

		
		if (Variables.containsKey("output")) {
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + "qualityreport.log");
			LB.addLogFile(output_path + "qualityreport.log");
		} else { 
			LB.error("An output directory must be supplied with the -output flag" );
			usage();
		}
	
		/* end bootstrap  - print out results of bootstrapped variables*/
		LB.notice(" * Output directory  : " + output_path);		
		
		if (Variables.containsKey("aligner")) {		
			CommandLine.test_parameter_count_min(LB, "aligner", Variables.get("aligner"), 1);
			aligner = Variables.get("aligner");
			LB.notice(" * Input aligner     : " + aligner);
		} else {
			LB.error("chomosome must be supplied with -chr flag");
			usage();
		}

		if (Variables.containsKey("maq_read_size")) {
			if (!aligner.equals(Constants.FILE_TYPE_MAQ)) {
				LB.notice("-maq_read_size only used for maq aligner");
				usage();
			}
			CommandLine.test_parameter_count(LB, "maq_read_size", Variables.get("maq_read_size"), 1);
			maq_read_size = Integer.valueOf(Variables.get("maq_read_size"));
			LB.notice(" * Maq read size     : " + maq_read_size);
		} else if (aligner.equalsIgnoreCase("maq")) {
			LB.error("Must specify list of size of the maq reads with the -maq_read_size flag."
					+ " Use 64 for maq 0.6.x use 128 for maq 0.7+");
			usage();
		}

		if (Variables.containsKey("input")) {
			CommandLine.test_parameter_count(LB, "input", Variables.get("input"), 1);
			input_file = Variables.get("input");
			if (input_file.equals("PIPE")) {
				new DataInputStream(System.in);
			} else if (!input_file.endsWith(System.getProperty("file.separator"))) {
				input_file = input_file.concat(System.getProperty("file.separator"));
			}
			LB.notice(" * Input directory   : " + input_file);
		} else { 
			LB.error("An input file must be specified with the -input flag" );
			usage();
		}
		
		if (Variables.containsKey("qualityfilter")) {		
			CommandLine.test_parameter_count(LB, "qualityfilter", Variables.get("qualityfilter"), 1);
			qualityfilter = Integer.valueOf(Variables.get("qualityfilter"));	
		} 
		LB.notice(" * Minimum quality   : " + qualityfilter);

		/*remove standard ht entries. Then process whatever is left with a warning:*/
		Variables.remove("input");
		Variables.remove("output");
		Variables.remove("aligner");
		Variables.remove("maq_read_size");
		Variables.remove("qualityfilter");

		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			StringBuffer sb = new StringBuffer();
			sb.append("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				sb.append("  " + k);
			}
			LB.error(sb.toString());
			LB.die();
		}
	}		
		
		
	private static void usage() {
		LB.notice("This program requires the following parameters:");
		LB.notice(" -input      | <String> | provide the full path to the eland files.");
		LB.notice(" -output     | <String> | provide a valid path for the output.");
		LB.notice(" -aligner    | <String> | Name of the aligner that provided the reads (defines file format).");
		LB.notice(" -maq_read_size | <int> | The file for intron spanning mapped reads.");
		LB.notice(" -qualityfilter | <int> | The minimum read quality score to use.");
		LB.die();
	}

	

	
	/**
	 * Main function for processing Transcriptome data.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables);									//interprets command line args.

		new CurrentVersion(LB);
		LB.Version("ReadsUsed", "$Revision: 1567 $");
		
		Generic_AlignRead_Iterator it = new Generic_AlignRead_Iterator(LB, 
				aligner, "sourcefile", input_file, qualityfilter, 128, null, 0, false);
		
		int cnt = 0;

		final int MAX_LENGTH = 100;
		final int MAX_QUAL = 40;
		
		int[][] data = new int[MAX_LENGTH+1][MAX_QUAL+1];
			
		while (it.hasNext()) {
			
			cnt++;
			if (cnt % 1000000 == 0) {
				LB.notice(cnt + " reads processed");
			}
			AlignedRead alnrd=null;
			try {
				alnrd = it.next();
			} catch (NoSuchElementException e) {
				break;
			}
			if (alnrd == null) {
				continue;
			}
			
			//LB.notice(alnrd.outElandExt());
			for (int x = 0; x < alnrd.get_sequence().length(); x++) { 
				//LB.notice("quality is : " + alnrd.get_quality(x));
				int t_q =alnrd.get_quality(x); 
				if (t_q > MAX_QUAL) {
					LB.warning("Quality found at " + t_q);
					t_q = MAX_QUAL;
				} else if (t_q < 0 ) {
					LB.warning("found quality below zero : " + t_q);
					t_q = 0;
				}
				if (alnrd.get_direction() == '+') {
					data[x][t_q] +=1;
				} else {
					data[alnrd.get_sequence().length() - x - 1][t_q] +=1;
				}
			}
		}

		//write out binned results:
		for (int x = 0; x <= MAX_LENGTH; x++) {
			int lteTEN =0;
			int lteTWENTY =0;
			int gtTWENTY = 0;
			for (int y = 0;  y <= 10; y++ ) {
				lteTEN += data[x][y];
			}
			for (int y = 11;  y <= 20; y++ ) {
				lteTWENTY += data[x][y];
			}
			for (int y = 21;  y <= MAX_QUAL; y++ ) {
				gtTWENTY += data[x][y];
			}
			
			System.out.println("pos.\t<=10\t<=20\t>20");
			
			if (!(lteTEN == 0 && lteTWENTY == 0 && gtTWENTY == 0)) {
				System.out.println(x + "\t" + lteTEN + "\t" + lteTWENTY + "\t" + gtTWENTY);
			}
		}
		it.close();
		
		LB.notice ("Statistics:");
		LB.notice ("Total sequence reads used:" + cnt);
		LB.close();
	}

}
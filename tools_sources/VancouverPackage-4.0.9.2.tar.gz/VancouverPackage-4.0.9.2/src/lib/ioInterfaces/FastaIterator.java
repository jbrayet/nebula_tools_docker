package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;

import src.lib.Constants;

/**
 * Iterates through a Fasta Format file, parsing it into individual records. The
 * records are returned as 2-dimensional string arrays. Only 1 record is ever
 * held in memory at one time. Absolutely no parsing of the record takes place,
 * therefore, fasta records that contain number or invalid letters are fine.
 * headers are retruned with leading ">".
 * 
 * Usage: FastaIterator fi = new FastaIterator(<name of fasta file>);
 * while(fi.hasNext()) {
 * 		String[] record = fi.next();
 * 		System.out.println("Name" + record[0].subnstring(1));
 * 		System.out.println("Data "+record[1]); 
 * }
 * @author Genome Science Centre
 * @version $Revision: 558 $
 */
public class FastaIterator implements Iterator<String[]> {
	private static boolean display_version = true;
	/** hasMore is true if there are more records in the fasta file */
	private boolean hasMore;

	/** The read that gets the data */
	private BufferedReader br;

	/** stores the fasta header information */
	private String header;

	/** Stores the fasta record data */
	private StringBuffer sb;
	
	private Log_Buffer LB;
	
	/**
	 * Constructs a new fasta iterator with a default 1000 character string
	 * buffer
	 * @param log_file
	 * @param f
	 *            The fasta file name
	 */
	public FastaIterator(Log_Buffer log_file, String f) {
		this(log_file, f, 1000);
	}

	/**
	 * Constructs a fasta iterator for file f, with initial StringBuffer size
	 * "size".
	 * 
	 * @param log_file
	 * @param f
	 *            The fasta file name
	 * @param size
	 *            The initial size of the StringBuffer
	 */
	public FastaIterator(Log_Buffer log_file, String f, int size) {
		LB = log_file;
		if (display_version) {
			LB.Version("FastaIterator", "$Revision: 558 $");
			display_version = false;
		}
		sb = new StringBuffer(size);
		try {
			br = new BufferedReader(new FileReader(f));
		} catch (IOException io) {
			LB.error("Error opening file " + f);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		String line = null;
		hasMore = false;
		try {
			while ((line = br.readLine()) != null) {
				if (line.length() < 1) {
					continue;				
				}
				if (line.charAt(0) == '>') {
					hasMore = true;
					header = line;
					break;
				}
			}
		} catch (IOException io) {
			LB.error("Failed to read line");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}

	/**
	 * Returns true if the fasta file has another fasta record, false otherwise.
	 * @return true if there are more records, else: false.
	 */
	public boolean hasNext() {
		return hasMore;
	}

	/**
	 * Returns the next fasta record in the file as a 2-dimensional string
	 * array. The record header is in the the first array position, and the data
	 * is in the second.
	 * @return a fasta record composed of two strings in a String[]
	 * @throws NoSuchElementException
	 */
	public String[] next() {
		if (!hasMore) {
			throw new NoSuchElementException("No more elements in fasta file.");
		}
		sb.delete(0, sb.capacity());
		hasMore = false;
		String line = null;
		String[] s2 = new String[2];
		try {
			while ((line = br.readLine()) != null) {
				if (line.length() < 1) {
					continue;
				}
				if (line.charAt(0) == '>') {
					hasMore = true;
					s2[0] = header;
					s2[1] = sb.toString();
					header = line;
					return s2;
				}
				sb.append(line);
			}
		} catch (IOException ioe) {
			throw new NoSuchElementException("Could not get any more reads.");
		}

		s2[0] = header;
		s2[1] = sb.toString();
		try {
			br.close();
		} catch (IOException io) {
			LB.warning("Could not close fasta file.  Continuing.");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		return s2;
	}

	/**
	 * Remove is not supported by this Iterator!
	 * @deprecated by Anthony Fejes
	 * @throws UnsupportedOperationException
	 */
	public void remove()  {
		throw new UnsupportedOperationException(
				"Remove operation not permitted on this object.");
	}

	/**
	 * Returns the name portion of a fasta header file
	 * 
	 * @param s
	 *            The fasta header string
	 * @return The name portion of the header string
	 */
	public static String getName(String s) {
		int j = 0;
		for (j = 0; j < s.length(); j++) {
			if (s.charAt(j) != '>' && s.charAt(j) != '\t' && s.charAt(j) != ' ') {
				break;
			}
		}
		int i = 0;
		for (i = 0; i < s.length(); i++) {
			if (s.charAt(i) == '\n' || s.charAt(i) == '\t' || s.charAt(i) == ' ') {
				break;
			}
		}
		return s.substring(j, i).trim();
	}

	/**
	 * Closes the buffered reader
	 */
	public void close() {
		hasMore = false;
		try {
			br.close();
		} catch (IOException io) {
			LB.warning("Error closing FastaIterator.  Continuing anyhow.");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}

}

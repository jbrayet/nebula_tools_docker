package src.projects.SNP_Database.SnpIterators;

import java.util.NoSuchElementException;

import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;

public class Generic_SNP_Iterator implements Iterable<SNP>{
	private static boolean display_version = true;
	private SNPIterator it;
	private SNP next;
	private final Log_Buffer LB;
	
	
	// ESCA-JAVA0138:
	/**
	 * Create a generic Iterator used to read the Aligned reads and return it.
	 * If aligner is already initialized, it will not re-initialize unless it is
	 * closed first.
	 * 
	 * @param logbuffer
	 * @param format
	 * @param file
	 */
	public Generic_SNP_Iterator(Log_Buffer logbuffer, String format, String file) {
		LB = logbuffer; 
		if (display_version) {
			LB.Version("Generic_SNP_Iterator", "$Revision: 1626 $");
			display_version = false;
		}
		if (it == null) { 
			if (format.equalsIgnoreCase("Maq")) {
				it = new MaqSnpIterator(LB, file);
			} else if (format.equalsIgnoreCase("sam")) {
				it = new SAMSnpIterator(LB, file);
			} else if (format.equalsIgnoreCase("andy")) {
				it = new AndySnpIterator(LB, file);
			} else if (format.equalsIgnoreCase("dbsnp")) {
				it = new dbSNP130Iterator(LB, file);
			} else if (format.equalsIgnoreCase("wtsspipeline")) {
				it = new WTSSPipelineSNPIterator(LB, file);
			} else {
				LB.error("Did not recognize SNP_caller type: " + format);
				LB.error("Please check that you have not made a spelling mistake when providing the snp caller type");
				LB.die();
			}
		}
	}
	
	public Generic_SNP_Iterator(Log_Buffer logbuffer, SNPIterator iter) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Generic_AlignRead_Iterator", "$Revision: 1626 $");
			display_version = false;
		}
		it = iter;
	}
	

	
	public SNP next() {
		SNP to_return=next;
		try {
			if (to_return==null) {
				next=it.next();
				to_return=next;
			} else {
				next = null;
			}
		} catch (NoSuchElementException nsee) {
			return null;
		}
		return to_return;
	}
	
	public boolean hasNext() {
		if (next!=null){
			return true;
		}else{
			try{
				next=it.next();
			}catch (NoSuchElementException nsee){
				next=null;
			}
			if (next!=null){
				return true;
			}else{
				return false;
			}
		}
	}

	public SNPIterator iterator() {
		return this.it;
	}
	
	/**
	 * Close whichever Iterator was being used.
	 */
	public void close() {
		
		if (it != null) {
			it.close(false);
			it = null;
		} else {
			LB.warning("Cannot close: Iterator doesn't exist");
		}
	}
	
}

package src.projects.findPeaks.objects;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.IterableIterator;
import src.lib.Utilities;
import src.lib.ioInterfaces.FileOut;
import src.lib.ioInterfaces.Log_Buffer;
import src.projects.findPeaks.FPConstants;


// ESCA-JAVA0100:
// ESCA-JAVA0136:
/**
 * @version $Revision: 1838 $
 * @author 
 */
public class Parameters {
	

	/* Strings for command line parametes */
	public static final String HELP_PARAM = "help";
	public static final String ALIGNER_PARAM = "aligner";
	public static final String ALPHA_PARAM = "alpha";
	public static final String AUTOTHRESH_PARAM = "auto_threshold";
	public static final String BEDGRAPH_PARAM = "bedgraph";
	public static final String COMPARE_PARAM = "compare";
	public static final String CONTROL_PARAM = "control";
	public static final String CONTROL_TYPE_PARAM = "control_type";
	public static final String DIST_TYPE_PARAM = "dist_type";
	public static final String FILTER_DUPS_PARAM = "duplicatefilter";
	public static final String EFF_FRAC_PARAM = "eff_frac";
	public static final String HIST_SIZE_PARAM = "hist_size";
	public static final String HIST_PREC_PARAM = "hist_precision";
	public static final String INPUT_PARAM = "input";
	public static final String MC_ITER_PARAM = "iterations";
	public static final String LANDERWATERMAN_PARAM = "landerwaterman";
	public static final String LOG_TRANSF_PARAM = "log_transform";
	public static final String MAQ_FILE_FORMAT_PARAM = "maq_read_size";
	public static final String MAX_PET_SIZE_PARAM = "max_pet_size";
	public static final String MIN_PK_PROCESS_PARAM = "min_ht_process";
	public static final String MIN_COVERAGE_PARAM = "min_coverage";
	public static final String MIN_PEAK_PARAM = "minimum";
	public static final String NAME_PARAM = "name";
	public static final String COMPARE_FILTER_PARAM = "no_filter_compare";
	public static final String NO_PEAKS_HEADER_PARAM = "no_peaks_header";
	public static final String SILENCE_WARNING_PARM = "no_warning";
	public static final String ONE_PER_PARAM = "one_per";
	public static final String OUTPUT_PARAM = "output";
	public static final String PET_FLAGS_PARAM = "pet_flags";
	public static final String PREPEND_PARAM = "prepend";
	public static final String FILTER_QUAL_PARAM = "qualityfilter";
	public static final String RMODE_PARAM = "rmode";
	public static final String REG_TRIM_PARAM = "regression_trim";
	public static final String SATURATION_PARM = "saturation";
	public static final String GOLDENPATH_PARAM = "sequence";
	public static final String SUBPEAKS_PARAM = "subpeaks";
	public static final String TRIM_PARAM = "trim";
	public static final String WINDOW_SIZE_PARAM = "window_size";
	public static final String WIG_STEP_SIZE_PARAM = "wig_step_size";
	
	/** Log Buffer - where all messages should be sent */
	private static Log_Buffer LB;
	private static boolean display_version = true;

	private  String Aligner;			// Which Aligner was used to generate files - selects format of file
	private final String name;			// Run specific string, used to prefix the name of the file being created
	private final String output;		// Directory where all output files will be created

	private final int dist_type;		// Which method of generating a distribution. 0 = XSET, 1 = Triangle, 2 = Adaptive, 3 = PET
	private final int number_of_bins;	// Size of the Histogram to create 
	private final int hist_precision;	// Precision of the Histogram = 1/bin_size
	private final int MC_iterations;	// Number of iterations to be used for MC FDR.
	private FileOut MC_FDR_output;
	private FileOut LW_FDR_output;
	
	private String[] aligned_files = null;						// List of Aligned Files
	private String[] control_files = null;						// List of Aligned Files
	private String[] compare_files = null;						// List of Aligned Files
	private String PET_flags = null;
	private int min_ht = 0;

	/** Only used for Triangle Distribution */
	private final int triangle_median;
	private final int triangle_low;
	private final int triangle_high;

	private final float subpeaks_parm;
	private final float trimpeaks_parm;
	private final float min_coverage;							//the lowest coverage value to allow.
	
	private final float regression_trim;							//turns on trimming of linear regression peaks.
	
	private float eff_frac = 0;

	private final boolean one_file_per;							// whether to group all output into a single file or separate files.
	private final boolean bedgraph;								//use the bedgraph format instead of wig file
	private final boolean filterDupes;
	private final boolean subpeaks;								// turns on subpeak mode
	private final boolean trim;									// turns on trim mode
	private final boolean peaks_header;							// turn peak header on or off.
	
	private final boolean rmode;								// used to enable R mode for generating images.
	private final boolean control;
	private final boolean compare;
	private final boolean filter_compare;
	private final boolean saturation;
	private final boolean log_transform;
	
	private final int control_type;								// method of control: 0 = linear regression, 1 = iterative
	private final int max_ext_len;								// hold until it can be put into dist.
	private final int min_store_ht;								// minimum height to store maps for.
	private final int max_PET_size;								// maximum length PET fragment may be accepted.
	private final int window_size;								// window size for basic compare mode.
	private final int goldenpath;
	private final int wig_step_size;
	
	private final float landerWaterman;						// Tell if the Lander-Waterman simulation should be run
	private final float alpha;									// parameter for confidence interval in compare mode
	private final float auto_thresh;							// parameter for confidence in control mode
	
	public final String type;									// string that indicates the type of run		
	public final String run;
	public final String file_start;

	private final int qualityfilter;
	private static final int MAQ_0_7_1_FORMAT_DEFAULT = 128;
	private final int maq_file_format;
	
	public final String prepend;
	
	public final boolean silence_warning;


	private static void test_for_manditory_fields(HashMap<String, String> Variables) {
		boolean pass = true;


		if (! Variables.containsKey(OUTPUT_PARAM)) {
			LB.error("Output location for generated files must be provided with the -"+OUTPUT_PARAM+" flag" );
			pass = false;
		}
		
		if (! Variables.containsKey(DIST_TYPE_PARAM)) {
			LB.error("Distribution type must be specified with the -"+DIST_TYPE_PARAM+" flag" );
			pass = false;
		}

		if (! Variables.containsKey(INPUT_PARAM)) {
			LB.error("Input file(s) must be provided with the -"+INPUT_PARAM+" flag" );
			pass = false;
		}		

		if (! Variables.containsKey(ALIGNER_PARAM)) {
			LB.error("Aligner type must be provided with the -"+ALIGNER_PARAM+" flag" );
			pass = false;
		}
		
		if (!pass) {
			CommandLine.help_message(LB);
		}
	}
	
	
	private static void check_extra_parameters(HashMap<String, String> Variables) {
		StringBuffer sb = new StringBuffer();
		Iterator<String> keys = Variables.keySet().iterator();
		for (String k : new IterableIterator<String>(keys)) {
			if (k.equalsIgnoreCase(NAME_PARAM) ||
				k.equalsIgnoreCase(HELP_PARAM) ||
				k.equalsIgnoreCase(FILTER_DUPS_PARAM) ||
				k.equalsIgnoreCase(DIST_TYPE_PARAM) ||
				k.equalsIgnoreCase(INPUT_PARAM) ||
				k.equalsIgnoreCase(CONTROL_PARAM) ||
				k.equalsIgnoreCase(CONTROL_TYPE_PARAM) ||
				k.equalsIgnoreCase(SUBPEAKS_PARAM) ||
				k.equalsIgnoreCase(TRIM_PARAM) ||
				k.equalsIgnoreCase(OUTPUT_PARAM) ||
				k.equalsIgnoreCase(EFF_FRAC_PARAM) ||
				k.equalsIgnoreCase(MIN_PEAK_PARAM) ||
				k.equalsIgnoreCase(ALIGNER_PARAM) ||
				k.equalsIgnoreCase(MC_ITER_PARAM) ||
				k.equalsIgnoreCase(ONE_PER_PARAM) ||
				k.equalsIgnoreCase(NO_PEAKS_HEADER_PARAM) ||
				k.equalsIgnoreCase(HIST_SIZE_PARAM) ||
				k.equalsIgnoreCase(HIST_PREC_PARAM) ||
				k.equalsIgnoreCase(PREPEND_PARAM) ||
				k.equalsIgnoreCase(FILTER_QUAL_PARAM) ||
				k.equalsIgnoreCase(MAQ_FILE_FORMAT_PARAM) ||
				k.equalsIgnoreCase(RMODE_PARAM) ||
				k.equalsIgnoreCase(PET_FLAGS_PARAM) ||
				k.equalsIgnoreCase(MAX_PET_SIZE_PARAM) ||
				k.equalsIgnoreCase(MIN_PK_PROCESS_PARAM) ||
				k.equalsIgnoreCase(MIN_COVERAGE_PARAM) ||
				k.equalsIgnoreCase(GOLDENPATH_PARAM) ||
				k.equalsIgnoreCase(AUTOTHRESH_PARAM) ||
				k.equalsIgnoreCase(COMPARE_PARAM) ||
				k.equalsIgnoreCase(WINDOW_SIZE_PARAM) ||
				k.equalsIgnoreCase(LOG_TRANSF_PARAM) ||
				k.equalsIgnoreCase(REG_TRIM_PARAM) ||
				k.equalsIgnoreCase(ALPHA_PARAM) ||
				k.equalsIgnoreCase(BEDGRAPH_PARAM) ||
				k.equalsIgnoreCase(COMPARE_FILTER_PARAM) ||
				k.equalsIgnoreCase(SATURATION_PARM) ||
				k.equalsIgnoreCase(LANDERWATERMAN_PARAM) ||
				k.equalsIgnoreCase(WIG_STEP_SIZE_PARAM) ||
				k.equalsIgnoreCase(SILENCE_WARNING_PARM)){
			}	else {											//unrecognised parameters
				sb.append(k + " ");
			}
			if (sb.length() > 0) {
				LB.error("Could not process the flags: " + sb);
				LB.die();
			}
		}	
	}



	/**
	 * checks which flag is currently being evaluated.  Tests information for format, but not for validity.
	 * @param Variables
	 * @param logbuffer
	 */
	public Parameters(Log_Buffer logbuffer, HashMap<String, String> Variables) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Parameters", "$Revision: 1838 $");
			display_version = false;
		}
		if (Variables == null) { 
			CommandLine.help_message(LB);						// break conditions
		}						 
		assert ( Variables != null);
		if (Variables.containsKey(HELP_PARAM)) { 				//shouldn't be necessary - 
			CommandLine.help_message(LB); 
		}
				
		boolean pass = true;		
		
		test_for_manditory_fields(Variables);					//Checks
		check_extra_parameters(Variables);
		

		/* Do bootstrap calls here */
		if (Variables.containsKey(NAME_PARAM)) {		
			CommandLine.test_parameter_count(LB, NAME_PARAM, Variables.get(NAME_PARAM), 1);
			this.name = Variables.get(NAME_PARAM);
		} else {
			this.name = "FP4output";
		}
		
		if (Variables.containsKey(OUTPUT_PARAM)) {					// output
			CommandLine.test_parameter_count(LB, OUTPUT_PARAM, Variables.get(OUTPUT_PARAM), 1);
			String tmp = Variables.get(OUTPUT_PARAM);
			
			if (!tmp.endsWith(System.getProperty("file.separator"))) {
				tmp = tmp.concat(System.getProperty("file.separator")).trim();
			}
			this.output = tmp;
			LB.notice("Log File: " + this.output + this.name  + ".log");
			LB.addLogFile(this.output + this.name  + ".log");
		} else {
			this.output = "Parameter Missing.";
		}
		

		if ( ! CommandLine.test_parameter_count(LB, OUTPUT_PARAM, Variables.get(OUTPUT_PARAM), 1)		//tests  
			|| ! CommandLine.test_parameter_count_min(LB, DIST_TYPE_PARAM, Variables.get(DIST_TYPE_PARAM), 1)
			|| ! CommandLine.test_parameter_count(LB, ALIGNER_PARAM, Variables.get(ALIGNER_PARAM), 1)) {
			pass = false;
		}
		
		
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output directory     : " + this.output);		
		LB.notice(" * Naming files as      : " + this.name);
		
		
		/* process remaining parameters */
		if (Variables.containsKey(MC_ITER_PARAM)) {			//MC sim parameter
			this.MC_iterations = Integer.valueOf(Variables.get(MC_ITER_PARAM));
			LB.notice(" * MC Iterations        : " + this.MC_iterations);
		} else {
			LB.notice(" * MC simulation        : Off" );
			this.MC_iterations = 0;
		}
		
		if (Variables.containsKey(PREPEND_PARAM)) { 			//string for naming chromsomes
			CommandLine.test_parameter_count(LB, PREPEND_PARAM, Variables.get(PREPEND_PARAM), 1);
			this.prepend = Variables.get(PREPEND_PARAM);
			LB.notice(" * Chr name prepend     : " + this.prepend);

		} else {
			this.prepend = "";
			LB.notice(" * Chr name prepend     : none");
		}
		
		if (Variables.containsKey(MIN_PEAK_PARAM)) {
			CommandLine.test_parameter_count(LB, MIN_PEAK_PARAM, Variables.get(MIN_PEAK_PARAM), 1);
			this.min_ht = Integer.valueOf(Variables.get(MIN_PEAK_PARAM));
		} else {
			this.min_ht = 0;
		}
		LB.notice(" * Min. reported pk ht  : " + this.min_ht);
		
		if (Variables.containsKey(MIN_COVERAGE_PARAM)) {
			CommandLine.test_parameter_count(LB, MIN_COVERAGE_PARAM, Variables.get(MIN_COVERAGE_PARAM), 1);
			this.min_coverage = Float.valueOf(Variables.get(MIN_COVERAGE_PARAM));
		} else {
			this.min_coverage = 0.001f;
		}
		LB.notice(" * Min. cov. allowed    : " + this.min_coverage);
		
		
		if (Variables.containsKey(MIN_PK_PROCESS_PARAM)) {			//MC sim parameter
			this.min_store_ht = Integer.valueOf(Variables.get(MIN_PK_PROCESS_PARAM));
			if (this.min_store_ht > this.min_ht) {
				LB.error("-" + MIN_PK_PROCESS_PARAM + " parameter can not be used with a value" +
						" smaller than that used with the -" + MIN_PEAK_PARAM + " flag.");
				LB.die();
			}
			LB.notice(" * Minimum ht to process: " + this.min_store_ht);
		} else {
			LB.notice(" * Minimum ht to process: Off" );
			this.min_store_ht = 0;
		}
		

		if (Variables.containsKey(LANDERWATERMAN_PARAM)) {		//LW sim parameter
			CommandLine.test_parameter_count(LB, LANDERWATERMAN_PARAM, Variables.get(LANDERWATERMAN_PARAM), 1);
			this.landerWaterman = Float.valueOf(Variables.get(LANDERWATERMAN_PARAM));
			if (this.landerWaterman <= 0  || this.landerWaterman >= 1 ) {
				LB.error(LANDERWATERMAN_PARAM + " may not be set <= zero or >= 1");
				LB.die();
			}
			LB.notice(" * Lander-Waterman FDR  : On (" + this.landerWaterman + ")" );
		} else {
			LB.notice(" * Lander-Waterman FDR  : Off" );
			this.landerWaterman = 0;
		}

		if (Variables.containsKey(GOLDENPATH_PARAM)) {	
			CommandLine.test_parameter_count(LB, GOLDENPATH_PARAM, Variables.get(GOLDENPATH_PARAM), 1);
			this.goldenpath = Integer.valueOf(Variables.get(GOLDENPATH_PARAM));
		} else {
			this.goldenpath = 0;
		}
		LB.notice(" * Output Sequence      : " + 
				((this.goldenpath > 0) ? 
						("On - (" + this.goldenpath + ") total len: " + (this.goldenpath *2) + 1 ) 
						: "Off") );
		


		//eff_fraction is mandatory only if the MC simulation is on
		if (MC_iterations > 0 ) {
			if ((!Variables.containsKey(EFF_FRAC_PARAM)) ||
					! CommandLine.test_parameter_count_min(LB, EFF_FRAC_PARAM, Variables.get(EFF_FRAC_PARAM), 1)) {
				LB.error("Effective fraction must be provided with the -" + EFF_FRAC_PARAM + " flag" );
				LB.die();
			} else {
				this.eff_frac = Float.valueOf(Variables.get(EFF_FRAC_PARAM));
				LB.notice(" * Eff. fraction        : " + this.eff_frac); 
			}
		}

		aligned_files = Variables.get(INPUT_PARAM).split(",");
		if (aligned_files.length == 0) {
			LB.error("-input flag must be followed by a list of files to process");
			LB.die();
		}
		
		if (Variables.containsKey(CONTROL_PARAM)) {
			control_files = Variables.get(CONTROL_PARAM).split(",");
			control = true;
			if (control_files.length == 0) {
				LB.error("-control flag must be followed by a list of files to process");
				LB.die();
			}
			LB.notice(" * Control files in use : On"); 
		} else {
			control = false;
			control_files = null;
			LB.notice(" * Control files in use : Off");
		}
		
		if (control_files != null && control_files.length != aligned_files.length) {
			LB.error("Must be the same number of control files as input files.");
			LB.die();
		}
		

		if (Variables.containsKey(COMPARE_PARAM)) {
			compare_files = Variables.get(COMPARE_PARAM).split(",");
			compare = true;
			if (compare_files.length == 0) {
				LB.error("-compare flag must be followed by a list of files to process");
				LB.die();
			}
			LB.notice(" * Compare files in use : On"); 
		} else {
			compare = false;
			compare_files = null;
			LB.notice(" * Compare files in use : Off");
		}
		
		if (compare_files != null && compare_files.length != aligned_files.length) {
			LB.error("Must be the same number of compare files as input files.");
			LB.die();
		}
		
		if (Variables.containsKey(LOG_TRANSF_PARAM)) { 
			if (!control && !compare)   {
				LB.error("The -" + LOG_TRANSF_PARAM + " parameter may only be used when controls or compares are engaged.");
				LB.die();
			} 
			this.log_transform = true;
			LB.notice(" * Peak ht transform    : " + this.log_transform);
		} else {
			this.log_transform = false;
			if (this.compare || this.control) {
				LB.notice(" * Peak ht transform    : " + this.log_transform);
			}
		}
		
		//TODO: fix.for regression.
		if (Variables.containsKey(REG_TRIM_PARAM)) { 
			if (!control && !compare)   {
				LB.error("The -" + REG_TRIM_PARAM + " parameter may only be used when controls or compares are engaged.");
				LB.die();
			}
			CommandLine.test_parameter_count(LB, REG_TRIM_PARAM, Variables.get(REG_TRIM_PARAM), 1);
			this.regression_trim = Float.valueOf(Variables.get(REG_TRIM_PARAM));
			LB.notice(" * Regression trim      : " + this.regression_trim);
		} else {
			this.regression_trim = 0.0f;
			if (this.compare || this.control) {
				LB.notice(" * Regression trim      : Off");
			}
		}		
		
		if (Variables.containsKey(WINDOW_SIZE_PARAM)) {			//MC sim parameter
			if (!this.compare && !this.control) {
				LB.error("-" + WINDOW_SIZE_PARAM + " parameter may not be used without " +
						"invoking the -" + COMPARE_PARAM + " or " + CONTROL_PARAM + " iflag.  " +
						"please provide a second sample to use this option.");
				LB.die();
			}
			CommandLine.test_parameter_count(LB, WINDOW_SIZE_PARAM, Variables.get(WINDOW_SIZE_PARAM), 1);
			this.window_size = Integer.valueOf(Variables.get(WINDOW_SIZE_PARAM));
			if (this.window_size <= FPConstants.MINIMUM_WINDOW_SIZE) {
				LB.notice("-" + WINDOW_SIZE_PARAM + " may not be less than 10.  Please provide a larger value" );
				LB.die();
			}
		} else {
			this.window_size = FPConstants.DEFAULT_WINDOW_SIZE;
		}
		if (this.compare) {
			LB.notice(" * Compare window size  : " + this.window_size);
		}
		
		
		if (Variables.containsKey(COMPARE_FILTER_PARAM)) {
			if (!this.compare) {
				LB.error("-" + COMPARE_FILTER_PARAM + " parameter may not be used without " +
						"invoking the -" + COMPARE_PARAM + " flag.  please provide a second sample to use this option.");
				LB.die();
			}
			CommandLine.test_parameter_count(LB, COMPARE_FILTER_PARAM, Variables.get(COMPARE_FILTER_PARAM), 0);
			this.filter_compare = false;
			LB.notice(" * Filtering on compare : Off");
		} else {
			this.filter_compare = true;
		}
		
		
		if (Variables.containsKey(AUTOTHRESH_PARAM)) {		//LW sim parameter
			CommandLine.test_parameter_count(LB, AUTOTHRESH_PARAM, Variables.get(AUTOTHRESH_PARAM), 1);
			if (!this.control && !this.saturation && this.MC_iterations == 0 && this.landerWaterman <= 0) {
				LB.error("-" + AUTOTHRESH_PARAM + " parameter may not be used without " +
						"a null control or in a saturation run with -iterations.  please provide a control to use this option.");
				LB.die();
			}
			this.auto_thresh = Float.valueOf(Variables.get(AUTOTHRESH_PARAM));
		} else {
			this.auto_thresh = -1;
		}
		LB.notice(" * Auto-threshold       : " + ((this.auto_thresh >= 0) ? "On" : "Off") );
		
		if (Variables.containsKey(PET_FLAGS_PARAM)) {
			PET_flags = Variables.get(PET_FLAGS_PARAM);
			LB.notice(" * Filter on PET flags  : " + this.PET_flags);
		} else {
			PET_flags = null;
			LB.notice(" * Filter on PET flags  : Off");
		}
		
		if (Variables.containsKey(MAX_PET_SIZE_PARAM)) {
			max_PET_size = Integer.valueOf(Variables.get(MAX_PET_SIZE_PARAM));
			LB.notice(" * Maximum PET frag size: " + this.max_PET_size);
		} else {
			max_PET_size = 0;
			LB.notice(" * Maximum PET frag size: Off");
		}
			
		if (aligned_files.length == 0) {
			LB.error("-input flag must be followed by a list of files to process");
			LB.die();
		}
		
		this.Aligner = Variables.get(ALIGNER_PARAM);
		if (!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_ELAND) &&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_BED) &&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_VULGAR) &&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_ELANDII) &&
			!this.Aligner.equalsIgnoreCase("maqpet") &&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAQ) &&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_GFF) &&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAPVIEW)&&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM) &&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM_SPLIT)&&
			!this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM_FILTER) ) {
			LB.error("Aligner format \"" + this.Aligner + "\" is unknown.");
			LB.die();
		} else {
			LB.notice(" * Aligner              : " + this.Aligner);
		}
		
		if (Variables.containsKey(SILENCE_WARNING_PARM)) {
			silence_warning = true;
			LB.notice(" * Silence all warning from sam/bam iterator: " + this.silence_warning);
		}else{
			silence_warning = false;
		}

		String[] s = Variables.get(DIST_TYPE_PARAM).split(",");
		this.dist_type = Short.valueOf(s[0]); 
		switch (this.dist_type) {
		case 0:	
			if (s.length < 2) {
				pass = false;
				LB.error("dist_type 0 requires at least on more parameter");
				this.max_ext_len = 0;
			} else {
				this.max_ext_len = (Integer.parseInt(s[1]));
			}
			LB.notice(" * Fixed width dist.    : " + this.max_ext_len + " xset");
			if (s.length > 2) {
				LB.error("Unexpected number of parameters for distribution " + this.dist_type + ": " 
						+ Variables.get(DIST_TYPE_PARAM));
			}
			this.triangle_median = 0;
			this.triangle_low = 0;
			this.triangle_high = 0;
			if (this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM)){
				//force the filtering of any split read if extention is used
				this.Aligner=Constants.FILE_TYPE_SAM_FILTER;
			}
			break;
		case 1:	
			if (s.length > 4) {
				LB.error("Unexpected number of parameters for distribution " + this.dist_type + ": " 
						+ Variables.get(DIST_TYPE_PARAM));
			}
			if (s.length > 3) {
				this.triangle_low = Integer.parseInt(s[3]);
			} else {
				this.triangle_low = FPConstants.TRIANGLE_LOW;
				//LB.notice("Use of triangle default low: "+FPConstants.TRIANGLE_LOW);
			}
			if (s.length > 2) {
				this.triangle_high = Integer.parseInt(s[2]);
			} else {
				this.triangle_high = FPConstants.TRIANGLE_HIGH;
				//LB.notice("Use of triangle default high: "+FPConstants.TRIANGLE_HIGH);
			}
			if (s.length > 1) {
				if (this.triangle_median >= this.triangle_high) {	
					this.triangle_median = this.triangle_high-1;
				} else {
					this.triangle_median = Integer.parseInt(s[1]);
				}
			} else {
				this.triangle_median = FPConstants.TRIANGLE_DEFAULT_MEDIAN;
				//LB.notice("Use of triangle default median: "+FPConstants.TRIANGLE_DEFAULT_MEDIAN);
			}
			if (this.triangle_high > FPConstants.XSET_MODE_1_MAX) {
				this.max_ext_len = this.triangle_high;
			} else {		
				this.max_ext_len = FPConstants.XSET_MODE_1_MAX;
			}
			/* Basic sanity checking required -- aparently this is needed.*/
			if (this.triangle_high < this.triangle_low) {
				LB.error("Triagle high value is less than the triangle low value.  " +
						"Please check values provided for dist_type 1.");
				LB.die();
			}
			if (this.triangle_median > this.triangle_high) {
				LB.error("Triangle median value is greater than the triangle high value.  " +
						"Please check value provided for dist_type 1.");
				LB.die();
			}
			if (this.triangle_median < this.triangle_low) {
				LB.error("Triangle median value is less than the triangle low value.  " +
						"Please check value provided for dist_type 1.");
				LB.die();
			}
			
			LB.notice(" * Triangle dist.       : " + this.triangle_low + " low");
			LB.notice(" * Triangle dist.       : " + this.triangle_median + " median");
			LB.notice(" * Triangle dist.       : " + this.triangle_high + " high");
			if (this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM)){
				//force the filtering of any split read if extention is used
				this.Aligner=Constants.FILE_TYPE_SAM_FILTER;
			}
			break;
		case 2:	
			LB.error("Mode 2 is no longer being supported supported.");
			LB.error("Please use modes 0 (fixed size), 1 (weighted reads) or 3 (PET/Native). ");
			LB.die();
			
			this.max_ext_len = FPConstants.XSET_MODE_2;
			this.triangle_median =0;
			this.triangle_low=0;
			this.triangle_high=0;
			if (this.Aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM)){
				//force the filtering of any split read if extention is used
				this.Aligner=Constants.FILE_TYPE_SAM_FILTER;
			}
			break;
		case 3:
			LB.notice(" * PET/native mode   : On");
			this.triangle_median = 0;
			this.triangle_low = 0;
			this.triangle_high = 0;
			this.max_ext_len = 0;
			if (this.max_PET_size == 0) {
				LB.notice(" Note: PET mode engaged, but no max_PET_size value in use. " +
						"This is likely to cause large memory overruns if excessively long fragments are found." +
						" It is suggested that this run be terminated and resumed with a upper " +
						"limit cut-off for your PET data.");
			}
			break;
		default:
			LB.notice("Distribution option unrecognized");
			pass = false;
			this.triangle_median =0;
			this.triangle_low=0;
			this.triangle_high=0;
			this.max_ext_len = 0;
			break;
		}

		/*Optional Variables;*/	

		if (Variables.containsKey(MAQ_FILE_FORMAT_PARAM)) {
			if (this.Aligner.equals("maq")) {
				CommandLine.test_parameter_count(LB, MAQ_FILE_FORMAT_PARAM, Variables.get(MAQ_FILE_FORMAT_PARAM), 1);
				LB.notice(" * MAQ file format/bits : " + Variables.get(MAQ_FILE_FORMAT_PARAM));
				maq_file_format = Integer.valueOf(Variables.get(MAQ_FILE_FORMAT_PARAM));
			} else {
				LB.notice("Maq parameter -" + MAQ_FILE_FORMAT_PARAM + " can not be used unless -"
						+ ALIGNER_PARAM + " is set to \"maq\"" );
				maq_file_format = MAQ_0_7_1_FORMAT_DEFAULT;
				CommandLine.help_message(LB);
			}
		} else {
			maq_file_format = MAQ_0_7_1_FORMAT_DEFAULT;
			if (this.Aligner.equals("maq")) {
				LB.notice(" * Maq file format      : " + this.maq_file_format
						+ "bit reads (default value.  use -" + MAQ_FILE_FORMAT_PARAM
						+ " to override)");
			} 

		}
		
		if (Variables.containsKey(ONE_PER_PARAM)) {
			CommandLine.test_parameter_count(LB, ONE_PER_PARAM, Variables.get(ONE_PER_PARAM), 0);
			one_file_per = true;
			LB.notice(" * One file per chr.    : On");
		} else {
			one_file_per = false;
			LB.notice(" * One file per chr.    : Off");
		}


		if (Variables.containsKey(SUBPEAKS_PARAM)) {
			if (CommandLine.test_parameter_count(LB, SUBPEAKS_PARAM, Variables.get(SUBPEAKS_PARAM), 1) ) {
				this.subpeaks = true;
				this.subpeaks_parm = Float.valueOf(Variables.get(SUBPEAKS_PARAM));
				LB.notice(" * Sub-peaks            : " + this.subpeaks_parm);
			} else { 
				this.subpeaks = false;
				this.subpeaks_parm = 0;
				CommandLine.help_message(LB);
			}
		} else { 
			this.subpeaks = false;
			this.subpeaks_parm = 0;
			LB.notice(" * Sub-peaks            : Off");
		}

		if (Variables.containsKey(TRIM_PARAM)) {
			if (CommandLine.test_parameter_count(LB, TRIM_PARAM, Variables.get(TRIM_PARAM), 1) ) {
				this.trim = true;
				this.trimpeaks_parm = Float.valueOf(Variables.get(TRIM_PARAM));
				/* Basic sanity check - apparently this is needed.*/
				if (this.trimpeaks_parm > 1 || this.trimpeaks_parm < 0) {
					LB.error("The -trim parameter is a float value between 0 and 1.  " +
							"Please check that the value you have provided fits in this range.");
					LB.die();
				}
				LB.notice(" * Trim-peaks           : " + this.trimpeaks_parm);
			} else { 
				this.trim = false;
				this.trimpeaks_parm = 0;
				CommandLine.help_message(LB);
			}
		} else { 
			this.trim = false;
			this.trimpeaks_parm = 0;
			LB.notice(" * Trim                 : Off");
		}

		if (Variables.containsKey(SATURATION_PARM)) {
			CommandLine.test_parameter_count(LB, SATURATION_PARM, Variables.get(SATURATION_PARM), 0);
			this.saturation = true;
			if (!this.control && this.MC_iterations == 0 && this.landerWaterman <= 0) {
				LB.error(SATURATION_PARM + " flag can only be used if an autothresholded control is in use.  Please use either "
						+ MC_ITER_PARAM + ", -" + LANDERWATERMAN_PARAM + " or " + COMPARE_PARAM + " parameters with this mode.");
				pass = false;
			}			
			LB.notice(" * Saturation Analysis  : On");
		} else {
			saturation = false;
			LB.notice(" * Saturation Analysis  : Off");
		}
		
		if (Variables.containsKey(ALPHA_PARAM)) {	// parameter for confidence interval
			if (!(this.compare || this.control)) {
				LB.error("-" + ALPHA_PARAM + " parameter may not be used without " +
				"invoking the -" + COMPARE_PARAM + " flag, or both the -" + SATURATION_PARM + " and -" + CONTROL_PARAM +  
				".  please provide a second sample to use this option.");
				LB.die();
			}
			CommandLine.test_parameter_count(LB, ALPHA_PARAM, Variables.get(ALPHA_PARAM), 1);
			this.alpha = Float.valueOf(Variables.get(ALPHA_PARAM));
		} else {
			this.alpha = 0.05f;
		}
		if (this.compare || this.control) {
			if (this.alpha > 0 && this.alpha < 1) {
				LB.notice(" * Compare alpha value  : " + Utilities.DecimalPoints(this.alpha, 3) 
						+ "\t(Confidence Interval: " + Utilities.DecimalPoints(((1-this.alpha)*FPConstants.PERCENTAGE),3) +")" );	
			} else {
				LB.die();
			}
				
		}
		
		if (Variables.containsKey(CONTROL_TYPE_PARAM)) {
			CommandLine.test_parameter_count(LB, CONTROL_TYPE_PARAM, Variables.get(CONTROL_TYPE_PARAM), 1);
			this.control_type = Integer.valueOf(Variables.get(CONTROL_TYPE_PARAM));
			LB.notice(" * Control type         : " + this.control_type);
		} else {
			this.control_type = 0;
			if (this.control) {
				LB.notice(" * Control type         : " + this.control_type);
			}
		}
		
		if (Variables.containsKey(WIG_STEP_SIZE_PARAM)) {
			CommandLine.test_parameter_count(LB, WIG_STEP_SIZE_PARAM, Variables.get(WIG_STEP_SIZE_PARAM), 1);
			this.wig_step_size = Integer.valueOf(Variables.get(WIG_STEP_SIZE_PARAM));
			if (this.wig_step_size < 1) {
				LB.error("Wig step size must be an integer value greater than one.");
				LB.die();
			}
		} else {
			this.wig_step_size = 1;
		}
		LB.notice(" * Wig step size        : " + this.wig_step_size);
		
		if (Variables.containsKey(HIST_SIZE_PARAM)) {
			CommandLine.test_parameter_count(LB, HIST_SIZE_PARAM, Variables.get(HIST_SIZE_PARAM), 1);
			this.number_of_bins = (Integer.valueOf(Variables.get(HIST_SIZE_PARAM))+1);
		} else { 
			this.number_of_bins = 31;
		}
		if (Variables.containsKey(HIST_PREC_PARAM)) {
			CommandLine.test_parameter_count(LB, HIST_PREC_PARAM, Variables.get(HIST_PREC_PARAM), 1);
			int precision = (Integer.valueOf(Variables.get(HIST_PREC_PARAM)));
			if (precision!=1 && precision!=2 && precision!=10 && precision!=100){
				LB.error("Histogram precision " + precision + " is invalid. must be one of 1, 2, 10, 100");
				this.hist_precision=1;
			} else {
				this.hist_precision=precision;
			}
		} else { 
			this.hist_precision = 1;
		}
		LB.notice(" * Histogram length     : " + (this.number_of_bins -1));
		LB.notice(" * Histogram precision  : " + (this.hist_precision));

		
		
		if (Variables.containsKey(NO_PEAKS_HEADER_PARAM)) {
			CommandLine.test_parameter_count(LB, NO_PEAKS_HEADER_PARAM, Variables.get(NO_PEAKS_HEADER_PARAM), 0);
			peaks_header = false;
			LB.notice(" * Peaks File Header    : Off");
		} else {
			peaks_header = true;
			LB.notice(" * Peaks File Header    : On");
		}
		
		if (Variables.containsKey(BEDGRAPH_PARAM)) {
			CommandLine.test_parameter_count(LB, BEDGRAPH_PARAM, Variables.get(BEDGRAPH_PARAM), 0);
			bedgraph = true;
			LB.notice(" * Bedgraph/Wigfile     : bedgraph file");
		} else {
			bedgraph = false;
			LB.notice(" * Bedgraph/Wigfile     : wig file");
		}
		
		if (Variables.containsKey(RMODE_PARAM)) {
			CommandLine.test_parameter_count(LB, RMODE_PARAM, Variables.get(RMODE_PARAM), 0);
			rmode = true;
			LB.notice(" * R mode               : On");
		} else {
			rmode = false;
			LB.notice(" * R mode               : Off");
		}

		if (Variables.containsKey(FILTER_DUPS_PARAM)) {
			CommandLine.test_parameter_count(LB, FILTER_DUPS_PARAM, Variables.get(FILTER_DUPS_PARAM), 0);
			this.filterDupes = true;
			LB.notice(" * Filter Duplicates    : On");
		} else {
			this.filterDupes = false;
			LB.notice(" * Filter Duplicates    : Off");
		}
		if (Variables.containsKey(FILTER_QUAL_PARAM)) {
			CommandLine.test_parameter_count(LB, FILTER_QUAL_PARAM, Variables.get(FILTER_QUAL_PARAM), 1);
			this.qualityfilter = Integer.parseInt(Variables.get(FILTER_QUAL_PARAM));
			LB.notice(" * Filter quality min.  : On ("+this.qualityfilter + ")");
		} else {
			this.qualityfilter = 0;
			LB.notice(" * Filter quality       : Off");
		}
		//File naming convention
		if (this.subpeaks) {
			this.type = "subpeaks";
		} else {
			this.type = "standard";
		}

		if (dist_type == 0) {
			run = "fixed_" + Integer.toString(this.max_ext_len);
		} else if (dist_type == 1) {
			run = "triangle";
		} else if (dist_type == 3) {
			run = "mode_3";
		} else {
			run = "unknown";
		}
		file_start = output + name + "_" + run + "_" +  type ;

		LB.notice(" * Input Files          : ");
		for (String file : aligned_files) {
			LB.notice("      " + file);
		}
		
		if (!pass) {
			CommandLine.help_message(LB);
		}
	}

	/** 
	 * This getter should only ever be used by Parameters() init.  DO NOT USE OTHERWISE!
	 * @return
	 */
	public int get_max_len()			{ return this.max_ext_len; }
	//public void set_max_len(int x)		{ this.max_len = x; }
	
	public float get_eff_frac() 		{ return this.eff_frac; }
	public void set_eff_frac(float x) 	{ this.eff_frac = x; }
	
	public int get_min_ht() 			{ return this.min_ht; }
	public void set_min_ht(int x)		{ this.min_ht = x; }

	/* just getters*/
	public List<String> get_sample_files()	{ return Arrays.asList(this.aligned_files); } 
	public List<String> get_control_files()	{ return Arrays.asList(this.control_files); } 
	public List<String> get_compare_files()	{ return Arrays.asList(this.compare_files); }
	
	public final String get_aligner()			{ return this.Aligner; }
	public final String get_name()				{ return this.name; }
	public final String get_output()			{ return this.output; }
	
	public final int get_dist_type() 			{ return this.dist_type; }
	public final int get_control_type()			{ return this.control_type; }
	public final int get_hist_precision() 		{ return this.hist_precision; }
	public final int get_number_of_bins() 		{ return this.number_of_bins; }
	public final int get_triangle_median() 		{ return this.triangle_median; }
	public final int get_triangle_low() 		{ return this.triangle_low; }
	public final int get_triangle_high() 		{ return this.triangle_high; }
	public final int get_qualityfilter() 		{ return this.qualityfilter; }
	public final int get_MC_iterations() 		{ return this.MC_iterations; }
	public final int get_maq_file_format()	 	{ return this.maq_file_format; }
	public final int get_min_store_ht()			{ return this.min_store_ht; }
	public final int get_max_PET_size()			{ return this.max_PET_size; }
	public final int get_window_size()			{ return this.window_size; }
	public final int get_goldenpath()			{ return this.goldenpath; }
	public final int get_wig_step_size()		{ return this.wig_step_size; }
	
	public final float get_alpha()				{ return this.alpha; }
	public final float get_subpeaks_parm() 		{ return this.subpeaks_parm; }
	public final float get_trimpeaks_parm()		{ return this.trimpeaks_parm; }
	public final float get_autothresh()			{ return this.auto_thresh; }
	public final float get_landerWaterman() 	{ return this.landerWaterman; }
	public final float get_regression_trim() 	{ return this.regression_trim; }
	public final float get_min_coverage() 		{ return this.min_coverage; }
	
	public final boolean get_one_file_per() 	{ return this.one_file_per; }
	public final boolean get_bedgraph()			{ return this.bedgraph; }
	public final boolean get_filterDupes() 		{ return this.filterDupes; }
	public final boolean get_subpeaks()  		{ return this.subpeaks; }
	public final boolean get_trim()  			{ return this.trim; }
	public final boolean get_peaks_header() 	{ return this.peaks_header; }
	public final boolean get_rmode()			{ return this.rmode; }
	public final boolean get_control()			{ return this.control; }
	public final boolean get_compare()			{ return this.compare; }
	public final boolean get_filterCompare()	{ return this.filter_compare; }
	public final boolean get_saturation()		{ return this.saturation; }
	public final boolean get_log_transform()	{ return this.log_transform; }
	
	public final String get_PET_flags_raw()		{ return this.PET_flags; }
	
	public final boolean get_silence_warning()    { return this.silence_warning; }
	
	public FileOut get_MCFileOut() {
		if (MC_FDR_output==null)
		{
			MC_FDR_output=new FileOut(LB,get_output()+get_name()+"_MC.FDR", false);
		}
		return this.MC_FDR_output; 
	}
	
	public FileOut get_LWFileOut(){
		if (LW_FDR_output==null)
		{
			LW_FDR_output=new FileOut(LB,get_output()+get_name()+"_LW.FDR", false);
		}
		return this.LW_FDR_output; 
	}
	
	public void close()
	{
		if (MC_FDR_output!=null) {
			MC_FDR_output.close();
		}
		if (LW_FDR_output!=null) {
			LW_FDR_output.close();
		}
	}
	
	public static final Log_Buffer get_Log_Buffer()			{ return LB; } 
	
}

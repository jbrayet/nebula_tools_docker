package src.lib.objects;


/**
 * @version $Revision: 1019 $
 * @author 
 */
public class PSNP implements Comparable<PSNP> {
	//example line
//	1       558867  ENST00000391373 Q9H2H5_HUMAN    101     Y>>>F   1       2
//	FILVLRVCYSFLFLWALVREVGGNL*Y*LIFLVG


	private final String Chromosome;
	private final int position;
	private final String transcript;
	private final String name;
	private final int aaposition;
	private final String substitution;
	private final int observed;
	private final int coverage;
	private final String sequence;

	// ESCA-JAVA0138:
	public PSNP(
			String Chromosome,
			int position,
			String transcript,
			String name,
			int aaposition,
			String substitution,
			int observed,
			int coverage,
			String sequence) {
		this.Chromosome = Chromosome;
		this.position = position;
		this.transcript = transcript;
		this.name = name;
		this.aaposition = aaposition;
		this.substitution = substitution;
		this.observed = observed;
		this.coverage = coverage;
		this.sequence = sequence;
	}

	public int compareTo (PSNP o) {
		return (this.position - o.position);
	}
	
	public String toString() {
		String X = this.Chromosome + " " + this.position + " " + this.transcript;
		X += " " + this.name + " " + this.aaposition + " " + this.substitution + " " + this.observed;
		X += " " + this.coverage + " " + this.sequence;
		return X;
	}
	
//	public final void set_Chromosome	(String c) 	{ this.Chromosome = c; }
//	public final void set_position		(int c) 	{ this.position = c; }
//	public final void set_transcript	(String c) 	{ this.transcript = c; }
//	public final void set_name			(String c) 	{ this.name = c; }
//	public final void set_aaposition	(int c) 	{ this.aaposition = c; }
//	public final void set_substitution	(String c) 	{ this.substitution = c; }
//	public final void set_observed		(int c) 	{ this.observed = c; }
//	public final void set_coverage		(int c) 	{ this.coverage = c; }
//	public final void set_sequence		(String c) 	{ this.sequence = c; }
	

	public final String		get_Chromosome() 	{ return Chromosome; }
	public final int 		get_position()	 	{ return position; }
	public final String 	get_transcript() 	{ return transcript; }
	public final String 	get_name() 			{ return name; }
	public final int 		get_aaposition() 	{ return aaposition; }
	public final String 	get_substitution() 	{ return substitution; }
	public final int	 	get_observed() 		{ return observed; }
	public final int 		get_coverage() 		{ return coverage; }
	public final String 	get_sequence() 		{ return sequence; }
	
}

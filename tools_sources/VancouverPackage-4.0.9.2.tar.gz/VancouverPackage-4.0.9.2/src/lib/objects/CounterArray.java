package src.lib.objects;

/**
 * @version $Revision: 463 $
 * @author 
 */
public class CounterArray {
	private int[] i;
	private static int sizeof;
	

	public CounterArray() {
		i =  new int[sizeof];
		for (int A = 0; A < sizeof; A++) {
			i[A] = 0;
		}
	}

	public final void add_value(int field, int value) {
		this.i[field] += value;
	}
	
	public final int get_value(int field) {
		return this.i[field];
	}
	
	public static final void set_sizeof(int x) {
		sizeof = x;
	}
	
	public String toString() {
		StringBuffer st = new StringBuffer();
		for (int x = 0; x < sizeof; x++) {
			st.append(Integer.toString(i[x]));
		}
		return st.toString();
	}
}

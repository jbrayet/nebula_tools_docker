package src.lib.Error_handling;

/**
 * @version $Revision: 320 $
 * @author 
 *
 */
public class OverflowException extends Exception {
       
	
	/**
	 * Generated serialVersion.  I have no idea how this works.
	 */
	private static final long serialVersionUID = -5639433013132170274L;
	

	public OverflowException(String message) {
		super(message);
	}
	
}

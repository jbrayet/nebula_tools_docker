package src.projects.findPeaks.FDR;

import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;

import src.lib.Graphics.GraphImage;
import src.lib.ioInterfaces.Log_Buffer;

import src.projects.findPeaks.PeakDataSetParent;
import src.projects.findPeaks.filewriters.RegionWriter;
import src.projects.findPeaks.objects.Compare;
import src.projects.findPeaks.objects.LinearRegressionPerpendicular;
import src.projects.findPeaks.objects.MinPeakDesc;
import src.projects.findPeaks.objects.PeakPairIdx;


// ESCA-JAVA0136:
public class ApplyCompare {
	
	private static Log_Buffer LB;
	private static boolean display_version = true;

	/**
	 * There should be five types of control testing.
	 * 
	 * 1. Takget_height_2e the Peak max from the sample, add a window, and compare to see if
	 * comparable peaks are in the control
	 * 
	 * 2. Take the Peak max, use the "trim" to set distances to either side, and
	 * then identify if there are any comparable peaks in the control
	 * 
	 * 3. Take the Peak max from the sample, add a window, and then compare the
	 * area in that space to the area in the control to see if the average
	 * coverage is the same.
	 * 
	 * 4. Take the area defined by the "subpeak"-ing and compare that to the
	 * average peak height in the control over the same range
	 * 
	 * 5. Take the area defined by the 'subpeak"-ing and compare that to the
	 * actual area in the control equivalent area.
	 *
	 * For method 1 and 2, we'll need to pre-process the peaks the same way we'd process the sample.
	 * 
	 * 
	 */
	
	//private FFInt[] pairs = null;
	private Compare comp;
	private final float slope;
	private final float intercept;
	
	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param logbuffer
	 * @param sample
	 * @param compare
	 * @param file
	 * @param chromosome
	 *            Name of the chromosome for which the comparison is being done.
	 * @param minimum
	 * @param window_size
	 * @param alpha
	 * @param filter_compare
	 * @param log_transform
	 *            Setting this to true will trigger the function to convert all
	 *            of the peak pairs to log-log format before calculating lines.
	 * @param regression_trim
	 *            Setting this to true will trigger the function to trim off the
	 *            top X percent of peaks from the peak heights in both
	 *            directions before calculating linear regression properties
	 */
	public ApplyCompare(Log_Buffer logbuffer, PeakDataSetParent sample,
			PeakDataSetParent compare, String file, String chromosome, int minimum,
			int window_size, float alpha, boolean filter_compare, boolean log_transform, 
			float regression_trim) {
		LB = logbuffer;

		if (display_version) {
			LB.Version("ApplyCompare", "$Revision: 1722 $");
			display_version = false;
		}
		comp = new Compare(LB);
		comp.set_pairs(MakePairs.makepairs_window(sample, compare, window_size));
		if (log_transform) {
			comp.log_transform();
		}
		LB.notice("Linear Regresion: Total:\t" + comp.size());
		PeakPairIdx[] mp = match_only(comp.get_array());
		
		if (regression_trim > 0) {
			mp = drop_top_X_percent(mp, regression_trim);
		}
		
		LB.notice("Linear Regresion: Used:\t" + mp.length);
		LinearRegressionPerpendicular mp_r = new LinearRegressionPerpendicular(LB, mp);
		this.slope = mp_r.get_slope();
		this.intercept = mp_r.get_intercept();
		export_to_graph(file + "_pre", mp);
		
		//pairs = add_back_unpaired(mp, pairs);
		mp_r.new_dataset(comp.get_array());
		//mp_r.recalculate_sigma();					//Changes the sigma and value of n.
		export_to_graph(file + "_first");
		if (filter_compare) {
			comp.set_pairs(mp_r.filter(alpha, minimum));
		}
		export_to_graph(file + "_second");
		if (log_transform) {
			comp.reverse_log();
		}
		
		LB.notice("Linear Regresion: Remaining:\t" + comp.size());
		try {
			RegionWriter rw = new RegionWriter(LB, file);
			rw.generate_region_file(sample, compare, comp.get_array(), chromosome, alpha, minimum, window_size);
			rw.close();
		} catch (IOException io) {
			LB.error("Error writing header to Region file - could not create file.");  //any other exception is handled
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());	//in the writer itself.
			LB.die();
		}
	}
	
	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param logbuffer
	 * @param st1
	 * @param st2
	 * @param minimum
	 * @param window_size
	 * @param alpha
	 * @param file
	 * @param log_transform
	 *            Setting this to true will trigger the function to convert all
	 *            of the peak pairs to log-log format before calculating lines.
	 * @param regression_trim
	 *            Setting this to true will trigger the function to trim off the
	 *            top X percent of peaks from the peak heights in both
	 *            directions before calculating linear regression properties

	 */
	public ApplyCompare(Log_Buffer logbuffer, PeakDataSetParent st1,
			PeakDataSetParent st2, String file, int minimum,
			int window_size, float alpha, boolean log_transform, 
			float regression_trim) {
		LB = logbuffer;

		if (display_version) {
			LB.Version("ApplyCompare", "$Revision: 1722 $");
			display_version = false;
		}
		comp = new Compare(LB);
		comp.set_pairs(MakePairs.makepairs_window(st1, st2, window_size));
		if (log_transform) {
			comp.log_transform();
		}
		LB.notice("Linear Regresion: Total:\t" + comp.size());
		PeakPairIdx[] mp = match_only(comp.get_array());	
		
		if (regression_trim > 0) {
			mp = drop_top_X_percent(mp, regression_trim);
		}
		
		LB.notice("Linear Regresion: Used:\t" + mp.length);
		LinearRegressionPerpendicular mp_r = new LinearRegressionPerpendicular(LB, mp);
		this.slope = mp_r.get_slope();
		this.intercept = mp_r.get_intercept();
		export_to_graph(file + "_pre", mp);
		
		//pairs = add_back_unpaired(mp, pairs);
		mp_r.new_dataset(comp.get_array());
		//mp_r.recalculate_sigma();					//Changes the sigma and value of n.
		export_to_graph(file + "_first");
		comp.set_pairs(mp_r.filter_below_only(alpha, minimum));
		LB.notice("Linear Regresion: Remaining:\t" + comp.size());
		export_to_graph(file + "_second");
		if (log_transform) {
			comp.reverse_log();
		}
	}
	
	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param logbuffer
	 * @param sample
	 * @param control
	 * @param minimum
	 * @param window_size
	 * @param alpha
	 * @param log_transform
	 *            Setting this to true will trigger the function to convert all
	 *            of the peak pairs to log-log format before calculating lines.
	 * @param regression_trim
	 *            Setting this to true will trigger the function to trim off the
	 *            top X percent of peaks from the peak heights in both
	 *            directions before calculating linear regression properties

	 */
	public ApplyCompare(Log_Buffer logbuffer, MinPeakDesc[] sample,
			PeakDataSetParent control, int minimum,	int window_size, float alpha, boolean log_transform, float regression_trim) {
		LB = logbuffer;

		if (display_version) {
			LB.Version("ApplyCompare", "$Revision: 1722 $");
			display_version = false;
		}
		comp = new Compare(LB);
		comp.set_pairs(MakePairs.makepairs_window(sample, control, window_size));
		
		if (log_transform) {
			comp.log_transform();
		}
		
		LB.notice("Linear Regresion: Total:\t" + comp.size());
		PeakPairIdx[] mp = match_only(comp.get_array());
		
		if (regression_trim > 0) {
			mp = drop_top_X_percent(mp, regression_trim);
		}
		
		LB.notice("Linear Regresion: Used:\t" + mp.length);
		LinearRegressionPerpendicular mp_r = new LinearRegressionPerpendicular(LB, mp);

		this.slope = mp_r.get_slope();
		this.intercept = mp_r.get_intercept();
		//pairs = add_back_unpaired(mp, pairs);
		mp_r.new_dataset(comp.get_array());
		//mp_r.recalculate_sigma();					//Changes the sigma and value of n.
		comp.set_pairs(mp_r.filter_below_only(alpha, minimum));	
		LB.notice("Linear Regresion: Remaining:\t" + this.comp.size());
		
		if (log_transform) {
			comp.reverse_log();
		}
	}

	
	private void export_to_graph(String file) {
		export_to_graph(file, this.comp.get_array());		
	}
	
	
	private void export_to_graph(String file, PeakPairIdx[] dataset) {
		GraphImage gi = new GraphImage(LB, "png");
		for (PeakPairIdx p : dataset) {
			float x = p.get_height_1();
			float y = p.get_height_2();
			if (x < 0) { x = 0;	}
			if (y < 0) { y = 0; }
			gi.add_point(x, y);
		}
		gi.add_line(this.slope, this.intercept);
		gi.write_to_disc(file + "_graph.png");
		gi.close();
		
	}

	private static PeakPairIdx[] match_only(PeakPairIdx[] idx) {
		Vector<PeakPairIdx> f = new Vector<PeakPairIdx>();
		for (PeakPairIdx p: idx) {
			if (p.get_pk_idx_1() != -1 && p.get_pk_idx_2() != -1) {
				f.add(p);
			}
		}
		return f.toArray(new PeakPairIdx[f.size()]);
	}
	
	
//	private static PeakPairIdx[] add_back_unpaired(PeakPairIdx[] dest, PeakPairIdx[] src) {
//		Vector<PeakPairIdx> f = new Vector<PeakPairIdx>();
//		for (PeakPairIdx p: dest) {
//			f.add(p);
//		}
//		for (PeakPairIdx p: src) {
//			if (p.get_pk_idx_1() == -1 || p.get_pk_idx_2() == -1) {
//				f.add(p);
//			}
//		}
//		return f.toArray(new PeakPairIdx[f.size()]);
//	}
	
	
	
	public float get_slope() {
		return this.slope;
	}
	
	
	
	
	private static PeakPairIdx[] drop_top_X_percent(PeakPairIdx[] mp, float x)  {
		float[] sampl_pk_hts = new float[mp.length];		
		float[] contr_pk_hts = new float[mp.length];
		int i = 0;
		for (PeakPairIdx p : mp) {
			sampl_pk_hts[i] = p.get_height_1();
			contr_pk_hts[i] = p.get_height_2();
			i++;
		}
		
		Arrays.sort(sampl_pk_hts);
		Arrays.sort(contr_pk_hts);
		
		int cutoff_bin = Math.round((float)mp.length * (1-x));
		
		float max_sample = sampl_pk_hts[cutoff_bin];
		float max_control = contr_pk_hts[cutoff_bin];
		
		Vector<PeakPairIdx> f = new Vector<PeakPairIdx>();
		for (PeakPairIdx p : mp) {
			if (p.get_height_1() <= max_sample && p.get_height_2() <= max_control) {
				f.add(p);
			}	
		}
		return f.toArray(new PeakPairIdx[f.size()]);
	}
	
	
	public Compare get_compare() {
		return this.comp;
	}
	
	
	
}





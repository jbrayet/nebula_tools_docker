package src.lib;

import src.lib.ioInterfaces.Log_Buffer;

public class CurrentVersion {

	
	private String VER = "4.0.9.2";
	
	public String get_version() {
		return VER;
	}
	
	public CurrentVersion(Log_Buffer LB) {
		LB.package_announce("Vancouver Short Read Analysis Package                " + VER); 
	}
	
	
}

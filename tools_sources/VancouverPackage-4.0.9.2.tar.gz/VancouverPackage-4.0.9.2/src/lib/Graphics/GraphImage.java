package src.lib.Graphics;

import java.util.Vector;

import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Tuple;

public class GraphImage extends BasicImage {

	
	private static final float GRAPH_PADDING = 1.05f;
	private static final int GRAPH_MAX_HT = 1000;
	private static final int GRAPH_MAX_WD = 1000;
	private static final int GRAPH_MARGIN = 23;
	private static final int GRAPH_TXT_INDNT = 10;
	private static final int GRAPH_GAP = 6;
	
	private Vector<Tuple<Float,Float>> data = null ;
	private float max_x = 0;
	private float max_y = 0;
	
	/**
	 * Creates a 1000x1000 graph with a 23 pixel border.
	 * @param log_buffer
	 * @param file_type
	 */
	public GraphImage(Log_Buffer log_buffer, String file_type) {
		
		//width always before height (x, y)
		super(log_buffer, file_type, GRAPH_MARGIN + GRAPH_MAX_WD + 1, GRAPH_MARGIN + GRAPH_MAX_HT + 1);  //1024x1024
		draw_axes();
		data = new Vector<Tuple<Float,Float>>();
	}
	
	public void draw_axes() {
		g2d.drawLine(GRAPH_MARGIN, 0, GRAPH_MARGIN, GRAPH_MAX_HT);
		g2d.drawLine(GRAPH_MARGIN, GRAPH_MAX_HT, GRAPH_MARGIN + GRAPH_MAX_WD, GRAPH_MAX_HT);
	}
	
	public void add_point(float x, float y) {
		if (x > max_x) { max_x = x; }
		if (y > max_y) { max_y = y; }
//		if (y < 0) { 
//			LB.debug("y less than zero!");
//		}
//		if (y < 0) { 
//			LB.debug("x less than zero!");
//		}
		data.add(new Tuple<Float, Float>(x,y));
	}
	
	
	public final void add_vert_line(float a) {
		g2d.drawLine(GRAPH_MARGIN + Math.round(a*GRAPH_MAX_WD/max_x),		//x1
				0,															//y1
				GRAPH_MARGIN + Math.round(a*GRAPH_MAX_WD/max_x),			//x2
				GRAPH_MAX_HT);												//y2
	}
	
	public final void add_horiz_line(float a) {
		g2d.drawLine(GRAPH_MARGIN,											//x1
				GRAPH_MAX_HT - Math.round(a*GRAPH_MAX_HT/max_y),			//y1
				GRAPH_MARGIN + GRAPH_MAX_WD,								//x2
				GRAPH_MAX_HT - - Math.round(GRAPH_MAX_HT*a/(max_y)));		//y2
	}
	
	
	/**
	 * Draw a straight line through the graph given it's slope and intercept
	 *  
	 * @param slope
	 * @param intercept
	 */
	public final void add_line(float slope, float intercept) {
		float x1 = 0;
		float x2 = 0;
		float y1 = 0;
		float y2 = 0;
		if (intercept < 0) {
			y1 = 0;
			x1 = Math.round(intercept/slope);
		} else {
			x1 = 0;
			y1 = Math.round(intercept);
		}
		final float tmp = (max_x * slope) + intercept;
		if (tmp > max_y) {
			y2 = max_y;
			x2 = (max_y - intercept)/slope;
		} else {
			y2 = tmp;
			x2 = max_x;
		}
		g2d.drawLine(GRAPH_MARGIN + Math.round(x1*GRAPH_MAX_WD/max_x), 					//x1
					GRAPH_MAX_HT - Math.round(GRAPH_MAX_HT*y1/(max_y)),	//y1
					GRAPH_MARGIN + Math.round(x2*GRAPH_MAX_WD/max_x),					//x2 
					GRAPH_MAX_HT - Math.round(GRAPH_MAX_HT*y2/(max_y)));	//y2
		g2d.drawString("y = " + slope +"x + " + intercept, Math.round((float)GRAPH_MAX_WD/2) , GRAPH_TXT_INDNT);
	}
	
//	
//	public void graph_point(int x, int y) {
//		g2d.drawRect(x+GRAPH_MARGIN, GRAPH_MAX-y, 1, 1);
//	}
	

	public void write_to_disc(String Filename) {
		
		max_x *= GRAPH_PADDING;
		max_y *= GRAPH_PADDING;
		
		for (Tuple<Float,Float> a : data) {
			g2d.drawRect(Math.round((a.get_first()*GRAPH_MAX_WD/max_x) + GRAPH_MARGIN),
					GRAPH_MAX_HT - Math.round(a.get_second()*GRAPH_MAX_HT/max_y) , 1, 1);
		}
		g2d.drawString(Integer.toString(Math.round(max_y)), GRAPH_GAP, GRAPH_TXT_INDNT);
		g2d.drawString("0", GRAPH_GAP, GRAPH_MAX_HT);
		g2d.drawString("0", GRAPH_MARGIN, GRAPH_MAX_HT + GRAPH_GAP + GRAPH_TXT_INDNT);
		g2d.drawString(Integer.toString(Math.round(max_x)), GRAPH_MAX_WD-GRAPH_MARGIN, GRAPH_MAX_HT + GRAPH_GAP + GRAPH_TXT_INDNT);
		super.write_to_disc(Filename);
	}

}

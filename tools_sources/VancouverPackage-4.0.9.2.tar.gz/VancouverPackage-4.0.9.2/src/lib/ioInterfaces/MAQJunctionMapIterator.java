package src.lib.ioInterfaces;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;

import src.lib.objects.MAQRyanMap;

/**
 * @version $Revision: 465 $
 * @author 
 */
public class MAQJunctionMapIterator implements Iterator<MAQRyanMap>{
	private static boolean display_version = true;
	private static Log_Buffer LB;
	
	String Name = null;
	BufferedReader br = null;
	int linecount =0;
	
	
	
	public MAQJunctionMapIterator(Log_Buffer logbuffer, final String Name, String source_file) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("MAQJunctionMapIterator", "$Revision: 465 $");
			display_version = false;
		}
		this.Name = Name;
		try {
			if (source_file.endsWith(".gz")) {
				br = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(source_file))));
			} else {
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (final FileNotFoundException e) {
			if (source_file.endsWith(".gz")) {
				try {
					LB.warning("Couldn't find file: " + source_file);
					source_file = source_file.substring(0,source_file.length()-3);
					LB.notice("Trying file: " + source_file);
					br = new BufferedReader(new FileReader(source_file));
					LB.notice("Success");
				} catch (final FileNotFoundException f) {
					LB.error("Can't open Junction Mapping file (notzipped) " + source_file);
					LB.die();
				}
			} else {		
				LB.error("Can't open Junction Mapping file " + source_file);
				if (source_file.endsWith(".gz")) {
					LB.notice("Tried to open as gzip.");
				}
				LB.die();
			}
		} catch (final IOException io) {
			LB.error("Couldn't Open Gzip File");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		try {
			br.readLine(); 					//skip first line.
		} catch (IOException io) {
			//Bypassing first line
			LB.error("can't skip first line.  Error reading ");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	} 
	
	public void close(final boolean verbose) {
		try {
			this.br.close();
		} catch (final IOException io) {
			LB.warning("Could not close Eland file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
		/*	LB.notice("Processed " + this.linecount + " records");
			LB.notice("Ux records : " + this.UXcnt);*/
		}
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (final IOException io){
			LB.error("Could not determine status of Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}	
	
	

/*	#junction_id    fasta_start     fasta_end
	chr1:2091-2474_+        0       69
	chr1:2585-3082_+        80      149
	chr1:4693-4831_-        160     229
	chr1:4902-5657_-        240     309
	chr1:5811-6468_-        320     389
*/

	public MAQRyanMap next() {
		String line = null;
		try {
			linecount++;
			line = br.readLine();
			if (line == null) { 
				throw new NoSuchElementException("Could not read next Junction Map element on line " + linecount);
			}
			final String[] st = line.split("\t");					//0 = chr1:5811-6468_-
			final String[] complex  = st[0].split(":"); 			// chr1 and 5811-6468_-
			final String[] dir		= complex[1].split("_");		// 5811-6468 and  -
			final String[] position = dir[0].split("-");			// 5811 and 6468		
			
			return new MAQRyanMap(complex[0], 
					Integer.valueOf(position[0]),
					Integer.valueOf(position[1]),
					(dir[1].equals("+"))? true : false,
					Integer.valueOf(st[1]),
					Integer.valueOf(st[2])
			);	
		} catch (final IOException io) {
			LB.error("Error reading Eland file on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		throw new NoSuchElementException("Could not get any more reads.");
	}

}

		
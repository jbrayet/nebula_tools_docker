package src.projects.maq_utilities.objects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * @version $Revision: 558 $
 * @author 
 */
public class ExonBoundaries implements Iterator<Exonboundary> {
		
	private List<Exonboundary> exons;
	private int index;
	
	public ExonBoundaries() {
		exons = new ArrayList<Exonboundary>();
		index = 0;
	}
		
	public int get_size() {
		return this.exons.size();
	}
	
	public Exonboundary get(int a) {
		return this.exons.get(a);
	}
	
	public void remove(int a) {
		this.exons.remove(a);
	}
	
	public void set(int x, Exonboundary y) {
		this.exons.set(x, y);
	}
	
	public void add(Exonboundary x) {
		this.exons.add(x);
	}
	
	public void add(int x, Exonboundary y) {
		this.exons.add(x, y);
	}
	
	public Exonboundary next() {
		if (index >= this.exons.size()) {
			throw new NoSuchElementException();
		} else{
			return this.exons.get(index++);
		}
	}
	
	public void remove() {
		//not supported
	}

	public boolean hasNext() {
		return (index < this.exons.size()) ? true : false; 
	}
	
}

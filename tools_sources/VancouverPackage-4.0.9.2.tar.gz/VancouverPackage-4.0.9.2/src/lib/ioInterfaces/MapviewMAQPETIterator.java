package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.zip.GZIPInputStream;
import src.lib.objects.PETRead;

/**
 * @version $Revision: 735 $
 * @author
 * @deprecated
 */
public class MapviewMAQPETIterator {
	String Name = null;
	BufferedReader br = null;
	int linecount = 0;
	int UXcnt = 0;
	
	private static Log_Buffer LB;
	

	public MapviewMAQPETIterator(Log_Buffer logbuffer, String Name, String source_file) {
		LB = logbuffer;
		this.Name = Name;
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else if (source_file.endsWith(".gz")) {
				br = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(source_file))));
			} else {
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (FileNotFoundException e) {
			if (source_file.endsWith(".gz")) {
				try {
					LB.warning("Couldn't find Mapview file: " + source_file);
					source_file = source_file.substring(0,source_file.length()-3);
					LB.notice("Trying file: " + source_file);
					br = new BufferedReader(new FileReader(source_file));
					LB.notice("Success");
				} catch (FileNotFoundException f) {
					LB.error("Can't find Mapview file (notzipped) " + source_file);
					LB.die();
				}
			} else {			
				LB.error("Can't open Mapview file " + source_file);
				if (source_file.endsWith(".gz")) {
					LB.error("Tried to open as gzip.");
				}
				LB.die();
			}
		} catch (IOException io) {
			LB.error("\nCouldn't open file: " + source_file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Ux records : " + this.UXcnt);
		}
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}


/* read name,
 * chromosome, 
 * position, 
 * strand, 
 * insert size from the outer coorniates of a pair, 
 * paired flag, 
 * mapping quality, 
 * single-end mapping quality, 
 * alternative mapping quality, 
 * number of mismatches of the best hit, 
 * sum of qualities of mismatched bases of the best hit, 
 * number of 0-mismatch hits of the first 24bp, 
 * number of 1-mismatch hits of the first 24bp on the reference, 
 * length of the read, 
 * read sequence and its quality
 * */
	
	

	// 6_171_609_863_reverse scaffold_1 79342 - 0 0 22 22 22 0 0 3 6  36
	// 6_79_732_595_reverse scaffold_1  79347 + 0 0 19 19 19 0 0 1 12 36
	// 7_48_500_640_forward scaffold_1  79349 - 0 0 0  0  0  0 0 2 15 36
	// 6_108_995_988_forward scaffold_1 79351 - 0 0 20 20 20 0 0 1 9  36


	public PETRead next() {
		String line = null;
		try {
			if ((line = br.readLine()) != null) {
				this.linecount++;	
				StringTokenizer st = new StringTokenizer(line, "\t");
				
				PETRead p = new PETRead(				
						st.nextToken(),							//6_171_609_863_reverse
						st.nextToken(),							//1
						Integer.parseInt(st.nextToken()), 		//79342
						st.nextToken().charAt(0),				//-
						Integer.parseInt(st.nextToken()), 						//0
						Integer.parseInt(st.nextToken()),							//0
						Integer.parseInt(st.nextToken()),		//22 (mapping quality)
						Integer.parseInt(st.nextToken()),							//22 (single end mapping quality)
						Integer.parseInt(st.nextToken()), 						//22			
						Integer.parseInt(st.nextToken()),		//0
						Integer.parseInt(st.nextToken()),							//0
						Integer.parseInt(st.nextToken()),		//3
						Integer.parseInt(st.nextToken()),		//6
						Integer.parseInt(st.nextToken()),		//36
						null,
						null);
				return p;
			}
		} catch (IOException io) {
			LB.error(io.getStackTrace().toString());
			LB.error("Error reading MAQPET file on line " + this.linecount);
			LB.error("Are you certain you're using the correct iterator?");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		} catch (NumberFormatException nfe) {
			LB.error("Error reading MAQPET file on line " + this.linecount);
			LB.error("Are you certain you're using the correct iterator?");
			LB.error("Message thrown by Java environment (may be null):" + nfe.getMessage());
			LB.die();
		}
		throw new NoSuchElementException("Could not get any more reads.");
	}
	
}

		
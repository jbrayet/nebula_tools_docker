package src.lib.ioInterfaces;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.zip.GZIPInputStream;

import src.lib.Constants;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;

/**
 * @version $Revision: 1790 $
 * @author 
 */
public class VulgarIterator implements AlignedReadsIterator {
	private static boolean display_version = true;
	private static Log_Buffer LB;

	String Name = null;
	BufferedReader br = null;
	int linecount = 0;
	final int max_PET_len;
	private int number_filtered;
	
	public VulgarIterator(Log_Buffer logbuffer, String Name, String source_file, int max_PET_len) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("VulgarIterator", "$Revision: 1790 $");
			display_version = false;
		}
		this.max_PET_len = max_PET_len;
		this.Name = Name;
		this.number_filtered = 0;
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else if (source_file.endsWith(".gz")) {
				br = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(source_file))));
			} else {
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (FileNotFoundException e) {
			if (source_file.endsWith(".gz")) {
				try {
					LB.warning("Couldn't find file: " + source_file);
					source_file = source_file.substring(0,source_file.length()-3);
					LB.notice("Trying file: " + source_file);
					br = new BufferedReader(new FileReader(source_file));
					LB.notice("Success");
				} catch (IOException io) {
					LB.error("Can't open Vulgar file (notzipped) " + source_file);
					LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
					LB.die();
				}
			} else {			
				LB.error("Can't open Vulgar file " + source_file);
				if (source_file.endsWith(".gz")) {
					LB.error("Tried to open as gzip.");
				}
				LB.die();
			}
		} catch (IOException io) {
			LB.error("Can't open file: " + source_file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		//read in first line to skip past:
		try {
			br.readLine();
			br.readLine();
		} catch (IOException io) {
			LB.error("Error trying to read past first two header lines.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		LB.notice("2 lines skipped by default, continuing.");
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	/**
	 * @deprecated
	 */
	public void apply_filters(String f) {
		throw new UnsupportedOperationException();
	}
	
	public boolean reset() {
		try {
			br.reset();
			return true;
		} catch (IOException ioe) {
			LB.error("Could not reset input file for read buffer.");
			return false;
		}
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Records Filtered : " + this.number_filtered);
		}
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

	
	
/*		Column 1: query (read) name
		Column 2: query start
		Column 3: query end
		Column 4: query strand
		Column 5: chromosome
		Column 6: subject start
		Column 7: subject end
		Column 8: subject strand
		Column 9: subject strand
		Column 10: score
		After that, it's a triplet of 'alignment type' 
	      (M - Match, G - Gap, I - Intron, 3 - 3' splice site, 5 - 5' splice site), 
	      followed by number of base pairs in the query and then number of base pairs in the subject:

		vulgar: 208AUAAXX_5_5_118_943_345 4 36 + 15 79379881 79379915 + 108 M 27 27 G 0 2 M 5 5
		vulgar: 208AUAAXX_5_5_118_945_80 0 36 + 2 43579492 43565949 - 156 M 17 17 5 0 2 I 0 13503 3 0 2 M 19 19
		vulgar: 208AUAAXX_5_5_118_947_819 3 36 + 14 51172321 51172357 + 110 M 23 23 G 0 2 M 5 5 G 0 1 M 5 5
		vulgar: 208AUAAXX_5_5_118_954_430 0 36 + 8 49864826 49864789 - 114 M 13 13 G 0 1 M 23 23
*/

	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public AlignedRead next() {
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				
				if (line.startsWith("--")) {
					return null;
				}
				this.linecount++;	
				StringTokenizer st = new StringTokenizer(line, " ");
				st.nextToken(); 										//vulgar:
				String seq_name 	= st.nextToken();					//208AUAAXX_5_5_118_943_345
				int seqStart		= Integer.valueOf(st.nextToken());	//4
				int seqEnd			= Integer.valueOf(st.nextToken());	//36
				st.nextToken(); 										//bogus direction value
				String chromosome	= st.nextToken();					//15
				int alignStart		= Integer.valueOf(st.nextToken());
				int alignEnd		= Integer.valueOf(st.nextToken());
				char direction 		= st.nextToken().charAt(0);			//+
				int score			= Integer.valueOf(st.nextToken());
				String structure 	= "";
				while (st.hasMoreTokens()) {
					char X = st.nextToken().charAt(0); 			//convert the triplets into some form of usable alignment.
					int Y  = Integer.valueOf(st.nextToken());
					int Z  = Integer.valueOf(st.nextToken());
					structure += (structure.equals("") ? "" : ",");
					structure += X + "," + Y + "," + Z;
				}

				
				if (chromosome.equals("MT")) {
					chromosome = "M";
				}
				
				if (alignStart > alignEnd) {
					
					int tmp = alignStart;		//swap to conform to regular aligner conventions
					alignStart = alignEnd;
					alignEnd = tmp;
				}

				/* test for conditions */
				if (this.max_PET_len != 0 && (alignStart - alignEnd) > this.max_PET_len) {
					this.number_filtered++;
					continue;
				}
				
				/*Fill in other parts of the AlignedRead Object:*/
				int alignLength = process_aln_length(line, structure);
				
				AlignedRead A = null;
				try {
					A = new AlignedRead(
						direction,
						seq_name,
						null,									/*Sequence*/
						score,
						seqStart,
						seqEnd,
						null,									/*alignName*/
						chromosome,
						alignStart,
						alignEnd,
						0,										/*percent*/
						0,										/*P*/
						null,									/*alignseq*/
						0,										/*mismatches*/
						0,										/*sort_score*/
						0,										/*queryLength*/
						alignLength,
						0,										/*contigStart*/
						0,										/*contigEnd*/
						0,										/*identity*/
						null,									/*Match*/
						0,										/*matches_noError*/
						0,										/*matches_1error*/
						0,										/*matches_2error*/
						null,									/*N_reads*/
						null,									/*error1*/
						null,									/*error2*/
						null);									/*quality*/
				} catch (UnexpectedResultException URE) {
					LB.error("Line " + linecount + " has an invalid read:");
					LB.error(URE.getMessage());
				}
				

				
				return A;
			} 
			throw new NoSuchElementException("Could not get any more reads.");
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());			
			LB.die();
		}
		throw new NoSuchElementException("Could not get any more reads.");
	}
	
	
	private static int process_aln_length(String line, String structure) {
		if (structure != null) {
			int alignLength = 0;
			StringTokenizer triplet= new StringTokenizer(line, ",");
			while (triplet.hasMoreTokens()) {
				if (triplet.nextToken().equals("M")) {
					alignLength += Integer.valueOf(triplet.nextToken());
				}
			}
			return alignLength;
		} else {
			return 0;
		}
	}

	
	/**
	 * Return the number of filtered read while iterating.
	 * TODO change this function if the Iterator start filtering
	 * @return 0 in every case
	 */
	public int get_NumberFilteredRead()
	{
		return this.number_filtered;
	}
	
}

		
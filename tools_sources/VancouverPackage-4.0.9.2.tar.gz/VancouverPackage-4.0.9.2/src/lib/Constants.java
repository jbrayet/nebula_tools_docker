package src.lib;

/**
 * @version $Revision: 1463 $
 * @author 
 */
public class Constants {
	
	public static final int		MOD_TEN 				= 10;
	public static final int		MOD_ONE_HUNDRED 		= 100;
	public static final int		MOD_HUNDRED_THOUSAND 	= 100000;
	
	public static final int 	ILLUMINA_BASE_MAX_32 	= 32;
	
	public static final int		PERCENT_100 			= 100;
	
	/** Colours On = 255 */
	public static final int		COLOURS_ON 				= 255;
	/** Colours half = 126 */
	public static final int		COLOURS_HALF 			= 126;
	/** Colours half = 0 */
	public static final int		COLOURS_OFF				= 0;
	
	public static final int   BIAS_PERCENT 			= 100;
	public static final int   BIAS_MARGIN 			= 20;
	public static final float BIAS_MARGIN_F 		= 20f;
	
	/*Protein Sequence Specific*/
	public static final int PRINT_FLANK_SIZE = 25;
	
	private Constants() {}
	
	/*Aligner Types*/
	public static final String FILE_TYPE_SNP = "snp";
	public static final String FILE_TYPE_ELAND = "eland";
	public static final String FILE_TYPE_BED = "bed";
	public static final String FILE_TYPE_GFF = "gff";
	public static final String FILE_TYPE_MAQ = "maq";
	public static final String FILE_TYPE_ELANDII = "elandext";
	public static final String FILE_TYPE_MAPVIEW = "mapview";
	public static final String FILE_TYPE_VULGAR = "vulgar";
	public static final String FILE_TYPE_BOWTIE = "bowtie";
	public static final String FILE_TYPE_SAM = "sam";
	public static final String FILE_TYPE_SAM_SPLIT = "sam-split";
	public static final String FILE_TYPE_SAM_FILTER = "sam-filter";
	
	
	/**Maximum size for a buffer when using mark()*/
	public static final int MARK_BUFFER_SIZE = 200000000;
	
	
}

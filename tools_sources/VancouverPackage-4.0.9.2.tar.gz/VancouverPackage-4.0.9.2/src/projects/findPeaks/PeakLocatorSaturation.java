package src.projects.findPeaks;

import java.util.Vector;

import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Tuple;
import src.projects.findPeaks.objects.MinPeakDesc;
import src.projects.findPeaks.objects.Parameters;

public class PeakLocatorSaturation {
	
	private PeakLocatorSaturation (){}		
	
	// ESCA-JAVA0138:
	/**
	 * Peak Locator for integer based array.
	 * @param LB  
	 * @param param
	 * @param coverage_array
	 * @param offset
	 * @param end
	 * @param subpeaks
	 * @return
	 */
	public static Vector<MinPeakDesc> process(
			Log_Buffer LB,
			Parameters param,
			int[] coverage_array,
			int offset,
			int end,
			boolean subpeaks) {
		
		Vector<MinPeakDesc> ps = new Vector<MinPeakDesc>();
		if (!subpeaks) {
			Tuple<Integer, Integer> max_ht_loc = Functions.maximum_and_location(coverage_array); // the max ht of the area
			MinPeakDesc p = new MinPeakDesc(offset, end-offset, max_ht_loc.get_second(), max_ht_loc.get_first());
			ps.add(p);
		} else { 											//sub peaks on.
			float min_valley = 			param.get_subpeaks_parm();
			float variability =  		param.get_trimpeaks_parm();
			boolean trim_peaks = 		param.get_trim();
			try {
				ps.addAll(process_subpeaks_on(coverage_array, min_valley,
						variability, offset, trim_peaks));
			} catch (UnexpectedResultException ure) {
				LB.warning("Could not find any peaks in area already identified as a peak.");
				LB.warning("this is indicative of much greater problems.  Will terminate.");
				LB.die();
			}
		}
		return ps;
	}
	
	// ESCA-JAVA0138:
	/**
	 * Peak Locator for float based array.
	 * @param LB  
	 * @param param
	 * @param coverage_array
	 * @param offset
	 * @param end
	 * @param subpeaks
	 * @return
	 */
	public static Vector<MinPeakDesc> process(
			Log_Buffer LB,
			Parameters param,
			float[] coverage_array,
			int offset,
			int end,
			boolean subpeaks) {
		
		Vector<MinPeakDesc> pd = new Vector<MinPeakDesc>();
		if (!subpeaks) {
			Tuple<Float, Integer> max_ht_loc = Functions.maximum_and_location(coverage_array); // the max ht of the area
			MinPeakDesc p = new MinPeakDesc (offset, end-offset, max_ht_loc.get_second(), max_ht_loc.get_first());
			pd.add(p);
		} else { 											//sub peaks on.
			float min_valley = 			param.get_subpeaks_parm();
			float variability =  		param.get_trimpeaks_parm();
			boolean trim_peaks = 		param.get_trim();
			try {
				pd.addAll(process_subpeaks_on(coverage_array, min_valley,
						variability, offset, trim_peaks));
			} catch (UnexpectedResultException ure) {
				LB.warning("Could not find any peaks in area already identified as a peak.");
				LB.warning("this is indicative of much greater problems.  Will terminate.");
				LB.die();
			}
		}
		return pd;
	}	

	// ESCA-JAVA0138:
	private static Vector<MinPeakDesc> process_subpeaks_on(
			float[] coverage_array, 
			float min_valley,
			float variability,
			int offset,
			boolean trim_peaks) 
	throws UnexpectedResultException {
		
		Tuple<Float, Integer>[] pk_maxima = Functions.all_maxima_and_location(coverage_array, min_valley); 
		Vector<MinPeakDesc> peaks = new Vector<MinPeakDesc>();
		
		int last_boundary = 0; 
		for (int v = 0; v < pk_maxima.length; v++) {			//initialise objects
			int boundary = (v != pk_maxima.length -1) ?			//last_boundary to end of range
					Utilities.findmin(coverage_array, pk_maxima[v].get_second(), pk_maxima[v+1].get_second()) :
					(coverage_array.length -1);
			if (trim_peaks) {
				int start = trim_peak_start(coverage_array, last_boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				int length = trim_peak_end(coverage_array, boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				peaks.add(new MinPeakDesc(offset + start, 
						length - start,			// length is the distance from the start of the array, so must be converted
						pk_maxima[v].get_second() - start,		//the max_loc must be converted relative to the start position.
						pk_maxima[v].get_first()));
			} else {					
				peaks.add(new MinPeakDesc(offset + last_boundary, boundary - last_boundary, 
						pk_maxima[v].get_second() - last_boundary,
						pk_maxima[v].get_first()));
			}
			last_boundary = boundary;
		}	
		return peaks;
	}

	// ESCA-JAVA0138:
	private static Vector<MinPeakDesc> process_subpeaks_on(
			int[] coverage_array, 
			float min_valley,
			float variability,
			int offset,
			boolean trim_peaks) 
	throws UnexpectedResultException {
		
		Tuple<Integer, Integer>[] pk_maxima = Functions.all_maxima_and_location(coverage_array, min_valley); 
		Vector<MinPeakDesc> peaks = new Vector<MinPeakDesc>();
		
		int last_boundary = 0; 
		for (int v = 0; v < pk_maxima.length; v++) {			//initialise objects
			int boundary = (v != pk_maxima.length -1) ?			//last_boundary to end of range
					Utilities.findmin(coverage_array, pk_maxima[v].get_second(), pk_maxima[v+1].get_first()) :
					(coverage_array.length -1); 
			if (trim_peaks) {
				int start = trim_peak_start(coverage_array, last_boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				int length = trim_peak_end(coverage_array, boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				peaks.add(new MinPeakDesc(start + offset,
						length - start,
						pk_maxima[v].get_second() - start,
						pk_maxima[v].get_first()));
			} else {
				peaks.add(new MinPeakDesc(last_boundary + offset, 
						boundary -last_boundary, 
						pk_maxima[v].get_second()-last_boundary,
						pk_maxima[v].get_first()));
			}
			last_boundary = boundary;
		}			
		return peaks;
	}

	private static int trim_peak_start(float[] coverageHeights, int pk_start, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j > pk_start) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j--;
		}
		return pk_start;
	}
	
	private static int trim_peak_start(int[] coverageHeights, int pk_start, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j > pk_start) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j--;
		}
		return pk_start;
	}
	
	private static int trim_peak_end(float[] coverageHeights, int pk_end, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j < pk_end) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j++;
		}
		return pk_end;
	}
	
	private static int trim_peak_end(int[] coverageHeights, int pk_end, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j < pk_end) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j++;
		}
		return pk_end;
	}

}

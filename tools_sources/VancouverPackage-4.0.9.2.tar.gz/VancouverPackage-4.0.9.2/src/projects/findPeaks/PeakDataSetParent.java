package src.projects.findPeaks;

import java.util.Random;
import java.util.Vector;

import src.lib.Coverage;
import src.lib.Histogram;
import src.lib.Utilities;
import src.lib.ioInterfaces.BedGraphWriter;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.PushBackIteratorWrapper;
import src.lib.ioInterfaces.WigwriterBuffered;
import src.lib.objects.AlignedRead;
import src.lib.objects.Tuple;

import src.projects.findPeaks.FDR.ApplyControl;
import src.projects.findPeaks.filewriters.PeakWriter;
import src.projects.findPeaks.objects.MapStore;
import src.projects.findPeaks.objects.Map_f;
import src.projects.findPeaks.objects.Map_i;
import src.projects.findPeaks.objects.MinPeakDesc;
import src.projects.findPeaks.objects.Parameters;
import src.projects.findPeaks.objects.PeakStore;
import src.projects.findPeaks.objects.Peakdesc;
import src.projects.findPeaks.objects.SaturationDataHolder;
import src.projects.findPeaks.objects.SeqStore;

// ESCA-JAVA0100:
// ESCA-JAVA0136:
/**
 * @version $Revision: 1830 $
 * @author 
 */
public class PeakDataSetParent {

	protected static final int WINDOW_SIZE = 2000;
	private static boolean display_version = true;
	private static final int FREQ_TEN = 10;
	private static final int ONE_SECOND = 1000;
	
	private static Log_Buffer LB;
	private MapStore maps;
	private PeakStore peaks;
	private SeqStore seqs;
	private String current_chromosome;
	private float[] values;
	private int iterations;
	private SaturationDataHolder store;
	PeakDataSetChild[][] children;
	private Random random_gen; 
	private int[] start_map;
	private int mapkey = 0;
	private boolean saturation = false;
	// ESCA-JAVA0138:
	// ESCA-JAVA0273:
	/**
	 * This version of access for PeakDataSetParent is for use in SATURATION MODE ONLY.
	 * 
	 * @param logbuffer
	 * @param param
	 * @param it
	 * @param dist
	 * @param val The values used by each of the thresholded child processes.
	 * @param iterations the number of iterations being used.
	 * 
	 */
	public PeakDataSetParent(Log_Buffer logbuffer, Parameters param, Generic_AlignRead_Iterator it, Distribution dist,
			float[] val, int iterations) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("PeakDataSet Peak Locator", "$Revision: 1830 $");
			display_version = false;
		}
		if (param.get_goldenpath() > 0 ) {
			seqs = new SeqStore(LB);
		} else {
			seqs = null;
		}
		saturation = true;
		this.values = new float[val.length];
		System.arraycopy(val, 0, this.values, 0, val.length);
		this.random_gen = new Random(); 
		this.iterations = iterations;
		this.store = new SaturationDataHolder(LB, this.values, this.iterations);
		Thread th = new Thread(this.store);
		th.start();
		children = new PeakDataSetChild[val.length][this.iterations];
		Thread[][] cth = new Thread[val.length][this.iterations];
		for (int x = 0; x < val.length; x++) {
			for (int y = 0; y < this.iterations; y++) {
				children[x][y] = new PeakDataSetChild(LB, this.store, param, dist, val[x], y);
				cth[x][y] = new Thread(children[x][y]);
				cth[x][y].start();
			}
		}
		
		this.peaks = new PeakStore(LB);
		if (dist.get_dist_type() == 3) {
			process_peaks_from_iterator_PET2(it, param);
		} else {
			process_peaks_from_iterator2(it, param, dist);
		} 
		
		for (int x = 0; x < val.length; x++) {
			for (int y = 0; y < this.iterations; y++) {
				boolean t = children[x][y].close();
				if (!t) {
					LB.warning("Thread " + x + " " + y + " did not close.  will wait 5 seconds and attempt again.");
					try {
						// ESCA-JAVA0087:
						Thread.sleep(5000);
					} catch (InterruptedException ie) {		
						//nothing to do.
					}
					t = children[x][y].close();	
					LB.warning("Thread " + x + " " + y + " is still not closing.  Will dump stack and interrupt.");
					if (!t) {
						cth[x][y].getStackTrace();
						cth[x][y].interrupt();
					}
				}
				
			}
		}	
		
		
		this.store.close();	
	}
	
	/**
	 * must test if this.peaks == null after using this function.
	 * This version of access for PeakDataSetParent is for use in NON-SATURATION Mode.
	 * 
	 * @param logbuffer
	 * @param param
	 * @param it
	 * @param dist
	 */
	public PeakDataSetParent(Log_Buffer logbuffer, Parameters param, Generic_AlignRead_Iterator it, Distribution dist) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("PeakDataSet Peak Locator", "$Revision: 1830 $");
			display_version = false;
		}
		if (param.get_goldenpath() > 0 ) {
			seqs = new SeqStore(LB);
		} else {
			seqs = null;
		}
		this.saturation = false;
		this.peaks = new PeakStore(LB);
		if (dist.get_dist_type() == 3) {
			process_peaks_from_iterator_PET2(it, param);
		} else {
			process_peaks_from_iterator2(it, param, dist);
		} 
	}
	
		
	public void clear() {
		if (maps != null ) {
			maps.clear();
		}
		if (peaks != null) {
			peaks.clear();
		}
		if (seqs != null) {
			seqs.clear();
		}
		start_map = null;
	}
	
	
	/**
	 * Pass through class to get results from data store.
	 * @return
	 */
	public MinPeakDesc[][][] return_peak_descs() {
		int count = 0;
		while (this.store.get_count_finished_threads() < (this.values.length * this.iterations)) {
			count++;
			try {
				// ESCA-JAVA0087:
				Thread.sleep(ONE_SECOND);
			} catch (InterruptedException ie) {
				LB.error("Main thread threw an interrupted exception while waiting for " +
						"saturation threads to complete");
				LB.die();
			}
			if (count % FREQ_TEN == 0) { 
				LB.notice("System has been waiting saturation threads to complete for " + count + " seconds");
				LB.notice("Finished: " + this.store.get_count_finished_threads() +" \tExpected: " 
						+ (this.values.length * this.iterations));
			}
			
		}
		return this.store.get_arrays_of_desc();
	}
	
	/**
	 * Pass through class to get results (coverage) from data store.
	 * @return
	 */
	public int[][] return_peak_coverages() {
		int count = 0;
		while (this.store.get_count_finished_threads() < (this.values.length * this.iterations)) {
			count++;
			try {
				// ESCA-JAVA0087:
				Thread.sleep(ONE_SECOND);
			} catch (InterruptedException ie) {
				LB.error("Main thread threw an interrupted exception while waiting for " +
						"saturation threads to complete");
				LB.die();
			}
			if (count % FREQ_TEN == 0) { 
				LB.notice("System has been waiting saturation threads to complete for " + count + " seconds");
				LB.notice("Finished: " + this.store.get_count_finished_threads() +" \tExpected: " 
						+ (this.values.length * this.iterations));
			}
			
		}
		return this.store.get_coverages();
	}
	
	
	
	
	
	/**
	 * Pass through class to get results from data store.
	 * @param histogram_size
	 * @param precision
	 * @return
	 */
	public Histogram[][] return_histograms(int histogram_size, int precision) {
		int count = 0;
		while (this.store.get_count_finished_threads() < (this.values.length * this.iterations)) {
			count++;
			try {
				// ESCA-JAVA0087:
				Thread.sleep(ONE_SECOND);
			} catch (InterruptedException ie) {
				LB.error("Main thread threw an interrupted exception while waiting for " +
						"saturation threads to complete");
				LB.die();
			}
			if (count % FREQ_TEN == 0) { 
				LB.notice("System has been waiting saturation threads to complete for " + count + " seconds");
				LB.notice("Finished: " + this.store.get_count_finished_threads() +" \tExpected: " 
						+ (this.values.length * this.iterations));
			}
			
		}
		return this.store.reduce_to_hist(histogram_size, precision);
	}
	
	public Tuple<int[][], int[][]> return_LW_stats() {
		return this.store.return_LW_stats();
	}
	
	public int[][] return_reads_used() {
		return this.store.return_reads_used();
	}
	
	
	
	/**
	 * 
	 * @param reader
	 * @param max_length
	 * @param cur_peak_end
	 * @param overlap_farenough
	 * @return 				The next aligned read that is allowable.
	 */
	private AlignedRead next_overlap_read(PushBackIteratorWrapper reader, int max_length,
			int cur_peak_end, Boolean[] overlap_farenough) {
		AlignedRead ar_tmp=reader.next();
		if (ar_tmp == null) {
			overlap_farenough[1]= true;
			return null;
		} else if (!ar_tmp.get_chromosome().equalsIgnoreCase(current_chromosome)) { //on the next chr
			reader.add_back(ar_tmp);
			overlap_farenough[1]= true;
			return null;
		} else {
			if (ar_tmp.get_direction() == '+')  {
				if (ar_tmp.get_alignStart()- cur_peak_end > max_length) {
					overlap_farenough[1] =  true;
					reader.add_back(ar_tmp);
					return null;
				} else if (ar_tmp.get_alignStart() <= cur_peak_end) {
					overlap_farenough[0] = true;
				}
			} else {  // negative strand - these are the ones we have to "worry about"
				if (ar_tmp.get_alignEnd() < max_length) {
					return null;
				}
				if (ar_tmp.get_alignEnd() - max_length <= cur_peak_end) {
					overlap_farenough[0] = true;
				} else if (ar_tmp.get_alignEnd() > max_length + cur_peak_end) {
					overlap_farenough[1] = true;
					reader.add_back(ar_tmp);
					return null;
				}
			}
			return ar_tmp;
		}
	}
	
	private AlignedRead next_overlap_read_PET(PushBackIteratorWrapper reader,
			int cur_peak_end, Boolean[] overlap_farenough) {
		AlignedRead ar_tmp = reader.next();
		if (ar_tmp == null) {
			overlap_farenough[1] = true;
			return null;
		} else if (!ar_tmp.get_chromosome().equalsIgnoreCase(current_chromosome)) { //on the next chr
			reader.add_back(ar_tmp);
			overlap_farenough[1] = true;
			return null;
		} else {		
			if (ar_tmp.get_alignStart() <= cur_peak_end) { 
				overlap_farenough[0] = true;
			} else if (ar_tmp.get_alignStart() - cur_peak_end > WINDOW_SIZE) {
				overlap_farenough[1] = true;
				reader.add_back(ar_tmp);
				return null;
			} else {
				overlap_farenough[0] = false;
			}
			return ar_tmp;
		}
	}
	
	
	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param cur_reads
	 * @param param
	 * @param dist
	 * @param cur_peak_start
	 * @param cur_peak_end
	 * @param subpeaks
	 */
	private void process_int_based(Vector<AlignedRead> cur_reads,
			Parameters param, Distribution dist, int cur_peak_start,
			int cur_peak_end, boolean subpeaks) {
		int[] coverage_array = Coverage.generatePeakHeight_ld_int(cur_reads, dist, cur_peak_start, cur_peak_end);
		if (cur_reads.size() >= param.get_min_store_ht()) {
			maps.put(coverage_array, cur_peak_start);
			PeakStore p = PeakLocator.process(LB, param, coverage_array,	//generate the peak description
						cur_peak_start, cur_peak_end, subpeaks, mapkey);
			if (param.get_goldenpath() > 0) {
				int width = param.get_goldenpath();
				for (Peakdesc pd : p) { 
					if (pd.get_height() > param.get_min_ht() && pd.get_height() > param.get_min_store_ht()) {
						int t = seqs.add(GoldenPath(cur_reads, cur_peak_start, cur_peak_end, 
								pd.get_max_loc() - width,
								pd.get_max_loc() + width ));
						pd.set_seq_key(t);
					}
				}
			}
			this.peaks.merge(p);
			mapkey++;
		} else {
			this.peaks.add(new Peakdesc(	//if we're skipping processing this peak, just make some assumptions - no subpeaks
					cur_peak_start, 				// the offset from the start of the genome
					cur_peak_end - cur_peak_start,		// length of region covered
					(cur_peak_end - cur_peak_start)/2,  // we'll just asign it as half way through						
					cur_reads.size(),					// the height is "assumed" to be the same as the number of reads
					-1));								// no hashkey
		}
	}
	
	
	private void process_float_based(Vector<AlignedRead> cur_reads, Parameters param,
			Distribution dist, int cur_peak_start, int cur_peak_end,
			boolean subpeaks) {
		float[] coverage_array = Coverage.generatePeakHeight_ld_float(cur_reads, dist, cur_peak_start, cur_peak_end); 
		if (cur_reads.size() >= param.get_min_store_ht()) {
			maps.put(coverage_array, cur_peak_start);
			PeakStore p = PeakLocator.process(LB, param, coverage_array,	//generate the peak description
					cur_peak_start, cur_peak_end, subpeaks, mapkey); 
			if (param.get_goldenpath() > 0) {
				int width = param.get_goldenpath();
				for (Peakdesc pd : p) { 
					if (pd.get_height() > param.get_min_ht() && pd.get_height() > param.get_min_store_ht()) {
						int t = seqs.add(GoldenPath(cur_reads, cur_peak_start, cur_peak_end, 
								pd.get_max_loc() - width,
								pd.get_max_loc() + width ));
						pd.set_seq_key(t);
					}
				}
			}
			this.peaks.merge(p);
			mapkey++;
		} else{
			this.peaks.add(new Peakdesc(	//if we're skipping processing this peak, just make some assumptions - no subpeaks
					cur_peak_start,						// the offset from the start of the genome
					cur_peak_end - cur_peak_start,		// length of region covered
					(cur_peak_end - cur_peak_start)/2,  // we'll just asign it as half way through
					cur_reads.size(),					// the height is "assumed" to be the same as the number of reads
					-1));								// no hashkey
		}
	}

	/**
	 *  Peak Locator - will be the new peak locator for FindPeaks 4.0
	 * @param it
	 * @param param
	 * @param dist
	 */
	private void process_peaks_from_iterator2(
			Generic_AlignRead_Iterator it, Parameters param, Distribution dist) {
		
		PushBackIteratorWrapper reader= new PushBackIteratorWrapper(it);
		this.maps = new MapStore(LB, dist.intbased());

		int cur_peak_start = 0;
		int cur_peak_end = 0;
		int reads_used = 0;
		int reads_filtered = 0;
		boolean first_time = true;
		
		Vector<AlignedRead> cur_reads = new Vector<AlignedRead>(0);
		int frag_start = 0;
		int frag_end  = 0;
		
		boolean subpeaks = 			param.get_subpeaks();
		boolean filter = 			param.get_filterDupes();
		AlignedRead ar = null;
		Vector<AlignedRead> local_buffer = new Vector<AlignedRead>();
		
		mapkey = 0;
		int max_length = dist.get_max_ext_len() -1; //max_ext_len is zero based.
		while (reader.has_next()) {
			ar=reader.next();
			if (ar == null) {
				break;
			}	
			
			if (first_time) {				// check if hitting new chromosome. 
				current_chromosome = ar.get_chromosome();
				if (!current_chromosome.equals("")) {
					LB.notice("Current chromosome : " + current_chromosome);
				}
				first_time = false;
			} else if (!ar.get_chromosome().equalsIgnoreCase(current_chromosome)) { //on the next chr
				reader.add_back(ar);
				break;						//stop iterating we have moved to the next chromosome.
			} 
			
			
			if (ar.get_direction() == '+') {
				cur_peak_start = ar.get_alignStart();
				cur_peak_end = ar.get_alignStart() + max_length;
			} else {
				if (ar.get_alignEnd() < max_length) {
					continue;
				}
				cur_peak_start = ar.get_alignEnd() - max_length;
				cur_peak_end = ar.get_alignEnd();
			}
			cur_reads.add(ar);
		
			Boolean[] overlap_farenough = new Boolean[2]; //overlap and far_enough
			overlap_farenough[0] = false;
			overlap_farenough[1] = false;
			while (!overlap_farenough[1] && reader.has_next()) {
				AlignedRead r = next_overlap_read(reader, max_length, cur_peak_end, overlap_farenough);
				if (r != null) {
					local_buffer.add(r);
				}
				if (overlap_farenough[0]) {   //if overlaps
					while (local_buffer.size() > 0 ) {
						AlignedRead a = local_buffer.remove(0);					
						frag_start = (a.get_direction() == '+') ? a.get_alignStart() : a.get_alignEnd() - max_length;  
						frag_end   = (a.get_direction() == '+') ? a.get_alignStart() + max_length : a.get_alignEnd();
						cur_peak_end = (frag_end > cur_peak_end) ?  frag_end : cur_peak_end;
						cur_peak_start = (frag_start < cur_peak_start) ? frag_start : cur_peak_start;
						cur_reads.add(a);
					}
				} else if (overlap_farenough[1]) {
					reader.push_back(local_buffer);
					local_buffer.clear();
				}
			}
			if (overlap_farenough[1] || !reader.has_next() ) { //means we know that the next set isn't an overlap with this peak.
				if (filter) {						//filter duplicates
					int filtered_reads = cur_reads.size();
					cur_reads = DuplicateFiltering.simplefilter(cur_reads);
					filtered_reads -= cur_reads.size();
					reads_filtered += filtered_reads;
				}
				if (cur_reads.size() == 1) {		//LanderWaterman Stats
					this.peaks.inc_LW_singles();
				} else if (cur_reads.size() == 2) {
					this.peaks.inc_LW_doubles();
				}
				if (dist.intbased()) {		//Get the profile for the peak - store into Hashmap of int[]/float[]
					process_int_based(cur_reads, param, dist, cur_peak_start, cur_peak_end, subpeaks);				
				} else {
					process_float_based(cur_reads, param, dist, cur_peak_start, cur_peak_end, subpeaks);
				}
				if (saturation) {
					feed_children(cur_reads);
				}
				reads_used += cur_reads.size();
				cur_reads.clear();
				cur_reads = new Vector<AlignedRead>();		//init new peak 
			}
			if (local_buffer.size() > 0) {
				reader.push_back(local_buffer);
				local_buffer.clear();
			}
		}
		this.peaks.set_reads_used(reads_used);							//clean up at the end of the chromosome
		this.peaks.set_reads_filtered(reads_filtered);
		maps.complete();
		LB.notice("Reads used: " + reads_used);
		if (reads_filtered > 0) {
			LB.notice("Reads filtered by duplicate: " + reads_filtered);
		}
		if (it.iterator().get_NumberFilteredRead() > 0) {
			LB.notice("Reads filtered by iterator: " + it.iterator().get_NumberFilteredRead());
		}
	}

	
	private void feed_children(Vector<AlignedRead> cur_reads) {
		AlignedRead[] cur_reads_array = cur_reads.toArray(new AlignedRead[cur_reads.size()]);
		
		for (int i = 0; i < iterations; i++ ) {
			float[] random_numbers = new float[cur_reads.size()];
			for (int r = 0; r <random_numbers.length; r++) {
				random_numbers[r] = random_gen.nextFloat();
			}
			for (int v = 0; v < values.length; v++) {
				children[v][i].receive_arrays(cur_reads_array, random_numbers);
			}
		}
	}

	/**
	 *  Peak Locator - will be the new peak locator for FindPeaks 4.0
	 * @param it
	 * @param param
	 */
	private void process_peaks_from_iterator_PET2(
			Generic_AlignRead_Iterator it, Parameters param) {
		
		PushBackIteratorWrapper reader=new PushBackIteratorWrapper(it);
		this.maps = new MapStore(LB, true);
		int cur_peak_start = 0;
		int cur_peak_end = 0;
		int reads_used = 0;
		int reads_filtered = 0;
		boolean first_time = true;
		
		Vector<AlignedRead> cur_reads = new Vector<AlignedRead>(0);
		int frag_start = 0;
		int frag_end  = 0;
		
		boolean subpeaks = 			param.get_subpeaks();
		boolean filter = 			param.get_filterDupes();
		AlignedRead ar = null;
		Vector<AlignedRead> local_buffer = new Vector<AlignedRead>();
		
		mapkey = 0;
		while (reader.has_next()) {
			ar=reader.next();							/*get next read*/
			if (ar == null) {
				break;
			}
			if (first_time) {							/* check if hitting new chromosome. */
				current_chromosome = ar.get_chromosome();
				LB.notice("Current chromosome : " + current_chromosome);
				first_time = false;
			} else if (!ar.get_chromosome().equalsIgnoreCase(current_chromosome)) { //on the next chr
				reader.add_back(ar);
				break;						//stop iterating we have moved to the next chromosome.
			} 
			cur_reads.add(ar);
			cur_peak_start = ar.get_alignStart();
			cur_peak_end = ar.get_alignEnd();
			
			Boolean[] overlap_farenough = new Boolean[2]; //overlap and far_enough
			overlap_farenough[0] = false;
			overlap_farenough[1] = false;
			
			while (!overlap_farenough[1] && reader.has_next()) {
				AlignedRead r = next_overlap_read_PET(reader, cur_peak_end, overlap_farenough);
				if (r != null) {
					local_buffer.add(r);
				}
				if (overlap_farenough[0]) {
					while (local_buffer.size() > 0 ) {
						AlignedRead a = local_buffer.remove(0);
						frag_start = a.get_alignStart();
						frag_end = a.get_alignEnd();
						cur_peak_end = (frag_end > cur_peak_end) ? frag_end : cur_peak_end;
						cur_peak_start = (frag_start < cur_peak_start) ? frag_start : cur_peak_start;
						cur_reads.add(a);
					}
				} else if (overlap_farenough[1]) {
					reader.push_back(local_buffer);
					local_buffer.clear();
				} 
			}
			if (overlap_farenough[1]) { 			//means we know that the next set isn't an overlap with this peak.
				if (filter) {						//filter duplicates
					int filtered_reads = cur_reads.size();
					cur_reads = DuplicateFiltering.simplefilter(cur_reads);
					filtered_reads -= cur_reads.size();
					reads_filtered += filtered_reads;
				}
				if (cur_reads.size() == 1) {		//LanderWaterman Stats
					this.peaks.inc_LW_singles();
				} else if (cur_reads.size() == 2) {
					this.peaks.inc_LW_doubles();
				}
				
				/*Get the profile for the peak - store into Hashmap of int[]*/
//				LB.debug("All reads currently in queue:");
//				for (AlignedRead a : cur_reads) {
//					LB.debug(a.toString());
//				}
				
//				LB.debug("start: " + cur_peak_start + "\tend: " +cur_peak_end  );
				int[] coverage_array = Coverage.generatePeakHeight_PET(cur_reads, cur_peak_start, cur_peak_end);
				maps.put(coverage_array, cur_peak_start);
				this.peaks.merge(PeakLocator.process(LB, param, coverage_array,			//generate the peak description
						cur_peak_start, cur_peak_end, subpeaks, mapkey));					
				mapkey++;
				if (saturation) {
					feed_children(cur_reads);
				}
				reads_used  += cur_reads.size();
				cur_reads.clear();
				cur_reads = new Vector<AlignedRead>();		//init new peak 
			}
			if (local_buffer.size() > 0) {
				reader.push_back(local_buffer);
				local_buffer.clear();
			}
		}
		this.peaks.set_reads_used(reads_used);						// clean up at the end of the chromosome 
		this.peaks.set_reads_filtered(reads_filtered);
		maps.complete();
		LB.notice("Reads used: " + reads_used);
		if (reads_filtered > 0) {
			LB.notice("Reads filtered by duplicate: " + reads_filtered);
		}
		if (it.iterator().get_NumberFilteredRead() > 0) {
			LB.notice("Reads filtered by iterator: " + it.iterator().get_NumberFilteredRead());
		}		
	}

	/**
	 * 
	 * @param x
	 * @return
	 */
	private static final int base_to_int(char x) {
		char y = Character.toUpperCase(x);
		if (y == 'A') {
			return 0;
		} else if (y == 'C') { 
			return 1;
		} else if (y == 'G') { 
			return 2;
		} else if (y == 'T') { 
			return 3;
		}
		return -1;
	}
	
	
	/**
	 * @param offset
	 * @param region_end
	 * @param reads
	 * @param start
	 * @param end
	 * @return
	 */
	private static String GoldenPath(Vector<AlignedRead> reads, int offset, int region_end, int start, int end) {
		
		int span = region_end - offset + 1;
		int[][] chart = new int[span][4];
		String x = "";
		for (AlignedRead ar : reads) {
			String s = ar.get_sequence();
			int s_pos = ar.get_alignStart();
			for (int i = 0; i < s.length(); i++) {
				int b = base_to_int(s.charAt(i));
				if (b >= 0) {
					chart[s_pos - offset + i][ base_to_int(s.charAt(i)) ] ++;
				}
			}
		}
		if (start < 0) {
			start = 0;
		}
		for (int z = start; z < end; z++) {
			x += get_nucleotide(chart[z]);
		}
		return x;
	}

	/**
	 * Determines the nucleotide most observed at a position, when passed an
	 * array indicating the number of observed occurences. The structure is an int
	 * array[4], where [0] = 'A', [1] = 'C', [2] = 'G', [3] = 'T'.
	 * 
	 * @param a
	 * @return
	 */
	private static char get_nucleotide(int[] a) {
		assert (a.length == 4);
		if (a[0] > a[1]) {
			if (a[0] > a[2]) {
				if (a[0] > a[3]) 		{ return 'A'; }
				else if (a[0] < a[3]) 	{ return 'T'; }
				else 					{ return Utilities.get_canonical_char('A', 'T'); }
			} else if (a[0] < a[2]) {
				if (a[2] > a[3]) 		{ return 'G'; }
				else if (a[2] < a[3]) 	{ return 'T'; }
				else 					{ return Utilities.get_canonical_char('G', 'T'); }
			} else  {		// A and G are same 
				if (a[2] > a[3]) 		{ return Utilities.get_canonical_char('A', 'G'); }
				else if (a[2] < a[3])	{ return 'T'; }
				else					{ return 'N'; }
			}
		} else if (a[0] < a[1]) {
			if (a[1] > a[2]) {
				if (a[1] > a[3]) 		{ return 'C'; }
				else if (a[1] < a[3]) 	{ return 'T'; }
				else 					{ return Utilities.get_canonical_char('C', 'T'); }
			} else if (a[1] < a[2]) {
				if (a[2] > a[3]) 		{ return 'G'; }
				else if (a[2] < a[3]) 	{ return 'T'; }
				else 					{ return Utilities.get_canonical_char('G', 'T'); }
			} else  {		// C and G are same 
				if (a[2] > a[3]) 		{ return Utilities.get_canonical_char('C', 'G'); }
				else if (a[2] < a[3])	{ return 'T'; }
				else					{ return 'N'; }
			}
		} else { 			// A and C are the same
			if (a[1] > a[2]) {
				if (a[1] > a[3]) 		{ return Utilities.get_canonical_char('A', 'C'); }
				else if (a[1] < a[3]) 	{ return 'T'; }
				else 					{ return 'N'; }
			} else if (a[1] < a[2]) {
				if (a[2] > a[3]) 		{ return 'G'; }
				else if (a[2] < a[3]) 	{ return 'T'; }
				else 					{ return 'N'; }
			} else  {		// C and G are same 
				if (a[2] > a[3]) 		{ return 'N'; }
				else if (a[2] < a[3])	{ return 'T'; }
				else					{ return 'N'; }
			}
		}
	}
	

		
	/**
	 * Function to write out wig. bedgraph, peak file or RFile.
	 * @param dist
	 * @param pw
	 * @param wig
	 * @param bgw
	 * @param threshold
	 * @param ac
	 * @param normalize
	 */
	public void write_out_files(Distribution dist, PeakWriter pw,
			WigwriterBuffered wig, BedGraphWriter bgw, float threshold, ApplyControl ac, float normalize) {
		if (wig != null) {
			if (dist.intbased()) {
				int_based_output(pw, wig, threshold, ac, normalize);		
			} else {
				float_based_output(pw, wig, threshold, ac, normalize);	
			}
		} else if (bgw != null) {
			if (dist.intbased()) {
				int_based_output(pw, bgw, threshold, ac, normalize);		
			} else {
				float_based_output(pw, bgw, threshold, ac, normalize);	
			}
		} else {
			LB.warning("both bedgraph file and wigfile had null handles.  Neither file written out.");
		}
		
	}
	
	/**
	 * Function to write out wig, bedgraph, peak file or RFile.
	 * @param dist
	 * @param pw
	 * @param wig
	 * @param bgw
	 * @param threshold
	 */
	public void write_out_files(Distribution dist, PeakWriter pw,
			WigwriterBuffered wig, BedGraphWriter bgw, float threshold) {
		
		if (wig != null) {
			if (dist.intbased()) {
				int_based_output(pw, wig, threshold);		
			} else {
				float_based_output(pw, wig, threshold);	
			}
		} else if (bgw!= null) {
			if (dist.intbased()) {
				int_based_output(pw, bgw, threshold);		
			} else {
				float_based_output(pw, bgw, threshold);	
			}
			
		} else {
			LB.warning("wigfile handle was null.  Will not write out wig file.");
		}
	}
		
	private void int_based_output(PeakWriter pw, WigwriterBuffered wig, float threshold) {
		
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y); 
			if (pd.get_height() >= threshold) {
				pw.writePeak2(y, this.current_chromosome, pd,
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				wig.section_header(this.current_chromosome, pd.get_offset());
				Map_i a = this.maps.get_i(pd.get_hashkey());
				int[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc(); 			//convert genomic coordinates to relative coords
				for (int x = start; x <= start + pd.get_length(); x++) {
					wig.writeln(map[x]);
				}
			}
		}
	}
	
	private void int_based_output(PeakWriter pw, BedGraphWriter bgw, float threshold) {
		
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y); 
			if (pd.get_height() >= threshold) {
				pw.writePeak2(y, this.current_chromosome, pd,
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				bgw.new_section(this.current_chromosome, pd.get_offset());
				Map_i a = this.maps.get_i(pd.get_hashkey());
				int[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc(); 			//convert genomic coordinates to relative coords
				for (int x = start; x <= start + pd.get_length(); x++) {
					bgw.next_value(map[x]);
				}
			}
		}
	}
	
	private void int_based_output(PeakWriter pw, WigwriterBuffered wig, float threshold, ApplyControl ac, float normalize) {
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y);
			if (pd.get_height() >= threshold) {
				pw.writePeak3(y, this.current_chromosome, pd, ac.get_significance(pd.get_height(), normalize),
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				wig.section_header(this.current_chromosome, pd.get_offset());
				Map_i a = this.maps.get_i(pd.get_hashkey());
				int[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc();			//convert genomic coordinates to relative coords
				for (int x = start; x <= start + pd.get_length(); x++) {
					wig.writeln(map[x]);
				}
			}
		}
	}

	private void int_based_output(PeakWriter pw, BedGraphWriter bgw, float threshold, ApplyControl ac, float normalize) {
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y);
			if (pd.get_height() >= threshold) {
				pw.writePeak3(y, this.current_chromosome, pd, ac.get_significance(pd.get_height(), normalize),
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				bgw.new_section(this.current_chromosome, pd.get_offset());
				Map_i a = this.maps.get_i(pd.get_hashkey());
				int[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc();			//convert genomic coordinates to relative coords
				for (int x = start; x <= start + pd.get_length(); x++) {
					bgw.next_value(map[x]);
				}
			}
		}
	}
	
	
	/**
	 * 
	 * @param pw
	 * @param wig
	 * @param threshold
	 */
	private void float_based_output(PeakWriter pw, WigwriterBuffered wig, float threshold) {
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y);
			if (pd.get_height() >= threshold) {
				pw.writePeak2(y, this.current_chromosome, pd, 
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				wig.section_header(this.current_chromosome, pd.get_offset());
				Map_f a = this.maps.get_f(pd.get_hashkey());
				float[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc();			//convert genomic coordinates to relative coords
				for (int x = start; x <= start + pd.get_length(); x++) {
					wig.writeln(map[x]);
				}
			}
		}	
	}
	
	/**
	 * 
	 * @param pw
	 * @param bgw
	 * @param threshold
	 */
	private void float_based_output(PeakWriter pw, BedGraphWriter bgw, float threshold) {
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y);
			if (pd.get_height() >= threshold) {
				pw.writePeak2(y, this.current_chromosome, pd, 
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				bgw.new_section(this.current_chromosome, pd.get_offset());
				Map_f a = this.maps.get_f(pd.get_hashkey());
				float[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc();			//convert genomic coordinates to relative coords
				for (int x = start; x <= start + pd.get_length(); x++) {
					bgw.next_value(map[x]);
				}
			}
		}	
	}
	
	
	
	/* 
	 * @param pw
	 * @param wig
	 * @param threshold
	 * @param ac
	 */
	private void float_based_output(PeakWriter pw, WigwriterBuffered wig, float threshold, ApplyControl ac, float normalize) {
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y);
			if (pd.get_height() >= threshold) {
				pw.writePeak3(y, this.current_chromosome, pd, ac.get_significance(pd.get_height(), normalize), 
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				wig.section_header(this.current_chromosome, pd.get_offset());
				Map_f a = this.maps.get_f(pd.get_hashkey());
				float[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc();		//convert genomic coordinates to relative coords
				for (int x = start; x <= start +pd.get_length(); x++) {		
					wig.writeln(map[x]);
				}
			}
		}	
	}
	
	/**
	 * 
	 * @param pw
	 * @param bgw
	 * @param threshold
	 * @param ac
	 * @param normalize
	 */
	private void float_based_output(PeakWriter pw, BedGraphWriter bgw, float threshold, ApplyControl ac, float normalize) {
		for (int y = 0; y < this.peaks.get_size(); y++) {
			Peakdesc pd = this.peaks.get_peak(y);
			if (pd.get_height() >= threshold) {
				pw.writePeak3(y, this.current_chromosome, pd, ac.get_significance(pd.get_height(), normalize), 
						(this.seqs != null) ? this.seqs.get(pd.get_seq_key()) : "");
				bgw.new_section(this.current_chromosome, pd.get_offset());
				Map_f a = this.maps.get_f(pd.get_hashkey());
				float[] map = a.get_map();
				int start = pd.get_offset() - a.get_loc();		//convert genomic coordinates to relative coords
				for (int x = start; x <= start +pd.get_length(); x++) {		
					bgw.next_value(map[x]);
				}
			}
		}	
	}

	
	
	
	/**
	 * Getter - returns the peakstore generated.  May not be necessary.
	 * @return 
	 */
	public PeakStore get_peak_store()	{ return this.peaks; }
	/**
	 * Do null check 
	 * @return boolean
	 */
	public boolean is_null() {
		return (this.peaks == null) ? true : false; 
	}
	
	public boolean is_empty() {
		return (this.peaks.get_size() > 0) ? false : true;
	}
	
	/**
	 * Getter - returns the mapstore generated.  May not be necessary.
	 * @return 
	 */
	public MapStore get_map_store()		{ return this.maps; }
	
	/**
	 * Getter - returns the name of the chromosome that was most recently processed.
	 * @return 
	 */
	public String get_chromosome()		{ return this.current_chromosome; }
	
	/**
	 * Getter - returns the start_distributions compiled from this data set 
	 * @return 
	 */
	public int[] get_start_distribution() { 
		int[] tmp = new int[this.start_map.length];
		System.arraycopy(this.start_map, 0, tmp, 0, this.start_map.length);
		return tmp; 
	}

	/**
	 * getter to return the list of peak descriptions as an array
	 * @return
	 */
	public Peakdesc[] get_array_of_peakdesc() {
		return this.peaks.get_array_of_peaks();

	}
	
	/**
	 * 
	 * @param idx
	 * @param start in genomic coordinates.
	 * @param end
	 * @return
	 */
	public float highest_point(int idx, int start, int end) {
		Peakdesc n = this.peaks.get_peak(idx);					//get peak
		int offset = n.get_offset();
		int s = start-offset;	
		if (s < 0) {											//make sure you're not going out of bounds
			s = 0;
		}
		int g = (n.get_length() + offset);			//the genomic coordinate of the end of the read of interest
				//calcualate the relative coordinate of the end of the read of interest 
		int e = (end > g) ? n.get_length() : (end - offset);		
		return this.maps.get_max_height(n.get_hashkey(), s, e);
	}

	public int get_peak_location(int key) {
		Peakdesc p = this.peaks.get_peak(key);
		return (p.get_max_loc() + p.get_offset()); 
	}
	
	public Peakdesc get_peak(int key) {
		Peakdesc p = this.peaks.get_peak(key);
		return p; 
	}
	
	
}

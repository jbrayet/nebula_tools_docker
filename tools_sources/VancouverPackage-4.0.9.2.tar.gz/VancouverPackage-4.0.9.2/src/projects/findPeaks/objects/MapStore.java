package src.projects.findPeaks.objects;

import java.util.Vector;

import src.lib.ioInterfaces.Log_Buffer;
import src.projects.findPeaks.Functions;

public class MapStore {
	private static boolean display_version = true;
	
	private Vector<Map_i> temp_maps_i;
	private Vector<Map_f> temp_maps_f;
	private static Log_Buffer LB;
	
	private boolean finalized = false;
	private Map_i[] maps_i;
	private Map_f[] maps_f;
	
	public final boolean int_based;
	
	public MapStore(Log_Buffer logbuffer, boolean intbased) {
		LB = logbuffer;
		int_based = (intbased) ? true : false;
		
		if (display_version) {
			LB.Version("MapStore", "$Revision: 1335 $");
			display_version = false;
		}
		if (int_based) {
			this.temp_maps_i = new Vector<Map_i>();
		} else {
			this.temp_maps_f = new Vector<Map_f>();
		}
	}
	
	public void put(int[] value, int loc) {
		Map_i a = new Map_i(value, loc);
		this.temp_maps_i.add(a);
	}
	
	public void put(float[] value, int loc) {
		Map_f a = new Map_f(value, loc);
		this.temp_maps_f.add(a);
	}

	public void complete() {
		if (finalized) {
			LB.error("This data set has already been finalized!");
		}
		if (int_based) {
			this.maps_i = temp_maps_i.toArray(new Map_i[temp_maps_i.size()]);
			this.temp_maps_i.clear();
			finalized = true;
		} else {
			this.maps_f = temp_maps_f.toArray(new Map_f[temp_maps_f.size()]);
			this.temp_maps_f.clear();
			finalized = true;
		}
	}
	
	
	public void clear() {
		if (int_based) {
			this.maps_i = null;
			if (this.temp_maps_i != null) {
				this.temp_maps_i = null;
			}
		} else {
			this.maps_f = null;
			if (this.temp_maps_f != null) {
				this.temp_maps_f = null;
			}
		}
	}
	
	public int get_coverage() {
		return get_coverage(0);
	}
	
	public Map_i get_i(int key) {
		return this.maps_i[key];
	}
	
	public Map_f get_f(int key) {
		return this.maps_f[key];
	}
	
	public int get_coverage(float min_ht) {
		int coverage = 0;
		if (!finalized) {
			LB.error("Coverage scanned before dataset was finalized.");
			return -1;
		}
		if (int_based) {
			int min_ht_i = (int) min_ht;
			for (Map_i y: maps_i) {
				int[] x = y.get_map();
				for (int z : x) {
					if (z >= min_ht_i) {
						coverage++;
					}
				}
			}
		} else {
			for (Map_f y: maps_f) {
				float[] x = y.get_map();
				for (float z : x) {
					if (z >= min_ht) {
						coverage++;
					}
				}
			}
			
		}
		return coverage;
	}

	/**
	 * Return the location of the maximum in the array specified by the hashkey of the peak.
	 * @param key
	 * @return
	 */
	public int get_max_location(int key) {
		if (int_based) {
			return Functions.maximum_and_location(maps_i[key]).get_second();
		} else {
			return Functions.maximum_and_location(maps_f[key]).get_second();
		}
	}
	
	
	/**
	 * 
	 * @param key
	 * @param start - Start and end must be relative to the map itself.
	 * @param end
	 * @return
	 */
	public float get_max_height(int key, int start, int end) {
		float max = 0;
		if (int_based) {
			Map_i map = maps_i[key];
			int[] m = map.get_map(); 
			if (end >= m.length) {
				end = m.length -1;
			}
			for (int x = start; x <=end; x++) {
				if (m[x] > max) {
					max = m[x];
				}
			}
		} else {
			Map_f map = maps_f[key];
			float[] m = map.get_map();
			if (end >= m.length) {
				end = m.length -1;
			}
			for (int x = start; x <=end; x++) {

				if (m[x] > max) {
					max = m[x];
				}
			}
		}
		return max;
	}
	
	public int size() {
		if (int_based) {
			return maps_i.length;
		} else {
			return maps_f.length;
		}
	}
	
}

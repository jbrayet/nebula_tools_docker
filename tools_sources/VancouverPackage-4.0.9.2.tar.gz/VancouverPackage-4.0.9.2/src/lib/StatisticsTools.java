package src.lib;

public class StatisticsTools {

	
	private StatisticsTools() {}
	
	private static final double[] C;

	static {
		C = new double[1000];
		C[0] = 1;
		for (int k = 1; k < C.length; k++) {
			C[k] = 0;
			for (int m = 0; m <= k - 1; m++) {
				C[k] += (C[m] * C[k - 1 - m]) / ((m + 1) * (2 * m + 1));
			}
		}
	}
	
	
	
	/**
	 * Error Function
	 *
   	 * <br><a href="http://en.wikipedia.org/wiki/Error_function">erf()&nbsp;@&nbsp;Wikipedia</a>
   	 * <br><a href="http://mathworld.wolfram.com/Erf.html">erf()&nbsp;@&nbsp;Wolfram MathWorld</a>

	 * @param anArg
	 * @return
	 */
	public static double erf(final double anArg) {
		double retVal = 0;
		final double tmpSqr = anArg * anArg;
		double tmpVal = 0;

		for (int n = 0; n <= 60; n++) {
			tmpVal = anArg / (2 * n + 1);
			for (int i = 1; i <= n; i++) {
				tmpVal *= -tmpSqr / i;
			}
			retVal += tmpVal;
		}
		return 2 * retVal / Math.sqrt(Math.PI);
	}

	
	/**
	 * Inverse Error Function
	 *
	 * <br><a href="http://en.wikipedia.org/wiki/Error_function">erf()&nbsp;@&nbsp;Wikipedia</a>
	 * <br><a href="http://mathworld.wolfram.com/Erf.html">erf()&nbsp;@&nbsp;Wolfram MathWorld</a>
	 * @param anArg
	 * @return
	 */
	public static double erfi(final double anArg) {
		double retVal = 0;
			for (int k = 500; k >= 0; k--) {
				retVal += C[k] * (StrictMath.pow(Math.sqrt(Math.PI) * anArg / 2, 2 * k + 1)) / (2 * k + 1);
			}
		return retVal;
	}
	
}

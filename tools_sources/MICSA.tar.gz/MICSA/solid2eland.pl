#!/usr/bin/perl

use strict;
use warnings;
use diagnostics;

my $usage = qq{
    solid2eland.pl

    -----------------------------
    mandatory parameters:
    
    -f solid_file               	solid txt file to convert (made by mapview)
    -o output_file            		save coordinates here
    
    -----------------------------
    optional parameters:
    
    none			
};

if(scalar(@ARGV) == 0){
    print $usage;
    exit(0);
}

## mandatory arguments

my $solid_fname = "";
my $output_fname = "";

## optional arguments

## parse command line arguments

while(scalar(@ARGV) > 0){
    my $this_arg = shift @ARGV;
    if ( $this_arg eq '-h') {print "$usage\n"; exit; }

    elsif ( $this_arg eq '-f') {$solid_fname = shift @ARGV;}
    elsif ( $this_arg eq '-o') {$output_fname = shift @ARGV;}

    elsif ( $this_arg =~ m/^-/ ) { print "unknown flag: $this_arg\n";}
}


if ( $solid_fname eq ""){
    die "you should specify solid txt file\n";
}
if( $output_fname eq ""){
    die "you should specify output file\n";
}

## print parameters

print "\n-----------------\n\n";
print "maq txt file file: $solid_fname \n";
print "output file: $output_fname\n";

print "\n-----------------\n\n";

open FILE, "< $solid_fname " || die "$solid_fname : $!\n";


if(-e $output_fname){ unlink("$output_fname");}
open OUT, "> $output_fname" || die "$output_fname: $!\n";

while(<FILE>){
	
   chomp;	
   my @fields = split(/,/,$_);
    if(scalar(@fields) >= 2){	
	my $seqField = $fields[1];
	my $read_name = $fields[0];
	$read_name =~ s/>//;
	my @cur_fields = split(/[_\.]/,$seqField );
	
	my $cur_seq = $cur_fields[0];		
	$cur_seq = "chr".$cur_seq;


	my $read= <FILE>;
	chomp ($read);
	
	my $cur_coord = $cur_fields[1];
	my $cur_orient = 'F';
	if ($cur_coord<0) {
		$cur_orient = 'R';
		$cur_coord = -$cur_coord;
	}	
		
	my $quality = 30;	
	my $map = "U0"; 		

	my $mism = "0\t0\t0";	
	
	print OUT ">$read_name\t$read\t$map\t$mism\t$cur_seq\t$cur_coord\t$cur_orient\t..\n";
	
    }
}

close FILE;
close OUT;


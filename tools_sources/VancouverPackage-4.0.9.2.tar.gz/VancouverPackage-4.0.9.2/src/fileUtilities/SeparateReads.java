package src.fileUtilities;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.zip.GZIPOutputStream;

import src.lib.CurrentVersion;
import src.lib.ioInterfaces.FileOut;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.AlignedRead;


/**
 * Separate Eland files based on chromosome 
 * output is <chr>.part.eland based
 * upon matthew Bainbridge's SeparateReads.java
 * 
 * @author Genome Sciences Centre
 * @version $Revision: 1559 $
 */

public class SeparateReads {
	
	private static final int INIT_SIZE = 40;
	private static Log_Buffer LB;
	
	/** Dummy Constructor */
	private SeparateReads() {}
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length < 3) {
			// ESCA-JAVA0266:
			System.out.println("usage: <Format> <Input file> <output path/> [name]");
			System.exit(0);
		}
		String output_path = args[2];
		if (!output_path.endsWith(System.getProperty("file.separator"))) {
			output_path = output_path.concat(System.getProperty("file.separator")); 
		}
		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		LB.addLogFile(output_path + "SeparateReads.log");
		Thread th = new Thread(LB);
		th.start();
		new CurrentVersion(LB);
		LB.Version("SeparateReads", "$Revision: 1559 $");
		String aligner = args[0];
		Hashtable<String, BufferedWriter> ht = new Hashtable<String, BufferedWriter>(INIT_SIZE);
		Hashtable<String, int[]> cntht = new Hashtable<String, int[]>(INIT_SIZE);
		String ex_name = "part";
		if (args.length > 3) {
			ex_name = args[3];
		}
		int cnt = 0;
		Generic_AlignRead_Iterator it = new Generic_AlignRead_Iterator(LB, args[0],
				"source", args[1], 0, 0, null,	0,false);
		AlignedRead alnrd = null;
		while (it.hasNext()) {
			cnt++;
			if (cnt % 1000000 == 0) {
				LB.notice(cnt + " lines processed.");
			}
			try { 
				alnrd = it.next();
			} catch (NoSuchElementException nsee) {
				continue;
			}
			String chrname = alnrd.get_chromosome();
			chrname = chrname.replace('>', ' ');
			chrname = chrname.trim();
			BufferedWriter bw = ht.get(chrname);// seqName = chrname!
			int[] I = cntht.get(chrname);
			if (bw == null) {		
				try {
					bw = new BufferedWriter(new OutputStreamWriter
							(new GZIPOutputStream(new FileOutputStream(
							 output_path + chrname + "." + ex_name + "." + aligner +".gz"))));
				} catch (IOException io) {
					LB.error("Could not create ." + aligner + " .gz file.");
					LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
					LB.die();
				}
				assert (bw != null);
				ht.put(chrname, bw);
				I = new int[1];
				cntht.put(chrname, I);
			}
			I[0]++;
			try {
				if (aligner.equalsIgnoreCase("eland")) {
					bw.write(alnrd.outEland());
				} else if (aligner.equalsIgnoreCase("elandext")) {
					bw.write(alnrd.outElandExt());
				} else if (aligner.equalsIgnoreCase("gff")) {
					bw.write(alnrd.outGff());
				} else if (aligner.equalsIgnoreCase("bed")) {
					bw.write(alnrd.outBed());
				} else if (aligner.equalsIgnoreCase("mapview")) {
					bw.write(alnrd.outMapview());
				} else if (aligner.equalsIgnoreCase("bowtie")) {
					bw.write(alnrd.outBowtie());
				}
				bw.newLine();
			} catch (IOException io) {
				LB.error("Could not write to file.");
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
		}
		it.close();
		Enumeration<String> keys = ht.keys();
		LB.notice("Found " + cnt + " records.");
		
		FileOut meta = new FileOut(LB, output_path + "meta_info.txt", false);
		meta.write("total\t" + cnt + "\n");
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			int[] I = cntht.get(key);
			LB.notice(key + "." + ex_name + "." + aligner +".gz\t" + I[0]);
			meta.writeln(key + "." + ex_name + "." + aligner + ".gz\t" + I[0]);
			BufferedWriter fw = ht.get(key);
			try {
				fw.close();
			} catch (IOException io) {
				LB.warning("Could not close file.");
				LB.warning("Message from java environment (may be null: " + io.getMessage());
			}
		}
		meta.close();
		LB.close();
	}
}

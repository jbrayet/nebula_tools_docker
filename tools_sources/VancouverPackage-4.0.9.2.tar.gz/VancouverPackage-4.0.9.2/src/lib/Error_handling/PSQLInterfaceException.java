package src.lib.Error_handling;

/**
 * @author GPL Software
 * @version "$Revision: 1385 $"
 */

public class PSQLInterfaceException extends Exception {
       
	/**
	 * Generated serialVersion.  I have no idea how this works.
	 */
	private static final long serialVersionUID = -6920930465050665497L;

	public PSQLInterfaceException(String message) {
		super(message);
	}
	
}

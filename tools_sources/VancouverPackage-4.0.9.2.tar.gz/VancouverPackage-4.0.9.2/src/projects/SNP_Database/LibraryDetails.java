package src.projects.SNP_Database;

import java.io.*;


import src.lib.CurrentVersion;
import src.lib.ioInterfaces.Log_Buffer;
import src.projects.SNP_Database.objects.Library;

public class LibraryDetails {

	private static Log_Buffer LB = null;

	private LibraryDetails() {}
	
	public static void main(String[] args) {

		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		
		// open up standard input
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String LibraryName = null;

		new CurrentVersion(LB);
		LB.Version("LibrairyDetails", "$Revision: 1615 $");

		LB.query("Enter the name of the library you wish to update : ");
		try {
			LibraryName = br.readLine();
		} catch (IOException ioe) {
			LB.error("IO error trying to read library name!");
			System.exit(1);
		}

		PSQLInterface.init(LB, args[0]);
		Library a = PSQLInterface.get_library_info(LibraryName);
		String temp = null;
		/*private static String[] fields  = {
		"library_id", "name", "seq_type", "read_length", "read_length_alt", 
		"sample_type", "sample_desc", "sample_organ", "sample_notes", "sample_cell_type"};*/

		LB.notice("Library ID : " + a.get_Library_id());
		LB.notice("Library Name : " + a.get_Name());
		LB.query("Seq_type [" + a.get_Seq_type() + "] : ");
		temp = get_line(br);

		if ((a.get_Seq_type() != null && a.get_Seq_type().compareTo(temp) != 0) || temp.compareTo("") != 0 ){
			a.set_Seq_type(temp);
		}			

		LB.query("Read Length [" + a.get_Read_length() + "] : ");
		temp = get_line(br);
		if (temp.compareTo("") != 0) {
			int t = Integer.valueOf(temp);
			if (a.get_Read_length() != t) {
				a.set_Read_length(t);
			}
		}
		LB.query("Read Length Alt [" + a.get_Read_length_alt() + "] : ");
		temp = get_line(br);
		if (temp.compareTo("") != 0) {
			int t = Integer.valueOf(temp);
			if (a.get_Read_length_alt() != t) {
				a.set_Read_length_alt(t);
			}
		}
		LB.query("Sample Type [" + a.get_Sample_type() + "] : ");
		temp = get_line(br);
	
		if ((a.get_Sample_type() != null && a.get_Sample_type().compareTo(temp) != 0) || temp.compareTo("") != 0 ){
			a.set_Sample_type(temp);
		}

		LB.query("Sample Desc [" + a.get_Sample_desc() + "] : ");
		temp = get_line(br);

		if ((a.get_Sample_desc() != null && a.get_Sample_desc().compareTo(temp) != 0) || temp.compareTo("") != 0 ){
			a.set_Sample_desc(temp);
		}

		LB.query("Sample Organ [" + a.get_Sample_organ() + "] : ");
		temp = get_line(br);

		if ((a.get_Sample_organ() != null && a.get_Sample_organ().compareTo(temp) != 0) || temp.compareTo("") != 0 ){
			a.set_Sample_organ(temp);
		}

		LB.query("Sample Notes [" + a.get_Sample_notes() + "] : ");
		temp = get_line(br);

		if ((a.get_Sample_notes() != null && a.get_Sample_notes().compareTo(temp) != 0) || temp.compareTo("") != 0 ){
			a.set_Sample_notes(temp);
		}

		LB.query("Sample Cell type [" + a.get_Sample_cell_type() + "] : ");
		temp = get_line(br);

		if ((a.get_Sample_cell_type() != null && a.get_Sample_cell_type().compareTo(temp) != 0) || temp.compareTo("") != 0 ){
			a.set_Sample_cell_type(temp);
		}

		boolean success = PSQLInterface.set_library_info(a);

		if (success) {
			LB.notice("Record Updated");
		} else {
			LB.notice("Record failed to update");
		}
		LB.close();

	}

	public static String get_line (BufferedReader br) {
		String t = null;
		try {
			t = br.readLine();
		} catch (IOException io) {
			LB.error(io.getMessage());
		}
		if (t == null) {
			LB.error("null recorded");
		}
		return t;
	}
	
	
	
}

package src.lib.objects;


/**
 * @version $Revision: 463 $
 * @author 
 */
public class SNPLine {
	//example line
	//10,135059763,5,6,A,novel
	private String Chromosome;
	private int position;
	private int observed;
	private int coverage;
	private char newbase;
	private String type;

	public SNPLine() {
		Chromosome = null;
		position   = -1;
		observed   = -1;
		coverage   = -1;
		newbase    =  0;
		type       = null;
	}

	/**
	 * get the name of the Chromosome location of the object
	 * @return String
	 */
	public final String get_Chromosome() { return this.Chromosome; }
	/** 
	 * get the position of the SNP
	 * @return
	 */
	public final int get_position() { return this.position; }
	/**
	 * get the number of times the SNP was observed 
	 * @return 
	 * */
	public final int get_observed() { return this.observed; }
	/**
	 * get the coverage - total times reads cover this base 
	 * @return 
	 */
	public final int get_coverage() { return this.coverage; }
	/**
	 * get the new base - the letter of the SNP
	 * @return
	 */
	public final char get_newbase() { return this.newbase; }
	/**
	 * get the type of SNP 
	 * @return
	 */ 
	public final String get_type() { return this.type; }

	/**
	 * Function for modifying the properties of a SNP
	 * @param c
	 */
	public final void set_Chromosome(String c) { this.Chromosome = c; }
	/**
	 * Function for modifying the properties of a SNP
	 * @param c
	 */
	public final void set_position(int c) { this.position = c; }
	/**
	 * Function for modifying the properties of a SNP
	 * @param c
	 */
	public final void set_observed(int c) { this.observed = c; }
	/**
	 * Function for modifying the properties of a SNP
	 * @param c
	 */
	public final void set_coverage(int c) { this.coverage = c; }
	/**
	 * Function for modifying the properties of a SNP
	 * @param c
	 */
	public final void set_newbase(char c) { this.newbase = c; }
	/**
	 * Function for modifying the properties of a SNP
	 * @param c
	 */
	public final void set_type(String c) { this.type = c; }
	
	
}
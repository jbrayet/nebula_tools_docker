package src.lib.objects;

public class SeqReducedAlignedRead  {
		
	private final boolean direction;
	private final boolean pair;
	private final byte snpcount;
	private final int alignstart;
	private final String sequence;
	private final String chr;

	
	// ESCA-JAVA0138:
	public SeqReducedAlignedRead(boolean direction, int start, String sequence, String Chromosome, boolean pair, byte snp_count ) {
		this.sequence = sequence;
		this.chr = Chromosome;
		this.direction = direction;
		this.alignstart = start;
		this.pair = pair;
		this.snpcount = snp_count;
		
	}
	
	public String get_sequence() { return this.sequence; }
	public String get_chromosome() { return this.chr; }
	public boolean get_direction() { return this.direction; }
	public boolean get_pair() { return this.pair; }
	public int get_alignstart() { return this.alignstart; }
	public int get_snpcount() { return this.snpcount; }
}

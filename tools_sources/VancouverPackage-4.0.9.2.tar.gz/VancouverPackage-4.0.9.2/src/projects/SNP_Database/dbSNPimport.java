package src.projects.SNP_Database;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;


import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.IterableIterator;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.Error_handling.PSQLInterfaceException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;
import src.projects.SNP_Database.SnpIterators.Generic_SNP_Iterator;

public class dbSNPimport {

	private static Log_Buffer LB = null;
	private static String input_file = null;
	private static String psql_file = null;
	
	private dbSNPimport() {}
	
	
	private static void parse_input(HashMap<String, String> Variables) {
		if (Variables == null) {
			usage();
		}
		assert (Variables != null);

		if (Variables.containsKey("help")) {
			usage();
		}


		if (Variables.containsKey("input_file")) {
			CommandLine.test_parameter_count(LB, "input_file", Variables.get("input_file"), 1);
			input_file = Variables.get("input_file");
			LB.notice(" * Input file        : " + input_file);
			if (Variables.containsKey("input")) {
				LB.warning("Ignoring -input flag.  Redundant with -input_file flag.");
			}
		} else { 
			LB.error("An input file must be supplied with the -input_file flag" );
			usage();
		}

		if (Variables.containsKey("psql")) {
			CommandLine.test_parameter_count(LB, "psql", Variables.get("psql"), 1);
			psql_file= Variables.get("psql");
			LB.notice(" * PSQL config file  : " + psql_file);
		} else { 
			LB.error("A psql config file must be supplied with the -psql flag" );
			usage();
		}
		
		
		Variables.remove("input_file");
		Variables.remove("psql");

		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  * " + k);
			}
			LB.die();
		}
	}

	public static void usage() {
		LB.notice(" available flags: -input_file <filename> -psql <filename>");
		LB.die();
	}
	
	
	
	public static void main(String[] args) {

		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		new CurrentVersion(LB);
		LB.Version("dbSNPimport", "$Revision: 1703 $");
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables);									//interprets command line args.
		PSQLInterface.init(LB, psql_file);
		Generic_SNP_Iterator gsi = new Generic_SNP_Iterator(LB, "dbSNP", input_file);
		ArrayList<SNP> VSNP = new ArrayList<SNP>();
		
		int count = 0;
		LB.notice("Reading in SNPs");
		while (gsi.hasNext()) {
			SNP s = gsi.next();
			VSNP.add(s);
			count += 1;
			if (count % 50000 == 0) {
				try {
					PSQLInterface.insert_dbSNP(VSNP, "hg18");
				} catch (PSQLInterfaceException e) {
					LB.notice(e.getMessage());
				}
				VSNP.clear();		
			}
		}
		LB.notice("Inserting SNPs to DB");
	
		
		try {
			PSQLInterface.insert_dbSNP(VSNP, "hg18");
			PSQLInterface.vacuum_db();
		} catch (PSQLInterfaceException e) {
			LB.notice(e.getMessage());
		}
		VSNP.clear();
		LB.die();
	}
	

	public static String get_line (BufferedReader br) {
		String t = null;
		try {
			t = br.readLine();
		} catch (IOException io) {
			LB.notice(io.getMessage());
		}
		if (t == null) {
			LB.notice("null recorded");
		}
		
		return t;
	}
	
	
	
}

package src.projects.findPeaks.FDR;

/**
 *
 * Code licence: "Free, but reference me in your project", thus:
 * @author inspired by http://www.mhsatman.com
 * 
 * Code modified from original available for download.
 *  
 * @version $Revision: 1535 $
 */

public class Multivariate {

	private Matrix A;

	public Multivariate(Matrix A) {
		this.A = A;
	}

	public Matrix CovarianceMatrix() {
		Matrix temp = new Matrix(A.myData);
		Matrix meanVector = temp.getMean();
		for (int i = 0; i < A.n; i++) {
			for (int j = 0; j < A.m; j++) {
				temp.myData[i][j] = temp.myData[i][j] - meanVector.myData[0][j];
			}
		}
		return temp.Transpose().Mult(temp).scalerMult(1.0D / ((double) A.n - 1.0D));
	}

	public Matrix Mahalanobis() {
		Matrix temp = new Matrix(A.myData);
		Matrix cov = CovarianceMatrix();
		Matrix inv = cov.Inverse();
		Matrix ret = new Matrix(1, A.n);
		Matrix meanVector = temp.getMean();
		Matrix row = new Matrix(1, A.m);
		for (int i = 0; i < A.n; i++) {
			row = A.getRow(i);
			ret.myData[0][i] = row.Diff(meanVector).Mult(inv).Mult(row.Diff(meanVector).Transpose()).myData[0][0];
		}
		return ret;
	}

}
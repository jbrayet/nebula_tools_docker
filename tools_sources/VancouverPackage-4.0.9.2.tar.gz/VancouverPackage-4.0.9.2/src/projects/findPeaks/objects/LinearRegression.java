package src.projects.findPeaks.objects;

import java.math.BigDecimal;
import java.util.Vector;

import src.lib.FloatingPoint;
import src.lib.ioInterfaces.Log_Buffer;

// ESCA-JAVA0100:
public class LinearRegression {

	private static Log_Buffer LB;
	private static boolean display_version = true;
	
	private PeakPairIdx[] dataset;  //first value is x, second value is y
	private BigDecimal n = BigDecimal.ZERO;
	private BigDecimal slope = BigDecimal.ZERO;
	private BigDecimal intercept = BigDecimal.ZERO;
	private BigDecimal Sxy = BigDecimal.ZERO;
	private BigDecimal Sxx = BigDecimal.ZERO;
	private BigDecimal Syy = BigDecimal.ZERO;
	private BigDecimal Sy2 = BigDecimal.ZERO; //Sum (yi^2)
	private BigDecimal Sx2 = BigDecimal.ZERO; //sum (xi^2);
	private BigDecimal Sy = BigDecimal.ZERO;
	private BigDecimal Sx = BigDecimal.ZERO;
	private BigDecimal X_bar = BigDecimal.ZERO;
	private BigDecimal Y_bar = BigDecimal.ZERO;
	
	/*stored as pairs of alpha/t for n = infinity*/
	private static final double[][] ttest = { { 0.4, 0.253347 }, { 0.25, 0.674490 }, { 0.10, 1.281552 }, { 0.05, 1.644854 },
								{ 0.025, 1.95996 }, { 0.01, 2.32635 } , { 0.005, 2.57583 }, { 0.0005, 3.2905 } }; 


	
	public static boolean valid_alpha( float a) {
		for (double[] d : ttest) {
			if (FloatingPoint.are_values_equal(d[0], a)) {
				return true;
			}
		}
		StringBuffer sb = new StringBuffer();
		sb.append("alpha value supplied is not valid.  Please use one of the following values: \n");
		for (double[] d : ttest) {
			sb.append("\t" + d[0]);
		}
		LB.error(sb.toString());
		return false;
	}
	
	/**
	 * This module works only for linear regression in the positive quadrant. If
	 * values are negative, it will result in excessive recalculations.
	 * 
	 * @param logbuffer
	 * @param d
	 */
	public LinearRegression(Log_Buffer logbuffer, PeakPairIdx[] d) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("LinearRegression", "$Revision: 987 $");
			display_version = false;
		}
		this.dataset = new PeakPairIdx[d.length];
		System.arraycopy(d, 0, this.dataset, 0, d.length);
		this.n = get_n();
		if (this.dataset.length < 120) {
			LB.warning("sample size is smaller than 120, so t values used are probably not accurate.");
		}
		Sums_and_squares();
		this.slope = slope_calc();
		this.intercept = intercept_calc();
	}
	
	
	private final BigDecimal get_n() {
		return BigDecimal.valueOf(this.dataset.length);
	}
	
	private final void Sums_and_squares() {	
		for (int a = 0; a < this.dataset.length; a++) { 
			Sx  = Sx .add(BigDecimal.valueOf(this.dataset[a].get_height_1()));
			Sx2 = Sx2.add(BigDecimal.valueOf(this.dataset[a].get_height_1() * this.dataset[a].get_height_1()));
			Sy  = Sy .add(BigDecimal.valueOf(this.dataset[a].get_height_2()));
			Sy2 = Sy2.add(BigDecimal.valueOf(this.dataset[a].get_height_2() * this.dataset[a].get_height_2()));
			Sxy = Sxy.add(BigDecimal.valueOf(this.dataset[a].get_height_1() * this.dataset[a].get_height_2()));
		}
		this.X_bar = Sx.divide(n, BigDecimal.ROUND_HALF_EVEN);
		this.Y_bar = Sy.divide(n, BigDecimal.ROUND_HALF_EVEN);
		
		this.Sxy = Sxy.subtract((Sx.multiply(Sy)).divide(n, BigDecimal.ROUND_HALF_EVEN));
		this.Sxx = Sx2.subtract((Sx.multiply(Sx)).divide(n, BigDecimal.ROUND_HALF_EVEN)); 
		this.Syy = Sy2.subtract((Sy.multiply(Sy)).divide(n, BigDecimal.ROUND_HALF_EVEN)); 
	}
	
	private final BigDecimal slope_calc() {
		return (Sxy.divide(Sxx, BigDecimal.ROUND_HALF_EVEN));
	}
	
	private final BigDecimal intercept_calc() {
		return Y_bar.subtract(this.slope.multiply(X_bar));
	}
		
	private final BigDecimal Sigma2() {
		BigDecimal SSE = Syy.subtract(this.slope.multiply(Sxy));
		return SSE.divide(n.subtract(BigDecimal.valueOf(2)), BigDecimal.ROUND_HALF_EVEN);
	}
	
	private static final double t_at_a(double a) {
		for (double[] d : ttest) {
			if (FloatingPoint.are_values_equal(d[0], a)) {  
				return d[1];
			}
		}
		StringBuffer s = new StringBuffer();
		for (double[] d : ttest) {
			s.append(" " + d[0]);
		}
		LB.error("Invalid alpha provided. Must be one of:" + s);
		return 0;
	}
	
	public final PeakPairIdx[] filter(double alpha, int minimum) {
		Vector<PeakPairIdx> f = new Vector<PeakPairIdx>();
		double t = t_at_a(alpha);
		for (PeakPairIdx d : this.dataset) {
			if (d.get_height_1() < minimum && d.get_height_2() < minimum) {
				continue;
			}
			BigDecimal mu_bar = this.intercept.add(this.slope.multiply(BigDecimal.valueOf(d.get_height_1())));
			BigDecimal c = BigDecimal.valueOf(d.get_height_1()).subtract(X_bar);
			BigDecimal b = (c.multiply(c));
			c = (b.divide(Sxx, BigDecimal.ROUND_HALF_EVEN));
			BigDecimal e = BigDecimal.ONE;
			e = e.divide(n, BigDecimal.ROUND_HALF_EVEN);
			b = c.add(e).add(BigDecimal.ONE);
			c = b.multiply(Sigma2());
			b = BigDecimal.valueOf(t*Math.sqrt(c.doubleValue()));
			
		
			if (d.get_height_2() > (mu_bar.add(b)).doubleValue()  && d.get_pk_idx_2() != -1) {
				f.add(d);
			} else if (d.get_height_2() < (mu_bar.subtract(b)).doubleValue()  && d.get_pk_idx_1() != -1) {
				f.add(d);
			}
		}		
		return f.toArray(new PeakPairIdx[f.size()]);
	}
	
	
	public final void destroy() {
		this.dataset = null;
	}
	
	public final void write_data() {
		LB.notice("n:         " + this.n);
		LB.notice("Sx:        " + this.Sx);
		LB.notice("Sy:        " + this.Sy);
		LB.notice("X_bar:     " + this.X_bar);
		LB.notice("Y_bar:     " + this.Y_bar);
		LB.notice("Sxy:       " + this.Sxy);
		LB.notice("Sx2:       " + this.Sx2);
		LB.notice("Sy2:       " + this.Sy2);
		LB.notice("Sxx:       " + this.Sxx);
		LB.notice("Syy:       " + this.Syy);
		LB.notice("slope:     " + this.slope);
		LB.notice("intercept: " + this.intercept);
		LB.notice("Sigma2:    " + Sigma2());		
	}
	
}

package src.projects.findPeaks.objects;

import java.io.IOException;

import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.WigwriterBuffered;
import src.projects.findPeaks.PeakDataSetParent;
import src.projects.findPeaks.filewriters.PeakWriter;
import src.projects.findPeaks.filewriters.RegionWriter;

public class Compare {

	private static Log_Buffer LB;
	private static boolean display_version = true;
	
	public Compare(Log_Buffer logbuffer) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("CompareObject", "$Revision: 1766 $");
			display_version = false;
		}
	}
	
	
	private PeakPairIdx[] pairs = null;
	
	
	public void set_pairs(PeakPairIdx[] p) {
		pairs = p;
	}
	
	public void log_transform() {
		for (PeakPairIdx p: pairs) {
			p.log_transform();
		}
	}
	
	public void reverse_log() {
		for (PeakPairIdx p: pairs) {
			p.log_revert();
		}
	}
	
	public int size() {
		return this.pairs.length;
	}
	
	public PeakPairIdx[] get_array() {
		return pairs;
	}
	
	public float get_lowest_sample_ht() {
		if (pairs.length == 0) {
			return 0;
		}
		float l = pairs[0].get_height_1();
		for (PeakPairIdx p: pairs ) {
			if (p.get_height_1() < l ) {
				l = p.get_height_1();
			}
		}
		return l;
	}

	// ESCA-JAVA0138:
	public void write_out_regions(String file, PeakDataSetParent sample,
			PeakDataSetParent control, String chromosome, int minimum, int window_size, float alpha) {
		try {
			RegionWriter rw = new RegionWriter(LB, file);
			rw.generate_region_file(sample, control, this.get_array(), chromosome, alpha, minimum, window_size);
			rw.close();
		} catch (IOException io) {
			LB.error("Error writing header to Region file - could not create file.");  //any other exception is handled
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());	//in the writer itself.
			LB.die();
		}
	}

	public void write_out_filtered_peaks(String file_name, String file_suffix, PeakDataSetParent sample,
			PeakDataSetParent control, String chromosome) {
		try {
			PeakWriter pw_s = new PeakWriter(LB, file_name+"_sample" + file_suffix);
			PeakWriter pw_c = new PeakWriter(LB, file_name+"_control" + file_suffix);
			Peakdesc[] pd_s  = sample.get_peak_store().get_array_of_peaks();
			Peakdesc[] pd_c  = control.get_peak_store().get_array_of_peaks();
			for (PeakPairIdx p: this.get_array()) {
				int pk_idx_1 = p.get_pk_idx_1();
					if (pk_idx_1 != -1) {
						pw_s.writePeak3(pk_idx_1, chromosome, pd_s[pk_idx_1], p.get_p_value(), "");
					}
				int pk_idx_2 = p.get_pk_idx_2();
				if (pk_idx_2 != -1) {
					pw_c.writePeak3(pk_idx_2, chromosome, pd_c[pk_idx_2], p.get_p_value(), "");
				}
			}
			pw_s.close();
			pw_c.close();
		} catch (IOException io) {
			LB.error("Error writing header to Region file - could not create file.");  //any other exception is handled
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());	//in the writer itself.
			LB.die();
		}
	}
	
	// ESCA-JAVA0138:
	public void write_out_filtered_wigs(String file_name, String file_suffix, PeakDataSetParent sample,
			PeakDataSetParent control, String chromosome, Parameters param) {
		String file_s = file_name + "_sample" + file_suffix;
		String file_c = file_name + "_control" + file_suffix;
		WigwriterBuffered wig_s = new WigwriterBuffered(LB, file_s, 
				param.prepend, param.get_wig_step_size(), param.get_min_coverage());
		LB.notice("writing to : " + file_s);
		wig_s.initialize_wig_files("sample_filtered_" + param.get_name(),
				param.type, param.run, param.get_filterDupes(), sample.get_chromosome());
		WigwriterBuffered wig_c = new WigwriterBuffered(LB, file_c, 
				param.prepend, param.get_wig_step_size(), param.get_min_coverage());
		LB.notice("writing to : " + file_c);
		wig_c.initialize_wig_files("control_filtered_" + param.get_name(),
				param.type, param.run, param.get_filterDupes(), sample.get_chromosome());
		
		MapStore map_s = sample.get_map_store();
		MapStore map_c = control.get_map_store();
		
		Peakdesc[] pd_s  = sample.get_peak_store().get_array_of_peaks();
		Peakdesc[] pd_c  = control.get_peak_store().get_array_of_peaks();
		for (PeakPairIdx p: this.get_array()) {	
			int pk_idx_1 = p.get_pk_idx_1();
				if (pk_idx_1 != -1) {
					wig_s.section_header(chromosome, pd_s[pk_idx_1].get_offset());
					if (map_s.int_based) {
						int[] a = map_s.get_i(pd_s[pk_idx_1].get_hashkey()).get_map();
						int start = pd_s[pk_idx_1].get_offset() - map_s.get_i(pd_s[pk_idx_1].get_hashkey()).get_loc();
						int end = start + pd_s[pk_idx_1].get_length();
						for (int x = start; x <= end; x++) {
							wig_s.writeln(a[x]);
						}
					} else {
						float[] a = map_s.get_f(pd_s[pk_idx_1].get_hashkey()).get_map();
						int start = pd_s[pk_idx_1].get_offset() - map_s.get_f(pd_s[pk_idx_1].get_hashkey()).get_loc();
						int end = start + pd_s[pk_idx_1].get_length();
						for (int x = start; x <= end; x++) {
							wig_s.writeln(a[x]);
						}
					}
				}
			int pk_idx_2 = p.get_pk_idx_2();
			if (pk_idx_2 != -1) {
				wig_c.section_header(chromosome, pd_c[pk_idx_2].get_offset());
				if (map_s.int_based) {
					int[] a = map_c.get_i(pd_c[pk_idx_2].get_hashkey()).get_map();
					int start = pd_c[pk_idx_2].get_offset() - map_c.get_i(pd_c[pk_idx_2].get_hashkey()).get_loc();
					int end = start + pd_c[pk_idx_2].get_length();
					for (int x = start; x <= end; x++) {
						wig_c.writeln(a[x]);
					}
				} else {
					float[] a = map_c.get_f(pd_c[pk_idx_2].get_hashkey()).get_map();
					int start = pd_c[pk_idx_2].get_offset() - map_c.get_f(pd_c[pk_idx_2].get_hashkey()).get_loc();
					int end = start + pd_c[pk_idx_2].get_length();
					for (int x = start; x <= end; x++) {
						wig_c.writeln(a[x]);
					}
				}
			}
		}
		wig_s.close();
		wig_c.close();
	}
	
	
	
}

package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;

import src.lib.Constants;
import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;

/**
 * @version $Revision: 1790 $
 * @author 
 */
public class BowtieIterator implements AlignedReadsIterator{
	
	private static boolean display_version = true;
	private static final int EXPECTED_FIELDS = 7;
	
	String Name = null;
	BufferedReader br = null;
	int linecount = 0;
	final int max_PET_len;
	private Log_Buffer LB;
	int number_filtered;
	
	
	
	public BowtieIterator(Log_Buffer log_file, String Name, String source_file, int max_PET_len) {
		LB = log_file;
		if (display_version) {
			LB.Version("BowtieIterator", "$Revision: 1790 $");
			display_version = false;
		}
		this.max_PET_len = max_PET_len;
		this.number_filtered = 0;
		this.Name = Name;
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else if (source_file.endsWith(".gz")) {
				br = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(source_file))));
			} else {
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (IOException io) {
			if (source_file.endsWith(".gz")) {
				try {
					LB.warning("Couldn't find file: " + source_file);
					source_file = source_file.substring(0,source_file.length()-3);
					LB.warning("Trying file: " + source_file);
					br = new BufferedReader(new FileReader(source_file));
					LB.notice("Success");
				} catch (IOException f) {
					LB.error("Can't open Eland Ext. file (notzipped) " + source_file);
					LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
					LB.die();
				}
			} else {
				LB.error("Can't open Eland Ext. file " + source_file);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				if (source_file.endsWith(".gz")) {
					LB.error("Tried to open as gzip.");
				}
				LB.die();
			}
		}	
	}
	
	/**
	 * @deprecated
	 */
	public void apply_filters(String f) {
		throw new UnsupportedOperationException();
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	} 
	
	public boolean reset() {
		try {
			br.reset();
			return true;
		} catch (IOException ioe) {
			LB.error("Could not reset input file for read buffer.");
			return false;
		}
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close Eland Ext. file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Lines Filtered: " + this.number_filtered);
		}
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Eland Ext. Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}


//5:6:619:776	-	scaffold_20094	334	TGCGTCAACCCCACTTTCTGGCCATCGCAATGCTATA	$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$	
//0	0:G>A,27:A>C,32:G>T,33:C>G,34:G>C,35:T>G
	
	
	
	public AlignedRead next() {
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				this.linecount++;	
				String[] elements = line.split("\t");				
				// ESCA-JAVA0076:
				if (elements.length < 7) {
					LB.warning("Not enough fields on line: " + this.linecount);
					LB.warning("The next line is as read from the file:");
					LB.warning(line);
					LB.die();
				}
				if (elements[1].length() > 1) {
					LB.warning("Line " + this.linecount + ": strand information is too long: " + elements[1]);
				}
				int alignStart = Integer.valueOf(elements[3]);
				int alignEnd = alignStart + elements[4].length() -1;
				if (this.max_PET_len > 0 && (alignEnd -alignStart) > this.max_PET_len) {
					this.number_filtered++;
					continue;
				}
				
				
				if (elements.length < EXPECTED_FIELDS) {
					LB.warning("Line " + this.linecount
							+ ": has a broken CR in the sequence: "
							+ elements[0] + "\t" + elements[1] + "\t"
							+ elements[2]);
				}
				// ESCA-JAVA0076:
				AlignedRead A = null;
				try {
					A = new AlignedRead(
						elements[1].charAt(0),							/*char direction*/
						elements[0],									/*String Name*/
						elements[4],									/*String Sequence*/
						0,												/*int score*/
						0,												/*int seqStart*/
						0,												/*int seqEnd*/
						null,											/*String alignName*/
						elements[2],									/*String chromosome*/
						alignStart,										/*int alignStart*/
						alignEnd,										/*int alignEnd*/
						0.0,											/*double percent*/
						0.0,											/*double P*/
						null,											/*String alignseq*/
						((elements.length > 7) ? 
								(Utilities.count_occurances(elements[7], ':'))
								: 0),									/*int mismatches*/
						-alignStart,											/*double sort_score*/
						0,												/*int queryLength*/
						elements[4].length(),							/*int alignLength*/
						0,												/*int contigStart*/
						0,												/*int contigEnd*/
						0,												/*int identity*/
						((elements.length > 7) ? elements[7] : ""),		/*String Match*/
						0,												/*int matches_noError*/
						0,												/*int matches_1error*/
						0,												/*int matches_2error*/
						null,											/*String N_reads*/
						null,											/*String error1*/
						null,											/*String error2*/
						elements[5].getBytes()							/*byte[] quality*/
						);
				} catch (UnexpectedResultException URE) {
					LB.error("Line " + linecount + " has an invalid read:");
					LB.error(URE.getMessage());
				}
				return A;						
			} 
			throw new NoSuchElementException("Could not get any more reads.");	
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount + " of Eland Ext file.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return null;
	}

	public static String parse_mismatches(String Sequence, char[] match_info) {
		StringBuffer alnseq = new StringBuffer(Sequence);
		String shift = "";
		int curr_pos = 0;
		for (char x : match_info) {
			if (Utilities.isBase(x)) {
				if (!shift.equals("")) {
					curr_pos += Integer.parseInt(shift); 
				}
				alnseq.setCharAt(curr_pos, x);
				curr_pos++;
				shift = "";
			} else {
				//is not base
				shift += x;
			}
		}
		return alnseq.toString();
	}
	
	/**
	 * Return the number of filtered read while iterating.
	 * TODO change this function if the Iterator start filtering
	 * @return 0 in every case
	 */
	public int get_NumberFilteredRead()
	{
		return 0;
	}

}

		
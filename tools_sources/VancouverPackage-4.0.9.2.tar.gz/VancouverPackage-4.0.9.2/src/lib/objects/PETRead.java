package src.lib.objects;


// ESCA-JAVA0136:
/**
 * Class to unify all types of sequence alignments
 * @author Genome Sciences Centre
 * @version $Revision: 463 $
 */
public class PETRead implements Comparable<PETRead> {
	public static final int    ARRAY_INIT_SIZE = 1000;
	
	private final String Name;									//The name of the query 
	private final String chromosome;							//Chromosome on which match was found
	private final int alignStart;								// Start of the alignment in the database
	private final char direction;								//direction of alignment, can be either '+' or '-'
	private final int insertsize;								//insert size from outer coordinates
	private final int flag;										//evil MAQ flag for something that doesn't need to be a flag
	private final int map_quality;								//mapping quality
	private final int set_quality;								//mapping quality - single end
	private final int alt_quality;								//mapping quality - alternative
	private final int mismatches;								//The mismatch count
	private final int soq;										//Sum of qualities of mismatched hits in best hit
	private final int matches_noError;							//Number of 0-error matches found using seed
	private final int matches_1error;							//Number of 1-error matches found using seed
	private final int alignLength;								//The length of the alignment (end - start)
	private final String Sequence;								//The original (query) Sequence
	private final String quality;								//quality
	private int sort_score;										//sort score



	/**
	 * Main method for creating a PETRead object
	 * @param Name
	 * @param chromosome
	 * @param alignStart
	 * @param direction
	 * @param insertsize
	 * @param flag
	 * @param map_quality
	 * @param set_quality
	 * @param alt_quality
	 * @param mismatches
	 * @param soq
	 * @param matches_noError
	 * @param matches_1error
	 * @param alignLength
	 * @param Sequence
	 * @param quality
	 */
	// ESCA-JAVA0138:
	public PETRead(
			String Name,
			String chromosome,
			int alignStart,
			char direction,
			int insertsize,
			int flag,
			int map_quality,
			int set_quality,
			int alt_quality,
			int mismatches,
			int soq,
			int matches_noError,
			int matches_1error,
			int alignLength,
			String Sequence,
			String quality) {
		this.Name	 			= Name;
		this.chromosome	 		= chromosome;
		this.alignStart	 		= alignStart;
		this.direction	 		= direction;
		this.insertsize	 		= insertsize;
		this.flag	 			= flag;
		this.map_quality	 	= map_quality;
		this.set_quality	 	= set_quality;
		this.alt_quality	 	= alt_quality;
		this.mismatches	 		= mismatches;
		this.soq	 			= soq;
		this.matches_noError	= matches_noError;
		this.matches_1error		= matches_1error;
		this.alignLength	 	= alignLength;
		this.Sequence	 		= Sequence;
		this.quality	 		= quality;
	}
	
	
	
	
	
	
	/**
	 * Performs the sort function on PETReads.
	 * @param a
	 * @return int
	 */
	public int compareTo(PETRead a) {
		if (a.sort_score < sort_score) {
			return -1;
		}
		if (a.sort_score > sort_score) {
			return 1;
		}
		if (a.direction == direction) {
			return 0;
		}
		if (a.direction == '-') {
			return -1;
		}
		return 1;
	}

	/**
	 * Simple toString routine to create a String representation of the key parts of the Read.
	 * @return String
	 */
	@Override
	public String toString() {
		String s = this.Name + "\t" + this.Sequence + "\t" + this.chromosome
				+ "\t" + this.alignStart + "\t" + this.direction;
		return s;
	}

		
	/**
	 * Function to return a Mapview (-b) format string.
	 * @return
	 */
	public String outMapview() {
		StringBuffer s = new StringBuffer(ARRAY_INIT_SIZE);
	
		s.append(this.Name + "\t");
		s.append(this.chromosome + "\t");
		s.append(this.alignStart + "\t");
		s.append(this.direction + "\t");
		
		s.append(this.insertsize + "\t");
		s.append(this.flag + "\t");
		
		s.append(this.map_quality + "\t");
		s.append(this.set_quality + "\t");
		s.append(this.alt_quality + "\t");
		
		s.append(this.mismatches + "\t");
		
		s.append(this.soq + "\t");
		
		s.append(this.matches_noError + "\t");
		s.append(this.matches_1error + "\t");
		s.append(this.alignLength + "\t");
		/*optional, I suppose: 
				String Sequence,
				String quality*/
		
		return s.toString();
	}
	/** 
	 * Use this function to set the sort-score - the field upon which a call to sort() will sort the reads
	 * @param x
	 */
	public final void		set_sort_score(int x) { this.sort_score = x; }
	
	/** Get functions for all fields
	 * @return
	 */
	public final int 		get_mismatches()	{ return this.mismatches; }
	public final int		get_alignStart() 	{ return this.alignStart; }
	public final char		get_direction() 	{ return this.direction; }
	public final String		get_Sequence() 		{ return this.Sequence; }
	public final double		get_sort_score()	{ return this.sort_score; }
	public final String 	get_chromosome()	{ return this.chromosome; }
	public final String 	get_name()			{ return this.Name; }
	public final int		get_alignLength() 	{ return this.alignLength; }
	public final String		get_quality() 		{ return this.quality; }
	
	public final int 		get_alignEnd()		{ return this.alignStart + this.alignLength; }
}
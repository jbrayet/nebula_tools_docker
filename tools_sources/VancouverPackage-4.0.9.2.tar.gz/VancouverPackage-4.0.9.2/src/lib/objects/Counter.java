package src.lib.objects;


/**
 * @version $Revision: 463 $
 * @author 
 */
public class Counter {
	private int i = 1;

	public final String toString() {
		return Integer.toString(i);
	}
	
	public void increment() {
		this.i++;
	}
	
	public int get_value() {
		return this.i;
	}
}

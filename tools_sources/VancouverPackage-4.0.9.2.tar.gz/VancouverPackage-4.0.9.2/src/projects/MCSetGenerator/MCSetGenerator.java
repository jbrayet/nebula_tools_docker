package src.projects.MCSetGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;

public class MCSetGenerator {

	private MCSetGenerator() {}
	
	static int[] total_genes = {10511, 10483, 11251, 11114, 10645};
	static 	String[] ids  = {"299", "419", "428", "445", "477" };
	static int[] sets = {250, 53,  131, 132, 95};
	static int[][] data = null;
	static int iterations = 500000;
	private static Random generator;
	private static HashMap<String, int[]> records;
	
	
	
	private static int[] overlap(final int[] a, final int[] b) {
		
		int l = 0;
		ArrayList<Integer> c = new ArrayList<Integer>();
		for (int i : a) {
			if (l >= b.length) {
				l = b.length -1; //reset l if it's gone too far;
			} else if (l < 0) {
				l = 0; 
			}
			if (i == b[l]) {
				c.add(i);
				continue;
			} else if (i > b[l] && l < b.length-1) {
				do {
					l++;
					if (l >= b.length) {
						continue;
					} else if (i == b[l]) {
						c.add(i);
						continue;
					}
				} while (l < b.length && b[l] < i);
			} else if (i < b[l] && l > 0) {
				do {
					l--;
					if (l < 0) {
						continue;
					} else if (i == b[l]) {
						c.add(i);
						continue;
					}
				} while (l >0 && b[l] > i);
			} else {
				//nothing - just go on to nextl
			}
		}
		int[] d = new int[c.size()];
		int g = 0;
		for (int f : c) {
			d[g] = f;
			g += 1;
		}	
		return d;
	}

	
	private static void recurs_overlaps(String names, int[] data_a, int start_at, int depth, int it) {
		if (depth > 1)  {
			//System.out.println(names + " : " + data_a.length);
			int[] s = null;
			if (records.containsKey(names)) {
				s = records.get(names);
			} else {
				s = new int[iterations];
			}
			s[it] = data_a.length;
			records.put(names, s);
		}
		for (int y = start_at +1; y < sets.length; y++ ) {			
			recurs_overlaps(names.concat("-" + ids[y]), overlap(data_a, data[y]), y, depth+1, it);
		}
	}
	
	
	// ESCA-JAVA0266:
	public static void main(String[] args) {
		
		generator = new Random();
		data = new int[sets.length][];
		records = new HashMap<String,int[]>();
		
		for (int i = 0; i < iterations; i++) {
			for (int x = 0; x < sets.length; x++) {		//SET UP THE SETS	
				data[x] = new int[sets[x]];
				for (int y = 0; y < sets[x]; y++) {
					data[x][y] = (generator.nextInt(total_genes[x]));		//FILL IN THE RANDOM CHARS
				}
				Arrays.sort(data[x]);
			}
			for (int j = 0; j < sets.length-1; j++) {	//Use the set
				recurs_overlaps(ids[j], data[j], j, 1, i);
			}
		}
		//print out results:
		Set<String> r = records.keySet();
		for(String s : r) {

			System.out.println(s + ":");
			int[] t = records.get(s);
			float avg = 0;
			for (int u : t) {
				avg += u;
			}
			float mean = avg/(float)t.length;
			System.out.format("\taverage: %f%n", mean);
			float sum2 = 0;
			for (int u :t) {
				final float x = (float)u-mean;
			    sum2 += (x*x);
			}
			final float var = sum2/((float)t.length -1);
			//			System.out.format("\tvariance...: %f\n", var);
			System.out.format("\tstd.dev.: %f%n", Math.sqrt(var));
		}
	}
	
	
	
	
}

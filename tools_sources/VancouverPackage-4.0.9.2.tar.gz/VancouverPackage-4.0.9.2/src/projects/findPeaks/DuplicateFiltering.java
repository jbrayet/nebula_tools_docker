package src.projects.findPeaks;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import src.lib.IterableIterator;
import src.lib.objects.AlignedRead;

public class DuplicateFiltering {
 
	private DuplicateFiltering() {}
	
	public static Vector<AlignedRead> simplefilter(Vector<AlignedRead> cur_reads) {
		Vector<AlignedRead> filtered = new Vector<AlignedRead>();
		HashMap<String, AlignedRead> filterstore = new HashMap<String, AlignedRead>();
		for (AlignedRead ar : cur_reads) {
			String key = Integer.toString(ar.get_alignStart()) + ar.get_direction();
			if (filterstore.containsKey(key)) {
				if (filterstore.get(key).get_score() > ar.get_score()) {
					filterstore.put(key, ar);	
				}
			} else {
				filterstore.put(key, ar);
			}
		}
		Iterator<String> keys = filterstore.keySet().iterator();
		for (String k : new IterableIterator<String>(keys)) {
			filtered.add(filterstore.get(k));
		}
		return filtered;
	}
		
	
}

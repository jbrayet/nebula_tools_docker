package src.lib.Graphics;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import src.lib.ioInterfaces.Log_Buffer;

public class BasicImage {


	protected Graphics2D g2d 			= null;
	private BufferedImage bufferedImage = null;
	protected Log_Buffer LB 			= null;
	private String type 				= null;

	/**
	 * 
	 * @param log_buffer
	 * @param file_type
	 * @param height
	 * @param width
	 */
	public BasicImage(Log_Buffer log_buffer, String file_type, int width, int height) {

		LB = log_buffer;
		//create the two objects used to work with this new image.
		bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		// Create a graphics contents on the buffered image
		g2d = bufferedImage.createGraphics();
		g2d.setBackground(Color.WHITE);
		g2d.clearRect(0, 0, width, height);
		g2d.setColor(Color.BLACK);
		type = file_type;
	}

	
	public void close() {
		g2d.dispose();
		bufferedImage = null;
		type = null;
		LB = null;
	}
	
	
	public void write_to_disc(String Filename) {
		// Write generated image to a file
		try {
			File file = null;
			if (type.equalsIgnoreCase("png")) {				// Save as PNG
				if ( ! Filename.endsWith(".png")) {
					Filename = Filename.concat(".png");
				}
				file = new File(Filename);	
			} else  if (type.equalsIgnoreCase("jpg")) {	// Save as jpg
				if ((! Filename.endsWith(".jpg")) && (! Filename.endsWith(".jpeg"))) {
					Filename = Filename.concat(".jpg");
				}
				file = new File(Filename);
			} else {
				LB.error("Graphics module asked to create an unrecognized file type : " + type);
			}
			ImageIO.write(bufferedImage, type, file);
			LB.notice("wrote to : " + Filename);
		} catch (IOException e) {
			LB.error("Problem encountered while trying to write graphic out to file."  );
			LB.error("Please check that you have the appropriate permissions and the correct directory structure");
			LB.error("Exists to write out the following file");
			LB.error("\t" + Filename);
		}
		
	}
	

	// Returns a generated image.
	public RenderedImage myCreateImage(int height, int width) {

		// Create a buffered image in which to draw
		
		// Draw graphics
		g2d.setColor(Color.white);
		g2d.fillRect(0, 0, width, height);
		g2d.setColor(Color.black);
		g2d.fillOval(0, 0, width, height);

		// Graphics context no longer needed so dispose it
		g2d.dispose();

		return bufferedImage;
	}

}

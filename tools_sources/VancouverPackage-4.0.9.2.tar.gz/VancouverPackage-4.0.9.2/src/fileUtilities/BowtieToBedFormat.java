package src.fileUtilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.Histogram;
import src.lib.IterableIterator;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.BowtieIterator;
import src.lib.ioInterfaces.FileOut;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.AlignedRead;
import src.lib.objects.SeqReducedAlignedRead;

/**
 * @version $Revision: 1571 $
 * @author 
 *
 */
public class BowtieToBedFormat {
	private static final String Forward = "/1";
	private static final String Reverse = "/2";
	private static final int trim_f = Forward.length();  //length of "_forward" and "_reverse";
	private static final int hist_size = 1000;
	private static final int OUTPUT_FREQ = 1000000;

	private BowtieToBedFormat() {}
	private static Log_Buffer LB = null;

	private static int unpaired = 0;
	private static int simple = 0;
	private static int forked = 0;
	private static int complex = 0;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		assert (Variables != null);

		/* Do bootstrap calls here */
		String name = null;
		String output_path = null;
		
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.error("file names must be supplied with -name flag");
			LB.die();
		}
		
		if (Variables.containsKey("output")) {		
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + name  + ".log");
			LB.addLogFile(output_path + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			LB.die();
		}	
		
		/* end bootstrap  - print out results of bootstrapped variables*/
		new CurrentVersion(LB);
		LB.Version("MaqPetToBedFormat", "$Revision: 1571 $");
		LB.notice(" * Output directory  : " + output_path);		
		LB.notice(" * Name              : " + name);
		
		
		
		if (!Variables.containsKey("input")) {
			LB.error("Must provide an -input file on the command line");
			LB.die();
		}

		boolean noflag_mode = Variables.containsKey("noflag")? true : false;
		if (noflag_mode) {
			LB.notice("Noflag mode is on. (-noflag)");
		} else {
			LB.notice("Flags expected \"/1\" and \"/2\"");
		}

		HashMap<String, ArrayList<SeqReducedAlignedRead>> storeF= new HashMap<String, ArrayList<SeqReducedAlignedRead>>();
		Histogram hist = new Histogram(LB, hist_size, 0, hist_size, false);
	
		BowtieIterator mi = new BowtieIterator(LB, "sourcefile", Variables.get("input"), 0);

		LB.notice("Processing file...");
		int cnt = 0;
		int seq_len = 0;
		IterableIterator<AlignedRead> miII = new IterableIterator<AlignedRead>(mi); 
		for (AlignedRead line : miII) {
			if (cnt == 0) {
				seq_len = line.get_sequence().length();
			}
			cnt++;

			if (cnt % OUTPUT_FREQ == 0) {
				LB.notice(cnt + " reads processed");
			}

			String name_key = null;
			if (noflag_mode) {
				name_key = line.get_name();
			} else {
				name_key = line.get_name().substring(0,
					((line.get_name().endsWith(Reverse) 
						|| line.get_name().endsWith(Forward)) 
							? line.get_name().length() - trim_f 
							: line.get_name().length()));
			}			
			ArrayList<SeqReducedAlignedRead> hr = null;
			if (storeF.containsKey(name_key)) {				//test if already there
				hr = storeF.get(name_key);
			} else {
				hr = new ArrayList<SeqReducedAlignedRead>(1);
			}
			SeqReducedAlignedRead a = new SeqReducedAlignedRead(
					(line.get_direction() == '+') ? true : false,
					line.get_alignStart(),
					line.get_sequence(),
					line.get_chromosome(),
					((line.get_name().endsWith(Forward)) ? true : false),
					(byte)line.get_mismatches());
			hr.add(a);
			storeF.put(name_key, hr);
		}
		/*File writers*/
		LB.notice("Creating FileWriters");
		/*Unpaired reads, in similar to bowtie format*/
		FileOut fw_unpaired = new FileOut(LB, output_path + name + "unpaired.tsv.gz", true);
		/*simple paired reads - Bed Format*/
		FileOut fw_simple_same = new FileOut(LB, output_path
				+ name + "_simple_paired_samechr.tsv.gz", true);
		/*simple paired reads - Bed Format*/
		FileOut fw_simple_span = new FileOut(LB, output_path
				+ name + "_simple_paired_spanchr.tsv.gz", true);
		/*Forked paired reads - Bed Format*/
		FileOut fw_forked = new FileOut(LB, output_path + name + "_forked_paired.tsv.gz", true);
		/*complex paired reads - Bed Format*/
		FileOut fw_complex = new FileOut(LB, output_path + name + "_complex_paired.tsv.gz", true);

		LB.notice("processing paired reads");
		Iterator<String> keys = storeF.keySet().iterator();

		LB.notice("Number of keys to process: " + storeF.keySet().size());
		IterableIterator<String> keysII = new IterableIterator<String>(keys);
		for (String read_name : keysII) {
			ArrayList<SeqReducedAlignedRead> h = storeF.get(read_name);
			if (noflag_mode) {
				int same = all_same(h);
				if (same == h.size()) {
					process_unpaired(fw_unpaired, read_name, h);
					unpaired++;
				} else if (same == 1 && h.size() == 2) { 							//find Pairs.
					process_simple(fw_simple_same, fw_simple_span, read_name, seq_len, hist, h);
					simple++;
				} else if (same == 1 || same == h.size() -1) {
					process_fork_noflag(fw_forked, read_name, h);
					forked++;
				} else {
					process_complex(fw_complex, read_name, h);
					complex++;
				}
			} else {
				if (all_same_flag(h)) {  			//do unpaired
					process_unpaired_flag(fw_unpaired, read_name, h);
					unpaired++;
				} else {
					int fw = count_forward_flag(h);
					int rv = h.size() - fw;
					if (fw == 1 && rv == 1) {		//simplest case.
						process_simple(fw_simple_same, fw_simple_span, read_name, seq_len, hist, h);
						simple++;
					} else if (fw == 1) {  //simple fork case
						process_fork(fw_forked, read_name, true, h);
						forked++;
					} else if ( rv == 1) {	//simple fork case
						process_fork(fw_forked, read_name, false, h);
						forked++;
					} else {						//complex case
						process_complex(fw_complex, read_name, h);
						complex++;
					} 
				}
			}
		}
		//sort and process unpaired.
		fw_unpaired.close();
		fw_simple_span.close();
		fw_simple_same.close();
		fw_forked.close();
		fw_complex.close();
		LB.notice(" Total unpaired name: " + unpaired);
		LB.notice(" Total simple name: " + simple);
		LB.notice(" Total forked name: " + forked);
		LB.notice(" Total complex name " + complex);

		hist.print_bins(output_path + "Histogram.txt");
		LB.close();
	}
	
	
	private static void process_unpaired_flag (FileOut fw, String name, ArrayList<SeqReducedAlignedRead> a) {
		for (SeqReducedAlignedRead l : a) {
			fw.writeln(name + ((l.get_pair()) ? "\\1" : "\\2") + "\t" + 
					((l.get_direction()) ? "+" : "-")  + "\t" + 
					l.get_chromosome() + "\t" +
					l.get_alignstart() + "\t" +
					l.get_sequence() + "\t" +
					l.get_snpcount());
		}
	}
	
	private static void process_unpaired(FileOut fw, String name, ArrayList<SeqReducedAlignedRead> a) {
		for (SeqReducedAlignedRead l : a) {
			fw.writeln(name + "\t" + 
					((l.get_direction()) ? "+" : "-")  + "\t" + 
					l.get_chromosome() + "\t" +
					l.get_alignstart() + "\t" +
					l.get_sequence() + "\t" +
					l.get_snpcount());
		}
	}
	
	// ESCA-JAVA0138:
	private static void process_simple(FileOut fw_same, FileOut fw_span,
			String name, int seq_len, Histogram hist,
			ArrayList<SeqReducedAlignedRead> a) {
		SeqReducedAlignedRead f = a.get(0);
		SeqReducedAlignedRead g = a.get(1);
		int b = f.get_alignstart(); 
		int c = g.get_alignstart();

		if (b < c) {
			if (f.get_chromosome().equals(g.get_chromosome())) {
				hist.bin_value(g.get_alignstart() - f.get_alignstart() + seq_len);
				fw_same.writeln(name + "\t" + 
						((f.get_direction()) ? "+" : "-")  + "\t" + 
						f.get_chromosome() + "\t" +
						f.get_alignstart() + "\t" +
						f.get_sequence() + "\t" +
						f.get_snpcount() + "\t" +
						((g.get_direction()) ? "+" : "-")  + "\t" +
						g.get_chromosome() + "\t" +
						g.get_alignstart() + "\t" +
						g.get_sequence() + "\t" +
						g.get_snpcount());
			} else {
				fw_span.writeln(name + "\t" + 
						((f.get_direction()) ? "+" : "-")  + "\t" + 
						f.get_chromosome() + "\t" +
						f.get_alignstart() + "\t" +
						f.get_sequence() + "\t" +
						f.get_snpcount() + "\t" +
						((g.get_direction()) ? "+" : "-")  + "\t" +
						g.get_chromosome() + "\t" +
						g.get_alignstart() + "\t" +
						g.get_sequence() + "\t" +
						g.get_snpcount());
			}
		} else {
			if (g.get_chromosome().equals(f.get_chromosome())) {
				hist.bin_value(f.get_alignstart() - g.get_alignstart() + seq_len);
				fw_same.writeln(name + "\t" + 
						((g.get_direction()) ? "+" : "-")  + "\t" + 
						g.get_chromosome() + "\t" +
						g.get_alignstart() + "\t" +
						g.get_sequence() + "\t" +
						g.get_snpcount() + "\t" +
						((f.get_direction()) ? "+" : "-")  + "\t" +
						f.get_chromosome() + "\t" +
						f.get_alignstart() + "\t" +
						f.get_sequence() + "\t" +
						f.get_snpcount());
			} else {
				fw_span.writeln(name + "\t" + 
						((g.get_direction()) ? "+" : "-")  + "\t" + 
						g.get_chromosome() + "\t" +
						g.get_alignstart() + "\t" +
						g.get_sequence() + "\t" +
						g.get_snpcount() + "\t" +
						((f.get_direction()) ? "+" : "-")  + "\t" +
						f.get_chromosome() + "\t" +
						f.get_alignstart() + "\t" +
						f.get_sequence() + "\t" +
						f.get_snpcount());
			}
		}
	}

	private static void process_fork (FileOut fw, String name, boolean first, ArrayList<SeqReducedAlignedRead> a) {
		int x = 0;
		SeqReducedAlignedRead f = null;
		for (x = 0 ; x < a.size(); x++) {			//find fw read
			if (a.get(x).get_pair() == first) { 			//if forward
				f = a.get(x);
				break;
			}
		}
		assert(f!= null);
		SeqReducedAlignedRead g = a.get(1);
		for (int y = 0 ; y < a.size(); y++) {			//find rv reads
			if (x != y) { 								//pair with all fork reads
				g = a.get(y);
				fw.writeln(name + "\t" + 
						((f.get_direction()) ? "+" : "-")  + "\t" + 
						f.get_chromosome() + "\t" +
						f.get_alignstart() + "\t" +
						f.get_sequence() + "\t" +
						f.get_snpcount() + "\t" +
						((g.get_direction()) ? "+" : "-")  + "\t" +
						g.get_chromosome() + "\t" +
						g.get_alignstart() + "\t" +
						g.get_sequence() + "\t" +
						g.get_snpcount());	
			}
		}
	}
	
	/**
	 * 
	 * @param fw
	 * @param name
	 * @param reads
	 */
	private static void process_fork_noflag (FileOut fw, String name, ArrayList<SeqReducedAlignedRead> reads) {
		int x = 0;
		int unique = -1;
		while (x < reads.size()) {
			String a = reads.get(x).get_sequence();
			if (x == reads.size() -1) {					//check that it's not the same as the two before
				if (!a.equals(reads.get(x-1).get_sequence()) && !a.equals(reads.get(x-2).get_sequence())) {
					unique = x;				
					break;
				} else {
					LB.notice("White dogs are invisible when hidden in white paint");
					LB.die();
				}
			}
			String b = reads.get(x+1).get_sequence();
			if (a.equals(b)) {
				x += 2;
			} else if (x < reads.size() -2) {
				unique = (a.equals(reads.get(x+2).get_sequence())) ? (x+1) : x;
				break;
			} else if (x > 0) {
				unique = (a.equals(reads.get(x-1).get_sequence())) ? x+1 : x;
				break;
			} else {
				LB.error("A not equal B, and x=" + x + " with a.size()= " + reads.size() + " Will terminate.");
				LB.die();
			}
		}
		if (unique < 0) {
			LB.error("Unexpected Error.");
			LB.error("unique is " + unique);
			LB.error("Size is " + reads.size());
			LB.die();
		}
		SeqReducedAlignedRead f = reads.get(unique);
		SeqReducedAlignedRead g = reads.get(1);
		for (int y = 0 ; y < reads.size(); y++) {			//find rv reads
			if (unique != y) { 								//pair with all fork reads
				g = reads.get(y);
				fw.writeln(name + "\t" + 
						((f.get_direction()) ? "+" : "-")  + "\t" + 
						f.get_chromosome() + "\t" +
						f.get_alignstart() + "\t" +
						f.get_sequence() + "\t" +
						f.get_snpcount() + "\t" +
						((g.get_direction()) ? "+" : "-")  + "\t" +
						g.get_chromosome() + "\t" +
						g.get_alignstart() + "\t" +
						g.get_sequence() + "\t" +
						g.get_snpcount());	
			}
		}
	}
	
	/**
	 * 
	 * @param fw
	 * @param name
	 * @param a
	 */
	private static void process_complex (FileOut fw, String name, ArrayList<SeqReducedAlignedRead> a) {
		for (int x = 0 ; x < a.size() -1; x++) {			//find fw read
			SeqReducedAlignedRead f = a.get(x);
			for (int y = x+1 ; y < a.size(); y++) {			//find rv reads
				SeqReducedAlignedRead g = a.get(y);
				fw.writeln(name + "\t" + 
						((f.get_direction()) ? "+" : "-")  + "\t" + 
						f.get_chromosome() + "\t" +
						f.get_alignstart() + "\t" +
						f.get_sequence() + "\t" +
						f.get_snpcount() + "\t" +
						((g.get_direction()) ? "+" : "-")  + "\t" +
						g.get_chromosome() + "\t" +
						g.get_alignstart() + "\t" +
						g.get_sequence() + "\t" +
						g.get_snpcount());		
			}
		}
	}
	
	private static boolean all_same_flag(ArrayList<SeqReducedAlignedRead> a) {
		boolean first_pair = a.get(0).get_pair();
		for (int x = 1; x < a.size(); x++) {
			if (a.get(x).get_pair() ^ first_pair) {
				return false;
			}
		}
		return true;
	}
	
	private static int all_same(ArrayList<SeqReducedAlignedRead> a) {
		String lastname = a.get(0).get_sequence();
		int n = 1;
		for (int x = 1; x < a.size(); x++) {
			if (a.get(x).get_sequence().equals(lastname)) {
				n++;
			}
		}
		return n;
	}

	private static int count_forward_flag (ArrayList<SeqReducedAlignedRead> a) {
		int x = 0;
		for (SeqReducedAlignedRead l : a) {
			if (l.get_pair()) {
				x++;
			}
		}
		return x;
	}	
	
}

package src.lib.analysisTools;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.ensembl.datamodel.Location;
import org.ensembl.datamodel.Transcript;
import org.ensembl.datamodel.Translation;

import src.lib.Chromosome;
import src.lib.Constants;
import src.lib.Ensembl;
import src.lib.Histogram;
import src.lib.ioInterfaces.Log_Buffer;

/**
 * @version $Revision: 1696 $
 * @author 
 */
public class Transcript_Bias {

	private Transcript_Bias() {}
	
	
	// ESCA-JAVA0138:
	// ESCA-JAVA0049:
	/**
	 * Function to check the bias of transcripts. Looks at three possible
	 * histograms: the first is 50 bases up and downstream of the start of the
	 * coding region (Forward reads only). The second is 50 bases up and down
	 * stream of the end of the coding region (Reverse reads only). the third is
	 * a percentage based look across the coding region of the transcript,
	 * including 20% before and after the start and end of the region.
	 * @param LB
	 * @param Const
	 * @param Chr
	 * @param list
	 * @param Bias_overall
	 * @param Bias_start
	 * @param Bias_end
	 * @param current_chromosome
	 * @param output_path
	 * @param HIST_BINS
	 * @param HIST_START
	 * @param HIST_WIDTH
	 */
	public static void check_bias(Log_Buffer LB, Ensembl Const, Chromosome Chr,
			List<Transcript> list, Histogram Bias_overall, int[] Bias_start,
			int[] Bias_end, int current_chromosome, String output_path,
			int HIST_BINS, int HIST_START, int HIST_WIDTH) {


		BufferedWriter bias_file = null;
		try {
			bias_file = new BufferedWriter(new FileWriter(output_path
					+ Const.get_chromosome(current_chromosome) + ".bias"));
		} catch (IOException io) {
			LB.error("Error creating Bias files.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}

		assert (bias_file != null);
		int[] StartBias = new int[Constants.BIAS_PERCENT];
		int[] EndBias = new int[Constants.BIAS_PERCENT];
		Histogram OverAllBias = new Histogram(LB, HIST_BINS, HIST_START, HIST_WIDTH, false);
		int bias_width = Constants.BIAS_PERCENT / 2;
		for (int b = 0; b < Constants.BIAS_PERCENT; b++) {
			StartBias[b] = 0;
			EndBias[b] = 0;
		}

		LB.notice("Looking for Transcript Bias...");

		for (Transcript t : list) {
			Translation t_translation = t.getTranslation();
			int strand = t.getLocation().getStrand();
			if (t_translation != null
					&& t.getCDNALocation().getEnd() < Chr.get_canonical_sequence_length()) {	// ignore not translating reads
				Location cdna_loc = t.getCDNALocation();
				int first_exon_start = 0;						// pull first position out of concatenated object
				int last_exon_end = 0;
				int length = t_translation.getTranscript().getLength();
				if (strand == 1) {
					first_exon_start = cdna_loc.getStart();
					Location last_cdna = cdna_loc.last();
					last_exon_end = last_cdna.getEnd();
					for (int n = 0; n < Constants.BIAS_PERCENT; n++) {
						StartBias[n] += Chr.get_forward_start_at_pos(n
								+ first_exon_start - bias_width)
								+ Chr.get_reverse_start_at_pos(n
										+ first_exon_start - bias_width);
					}
					/* get 100 base pair around end of coding sequence*/
					for (int n = 0; n < Constants.BIAS_PERCENT; n++) {
						if (n + last_exon_end - bias_width < Chr.get_canonical_sequence_length()) {
							EndBias[n] += Chr.get_forward_start_at_pos(n
									+ last_exon_end - bias_width)
									+ Chr.get_reverse_start_at_pos(n
									+ last_exon_end - bias_width);
						}
					}

				} else {
					last_exon_end = cdna_loc.getEnd();
					Location last_cdna = cdna_loc.last();
					first_exon_start = last_cdna.getStart();
					/* get 100 base pair around start of coding sequence*/
					for (int n = 0; n < Constants.BIAS_PERCENT; n++) {
						StartBias[n] += Chr
								.get_forward_start_at_pos(last_exon_end
										+ (bias_width - 1) - n)
								+ Chr.get_reverse_start_at_pos(last_exon_end
										+ (bias_width - 1) - n);
					}
					/* get 100 base pair around end of coding sequence*/
					for (int n = 0; n < Constants.BIAS_PERCENT; n++) {
						EndBias[n] += Chr
								.get_forward_start_at_pos(first_exon_start
										+ (bias_width - 1) - n)
								+ Chr.get_reverse_start_at_pos(first_exon_start
										+ (bias_width - 1) - n);
					}
				}
				/* get all base pairs around in coding sequence + 20% flanking
				 seq, and build normalised histogram on it.
				 calculate 20% margin:*/
				int margin = (int) (length * 0.20);
				float binvalue = 0;
				int tmp_pos = 0;
				/* get stuff before start*/
				for (int n = 0; n < margin; n++) {
					if (strand == 1) {
						tmp_pos = (first_exon_start - margin) + n;
						binvalue = (((float) n / (float) margin) * Constants.BIAS_MARGIN_F) - Constants.BIAS_MARGIN;
					} else {
						tmp_pos = (last_exon_end + margin) - n;
						binvalue = (Constants.BIAS_MARGIN_F - (((float) n / (float) margin) * Constants.BIAS_MARGIN_F))
								- Constants.BIAS_MARGIN;
					}
					if (tmp_pos < Chr.get_canonical_sequence_length()) {
						if (Const.get_number_of_chromosomes() > 1) {
							Bias_overall.bin_value(binvalue, Chr
									.get_forward_start_at_pos(tmp_pos)
									+ Chr.get_reverse_start_at_pos(tmp_pos));
						}
						OverAllBias.bin_value(binvalue, Chr
								.get_forward_start_at_pos(tmp_pos)
								+ Chr.get_reverse_start_at_pos(tmp_pos));
					}
				}
				/* get stuff after end*/
				for (int n = 1; n < margin; n++) {
					if (strand == 1) {
						tmp_pos = n + last_exon_end;
						binvalue = (((float) n / (float) margin) * Constants.BIAS_MARGIN_F) + Constants.PERCENT_100;
					} else {
						tmp_pos = first_exon_start - n;
						binvalue = (Constants.BIAS_MARGIN_F - (((float) n / (float) margin) * Constants.BIAS_MARGIN_F))
								+ Constants.PERCENT_100;
					}
					if (tmp_pos < Chr.get_canonical_sequence_length()) {
						if (Const.get_number_of_chromosomes() > 1) {
							Bias_overall.bin_value(binvalue, Chr
									.get_forward_start_at_pos(tmp_pos)
									+ Chr.get_reverse_start_at_pos(tmp_pos));
						}
						OverAllBias.bin_value(binvalue, Chr
								.get_forward_start_at_pos(tmp_pos)
								+ Chr.get_reverse_start_at_pos(tmp_pos));
					}
				}
				/*get stuff in exons*/
				int exon_start = cdna_loc.getStart();
				int exon_end = cdna_loc.getEnd();
				int curr_pos = 0;

				for (int n = exon_start; n <= exon_end; n++) {
					binvalue = (((float) curr_pos / (float) length) * Constants.PERCENT_100);
					if (strand == -1) {
						binvalue = Constants.PERCENT_100 - binvalue;
					}
					if (n < Chr.get_canonical_sequence_length()) {
						if (Const.get_number_of_chromosomes() > 1) {
							Bias_overall.bin_value(binvalue, Chr
									.get_forward_start_at_pos(n)
									+ Chr.get_reverse_start_at_pos(n));
						}
						OverAllBias.bin_value(binvalue, Chr
								.get_forward_start_at_pos(n)
								+ Chr.get_reverse_start_at_pos(n));
					}
					curr_pos++;

				}
				while (cdna_loc.hasNext()) {
					cdna_loc = cdna_loc.next();
					exon_start = cdna_loc.getStart();
					exon_end = cdna_loc.getEnd();
					for (int n = exon_start; n <= exon_end && n < Chr.get_canonical_sequence_length(); n++) {
						binvalue = (((float) curr_pos / (float) length) * Constants.PERCENT_100);
						if (strand == -1) {
							binvalue = Constants.PERCENT_100 - binvalue;
						}
						if (Const.get_number_of_chromosomes() > 1) {
							Bias_overall.bin_value(binvalue, Chr
									.get_forward_start_at_pos(n)
									+ Chr.get_reverse_start_at_pos(n));
						}
						OverAllBias.bin_value(binvalue, Chr
								.get_forward_start_at_pos(n)
								+ Chr.get_reverse_start_at_pos(n));
						curr_pos++;
					}
				}
			}
		}
		/* Output to files:*/
		try {
			bias_file.write("Start Bias:");
			bias_file.newLine();
			for (int n = 0; n < StartBias.length; n++) {
				bias_file.write((n - bias_width) + " " + StartBias[n]);
				bias_file.newLine();
			}
			bias_file.write("End Bias:");
			bias_file.newLine();
			for (int n = 0; n < StartBias.length; n++) {
				bias_file.write((n - bias_width) + " " + EndBias[n]);
				bias_file.newLine();
			}
			bias_file.write("Overall Bias:");
			bias_file.newLine();
			OverAllBias.print_bins(bias_file);
			bias_file.close();
		} catch (IOException io) {
			LB.error("Can't write bias files");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}

		/*Transfer to whole genome stats*/
		if (Const.get_number_of_chromosomes() > 1) {
			for (int y = 0; y < Constants.BIAS_PERCENT; y++) {
				Bias_start[y] += StartBias[y];
				Bias_end[y] += EndBias[y];
			}
		}
		LB.notice("Done");
	}
	
	public static void write_whole_transcript_bias(Log_Buffer LB, Histogram Bias_overall, int[] Bias_start,
			int[] Bias_end, int end_bias_size, String output_path ) {
		BufferedWriter bias_file = null;
		int bias_width = end_bias_size / 2;
		try {
			bias_file = new BufferedWriter(new FileWriter(output_path
					+ "Transcriptome.bias"));
			bias_file.write("Start Bias:");
			bias_file.newLine();
			for (int n = 0; n < Bias_start.length; n++) {
				bias_file.write((n - bias_width) + " " + Bias_start[n]);
				bias_file.newLine();
			}
			bias_file.write("End Bias:");
			bias_file.newLine();
			for (int n = 0; n < Bias_end.length; n++) {
				bias_file.write((n - bias_width) + " " + Bias_end[n]);
				bias_file.newLine();
			}
			bias_file.write("Overall Bias:");
			bias_file.newLine();
			Bias_overall.print_bins(bias_file);
			bias_file.close();
		} catch (IOException io) {
			LB.error("Can't write bias files");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}

	}
	
	
}

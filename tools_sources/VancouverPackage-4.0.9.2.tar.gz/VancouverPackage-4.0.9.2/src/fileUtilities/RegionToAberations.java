package src.fileUtilities;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.zip.GZIPInputStream;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.Log_Buffer;


/**
 * Convert  .region file into am aberation list that can then be used with FindFeatures.
 * @author T. Cezard
 * @author Anthony Fejes
 * @version $Revision: 1604 $
 */
public class RegionToAberations {
	
	private static Log_Buffer LB = null;
	
	private RegionToAberations() {}
	
	public static void main(String[] args) {
		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		new CurrentVersion(LB);
		LB.Version("RegionsToFeatures", "$Revision: 1604 $");
		//process parameters
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
			return;
		}		
		if (!Variables.containsKey("name")) {
			LB.error("Must provide a -name parameter on the command line");
			LB.die();
		}
		if (!Variables.containsKey("output")) {
			LB.error("Must provide an -output path on the command line");
			LB.die();
		} else { 
			String tmp = Variables.get("output");
			if (!tmp.endsWith(System.getProperty("file.separator"))) {
				tmp = tmp.concat(System.getProperty("file.separator"));
				Variables.put("output", tmp);
			}
			LB.notice("Log File: " + Variables.get("output") + Variables.get("name") + ".log");
			LB.addLogFile(Variables.get("output") + Variables.get("name")  + ".log");
		}

		if (!Variables.containsKey("input")) {
			LB.error("Must provide an -input path on the command line");
			LB.die();
		}

		
		BufferedReader br = null;
		String[] source_files = Variables.get("input").split(",");
		
		for (String file : source_files) {
			try {
				if (file.endsWith(".gz")) {
					br = new BufferedReader(new InputStreamReader(
							new GZIPInputStream(new FileInputStream(file))));
				} else {
					br = new BufferedReader(new FileReader(file));
				}
			} catch (FileNotFoundException e) {
				LB.error("Can't open file " + file);
				LB.die();
			} catch (IOException io) {
				LB.error("Error processing gzipped Regions file " + source_files);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
				
			
			assert (br != null);
			
			//read header:
			String line = null;
			String chromosome = "";
			for (int x =0; x < 4; x++ ) {
				try {
					line = br.readLine();
				} catch (IOException io) {
					LB.error("Error encountered while reading region file header");
					LB.die();
				}
				assert(line != null);
				if (line.startsWith("# chromosome")) {
					String[] fields = line.split("\t");
					chromosome = fields[1];
				}
			}
			
			BufferedWriter bw = null;
			//String name = Variables.get("name");
			String output_file = Variables.get("output").concat(chromosome).concat(".aberations");
			
			try {
				bw = new BufferedWriter(new FileWriter(output_file));
			} catch (FileNotFoundException e) {
				LB.error("Can't open file " + output_file);
				LB.die();
			} catch (IOException io) {
				LB.error("Error processing gzipped Regions file " + output_file);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
				
			assert (bw != null);
			
			
			
			int linecount = 0; 
			try {
				while ((line = br.readLine()) != null) {
					linecount++;
					String[] fields = line.split("\t");
					int location = Integer.valueOf(fields[0]);
					bw.write("P\t" + chromosome + "\t" + location + "\t" + 1 + "\t");
					float s = Float.valueOf(fields[3]);
					float c = Float.valueOf(fields[4]);
					if (Float.valueOf(fields[3]) > Float.valueOf(fields[4])) {
						bw.write("sample ");
						bw.write( (!(c > 0)) ? (s +"/0") : ((s/c) + "x:" + s));
					} else {
						bw.write("compare ");
						bw.write( (!(s > 0)) ? (c +"/0") : ((c/s) + "x:" + c));
					}
					bw.write(" " + fields[5]);
					bw.newLine();
				}
			} catch (IOException io) {
				LB.error("Error occured on line " + linecount);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
			
			try {
				br.close();
				bw.close();	
			} catch (IOException io) {
				LB.error("Error occured while closing file " + file);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
			
		}
		
		
		LB.notice("Processing completed successfully.");
		LB.close();
	}
	
}

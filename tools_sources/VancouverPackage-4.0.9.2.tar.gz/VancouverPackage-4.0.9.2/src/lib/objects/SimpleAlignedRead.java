package src.lib.objects;

import src.lib.Error_handling.UnexpectedResultException;


/**
 * @version $Revision: 1791 $
 * @author 
 */
public class SimpleAlignedRead {
	private final String chr;
	private final boolean direction;
	private final int start;
	private final int end;
	private final char[] seq;
	private final byte[] prb;

	// ESCA-JAVA0138:
	public SimpleAlignedRead(String chr, int start, int end, boolean direction, String seq, byte[] prb ) {
		this.chr = chr;
		this.start = start;
		this.end = end;
		this.direction = direction;
		this.seq = seq.toCharArray();
		this.prb = prb.clone();
	}
	
	public String get_chr() { return this.chr;}
	public boolean get_direction() { return this.direction;}
	public int get_start() { return this.start;}
	public int get_end() { return this.end;}
	public char get_seq_at(int x) { return this.seq[x];}
	public short get_prb_at(int x) { return this.prb[x];}
	
	public final String get_seq() {
		StringBuffer sb = new StringBuffer();
		for(int a = 0; a < this.seq.length; a++) {
			sb.append(this.seq[a]);
		}
		return sb.toString();
	}
	
	public byte[] get_prb(int begin, int termiate) {
		byte[] a = new byte[termiate - begin +1]; 
		for (int y = 0; y <= termiate-begin; y++) { 
			a[y] = this.prb[y+begin];
		}
		return a;
	}
	
	public String get_prb_string() {
		StringBuffer sb = new StringBuffer();
		for (int a = 0; a < this.prb.length ; a ++) {
			sb.append(this.prb[a] + " ");
		}
		return sb.toString().trim();
	}
	
	public byte[] get_prb_byte() {
		return this.prb.clone();
	}
	
	public byte[] get_prb_byte_rev() {
		int l = this.prb.length;
		byte[] a = new byte[l];
		for (int x = 0; x < l; x++) {
			a[x] = this.prb[((l-1)-x)];
		}
		return a;
	}
	
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(this.chr + "\t" + this.start + "\t" + this.end + "\t" + this.get_seq() + "\t" + this.get_prb_string());
		return sb.toString();
	}
	
	public AlignedRead toAlignedRead() throws UnexpectedResultException{
		return new AlignedRead(
						(this.direction) ? '+' : '-',
						null,				/*Name,*/
						this.get_seq(),		/*Sequence,*/
						0,					/*score,*/
						0,					/*seqStart,*/
						0,					/*seqEnd,*/
						"junction",			/*alignName,*/
						this.chr,			/*chromosome,*/
						this.start,			/*alignStart,*/
						this.end,			/*alignEnd,*/
						0d,					/*percent,*/
						0d,					/*P,*/
						null,				/*alignseq,*/
						0,					/*mismatches,*/
						0d,					/*sort_score,*/
						0,					/*queryLength,*/
						this.seq.length,	/*alignLength,*/
						0,					/*contigStart,*/
						0,					/*contigEnd,*/
						0,					/*identity,*/
						null,				/*Match,*/
						0,					/*matches_noError,*/
						0,					/*matches_1error,*/
						0,					/*matches_2error,*/
						null,				/*N_reads,*/
						null, 				/*error1,*/
						null,				/*error2,*/
						null				/*quality*/
						);
	}
	
	
}

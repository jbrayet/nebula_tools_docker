package src.lib.objects;

/**
* Class for storing basic aberation details
* @author Genome Sciences Centre
* @version $Revision: 1482 $
*/
public class Aberation {
	private final char type;
	private final String chromosome;
	private final int start;
	private final int end;
	private final String comment;
	
	public Aberation(char type, String chromosome, int start, int span, String comment) {
		this.type = type;
		this.chromosome = chromosome;
		this.start = start;
		this.end = start + span;
		this.comment = comment;
		
	}
	
	public char get_type() { return this.type; }
	public String get_chromosome() { return this.chromosome; }
	public int get_start() { return this.start; }
	public int get_end() { return this.end; }
	public String get_comment() { return this.comment; }
	
	
	
	public SNP toSNP() {
		return new SNP(this.chromosome, this.start, '.', '.', 0, 0, 0, 0, 0, -1, "..");
	}
	
	
	
}

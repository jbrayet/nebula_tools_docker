package src.projects.findPeaks.FDR;


/**
 * 
 * 
 * Code licence: "Free, but reference me in your project", thus:
 * @author inspired by http://www.mhsatman.com
 * 
 * Code modified from original available for download.
 * 
 * @version $Revision: 1726 $ 
 */

// ESCA-JAVA0136:
public class Matrix {

	double[][] myData = null;
	int n;
	int m;

	public Matrix() {
	}

	public Matrix(int n, int m) {
		this.n = n;
		this.m = m;
		myData = new double[n][m];
	}

	public Matrix(double data[][]) {
		n = data.length;
		m = data[0].length;
		myData = new double[n][m];
		for(int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				myData[i][j] = data[i][j];
			}
		}
	}

	public double Det() {
		if (n != m) { return 0.0D; }
		double mydet = 1.0D;
		Matrix temp1 = new Matrix(myData);
		final double[][] temp2 = temp1.Eshelon().getData();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (i == j) {
					mydet *= temp2[i][j];
				}
			}
		}
		return mydet;
	}

	public Matrix Diff(Matrix A) {
		Matrix mynew = new Matrix(A.n, A.m);
		for (int i = 0; i < A.n; i++) { 
			for (int j = 0; j < A.m; j++) {
				mynew.setValue(i, j, myData[i][j] - A.getValue(i, j));
			}
		}
		return mynew;
	}

	public Matrix Eshelon() {
		double pivot = 0.0D;
		Matrix t = new Matrix(myData);
		double[][] temp = new double[t.n][t.m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				temp[i][j] = t.getValue(i, j);
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				pivot = -temp[j][i] / temp[i][i];
				for (int k = 0; k < m; k++) {
					temp[j][k] = temp[i][k] * pivot + temp[j][k];
				}
			}
		}
		return new Matrix(temp);
	}

	public Matrix Inverse() {
		// ESCA-JAVA0078:
		if (this.n != this.m || Det() == 0.0D) {
			return new Matrix(this.n, this.m);
		}
		Matrix temp = new Matrix(myData);
		int t_n = temp.n;
		int t_m = temp.m;
		Matrix Cofactor = new Matrix(t_n, t_m);
		for (int j = 0; j < t_m; j++) {
			for (int i = 0; i < t_n; i++) {
				Matrix Mintemp = temp.Minor(i, j);
				double tempdet = Mintemp.Det();
				Cofactor.setValue(i, j, tempdet);
			}

		}
		Cofactor = Cofactor.Transpose();
		double determ = temp.Det();
		for (int i = 0; i < t_n; i++) {
			for (int j = 0; j < t_m; j++) {
				Cofactor.setValue(i, j, (Cofactor.getValue(i, j) * Math.pow(-1D, i + j + 2)) / determ);
			}
		}
		return Cofactor;
	}

	public Matrix Minor(int x, int y) {
		Matrix temp = new Matrix(myData);
		Matrix newmat = new Matrix(temp.n - 1, temp.m - 1);
		int t_n = temp.n;
		int t_m = temp.m;
		int cnt = 0;
		double[] myArr = new double[(t_n - 1) * (t_m - 1)];
		for (int i = 0; i < t_n; i++) {
			for (int j = 0; j < t_m; j++) {
				if (i != x && j != y) {
					myArr[cnt] = temp.getValue(i, j);
					cnt++;
				}
			}
		}
		cnt = 0;
		for (int i = 0; i < t_n - 1; i++) {
			for (int j = 0; j < t_m - 1; j++) {
				newmat.setValue(i, j, myArr[cnt]);
				cnt++;
			}

		}
		return newmat;
	}

	public Matrix Mult(Matrix A) {
		double[][] c = new double[n][A.m];
		double[][] tempdata = A.getData();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < A.m; j++) {
				for (int y = 0; y < m; y++) {
					c[i][j] = c[i][j] + myData[i][y] * tempdata[y][j];
				}
			}
		}

		return new Matrix(c);
	}

	public Matrix Transpose() {
		Matrix temp = new Matrix(myData);
		int t_n = temp.n;
		int t_m = temp.m;
		Matrix newmat = new Matrix(t_m, t_n);
		for (int i = 0; i < t_n; i++) {
			for (int j = 0; j < t_m; j++) {
				newmat.setValue(j, i, temp.getValue(i, j));
			}
		}
		return newmat;
	}

	public double[][] getData() {
		double[][] temp = myData;
		return temp;
	}

	public Matrix getRow(int r) {
		Matrix temp = new Matrix(1, m);
		for (int i = 0; i < m; i++) {
			temp.myData[0][i] = myData[r][i];
		}
		return temp;
	}

	public double getValue(int x, int y) {
		return myData[x][y];
	}

	public Matrix scalerMult(double k) {
		Matrix temp = new Matrix(myData);
		for (int i = 0; i < temp.n; i++) {
			for (int j = 0; j < temp.m; j++) {
				temp.myData[i][j] = temp.myData[i][j] * k;
			}
		}

		return temp;
	}

	public void setValue(int x, int y, double value) {
		myData[x][y] = value;
	}

	public Matrix getMean() {
		Matrix temp = new Matrix(1, m);
		double u = 0.0D;
		for (int j = 0; j < m; j++) {
			u = 0.0D;
			for (int i = 0; i < n; i++) {
				u += myData[i][j];
			}
			temp.setValue(0, j, u / (double) n);
		}

		return temp;
	}
	
	
}
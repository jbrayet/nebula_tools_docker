package src.transcriptome_analysis.SNP_Detection;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.ensembl.datamodel.Location;
import org.ensembl.variation.datamodel.VariationFeature;

import src.lib.Chromosome;
import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.Ensembl;
import src.lib.IterableIterator;
import src.lib.ReducedAlignedReads;
import src.lib.SNPDB;
import src.lib.Utilities;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.Bedwriter;
import src.lib.ioInterfaces.FastaIterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;

// ESCA-JAVA0100:
/**
 * This application just calls snps and tells you if they're known or not.  Nothing more.
 * @version $Revision: 1670 $
 * @author 
 */
public class SNPAnalysis {
	// current state for Transcriptome processor
	static Ensembl Const = null;
	static Chromosome Chr;
	static int current_chromosome;


	// input variables
	static String elandfile_path;
	static String output_path;
	static String input_species;
	static String input_chr;
	static String name;
	static float min_percent;
	static int min_observed;
	static String conf_file;
	private static Log_Buffer LB;
	
	private SNPAnalysis() {}
	
	/**
	 * Processing command line arguments for program.
	 * @param Variables
	 */
	private static void parse_input(HashMap<String, String> Variables) {

		if (Variables == null) {
			usage();
		}
		
		assert (Variables != null);
		
		if (Variables.containsKey("help")) {
			usage();
		}
		
		/* Do bootstrap calls here */
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.notice("file names must be supplied with -name flag");
			usage();
		}
		
		if (Variables.containsKey("output")) {		
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + name  + ".log");
			LB.addLogFile(output_path + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			usage();
		}	
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output directory  : " + output_path);		
		LB.notice(" * Name              : " + name);
		
		if (Variables.containsKey("force32")) {
			CommandLine.test_parameter_count(LB, "force32", Variables.get("force32"), 0);
			Chromosome.set_force32(true);
			LB.notice(" * Filter Duplicates : On");
		} else {
			Chromosome.set_force32(false);
			LB.notice(" * Filter Duplicates : Off");
		}
		
		if (Variables.containsKey("min_alt")) {
			CommandLine.test_parameter_count(LB, "min_alt", Variables.get("min_alt"), 1);
			min_percent = Float.parseFloat(Variables.get("min_alt"));
			
			if (min_percent >1 || min_percent < 0) {
				LB.error("Min_alt value must be in the range of zero to one.");
				LB.close();
				System.exit(0);
			}
		} else { 
			LB.error("Must specify minimum alternative base percent for SNP positions with the -min_alt flag");
			usage();
		}
		LB.notice(" * Min. change fract : " + min_percent);
		
		if (Variables.containsKey("min_obs")) {
			CommandLine.test_parameter_count(LB, "min_obs", Variables.get("min_obs"), 1);
			min_observed = Integer.parseInt(Variables.get("min_obs"));
		} else { 
			LB.error("Must specify minimum observed base count for SNP positions with the -min_obs flag");
			usage();
		}
		LB.notice(" * Minimum coverage  : " + min_observed);
		
		
		if (Variables.containsKey("conf")) {		
			CommandLine.test_parameter_count(LB, "conf", Variables.get("conf"), 1);
			conf_file = Variables.get("conf");
			LB.notice(" * Config file       : " + conf_file);
		} else {
			LB.error("Must specify config file with the -conf flag");
			usage();
		}
		
		if (Variables.containsKey("chr")) {		
			CommandLine.test_parameter_count_min(LB, "chr", Variables.get("chr"), 1);
			input_chr = Variables.get("chr");
			LB.notice(" * Chromosome in use : " + input_chr);
		} else {
			LB.error("chomosome must be supplied with -chr flag");
			usage();
		}
		
		if (Variables.containsKey("species")) {		
			CommandLine.test_parameter_count(LB, "species", Variables.get("species"), 1);
			input_species =Variables.get("species");
			LB.notice(" * Input Species     : " + input_species);
		} else {
			LB.error("input species must be supplied with -input flag");
			usage();
		}
		
		if (Variables.containsKey("input")) {
			CommandLine.test_parameter_count(LB, "input", Variables.get("input"), 1);
			elandfile_path = Variables.get("input");
			if (!elandfile_path.endsWith(System.getProperty("file.separator"))) {
				elandfile_path = elandfile_path.concat(System.getProperty("file.separator"));
			}
			LB.notice(" * Input directory   : " + elandfile_path);
		} else { 
			LB.error("An input directory must be supplied with the -input flag" );
			usage();
		}
		
		
		
		Variables.remove("input");								//remove standard ht entries. 
		Variables.remove("output");								//Then process whatever is left with a warning:
		Variables.remove("species");
		Variables.remove("chr");
		Variables.remove("min_alt");
		Variables.remove("min_obs");
		Variables.remove("force32");
		Variables.remove("conf");
		
		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  " + k);
			}
			LB.die();
		}
	}		
		
		
	private static void usage() {
		LB.notice("This program requires six parameters:");
		LB.notice(" -input   | <String> | provide the full path to the eland files.");
		LB.notice(" -output  | <String> | provide a valid path for the output.");
		LB.notice(" -species | <String> | Provide a Species handled in the conf file");
		LB.notice(" -chr     | <String> | Indicate which chromosome to run, or \"A\" for all.");
		LB.notice(" -min_alt | <Float>  | Indicate the minimum fraction for calling a snp (eg 0.5");
		LB.notice(" -min_obs | <Int>    | Indicate the minimum coverage that must be observed to call. (eg 4)");
		LB.notice(" -force32 |          | use to force the maximum read length to be 32 bases.");
		LB.notice(" -conf    | <String> | The location of the configuration file to use.");
		LB.close();
		System.exit(0);	
	}


	
	/**
	 * This function processes SNPs, by retrieving all known snps for a given
	 * chromsome, before getting all observed snps (using a CLI passed
	 * variable). These two lists are then compared using a binary search to
	 * find the snps, and report on whether they're known, novel, or new for a
	 * given position
	 */
	private static void snp_processing() {

		BufferedWriter snpfile = null;

		try {
			snpfile = new BufferedWriter(new FileWriter(output_path
					+ Const.get_chromosome(current_chromosome) + ".snps"));
		} catch (IOException io) {
			LB.error("Error creating SNPs files.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}

		assert (snpfile != null);
		
		LB.notice("Retrieving all known SNPs from Ensembl SNP vardb for Chromosome...    ");
		SNPDB[] SNP_list = null;
		List<VariationFeature> variations_list = Ensembl.get_vfa(new Location(
				"chromosome", Const.get_chromosome(current_chromosome)));
		SNP_list = new SNPDB[variations_list.size()];
		for (int X = 0; X < variations_list.size(); X++) {
			VariationFeature A = variations_list.get(X);
			SNP_list[X] = new SNPDB();
			SNP_list[X].set_details(A.getAlleleString().toString());
			SNP_list[X].set_start(A.getLocation().getStart());
		}
		variations_list.clear();
		LB.notice("Done");

		LB.notice("Processing Simple SNPS in Chromosome...                               ");
		ArrayList<SNP> ALL_snps = new ArrayList<SNP>();
		ALL_snps = Chr.get_all_SNPs(min_percent, min_observed);
		String bedfile = output_path + Const.get_chromosome(current_chromosome)
				+ ".SNP.bed.gz";
		Bedwriter bed = new Bedwriter(LB, bedfile);
		bed.BedHeader("SNPs", "SNPs found", false);
		int snpcnt = 0;
		try {
			for (SNP base : ALL_snps) {
				snpcnt++;
				int pos = base.get_position();
				char alt_base = base.get_new_base();
				float score = ((((float) base.get_coverage_snp()) / ((float) base
						.get_total_coverage())) * 100);
				snpfile.write(Const.get_chromosome(current_chromosome) + ","	// wig files are 1 based, bed files are zero based.
						+ (pos + 1) + ",");
				snpfile.write(base.get_coverage_snp() + "," + base.get_total_coverage() + ","
						+ alt_base + ",");
				bed.writelineSNP("chr" + Const.get_chromosome(current_chromosome),
						pos, alt_base, (int) score);
				
				int index = SNPDB.SNPbinarySearch(SNP_list, pos + 1);	// check if in SNP_list
				if (index != -1) {
					String Allele = SNP_list[index].get_details();
					if (Allele.length() < 3) {
						LB.warning("Allele found, no SNP! :" + Allele);
						snpfile.write("novel(nosnp)\n");
					} else {									// else, does not match - no known snp.
						snpfile.write(Utilities.is_expected_base(Allele,
								Chr.get_base_at(pos), alt_base));
						
					}
				} else {
					snpfile.write("novel\n");
				}
			}
			
		} catch (IOException io) {
			LB.error("Can't write snp files");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		ALL_snps.clear();
		LB.notice("Done");
		LB.notice(snpcnt + " SNPS found");

		try {
			snpfile.close();
		} catch (IOException io) {
			LB.warning("Could not close buffered writer");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		bed.close();
	}

	/**
	 * Main function for processing Transcriptome data.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();		
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables);									//interprets command line args.

		new CurrentVersion(LB);
		LB.Version("SNPAnalysis", "$Revision: 1670 $");
		
		Const = Ensembl.init(LB, input_species, conf_file, input_chr);

		int read_count = 0;
		int fail_count = 0;
		int coverage = 0;
		int total_coverage = 0;

		for (current_chromosome = 0; current_chromosome < Const.get_number_of_chromosomes(); current_chromosome++) {
			read_count = 0;
			fail_count = 0;
			LB.notice("*** Begin Processing Chromosome "
					+ Const.get_chromosome(current_chromosome));
			LB.notice("Creating Chromosome...");
			String ffile = Const.getFastaFilename(current_chromosome);
			

			FastaIterator fi = new FastaIterator(LB, ffile);
			String[] rrr = null;
			while (rrr == null && fi.hasNext()) {	
				rrr = fi.next();								//only want first record.
			}
			fi.close();
			Chr = new Chromosome(LB, rrr[1], "chr" + current_chromosome, 0);  //as long as this is eland only, min_alt_quality = 0
			LB.notice("Done");
			
			LB.notice("Loading Reads...");
			
			/*Process Eland Files*/
			
			String elandfile = elandfile_path + Const.get_chr_filename(current_chromosome) + ".part.eland.gz";
			ReducedAlignedReads.LoadElandReads(LB, elandfile, Chr, Const, current_chromosome);
			LB.notice("Done");
			
			/*process Eland Extended Files*/

			LB.notice("Chromosome "
					+ Const.get_chromosome(current_chromosome) + " Reads passed: "
					+ read_count + " Reads Failed: " + fail_count);
			total_coverage += coverage;

			snp_processing();

		
			Chr.destroy();
		} 														// end chromosome
	}

}

	

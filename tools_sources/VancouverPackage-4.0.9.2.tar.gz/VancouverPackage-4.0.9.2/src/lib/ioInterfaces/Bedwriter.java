package src.lib.ioInterfaces;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.zip.GZIPOutputStream;


/**
 * @version $Revision: 1019 $
 * @author 
 *
 */
public class Bedwriter {
	
	private static final int DEFAULT_PRIORITY = 10;
	private static final int DEFAULT_VISIBILITY = 2;
	private static final int SCORE_MULTIPLIER_TEN = 10;
	
	private static boolean display_version = true;
	private static Log_Buffer LB;
	/**
	 * Killer information:  Unlike Wig files, Bed files are Zero based!!!!!
	 */

	BufferedWriter bw;
	
	public Bedwriter(Log_Buffer logbuffer, String file) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("BedWriter", "$Revision: 1019 $");
			display_version = false;
		}
		try {
			bw = new BufferedWriter(new OutputStreamWriter
					(new GZIPOutputStream(new FileOutputStream(file))));
		} catch (FileNotFoundException E) {
			LB.error("Error: Bed File Not Found : " + file);
			LB.die();
		} catch (IOException io) {
			LB.error("Error: Coundn't create bed file : " + file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	

	
	public void writeln(String chr, int X, int Y) {
		try {
			bw.write(chr + '\t' + X + '\t' + Y);
			bw.newLine();
		} catch (IOException io) {
			LB.warning(io.getStackTrace().toString());
			LB.warning("could not write \"" + X + "\"  to file : ");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	
	/**
	 * 
	 * @param chr
	 *            The name of the chromosome (e.g. chr3, chrY, chr2_random) or
	 *            scaffold (e.g. scaffold10671).
	 * @param X
	 *            The starting position of the feature in the chromosome or
	 *            scaffold. The first base in a chromosome is numbered 0.
	 * @param Y
	 *            The ending position of the feature in the chromosome or
	 *            scaffold. The chromEnd base is not included in the display of
	 *            the feature. For example, the first 100 bases of a chromosome
	 *            are defined as chromStart=0, chromEnd=100, and span the bases
	 *            numbered 0-99.
	 * @param name
	 *            Defines the name of the BED line. This label is displayed to
	 *            the left of the BED line in the Genome Browser window when the
	 *            track is open to full display mode or directly to the left of
	 *            the item in pack mode.
	 * @param score
	 *            A score between 0 and 1000. If the track line useScore
	 *            attribute is set to 1 for this annotation data set, the score
	 *            value will determine the level of gray in which this feature
	 *            is displayed (higher numbers = darker gray).
	 * @param dir
	 *            Defines the strand - either '+' or '-'.
	 * @param thickstart
	 *            The starting position at which the feature is drawn thickly
	 *            (for example, the start codon in gene displays).
	 * @param thickend
	 *            The ending position at which the feature is drawn thickly (for
	 *            example, the stop codon in gene displays).
	 * @param R
	 *            An RGB value of the form R,G,B (e.g. 255,0,0). If the track
	 *            line itemRgb attribute is set to "On", this RBG value will
	 *            determine the display color of the data contained in this BED
	 *            line. NOTE: It is recommended that a simple color scheme
	 *            (eight colors or less) be used with this attribute to avoid
	 *            overwhelming the color resources of the Genome Browser and
	 *            your Internet browser.
	 * @param G
	 *            G value of RGB
	 * @param B
	 *            B value of RGB
	 * @param blocks
	 *            The number of blocks (exons) in the BED line
	 * @param block_sizes
	 *            A comma-separated list of the block sizes. The number of items
	 *            in this list should correspond to blockCount
	 * @param block_starts
	 *            A comma-separated list of block starts. All of the blockStart
	 *            positions should be calculated relative to chromStart. The
	 *            number of items in this list should correspond to blockCount
	 */
	// ESCA-JAVA0138:
	public void writelnExt(String chr, int X, int Y, String name, int score,
			char dir, int thickstart, int thickend, int R, int G, int B,
			int blocks, String block_sizes, String block_starts) {
		try {
			bw.write(chr + '\t' + X + '\t' + Y + '\t' + name + '\t' + score
					+ '\t' + dir + '\t' + thickstart + '\t' + thickend + '\t'
					+ R + ',' + G + ',' + B);
			if (blocks == 0 ) {
				//if there is no block just don't write anything
				//bw.write("\t" + 0);
			} else {
				bw.write("\t" + blocks + "\t" + block_sizes + "\t" + block_starts);
			}
			bw.newLine();
		} catch (IOException io) {
			LB.warning("could not write \"" + chr + ":" + X + "\"  to file : ");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	

	
	public void close() {
		try {
			bw.close();
		} catch (IOException io) {
			LB.warning("Could not close buffered BED writer");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	
	/**
	 * File writer to output the header for SNPs to a BED type file.
	 * @param name
	 * @param description
	 * @param priority
	 * @param visibility
	 * @param RGB
	 */
	public void BedHeader(String name, String description, int priority, int visibility, boolean RGB) {
		try {
			//bw.write("browser hide all\n");
			bw.write("track name=\"" + name +"\" description=\"" + description + "\" visibility="+visibility+" priority="+priority);
			if (RGB) {
				bw.write(" itemRgb=\"On\"");	
			}
			bw.newLine();
		}
		catch (IOException io){
			LB.error("Could not write header to BED file.  Halting.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	/**
	 * File writer to output the header for SNPs to a BED type file.
	 * @param name
	 * @param description
	 * @param RGB
	 */
	public void BedHeader(String name, String description, boolean RGB) {
		BedHeader(name, description, DEFAULT_PRIORITY, DEFAULT_VISIBILITY,  RGB);
	}
	
	
	
	
	/*
	 * File writer to output the SNPs to a BED type file.
	 */
	public void writelineSNP(String chr, int position, char alternative, int score) {
		int percent = 0;
		try {
			bw.write(chr);			//BED name
			bw.write("\t");
			bw.write(String.valueOf(position));		//location of feature
			bw.write("\t");
			bw.write(String.valueOf(position+1));		//end of feature location
			bw.write("\t");
			bw.write(String.valueOf(alternative));	//name of feature
			bw.write("\t");
			percent = score * SCORE_MULTIPLIER_TEN;
			if ((percent <= 1000) || (percent >= 0))  {
				bw.write(String.valueOf(percent));		//needs to be a value between 0 and 1000
				bw.newLine();
			}
			else { 
				bw.write("0");
				bw.newLine();
				LB.warning("Score : " + score + " : " + percent);
				LB.warning("SNP at position " + position
						+ " has score (" + percent
						+ ") out of bounds - writing zero.");
			}
		}
		catch (IOException io){
			LB.error("Could not write SNPs to BED file.  Halting.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();			
		}
	}
	
	
}
package src.lib.objects;

public class MinimalLocation {

	private final String chr;
	private final int start;
	private final int end;
	
	MinimalLocation(String chromosome, int start, int end) {
		this.chr = chromosome;
		this.start = start;
		this.end = end;
	}
	
	public String get_chr()  { return this.chr; }
	public int get_start()  { return this.start; }
	public int get_end()  { return this.end; }
	
}

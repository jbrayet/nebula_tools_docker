package src.transcriptome_analysis.SNP_Detection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.ensembl.datamodel.Location;
import org.ensembl.datamodel.Transcript;

import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.CurrentVersion;
import src.lib.Ensembl;
import src.lib.IterableIterator;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.analysisTools.Process_Exons;
import src.lib.analysisTools.Process_SNPs;
import src.lib.ioInterfaces.FastaIterator;
import src.lib.ioInterfaces.GSC_Aberation_Iterator;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Aberation;
import src.lib.objects.SNP;



// ESCA-JAVA0100:
/**
 * @version $Revision: 1668 $
 * @author 
 */
public class evaluate_snps {
	/*current state for Transcriptome processor*/
	static Ensembl Const = null;
	static String[] CanonicalSequence = null;

	/* input variables*/
	static String input_file;
	static String output_path;
	static String name;
	static String input_species;
	static String input_chr;
	static String conf_file;
	static String aligner;
	static int maq_quality_filter;
	static int maq_file_format;

	private evaluate_snps() {}

	private static Log_Buffer LB = null;
	
	/**
	 * Processing command line arguments for program.
	 * 
	 * @param Variables
	 *            Command line arguments: input path, output path, Species,
	 *            Chromosome(s), min snp percent, min snp observed.
	 */
	private static void parse_input(HashMap<String, String> Variables) {
		if (Variables == null) {
			usage();
		}
		assert (Variables != null);

		if (Variables.containsKey("help")) {
			usage();
		}

		/* Do bootstrap calls here */
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.notice("file names must be supplied with -name flag");
			usage();
		}
		
		if (Variables.containsKey("output")) {		
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + name  + ".log");
			LB.addLogFile(output_path + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			usage();
		}	
		
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output file name  : " + output_path);		
		LB.notice(" * Name              : " + name);
		
		if (Variables.containsKey("conf")) {
			CommandLine.test_parameter_count(LB, "conf", Variables.get("conf"), 1);
			conf_file = Variables.get("conf");
			LB.notice(" * Config file       : " + conf_file);
		} else {
			LB.error("Must specify config file with the -conf flag");
			usage();
		}

		if (Variables.containsKey("chr")) {
			CommandLine.test_parameter_count_min(LB, "chr", Variables.get("chr"), 1);
			input_chr = Variables.get("chr");
			LB.notice(" * Chromosome in use : " + input_chr);
		} else {
			LB.error("chomosome must be supplied with -chr flag");
			usage();
		}

		if (Variables.containsKey("species")) {
			CommandLine.test_parameter_count(LB, "species", Variables.get("species"), 1);
			input_species =Variables.get("species");
			LB.notice(" * Input Species     : " + input_species);
		} else {
			LB.error("input species must be supplied with -species flag");
			usage();
		}

		if (Variables.containsKey("input")) {
			CommandLine.test_parameter_count(LB, "input", Variables.get("input"), 1);
			input_file = Variables.get("input");
			LB.notice(" * Input file       : " + input_file);
		} else { 
			LB.error("An input file must be supplied with the -input flag" );
			usage();
		}
		
		if (Variables.containsKey("aligner")) {
			CommandLine.test_parameter_count(LB, "aligner", Variables.get("aligner"), 1);
			aligner = Variables.get("aligner");
			LB.notice(" * Aligner soure    : " + aligner);
		} else { 
			LB.error("The type of input file must be supplied with the -aligner flag" );
			usage();
		}
		
		if (Variables.containsKey("maq_file_format")) {
			if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAQ)) {
				CommandLine.test_parameter_count(LB, "maq_file_format", Variables.get("maq_file_format"), 1);
				maq_file_format = Integer.valueOf(Variables.get("aligner"));
				LB.notice(" * Maq file format  : " + maq_file_format);	
			} else {
				LB.error("Can not use \"-maq_file_format\" flag with non-maq aligner.");	
				usage();
			}
		} else {
			if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAQ)) {
				LB.notice(" * Maq file format  : None provided (128 default)");
				maq_file_format = 128;
			}
		}
		
		
		if (Variables.containsKey("qualityfilter")) {
			if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAQ)) {
				CommandLine.test_parameter_count(LB, "qualityfilter", Variables.get("qualityfilter"), 1);
				maq_quality_filter = Integer.valueOf(Variables.get("aligner"));
				LB.notice(" * Maq min. quality : " + maq_quality_filter);	
			} else {
				LB.error("Can not use \"-qualityfilter\" flag with non-maq aligner.");	
				usage();
			}
		} else {
			if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAQ)) {
				LB.notice(" * Maq min. quality : None provided (zero default)");
				maq_quality_filter =0;
			}
		}
		

		/*remove standard ht entries. Then process whatever is left with a warning:*/
		Variables.remove("aligner");
		Variables.remove("chr");
		Variables.remove("conf");
		Variables.remove("input");
		Variables.remove("name");
		Variables.remove("output");
		Variables.remove("qualityfilter");
		Variables.remove("species");
		

		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  * " + k);
			}
			LB.die();
		}
	}

	private static void usage() {
		LB.notice("This program requires six parameters:");
		LB.notice(" -input      | <String> | provide the full path to the input file.");
		LB.notice(" -output     | <String> | provide a valid path for the output.");
		LB.notice(" -species    | <String> | Provide a Species handled in the conf file");
		LB.notice(" -chr        | <String> | Indicate which chromosome to run, or \"A\" for all.");
		LB.notice(" -conf       | <String> | The location of the configuration file to use.");
		LB.notice(" -name       | <String> | File pre-fix to use for log file output.");
		LB.notice(" -aligner    | <String> | The aligner type to use");
		LB.die();
	}

	/**
	 * 
	 * @param ffile
	 */
	private static void new_chr_from_fasta_file (String ffile) {
		FastaIterator fi = new FastaIterator(LB, ffile);
		CanonicalSequence = fi.next();
		fi.close();
	}

	/**
	 * Main function for processing Transcriptome data.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		/* This code bootstraps the log file */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables);									//interprets command line args.

		new CurrentVersion(LB);
		LB.Version("evaluate_snps", "$Revision: 1668 $");
		
		boolean snp_p = false;									//turns off snp processing, which isn't needed in Yaron's pipeline.

		Const = Ensembl.init(LB, input_species, conf_file, input_chr); // build the Ensembl interface 
		for (int current_chromosome = 0; current_chromosome < Const.get_number_of_chromosomes(); current_chromosome++) {
			LB.notice("*** Begin Processing Chromosome " + Const.get_chromosome(current_chromosome));
			LB.notice("Obtaining Canonical Sequence/Building Chromosome...");
			String ffile = Const.getFastaFilename(current_chromosome);
			new_chr_from_fasta_file(ffile);
			LB.notice("Loading Reads...");
			ArrayList<SNP> trans_snps = new ArrayList<SNP>();
			if (!aligner.equalsIgnoreCase(Constants.FILE_TYPE_SNP)) {
				Generic_AlignRead_Iterator it = new Generic_AlignRead_Iterator(
						LB, aligner, "input_file", input_file,
						maq_quality_filter, maq_file_format, null, 0,false);
				while (it.hasNext()) {
					
				}
				LB.error("This setting (non bed files) is currently under development.  Sorry!");
				LB.die();
				//TODO: build code here.
					//build chromosome, 
					//extract snps to trans_snps array.
				
				
			} else {   //SNP type.
				GSC_Aberation_Iterator it = new GSC_Aberation_Iterator(LB, "input_file", input_file, true);
				
				for (Object a : new IterableIterator<Object>(it)) {
					//if type = snp.
					trans_snps.add(((Aberation)a).toSNP());			//convert nsnp to a SNP object and add to trans_snps
				}
			}
			SNP[] snps = new SNP[trans_snps.size()];
			snps = trans_snps.toArray(snps);
			Arrays.sort(snps);
			LB.notice("Sorting/processing SNPs...");
			
			ArrayList<SNP> oneChrSnps = new ArrayList<SNP>();
			for (SNP s : snps) {
				if (s.get_chromosome().equals(Const.get_chromosome(current_chromosome))) {					
					oneChrSnps.add(s);
				}
			}
			SNP[] thischr_snps = new SNP[oneChrSnps.size()];
			thischr_snps = oneChrSnps.toArray(thischr_snps);
			Arrays.sort(thischr_snps);
			
			
			if (snp_p) {  
				Process_SNPs.snp_processing(LB, Const, CanonicalSequence, current_chromosome, thischr_snps, output_path);
			}
			LB.notice("Fetching Exon Locations...");
			Location loc = new Location("chromosome", Const.get_chromosome(current_chromosome));
			List<Transcript> list = Ensembl.get_ta(loc);
			LB.notice("Done");
			LB.notice("Processing Exons in Chromosome...");
			Process_Exons.process_exons(LB, Const, CanonicalSequence, list, current_chromosome, input_species, snps, output_path);
			LB.notice("Done");
		} 
		Const.destroy();
		Const = null;														// end chromosome
		LB.close();
	}
}
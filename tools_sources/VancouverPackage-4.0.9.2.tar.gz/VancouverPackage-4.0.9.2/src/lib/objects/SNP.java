package src.lib.objects;

// ESCA-JAVA0100:
/**
 * @version $Revision: 1621 $
 * @author 
 */
public class SNP implements Comparable<SNP> {
	
	static final int BLANK_INT = -1;
	
	
	String chr = null;
	int position = BLANK_INT;
	char alternative = ' ';
	int coverage_snp = BLANK_INT;
	int coverage_ref = BLANK_INT;
	int coverage_total = BLANK_INT;
	int misc = BLANK_INT;
	char cannonical = ' ';
	double quality = 0d;
	/**
	 * Hetrozygous -1 is uncalled, 0 is false, 1 is true; 
	 */
	int hetrozygous = -1;
	String id = null;
		
	// ESCA-JAVA0138:
	public SNP(String chr, int pos, char alt, char cannon, int obs_snp, int obs_ref, int total,
			int misc, double quality, int hetrozygous, String id) {
		this.chr = chr;
		this.position = pos;
		this.alternative = alt;
		this.cannonical = cannon;
		this.coverage_snp = obs_snp;
		this.coverage_ref = obs_ref;
		this.coverage_total = total;
		this.misc = misc;
		this.quality = quality;
		this.hetrozygous = hetrozygous;
		this.id = id;	
	}
	
	public SNP copy_snp() {
		SNP B = new SNP(
						this.chr,
						this.position,
						this.alternative,
						this.cannonical,
						this.coverage_snp,
						this.coverage_ref,
						this.coverage_total, 
						this.misc,
						this.quality,
						this.hetrozygous,
						this.id);
		return B;
	}
	
	public void set_position(int A) {
		this.position = A;
	}
	
	public String get_id() {
		return this.id;
	}
	
	
	public int compareTo(SNP o) {
		return this.position - o.position;
	}
	
	/**
	 * get chromosome - accessor function;
	 * @return 
	 */
	public final String get_chromosome() {
		return this.chr;
	}
	
	/**
	 * get base - accessor function;
	 * @return
	 */
	public final char get_new_base() {
		return this.alternative;
	}
	
	public final char get_snp_cannonical() {
		return this.cannonical;
	}
	
	public final int get_hetrozygous() {
		return this.hetrozygous;
	}
	
	
	/**
	 * get misc value - accessor function;
	 * @return
	 */
	public final int get_misc_value() {
		return this.misc;
	}
	
	/**
	 * get quality value - accessor function;
	 * @return
	 */
	public final double get_quality() {
		return this.quality;
	}
	
	
	/**
	 * get position - accessor function;
	 * @return
	 */
	public final int get_position() {
		return this.position;
	}
	
	/**
	 * get total - accessor function;
	 * @return
	 */
	public final int get_total_coverage() {
		return this.coverage_total;
	}

	/**
	 * get count - accessor function;
	 * @return
	 */
	 public final int get_coverage_snp() {
		return this.coverage_snp;
	}
	
	/**
	 * get count - accessor function;
	 * @return
	 */
	public final int get_coverage_ref() {
		return this.coverage_ref;
	}
	 
	/**
	 * subtract Y from current position
	 * @param Y
	 */
	public final void addto_position(int Y) {
		this.position += Y;
	}
	
	/**
	 * set value of snp.misc property
	 * @param Y
	 */
	public final void set_misc_value(int Y) {
		this.misc = Y;
	}
	
	
}
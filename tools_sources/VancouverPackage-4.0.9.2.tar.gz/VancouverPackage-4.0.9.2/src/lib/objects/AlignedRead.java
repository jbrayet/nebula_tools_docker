package src.lib.objects;

import java.util.Vector;

import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedCharacterException;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.ioInterfaces.ElandExtUtilities;

// ESCA-JAVA0136:
/**
 * Class to unify all types of sequence alignments
 * @author Genome Sciences Centre
 * @version $Revision: 1791 $
 */
public class AlignedRead implements Comparable<AlignedRead> {
	public static final int    ARRAY_INIT_SIZE = 1000;

	/** direction of alignment, can be either '+' or '-' */		private final char direction;
	/** The name of the query */								private final String Name;
	/** The original (query) Sequence */						private final String Sequence;
	/** the blast/eland/quality score */						private final int score;
	/** Start of the alignment in the query */					private final int seqStart;
	/** End of the alignment in the query */					private final int seqEnd;
	/** Name of the database sequence  */						private final String alignName;
	/** Chromosome on which match was found. */					private final String chromosome;
	/** Start of the alignment in the database */				private final int alignStart; 
	/** End of the alignment in the database */					private final int alignEnd; 
	/** Percent matching */										private final double percent;
	/** P-value of alignment */									private final double P;
	/** The aligned database sequence. */						private final String alignseq;  
	/** The mismatch count */									private final int mismatches;
	/** The value used to sort */								private double sort_score;
	/** The length of the original query ... probably */		private final int queryLength;
	/** The length of the alignment (end - start) */			private final int alignLength;
	/** The start point of the best contiguous 
     *	match (in the alignment, starting at 0 */				private final int contigStart; 								
    /** The end point of the best contiguous match 
	 *  	(in the alignment, starting at 0 */					private final int contigEnd;
	/** identity property */									private final int identity;
	/** Eland Specific: Type of match found. */					private final String Match;
	/** Eland Specific: 5. Number of 1-error matches found. */	private final int matches_noError;
	/** Eland Specific: 6. Number of 2-error matches found. */	private final int matches_1error;							
	/** Eland Specific: Rest of fields are only seen if a
	 *		unique best match was found */					 	private final int matches_2error; 
	/** Eland Specific: 10. How N characters in read 
	 *		were interpreted: */								private final String N_reads;								
	/** Position and type of first substitution 
	 * 		error eg. 12A */									private final String error1;
	/** Position and type of first substitution error */		private final String error2;
	/** quality of match */										private final byte[] quality;
	// ESCA-JAVA0138:

	/**
	 * Create new Aligned Read
	 * @param direction
	 * @param Name
	 * @param Sequence
	 * @param score
	 * @param seqStart
	 * @param seqEnd
	 * @param alignName
	 * @param chromosome
	 * @param alignStart
	 * @param alignEnd
	 * @param percent
	 * @param P
	 * @param alignseq
	 * @param mismatches
	 * @param sort_score
	 * @param queryLength
	 * @param alignLength
	 * @param contigStart
	 * @param contigEnd
	 * @param identity
	 * @param Match
	 * @param matches_noError
	 * @param matches_1error
	 * @param matches_2error
	 * @param N_reads
	 * @param error1
	 * @param error2
	 * @param quality
	 * @throws UnexpectedResultException
	 */
	public AlignedRead(
			final char direction,
			final String Name,
			final String Sequence,
			final int score,
			final int seqStart,
			final int seqEnd,
			final String alignName,
			final String chromosome,
			final int alignStart,
			final int alignEnd,
			final double percent,
			final double P,
			final String alignseq,
			final int mismatches,
			final double sort_score,
			final int queryLength,
			final int alignLength,
			final int contigStart,
			final int contigEnd,
			final int identity,
			final String Match,
			final int matches_noError,
			final int matches_1error,
			final int matches_2error,
			final String N_reads,
			final String error1,
			final String error2,
			final byte[] quality) throws UnexpectedResultException {

		if (direction != '+' && direction != '-') {
			throw new UnexpectedResultException("Direction character " + direction + " unrecognized.  Should be \'+\' or \'-\'");
		}
		this.direction	 		= direction;
		this.Name				= Name;
		this.Sequence			= Sequence;
		this.score				= score; 
		this.seqStart			= seqStart; 
		this.seqEnd				= seqEnd;
		this.alignName			= alignName;
		this.chromosome			= chromosome;
		if (alignStart < 0) {
			throw new UnexpectedResultException("Align start position is less than 0");
		}	
		this.alignStart			= alignStart;
		this.alignEnd			= alignEnd;
		this.percent			= percent;
		this.P					= P;
		this.alignseq			= alignseq;
		if (mismatches == -1) {
			throw new UnexpectedResultException("Mismatches is less than 0");
		}
		this.mismatches			= mismatches;
		this.sort_score			= sort_score;
		this.queryLength		= queryLength;
		if (this.alignLength<0) {
			 throw new UnexpectedResultException("Align length is less than 0");
		} 
		this.alignLength		= alignLength;
		this.contigStart		= contigStart;
		this.contigEnd			= contigEnd;
		this.identity			= identity;
		this.Match				= Match;
		this.matches_noError	= matches_noError;
		this.matches_1error		= matches_1error;
		this.matches_2error		= matches_2error;
		this.N_reads			= N_reads;
		this.error1				= error1;
		this.error2				= error2;
		if (quality!=null) {			//TODO check when and why this quality can be null.
			this.quality 		= quality.clone();
		} else {
			this.quality 		= new byte[alignLength];
		}		
	}

	/* Template: 
	 * AlignedRead a = new AlignedRead(
					direction,
					Name,
					Sequence,
					score,
					seqStart,
					seqEnd,
					alignName,
					Genome,
					chromosome,
					alignStart,
					alignEnd,
					percent,
					P,
					alignseq,
					mismatches,
					sort_score,
					queryLength,
					alignLength,
					contigStart,
					contigEnd,
					identity,
					Match,
					matches_noError,
					matches_1error,
					matches_2error,
					N_reads,
					error1,
					error2,
					alignments,
					structure,
					quality);
	 */



	/** CompareTo method for comparing sorting of aligned reads. 
	 * 
	 * @return
	 */
	public int compareTo(AlignedRead a) {
		if (a.sort_score < sort_score) {
			return -1;
		}
		if (a.sort_score > sort_score) {
			return 1;
		}
		if (a.direction == direction) {
			return 0;
		}
		if (a.direction == '-') {
			return -1;
		}
		return 1;
	}

	/**
	 * Method to find the read with the best p value in a vector of aligned reads
	 * @param v
	 * @return
	 */
	public static AlignedRead getBestP(Vector<AlignedRead> v) {
		if (v == null) {
			return null;
		}
		if (v.size() == 0) {
			return null;
		}
		AlignedRead a = v.elementAt(0);
		for (int i = 1; i < v.size(); i++) {
			if (v.elementAt(i).P < a.P) {
				a = v.elementAt(i);
			}
		}
		return a;
	}

	/**
	 * 
	 * @return A very simple string representation of the aligned read.
	 */
	@Override
	public String toString() {
		String s = this.Name + "\t" + this.Sequence + "\t" + this.chromosome
				+ "\t" + this.alignStart + "\t" + this.direction;
		return s;
	}

	/**
	 * Output an Aligned read in Eland format.
	 * @return
	 */
	public String outEland() {
		StringBuffer s = new StringBuffer(ARRAY_INIT_SIZE);
		s.append(this.Name + "\t");
		s.append(this.Sequence + "\t");
		s.append((this.Match == null) ? "U0\t" : (this.Match + "\t"));
		s.append(this.matches_noError + "\t");
		s.append(this.matches_1error + "\t");
		s.append(this.matches_2error + "\t");
		s.append(this.chromosome + "\t");
		s.append(this.alignStart + "\t");
		if (this.direction == '+') {
			s.append("F" + "\t");
		} else if (this.direction == '-') {
			s.append("R" + "\t");
		} 
		s.append((this.N_reads == null) ? "..\t" : (this.N_reads + "\t"));
		if (this.error1 != null) {
			s.append(this.error1 + "\t");
		}
		if (this.error2 != null) {
			s.append(this.error2 + "\t");
		}
		return s.toString();
	}

	/**
	 * output an aligned read in Mapview format.
	 * @return
	 */
	public String outMapview() {
		StringBuffer s = new StringBuffer(ARRAY_INIT_SIZE);
		s.append(this.Name + "\t");
		s.append(this.chromosome + "\t");
		s.append(this.alignStart + "\t");
		s.append(this.direction + "\t");
		s.append("0\t");
		s.append("0\t");
		s.append(this.score + "\t");
		s.append(this.score + "\t");
		s.append(this.score + "\t");
		s.append(this.mismatches + "\t");
		s.append("0\t");
		s.append(this.matches_noError + "\t");
		s.append(this.matches_1error + "\t");
		s.append(this.alignLength);
		return s.toString();
	}

	/**
	 * Produce a GFF line from an aligned read - probably not a great idea to use as a conversion tool.
	 * @return
	 */
	public String outGff() {
		StringBuffer s = new StringBuffer(ARRAY_INIT_SIZE);
		s.append(this.chromosome + "\t");
		s.append(this.Name + "\t");
		s.append(this.alignName + "\t");
		s.append(this.alignStart + "\t");
		s.append(this.alignEnd + "\t");
		s.append(((this.score == 0) ? "." : this.score) + "\t");
		s.append(this.direction + "\t");
		s.append(((this.contigStart == 0) ? "." : this.contigStart) + "\t");
		s.append(this.N_reads);
		return s.toString();
	}

	/**
	 * setter sort score 
	 * @param x
	 */
								public final void		set_sort_score(int x) { this.sort_score = x; }

	/** @return mismatches */	public final int 		get_mismatches()	{ return this.mismatches; }
	/** @return alignstart */	public final int		get_alignStart() 	{ return this.alignStart; }
	/** @return align end  */	public final int 		get_alignEnd() 		{ return this.alignEnd; }
	/** @return direction  */	public final char		get_direction() 	{ return this.direction; }
	/** @return sequence   */	public final String		get_sequence() 		{ return this.Sequence; }
	
	/** @return sort score */	public final double		get_sort_score()	{ return this.sort_score; }
	/** @return chromosome */	public final String 	get_chromosome()	{ return this.chromosome; }
	/** @return align name */	public final String		get_alignName()		{ return this.alignName; }
	/** @return name       */	public final String 	get_name()			{ return this.Name; }
	/** @return align len. */	public final int		get_alignLength() 	{ return this.alignLength; }
	/** @return match     
	 * @deprecated */	public final String 	get_match() 		{ return this.Match; }

	/*Dual purpose fields*/
	/** @return maq indel  */	public final int 		get_maq_indel_loc()		{ return this.seqStart; }
	/** @return eland st.  */	public final int 		get_eland_seqstart()	{ return this.seqStart; }

	/** @return maq indel  */	public final int		get_maq_indel_len()		{ return this.seqEnd; }
	/** @return eland se.  */	public final int		get_eland_seqend()		{ return this.seqEnd; }

	/** @return score      */	public final int	 	get_score()				{ return this.score; }
	/** @return maq pair q */	public final int	 	get_maq_pair_qual()		{ return this.score; }

	/** @return identity   */	public final int		get_identity()	 		{ return this.identity; }
	/** @return maq sw fl. */	public final int		get_maq_sw_flag() 		{ return this.identity; }
	/** @return bed color  */	public final int		get_BED_colour() 		{ return this.identity; }

	/** @return maq pet i  */	public final int		get_maq_PET_insert_sz() { return this.queryLength; }

	/** @return bed type   */	public final String		get_BED_type()			{ return this.alignseq; }
	/** @return align seq  */	public final String 	get_alignseq()			{ return this.alignseq; }
	

	/**
	 * getter quality
	 * @param x
	 * @return
	 */
	public final int get_quality(int x) {
		assert (x < this.quality.length); 
		return this.quality[x]; 
	}

	/**
	 * getter - get qualities for a subset of the bases     
	 * 	
	 * @param begin
	 * @param termiate
	 * @return
	 */
	public byte[] get_prb(int begin, int termiate) {
		byte[] a = new byte[termiate - begin +1]; 
		for (int y = 0; y <= termiate-begin; y++) { 
			a[y] = this.quality[y+begin];
		}
		return a;
	}

	/** getter - return probabilities in reverse order (used for reverse compliment)   
	 * @return 
	 */	
	public byte[] get_prb_byte_rev() {
		int l = this.quality.length;
		byte[] a = new byte[l];
		for (int x = 0; x < l; x++) {
			a[x] = this.quality[((l-1)-x)];
		}
		return a;
	}

	/**
	 * create reverse complimented version of the alignread
	 * @return
	 */
	public final AlignedRead clone_rc() {
		
		AlignedRead RC = null;
		// ESCA-JAVA0008:  Nothing to do about a failure here.  It's highly unlikely, so we just swallow the error.
		try {
			RC = new AlignedRead(
				this.direction,
				this.Name,
				Utilities.reverseCompliment(this.Sequence),
				this.score,
				this.seqStart,
				this.seqEnd,
				this.alignName,
				this.chromosome,
				this.alignStart,
				this.alignEnd,
				this.percent,
				this.P,
				this.alignseq,
				this.mismatches,
				this.sort_score,
				this.queryLength,
				this.alignLength,
				this.contigStart,
				this.contigEnd,
				this.identity,
				this.Match,
				this.matches_noError,
				this.matches_1error,
				this.matches_2error,
				this.N_reads,
				this.error1,
				this.error2,
				this.quality);
		} catch (UnexpectedCharacterException URE) {
			
		} catch (UnexpectedResultException URE) {

		}
		return RC;
	}
	
	/**
	 * Downsize the Alignread to a simpleAlignedRead to save space.
	 * @return
	 */
	public SimpleAlignedRead toSimpleAlignedRead() {
		return new SimpleAlignedRead(
				this.chromosome,
				this.alignStart,
				this.alignEnd,
				(this.direction == '+')? true : false,
				this.Sequence,
				this.quality);
	}

	/**
	 * Produce a bed string from the aligned read
	 * @return
	 */
	public String outBed() {
		StringBuffer s = new StringBuffer();
		s.append(this.chromosome + "\t");
		s.append(this.alignStart + "\t");
		s.append(this.alignEnd + "\t");
		s.append(this.alignseq + "\t");				//type (dual use field)
		s.append(this.identity + "\t");				//colour (dual use field)
		s.append(this.direction);
		return s.toString();
	}
	
	/**
	 * Produce an eland Export file string from the AlignedRead
	 * @return
	 */
	public String outElandExt() {
		StringBuffer s = new StringBuffer();
		String[] elements = this.Name.split("_");
		if (elements.length >=6) {
			s.append(elements[0] + "\t");
			s.append(elements[1] + "\t");
			s.append(elements[2] + "\t");
			s.append(elements[3] + "\t");
			s.append(elements[4] + "\t");
			s.append(elements[5] + "\t");
		} else {
			s.append(this.Name + "\t\t\t\t\t\t");
		}
		s.append("" + "\t");		//element 6 isn't read or retained.
		s.append("" + "\t");		//element 7 isn't read or retained.
		s.append(this.Sequence + "\t");
		s.append(new String(this.quality) + "\t");
		s.append(this.chromosome + "\t");
		s.append("" + "\t");		//element 11 is only not-null for filtered reads
		s.append(this.alignStart + "\t");
		s.append(((this.direction == '-') ? "R" : "F") + "\t");
		if (this.alignseq != null && this.Sequence.length() == this.alignseq.length()) {
			s.append(ElandExtUtilities.undo_parse_mismatches(this.Sequence, this.alignseq) + "\t");  //element 14
		} else {
			s.append("\t");
		}
		s.append(this.score + "\t");
		if(this.error2 != null) {
			s.append("\t\t\t\t\t\t" + this.error2);
		}
		return s.toString();
	}

	/**
	 * Produce a bowtie format line from the aligned read
	 * @return
	 */
	public String outBowtie() {
		StringBuffer s = new StringBuffer();
		s.append(this.Name + "\t");
		s.append(this.direction + "\t");
		s.append(this.chromosome + "\t");
		s.append(this.alignStart + "\t");
		s.append(this.Sequence + "\t");
		s.append(new String(this.quality) + "\t");
		s.append("0" + "\t");
		s.append(this.Match + "\t");		
		return s.toString();	
	}

}
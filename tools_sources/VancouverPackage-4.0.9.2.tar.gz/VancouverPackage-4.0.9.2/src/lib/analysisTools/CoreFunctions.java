package src.lib.analysisTools;

import java.util.ArrayList;

import org.ensembl.util.SequenceUtil;

import src.lib.Chromosome;
import src.lib.SNPDB;
import src.lib.Utilities;

import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.PSNPwriter;

import src.lib.objects.SNP;

/**
 * @version $Revision: 558 $
 * @author 
 */
public class CoreFunctions {

	private CoreFunctions() {} 
	
	// ESCA-JAVA0138:
	public static void compare_and_print_transcripts(Log_Buffer LB, String codingDNA,
			int index_start, String peptide, ArrayList<SNP> trans_snps,
			PSNPwriter psnpfile, int strand, StringBuffer NewTranscript,
			SNPDB[] SNP_list, String Accession, String Display,
			String chromosome, Chromosome chr) {
		int index_end = index_start + (codingDNA.length() - 1);
		StringBuffer Mod_Exon = null;
		String Mod_peptide = null;
		
		peptide = Utilities.remove_spurious_Xs(peptide);
		
		for (int q = 0; q < trans_snps.size(); q++) {	// loop over SNPS
			Mod_Exon = new StringBuffer(NewTranscript);
			SNP snp = trans_snps.get(q);
			if (strand == -1) { 					// reverse strand
				Mod_Exon.setCharAt(snp.get_misc_value(), Utilities.Flip_Base(snp.get_new_base()));
			} else {								// on forward Strand
				Mod_Exon.setCharAt(snp.get_misc_value(), snp.get_new_base());
			}
			Mod_peptide = SequenceUtil.dna2protein(Mod_Exon
					.substring(index_start, index_end - 1), true);
			int dex = peptide.indexOf("U");			//patch for seleno cysteins
			int startat = 0;						

			while (dex != -1 && dex < Mod_peptide.length()) {		//System.out.println("Found a U!"); 
				String tmp = Mod_peptide.substring(0, dex);
				tmp = tmp.concat("U");
				if (dex < Mod_peptide.length()-1) {
					tmp = tmp.concat(Mod_peptide.substring(dex+1));
				}
				Mod_peptide = tmp;							
				startat = dex+1;
				dex = peptide.indexOf("U", startat);
			}
			
			int pos = snp.get_position();
			char canonical_base = chr.get_base_at(pos);
			String snp_status = get_snp_info(LB, snp, SNP_list, canonical_base);
			
			/*check if the SNP causes a protein coding change*/
			if (!Mod_peptide.equals(peptide) && (peptide.length() == Mod_peptide.length())) {
				for (int p = 0; p < Mod_peptide.length(); p++) {
					if (Mod_peptide.charAt(p) != peptide.charAt(p)) {
						psnpfile.write_allsnp_file_change(chromosome,  snp,
								Accession, Display, snp_status,
								peptide, Mod_peptide, p);
					}
				}
			} else { 								// no protein coding change.
				psnpfile.write_allsnp_file_nochange(chromosome, snp, Accession, Display, snp_status );
				
			}
		}
	}
	
	
	private static String get_snp_info(Log_Buffer LB, SNP snp, SNPDB[] SNP_list, char canonical_base) {
		// check if in SNP_list
		int pos = snp.get_position();
		char alt_base = snp.get_new_base();
		int index = SNPDB.SNPbinarySearch(SNP_list, pos + 1);
		if (index != -1) {
			String Allele = SNP_list[index].get_details();
			if (Allele.length() < 3) {
				LB.warning("Allele found, no SNP! :" + Allele);
				return ("novel(nosnp)");
			} else {
				return (Utilities.is_expected_base(Allele,
						canonical_base, alt_base));
				// else, does not match - no known snp.
			}
		} else {
			return ("novel");
		}
	}
	

	
}

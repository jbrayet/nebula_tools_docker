package src.projects.findPeaks.tests;

import java.util.Vector;

import src.lib.ioInterfaces.Log_Buffer;
import src.projects.findPeaks.objects.LinearRegressionPerpendicular;
import src.projects.findPeaks.objects.PeakPairIdx;

public class test_linear_regressionPerpendicular {

	private test_linear_regressionPerpendicular() {}
	
	
	public static void main(String[] args) {
		
		
		// ESCA-JAVA0076:
		float[][] oxygen_data = { {0.99f,90.1f},
				{1.02f,89.05f},
				{1.15f,91.43f},
				{1.29f,93.74f},
				{1.46f,96.73f},
				{1.36f,94.45f},
				{0.87f,87.59f},
				{1.23f,91.77f},
				{1.55f,99.42f},
				{1.40f,93.65f},
				{1.19f,93.54f},
				{1.15f,92.52f},
				{0.98f,90.56f},
				{1.01f,89.54f},
				{1.11f,89.85f},
				{1.20f,90.39f},
				{1.26f,93.25f},
				{1.32f,93.41f},
				{1.43f,94.98f},
				{0.95f,87.33f}};

	/*	
		float[][] oxygen_data_inv = { {90.1f, 0.99f},
				{89.05f,1.02f},
				{91.43f,1.15f},
				{93.74f,1.29f},
				{96.73f,1.46f},
				{94.45f,1.36f},
				{87.59f,0.87f},
				{91.77f,1.23f},
				{99.42f,1.55f},
				{93.65f,1.40f},
				{93.54f,1.19f},
				{92.52f,1.15f},
				{90.56f,0.98f},
				{89.54f,1.01f},
				{89.85f,1.11f},
				{90.39f,1.20f},
				{93.25f,1.26f},
				{93.41f,1.32f},
				{94.98f,1.43f},
				{87.33f,0.95f}};*/
		
		Log_Buffer LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();

		LB.notice("This example comes from Chapter 10 - Simple Linear Regression and Correlation");
		LB.notice("TODO: get name of textbook from Inanc.");
		
		Vector<PeakPairIdx> store = new Vector<PeakPairIdx>();
		for (float[] a : oxygen_data ) {
			PeakPairIdx z = new PeakPairIdx(1, 1, a[0], a[1]);
			store.add(z);
		}
		PeakPairIdx[] pairs = store.toArray(new PeakPairIdx[store.size()]);
		
		LinearRegressionPerpendicular n = new LinearRegressionPerpendicular(LB, pairs);
		n.filter(0.05, 0);
		
		LB.notice("Expected values: (note: rounding errors are present.)");
		LB.notice("Sxy:       10.18");
		LB.notice("Sx2:       29.29");
		LB.notice("Sy2:       170044.53");
		LB.notice("Sxx:       0.68");
		LB.notice("Syy:       173.37");
		LB.notice("slope:     14.97");
		LB.notice("intercept: 74.20");
		LB.notice("Calculated values: ");
		n.write_data();
		
		/*
		store.clear();
		for (float[] a : oxygen_data_inv ) {
			PeakPairIdx z = new PeakPairIdx(1, 1, a[0], a[1]);
			store.add(z);
		}
		pairs = store.toArray(new PeakPairIdx[store.size()]);
		
		n = new LinearRegressionPerpendicular(LB, pairs);
		pairs = n.filter(0.05, 0);
		n.write_data();*/
		LB.close();
		
	}
	
}

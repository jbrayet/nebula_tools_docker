package src.lib.ioInterfaces;

import java.util.Iterator;

import src.lib.objects.AlignedRead;

/**
 * AligneReadsIterator is an Iterator that also contain a File reader.
 * It can read alignedreads from different alignment formats.
 * @author tcezard
 * @version $Revision: 592 $
 *
 */
public interface AlignedReadsIterator extends Iterator<AlignedRead>
{
	/**
	 * Close the file reader and other specific stuff.
	 * @param verbose
	 */
	void close(boolean verbose);
	
	int get_NumberFilteredRead();

	boolean mark();
	
	boolean reset();
	
	void apply_filters(String filter);
}

package src.lib.ioInterfaces;

import java.util.NoSuchElementException;

import src.lib.Constants;
import src.lib.objects.AlignedRead;

public class Generic_AlignRead_Iterator implements Iterable<AlignedRead>{
	private static boolean display_version = true;
	private AlignedReadsIterator it;
	private AlignedRead next;
	private final Log_Buffer LB;
	
	
	// ESCA-JAVA0138:
	/**
	 * Create a generic Iterator used to read the Aligned reads and return it.
	 * If aligner is already initialized, it will not re-initialize unless it is
	 * closed first.
	 * 
	 * @param logbuffer
	 * @param aligner
	 * @param st
	 * @param file
	 * @param qualityfilter
	 * @param maq_read_len
	 * @param PET_flag_filters Only for use with MAQ.
	 * @param max_PET_len
	 * @param silence_warning Only for use with SAM/BAM
	 */
	public Generic_AlignRead_Iterator(Log_Buffer logbuffer, String aligner,
			String st, String file, int qualityfilter, int maq_read_len,
			String PET_flag_filters, int max_PET_len,boolean silence_warning) {
		LB = logbuffer; 
		if (display_version) {
			LB.Version("Generic_AlignRead_Iterator", "$Revision: 1600 $");
			display_version = false;
		}
		if (it == null) { 
			if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_ELAND)) {
				it = new ElandIterator(LB, st, file, max_PET_len);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_VULGAR)) {
				it = new VulgarIterator(LB, st, file, max_PET_len);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_ELANDII)) {
				it = new ElandExtIterator(LB, st, file, max_PET_len);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAPVIEW)) {
				it = new MapviewMAQIterator(LB, st, file, qualityfilter, max_PET_len);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAQ)) {
				it = new MAQmapIterator(LB, st, file, qualityfilter, maq_read_len, max_PET_len);
				if (PET_flag_filters != null) {
					it.apply_filters(PET_flag_filters);
				}
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_BED)) {
				it = new BedIterator(LB, file, max_PET_len);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_GFF)) {
				it = new GffIterator(LB, file, max_PET_len);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_BOWTIE)) {
				it = new BowtieIterator(LB, st, file, max_PET_len);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM) 
					|| aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM_SPLIT)) {
				it = new SAMIterator(LB, st, file, max_PET_len, qualityfilter, SAMIterator.ALLOWS_SPLIT_READ, silence_warning);
			} else if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_SAM_FILTER)) {
				it = new SAMIterator(LB, st, file, max_PET_len, qualityfilter, SAMIterator.NO_SPLIT_READ, silence_warning);
			}else {
				LB.error("Did not recognize aligner type: " + aligner);
				LB.error("Please check that you have not made a spelling mistake when providing the alignment type");
				LB.die();
			}
		}
	}
	
	public Generic_AlignRead_Iterator(Log_Buffer logbuffer, AlignedReadsIterator iter) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Generic_AlignRead_Iterator", "$Revision: 1600 $");
			display_version = false;
		}
		it = iter;
	}
	
	public boolean mark() {
		return it.mark();
	}

	public boolean reset() {
		return it.reset();
	}
	
	public AlignedRead next() {
		AlignedRead to_return=next;
		try {
			if (to_return==null) {
				next=it.next();
				to_return=next;
			} else {
				next = null;
			}
		} catch (NoSuchElementException nsee) {
			return null;
		}
		return to_return;
	}
	
	public boolean hasNext() {
		if (next!=null){
			return true;
		}else{
			try{
				next=it.next();
			}catch (NoSuchElementException nsee){
				next=null;
			}
			if (next!=null){
				return true;
			}else{
				return false;
			}
		}
	}

	public AlignedReadsIterator iterator() {
		return this.it;
	}
	
	/**
	 * Close whichever Iterator was being used.
	 */
	public void close() {
		
		if (it != null) {
			it.close(false);
			it = null;
		} else {
			LB.warning("Cannot close: Iterator doesn't exist");
		}
	}
	
}

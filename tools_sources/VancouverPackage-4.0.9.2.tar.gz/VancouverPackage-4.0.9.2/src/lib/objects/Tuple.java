package src.lib.objects;

import java.io.Serializable;

/**
 * This file was shared from the Endrov library, 2-clause BSD licensed, Johan Henriksson  
 * http://www.endrov.net/
 *  
 * A Java tuple (a,b)
 * 
 * This code was taken from a forum post and modified. It is the only possible
 * technical implementation and hence not copyrightable.
 * 
 * @author afejes
 * @author Johan Henriksson
 * @version $Revision: 1409 $
 */
public class Tuple<L, R> implements Serializable {
	private static final long serialVersionUID = 0;
	private L a;
	private R b;

	public Tuple(L fst, R right) {
		this.a = fst;
		this.b = right;
	}

	
	
//	public final float get_float() { return a; }
//	public final int get_int() { return b; }
	
	public void set_first(L number) { a = number; }
	public void set_second(R number) { b = number; }
	
	/**
	 * First value (a,_) -> a
	 * @return first value of tuple
	 */
	public L get_first() {
		return a;
	}

	/**
	 * Second value (_,b) -> b
	 * @return second value of tuple
	 */
	public R get_second() {
		return b;
	}

	public final boolean equals(Object o) {
		if (!(o instanceof Tuple<?,?>)) {
			return false;
		}
		final Tuple<?, ?> other = (Tuple<?, ?>) o;
		return equal(get_first(), other.get_first()) && equal(get_second(), other.get_second());
	}

	public static final boolean equal(Object o1, Object o2) {
		if (o1 == null) {
			return o2 == null;
		} else {
			return o1.equals(o2);
		}
	}

	public int hashCode() {
		int hLeft = get_first() == null ? 0 : get_first().hashCode();
		int hRight = get_second() == null ? 0 : get_second().hashCode();
		return hLeft + (57 * hRight);
	}

	public static <L, R> Tuple<L, R> make(L a, R b) {
		return new Tuple<L, R>(a, b);
	}

	public String toString() {
		return "(" + a + "," + b + ")";
	}
}
package src.lib.objects;

import src.lib.Error_handling.UnexpectedResultException;


/**
 * Class to unify all types of sequence alignments
 * @author Genome Science Centre
 * @version $Revision: 1796 $
 */
public class ReducedAlignedRead implements Comparable<ReducedAlignedRead> {
	/**
	 * direction of alignment, can be either '+' or '-'
	 */
	private char direction = '0';
	/**
	 * Start of the alignment in the database (Coordhit field: hstart)
	 */
	private int alignStart = -1;
	/**
	 * End of the alignment in the database (Coordhit field: hend)
	 */
	private int alignEnd = -1;
	/**
	 * The value used to sort
	 */
	private double sort_score = 0;

	
	public final void set_direction(char Y) {
		this.direction = Y;
	}
	
	public final char get_direction() {
		return this.direction;
	}
	
	public final void set_alignStart(int Y) {
		this.alignStart = Y;
	}
	
	public final int get_alignStart() {
		return this.alignStart;
	}
	
	public final void set_alignEnd(int Y) {
		this.alignEnd = Y;
	}
	
	public final int get_alignEnd() {
		return this.alignEnd;
	}
	
	public final void set_sort_score(double Y) {
		this.sort_score = Y;
	}
	
	public final double get_sort_score() {
		return this.sort_score;
	}
	
	
	public ReducedAlignedRead(char direction, int start, int end, double sort) {
		this.direction = direction;
		this.alignStart = start;
		this.alignEnd = end;
		this.sort_score = sort; 
	}
	
	public ReducedAlignedRead() { 
	}
	
	public int compareTo(ReducedAlignedRead A) {
		if (A.sort_score < sort_score) {
			return -1;
		}
		if (A.sort_score > sort_score) {
			return 1;
		}
		if (A.direction == direction) {
			return 0;
		}
		if (A.direction == '-') {
			return -1;
		}
		return 1;
	}


	public AlignedRead toAlignedRead() throws UnexpectedResultException {
		return new AlignedRead(
					this.direction,
					null,								/*read_name*/
					null,								/*Sequence*/
					(int)this.sort_score,				/*score*/
					0,									/*seqStart*/
					0,									/*seqEnd*/
					null,								/*alignName*/
					"",									/*chromosome - Chromosome may not be null*/
					this.alignStart,
					this.alignEnd,
					0f,									/*percent*/
					0f,									/*P*/
					null,								/*alignseq*/
					0,									/*mismatches*/
					this.sort_score,					/*sort_score*/
					0,									/*queryLength*/
					this.alignEnd - this.alignStart,	/*alignLength*/
					0,									/*contigStart*/
					0,									/*contigEnd*/
					0,									/*identity*/
					null,								/*Match*/
					0,									/*matches_noError*/
					0,									/*matches_1error*/
					0,									/*matches_2error*/
					null,								/*N_reads*/
					null,								/*error1*/
					null,								/*error2*/
					new byte[0]);						/*quality*/
	}

}
package src.projects.SNP_Database.SnpIterators;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import src.lib.Constants;
import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedCharacterException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;

/**
 * @version $Revision: 1612 $
 * @author 
 */
public class WTSSPipelineSNPIterator implements Iterator<SNP>, SNPIterator {
	private static boolean display_version = true;
	private static Log_Buffer LB;

	BufferedReader br = null;
	int linecount = 0;
	final String filename;
	Vector<SNP> buffer;
	
	
	
	public WTSSPipelineSNPIterator(Log_Buffer logbuffer, String source_file) {
		LB = logbuffer;
		this.filename = source_file;
		if (display_version) {
			LB.Version("WTSSPipelineSNPIterator", "$Revision: 1612 $");
			display_version = false;
		}
		try {
			br = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException e) {
			LB.error("Can't find file " + filename);
			LB.die();
		}
		buffer = new Vector<SNP>();
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		LB.notice(filename + " closed successfully");
		
	}
	
	
	/** 
	 * Read in next line of the SNP file
	 * 
	 * Expected format:
	 * #position       ref  called_base    information
	 * chr10:284953    A       G       320,G,0,A,E:320,J:,320,
	 * chr10:419977    G       K       20,G,11,T,E:,J:11,33,junction-only
	 * chr10:435061    C       A       19,A,3,T,E:,J:19,22,nonref,junction-only
	 * chr10:449940    G       A       16,A,0,G,E:16,J:,16,
	 * chr10:846325    C       G       202,G,1,A,E:202,J:,203,nonref
	 * chr10:848033    G       R       145,G,87,A,E:87,J:,232,
	 * chr10:861702    G       K       13,G,10,T,E:10,J:,23,
	 * chr10:1007914   G       A       8,A,1,G,E:8,J:,9,
	 * chr10:1008129   G       A       7,A,0,G,E:7,J:,7, 
	 * 
	 * Notes:  Throw away reads with "junction-only"
	 * Notes:  nonref annotation can safely be ignored.
	 * 
	 * 
	 * @return SNP object
	 */
	// ESCA-JAVA0049:
	public SNP next() {
		final int SEVEN = 7;
		
		String line = null;
		//Since a single line can return more than one SNP, check to see if there is anything in the buffer.
		Vector<SNP> S =  new Vector<SNP>();
		if (!buffer.isEmpty()) {
			return buffer.remove(0);
		}		
		try {
			while ((line = br.readLine()) != null) {
				if (line.startsWith("#")) {
					continue;
				}
				
				this.linecount++;	
				
				 
				String[] elements = line.split("\t");				
				if (elements.length < 4) {
					LB.error("Lack of fields in SNP file provided");
					LB.die();
				}
				String[] tmp = elements[0].split(":");
				String chromosome 	= tmp[0];
				int position 		= Integer.valueOf(tmp[1]);
				char ref 			= elements[1].charAt(0);		
				char alt			= elements[2].charAt(0);
				String[] remaining	= elements[3].split(",");
				int depth			= Integer.valueOf(remaining[6]);
				//if the read is "junction only", then we'll just abandon it. (two ways it can say it..)
				//String notes = null;
				if (remaining.length > SEVEN) {
					if (remaining[SEVEN].compareTo("junction-only") == 0) {
						continue;
					} else {
						//notes = remaining[SEVEN];
					}
					if (remaining.length == 9 && remaining[8].compareTo("junction-only") == 0 ) {
							continue;
					} 
				}
				
				
				int[] counts 		= new int[4];
				//these are the calls for each base.
				try {
					counts[Utilities.getIndexForBase(remaining[1].charAt(0))] = Integer.valueOf(remaining[0]);
					counts[Utilities.getIndexForBase(remaining[3].charAt(0))] = Integer.valueOf(remaining[2]);
				} catch (UnexpectedCharacterException uce) {
					LB.notice(uce.getMessage());
					LB.die();
				}
				
				//int qual			= there is no quality score for these snp calls
				int ref_coverage 	= -1;
				try {
					if (remaining[1].charAt(0) == ref) {
						ref_coverage = counts[Utilities.getIndexForBase(ref)];
					} else if (remaining[3].charAt(0) == ref) {
						ref_coverage = counts[Utilities.getIndexForBase(ref)];
					} else {
						ref_coverage = depth - (counts[Utilities.getIndexForBase(remaining[1].charAt(0))] 
						                       + counts[Utilities.getIndexForBase(remaining[3].charAt(0))]);
					}
					
					char[] snps = Utilities.non_canonical_expansion(alt);
					for (char o : snps) {
						if (o != ref) {
							S.add(new SNP(chromosome, position, o, ref, 
									counts[Utilities.getIndexForBase(alt)], ref_coverage,
									 depth, -1, -1, -1, null));
						}
					}
				} catch (UnexpectedCharacterException uce) {
					LB.error(uce.getMessage());
					LB.die();
				}
			}
			throw new NoSuchElementException("Could not get any more reads.");
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		if (S.size() > 1) {
			SNP first_snp = S.remove(0);
			buffer.addAll(S);
			return first_snp;
		} else {
			return S.firstElement();
		}
	}
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of SNPIterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

}

		
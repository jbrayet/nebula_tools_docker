package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Iterator;
import java.util.NoSuchElementException;

import src.lib.objects.Aberation;
import src.lib.objects.Aberation_Deletion;

/**
 * @version $Revision: 1019 $
 * @author 
 */
public class GSC_Aberation_Iterator implements Iterator<Object>{
	String Name = null;
	BufferedReader br = null;
	int linecount = 0;
	int UXcnt = 0;
	private static Log_Buffer LB;
	private static boolean verbose = false;
	private static boolean display_version = true;
		/*
		chr8:608728 A 37 @G,Gg.CG.ggGgg..gg.gg.ggcgggg.g...g.g, @*+BII"8IIIIII&'I=I1<=D7'/I&,9>497<4I4 
				@[faVU*[5JTX:L*XN^^X^8Ne*RdU]:^XX[_JgF A R 74 37 1.00 63 -120
		chr8:613839 A 10 @.T,.,,,TTT @I0'IIHIII) @^dLhTVVT?* A W 25 10 1.00 63 96
		chr8:671206 G 41 @ccccccccccccccccccccccccccccccccccccccccc @+++II2IIIAIIIIIIIIIIAIIIIIIIIIIIIIIIII9ID 
				@HN8FR2<N=DU>TPVJJNPVHNNTMP>RT=LGFP4HDV*@4 G C 150 41 1.00 53 -124
		chr8:9601847 A 10 @..,,,,GG.G @II"2"+5>II @^[DX3dRdgL A R 22 10 1.00 63 52
		chr8:96236430 G 63 @TTTTTCTTTTTTT,TT,TTTTTTTTT.TT..,T................,.,,..,,.,,,,, 
				@+$+++$+%+++(($'&&I7<II&+&22$.IIIIII%I%IIIFIIIIIIII<IIIIIIIIIIII 
				@H0^jg8j/Fa:dR1aU[dNNddRNd=SXObhgdgVagIggj7dggdaggf^^9jjOkjg<dd^ G K 59 63 1.00 63 124
		chr8:96237001 A 18 @..,,,C,,,ggg,,,,,, @2I9%I$I8#III2IIIII @Ua>Dj/g?7RNRa^dddd A R 24 18 1.00 63 124
		*/
		
/*		public  String 	chromosome 	= null;
		public  int 	position 	= -1;
		public	char 	base		= 'Q';
		public 	char	cannonical	= 'Q';
*/			


	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public GSC_Aberation_Iterator(Log_Buffer logbuffer, String Name, String source_file, boolean loud) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("GSC_Aberation_Iterator", "$Revision: 1019 $");
			display_version = false;
		}
		verbose = loud;
		this.Name = Name;
		try {
			br = new BufferedReader(new FileReader(source_file));
		} catch (FileNotFoundException io) {
			LB.error("Can't find file " + source_file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		
	}
	
	public void close() {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Ux records : " + this.UXcnt);
		}
		
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

    /*
	1 position
	2 and 7 are always the same (output by different programs, a remnant of sloppy joins).
	3 is a consensus score
	4 is a list of nucleotides (. and , mean matches reference) for the corresponding mapped read
	5 is the same deal, but score of that position in the read (byte-encoded)
	6 is the same deal, but total mapping score for that read (byte-encoded)
	8 is the base call, IUPAC encoded
	9 is the consensus quality
	10 is coverage depth
	11 12 and 13, I can't remember (I ignore them)
     */
	
	
	public Object next() {
		String line = null;
		Object rs = null;
		try {			
			if ((line = br.readLine()) != null) {
				this.linecount++;	
				String[] fields = line.split("\t");		//just get the title row.
				
				/*error checking*/
				if (fields[0].length() > 1) {
					LB.error ("line " + this.linecount + ": first field is too long - truncating from " + fields[0]);
				}
				if (fields[0].equalsIgnoreCase("D")) {			//Deletion
					rs = new Aberation_Deletion(fields[0].charAt(0), fields[1],
							Integer.valueOf(fields[2]), 
							Integer.valueOf(fields[3]),
							fields[4],
							Float.valueOf(fields[5]),
							Float.valueOf(fields[6]),
							Float.valueOf(fields[7]));
				} else if (fields[0].equalsIgnoreCase("S")) {	//SNP
					rs = new Aberation(fields[0].charAt(0),
							fields[1],
							Integer.valueOf(fields[2]),
							Integer.valueOf(fields[3]),
							fields[4]);
				} else if (fields[0].equalsIgnoreCase("I")) {	//Insertion
					rs = new Aberation(fields[0].charAt(0),
							fields[1], 
							Integer.valueOf(fields[2]), 
							Integer.valueOf(fields[3]), 
							fields[4] );
				} else if (fields[0].equalsIgnoreCase("C")) {	//complex (combination of one or more of the above.)
					rs = new Aberation(fields[0].charAt(0), 
							fields[1], 
							Integer.valueOf(fields[2]), 
							Integer.valueOf(fields[3]),
							fields[4] );
				} else if (fields[0].equalsIgnoreCase("P")) {   //Peak
					rs = new Aberation(fields[0].charAt(0), 
							fields[1], 
							Integer.valueOf(fields[2]), 
							Integer.valueOf(fields[3]),
							fields[4] );
				} else {
					LB.warning("Aberation type not recognized on line " + linecount);
					LB.warning("Type found, " + fields[0].charAt(0)	+ ", was not recognized as " +
							"either D (deletion), S (snp), I (insertion), P (peak) or C (complex)");
				}
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
			}
			//System.out.println(rs.toString());
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return rs;
	}

}

		
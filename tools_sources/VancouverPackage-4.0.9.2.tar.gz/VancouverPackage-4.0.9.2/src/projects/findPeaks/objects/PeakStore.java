package src.projects.findPeaks.objects;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Tuple;

// ESCA-JAVA0136:
public class PeakStore implements Iterable<Peakdesc> {

	private static final int INIT_SIZE = 5000; 
	
	private Vector<Peakdesc> peaks;
	private int current_location = 0;
	private static boolean display_version = true;
	private Log_Buffer LB = null;
	private int reads_used = 0;
	private int reads_filtered = 0;
	private Tuple<Integer, Integer> LW = new Tuple<Integer, Integer>(0,0);
	
	public PeakStore(Log_Buffer logbuffer) {
		if (this.LB == null) {
			this.LB = logbuffer;
		}
		peaks = new Vector<Peakdesc>(INIT_SIZE);
		if (display_version) {
			LB.Version("PeakStore", "$Revision: 1335 $");
			display_version = false;
		}
	}	

	public void add(Peakdesc pd) {
		peaks.add(pd);
	}

	public void clear() {
		peaks.clear();
	}

	public Peakdesc next() {
		try {
			return peaks.get(current_location++); //increments after evaluation of expression
		} catch (NoSuchElementException NSEE) {
			throw new NoSuchElementException("Could not get any more peaks.");
		}
	}

	public final Iterator<Peakdesc> iterator() {
		return peaks.iterator();
	}

	public final void restart() {
		current_location = 0;
	}

	public final void merge(PeakStore n) {
		for (Peakdesc p : n) {
			peaks.add(p);
		}
	}

	public final boolean hasNext() {
		return ((current_location <= peaks.size() -1 ) ? true : false); 
	}

	/** This function has not been implemented - it is a place holder only */
	public final void remove() {
	}

	public final void get_distribution() {
		// placeholder function - will need later
	}

	public final void set_reads_used(int r) {
		this.reads_used = r;
	}

	public final void set_reads_filtered(int r) {
		this.reads_filtered = r;
	}

	public final int get_reads_used() {
		return this.reads_used;
	}

	public final int get_reads_filtered() {
		return this.reads_filtered;
	}

	public final int get_reads_total() {
		return this.reads_filtered + this.reads_used;
	}

	/**
	 * Getter - returns the number of regions with a single fragment
	 * @return
	 */
	public final int get_LW_singles() 		{ return this.LW.get_first(); }

	/**
	 * Getter - returns the number of regions with two fragments
	 * @return
	 */

	public final int get_LW_doubles() 		{ return this.LW.get_second(); }

	public final void inc_LW_singles() {
		this.LW.set_first(this.LW.get_first() + 1);
	}

	public final void inc_LW_doubles() {
		this.LW.set_second(this.LW.get_second() + 1);
	}
	
	public final Tuple<Integer, Integer> get_LW_pair() {
		return this.LW;
	}

	public final int get_size() {
		return peaks.size();
	}

	public Peakdesc[] get_array_of_peaks() {
		return this.peaks.toArray(new Peakdesc[peaks.size()]);
	}

	public Peakdesc get_peak(int key) {
		return this.peaks.get(key);
	}
}
	



package src.lib;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Hashtable;

import src.lib.ioInterfaces.Log_Buffer;

public class ConstantsFile {

	
	/**
	 * Log_buffer
	 */
	private static Log_Buffer LB;
	private static boolean display_version = true;
	/**
	 * Must set species when initializing a constants object
	 */
	private String species = null;
	private static Hashtable<String, String> Variables = new Hashtable<String, String>();
	/**
	 * Strings for connectivity and keeping track of chromosomes
	 */
	private String filepath = null;
	private String[] CHROMOSOMES = null;
	
	
	/**
	 * @param logbuffer
	 * @param input_species
	 * @param conf_file
	 * @param input_chr
	 * @return
	 */
	public static ConstantsFile init(Log_Buffer logbuffer, String input_species, String conf_file, String input_chr) {
		ConstantsFile Const = new ConstantsFile(logbuffer, input_species);
		if (display_version) {
			LB.Version("ConstantsFile", "$Revision: 1290 $");
			display_version = false;
		}
		Const.get_ext_constants(conf_file);
		
		Const.species_constants(input_chr);
		return Const;
	}
	
	
	/**
	 * 
	 * @param logbuffer
	 * @param species
	 */
	public ConstantsFile(Log_Buffer logbuffer, String species) {
		LB = logbuffer;
		this.species = species;
	}
	
	
	
	/**
	 * 
	 * @param file
	 */
	public void get_ext_constants(String file) {
		
		BufferedReader br = null;
		String line = "";
		try {													//open file
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException fnf) {
			LB.error("Could not find file: " + file);
			LB.die();
		}
		assert (br != null);
		
		try {													//find Connection section in file		
			while (!line.trim().equalsIgnoreCase("[Connection]")) {
				line = br.readLine();							
			}
			line = br.readLine().trim();
			while (!line.startsWith("[") && (br.ready())) {  	//iterate until line starts with "["
				if (!line.startsWith("#") && line.trim().length() > 0 ) {
					String[] st = line.split("=");
					Variables.put(st[0], st[1]);
				}
				line = br.readLine(); 
			}
			br.close();
				
			try {												//open file again, to return to start,
				br = new BufferedReader(new FileReader(file));	// in case sections are out of order
			} catch (FileNotFoundException fnf) {
				LB.error("Could not find file " + file);
				LB.die();
			}
			
			while (!line.trim().equalsIgnoreCase("[" + this.species + "]")) {
				line = br.readLine();	
			}
			line = br.readLine().trim();
			while (!line.startsWith("[") && (br.ready())) {		//iterate until line starts with "["  
				if (!line.startsWith("#") && (line.length() > 2)) {
					String[] st = line.split("=");
					Variables.put(st[0], st[1].trim());
				}
				line = br.readLine(); 
			}
			br.close();
		} catch (IOException io) {
			LB.error("Error while reading constants. line = " + line);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}	
	
	}
	
	/**
	 * 
	 * @param chr
	 * @return
	 */
	public String getFastaFilename(int chr){	
		return this.filepath + get_chr_filename(chr);
	}
	
	/**
	 * 
	 * @param chr
	 */
	public void species_constants(String chr) {
		this.filepath = Variables.get("filepath");
		String temp = null;
		if (chr.equals("A")) {
			temp = Variables.get("CHR");
		} else {
			temp = chr;
		}
		this.CHROMOSOMES = temp.split(",");
	}
	
	
	
	/**
	 * 
	 * @param chr
	 * @return
	 */
	public String get_chr_filename(int chr) {
//		if (CHROMOSOMES[chr].charAt(0) == 'M') {
//			return "MT";
//		} else {
			return CHROMOSOMES[chr];
//		}
	}
	
	/**
	 * 
	 * @return
	 */
	public final int get_number_of_chromosomes() {
		return this.CHROMOSOMES.length;
	}
	
	/**
	 * @param i
	 * @return
	 */
	public final String get_chromosome(int i) {
		return this.CHROMOSOMES[i];
	}
	
	/**
	 * 
	 */
	public void destroy() {		
		this.species = null;
		this.filepath = null;
		this.CHROMOSOMES = null;
	}
	
	public final int index_chromosomes(String x) {
		for (int a = 0; a < this.CHROMOSOMES.length; a++) {
			if (x.equals(this.CHROMOSOMES[a])) {
				return a;
			}
		}
		return -1;
	}
	
	/**
	 * Used for AlignSlice.  This could be cleaned up to use the above designation, though.
	 * @param chromosome
	 * @param prepend
	 * @return
	 */
	public String getFastaFilename(String chromosome, String prepend){
		if (chromosome.equals("M")) {
			return this.filepath + prepend + "MT";
		} else {
			return this.filepath + prepend + chromosome;
		}
	}
	
}

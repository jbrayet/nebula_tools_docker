package src.projects.findPeaks.objects;

public class Map_i {

	private int[] map = null;
	private int location;
	
	public Map_i(int[] m, int loc) {
		this.map =  new int[m.length];
		System.arraycopy(m, 0, this.map, 0, m.length);
		this.location = loc;
	}
	
	public int[] get_map() {
		int[] tmp = new int[this.map.length];
		System.arraycopy(this.map, 0, tmp, 0, this.map.length);
		return tmp;
	}
	
	public int get_loc() {
		return this.location;
	}
	
	
	
}

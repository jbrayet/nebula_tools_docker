package src.projects.findPeaks.filewriters;

import java.io.FileWriter;
import java.io.IOException;

import src.lib.Utilities;
import src.lib.ioInterfaces.Log_Buffer;

import src.projects.findPeaks.objects.Peakdesc;

/**
 * @version $Revision: 1498 $
 * @author 
 */
public class PeakWriter extends FileWriter{

	private static boolean display_version = true;
	private static Log_Buffer LB;
	
	public PeakWriter(Log_Buffer log_file, String filename) throws IOException{
		super(filename);
		LB = log_file;
		if (display_version) {
			LB.Version("PeakWriter", "$Revision: 1498 $");
			display_version = false;
		}
	}

	public void Peaksfileheader() {
		this.writeln("id\tchrom\tstart\tend\tmax_coord");
	}

	public void Peaksfileheader_ext() {
		this.writeln("id\tchrom\tstart\tend\tmax_coord\theight\tprob.\tsequence");
	}

	/**
	 * 
	 * @param y the peak index
	 * @param Chromosome
	 * @param pd
	 * @param Seq
	 */
	public void writePeak2(int y, String Chromosome, Peakdesc pd, String Seq) {
		this.writeln(y + "\t" + Chromosome + "\t"		//write out information 
					+ (pd.get_offset()) + "\t" 
					+ (pd.get_length() + pd.get_offset()) + "\t"
					+ (pd.get_max_loc() + pd.get_offset()) + "\t"
					+ Utilities.DecimalPoints(pd.get_height(),3) 
					+ ((Seq != null && !Seq.contentEquals("")) ? ("\t" + Seq) : ""));
	}

	/**
	 * @param y the peak index
	 * @param Chromosome
	 * @param pd
	 * @param p
	 * @param Seq
	 */
	public void writePeak3(int y, String Chromosome, Peakdesc pd, double p, String Seq) {
		//keep track of which peak this is.
		this.writeln(y + "\t" + Chromosome + "\t" 
					+ (pd.get_offset()) + "\t" 
					+ (pd.get_length() + pd.get_offset()) + "\t"
					+ (pd.get_max_loc() + pd.get_offset()) + "\t"
					+ Utilities.DecimalPoints(pd.get_height(),3) + "\t" 
					+ Utilities.DecimalPoints(p,3) 
					+ ((Seq != null && !Seq.contentEquals("")) ? ("\t" +Seq) : ""));
	}

	private void writeln(String s) {
		try {
			this.write(s + "\n");
		} catch (IOException io) {
			LB.error("Error writing header to Peaks file.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}	
	}
}

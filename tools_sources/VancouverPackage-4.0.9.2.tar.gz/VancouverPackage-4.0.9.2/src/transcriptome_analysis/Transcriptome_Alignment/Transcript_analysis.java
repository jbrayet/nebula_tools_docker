package src.transcriptome_analysis.Transcriptome_Alignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Vector;
import java.util.regex.*;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.ExonerateIterator;
import src.lib.ioInterfaces.FileOut;
import src.lib.ioInterfaces.Log_Buffer;

import src.lib.objects.AlignedRead;
import src.lib.objects.Counter;

/**
 * @version $Revision: 1587 $
 * @author 
 */
public class Transcript_analysis {
	/*
	 * Transcriptome1 stores the number of times each transcript is seen as a
	 * direct count of the matches to it - thus, multimatches result in multiple
	 * transcripts each obtaining an increment in their count.
	 */
	private static final int INIT_ALLOC = 20000;

	private static Log_Buffer LB = null;

	private Transcript_analysis() {}

	private static HashMap<String, Counter> Transcriptome1 = new HashMap<String, Counter>(
			INIT_ALLOC);

	/*
	 * Transcriptome2 counts the number of times a set of transcripts is
	 * observed, which results in only a single incremented value for
	 * multimatches. This creates a much more extensive tree, however. This was
	 * steve's idea, such that we can sort out which transcript is being
	 * observed. i.e, if several multimatches are found for transcript RJ04A.1.5
	 * and RJ04A.1.6, and several single matches are found for RJ04A.1.5, it's
	 * likely that all the multimatches against transcripts .5 and .6 were
	 * really matches against .5, as no single .6 transcripts were ever found.
	 * However, that might be observed under several cases where that assumption
	 * is incorrect (i.e., all .6 transcripts are found within .5 transcripts.)
	 */

	private static HashMap<String, Counter> Transcriptome2 = new HashMap<String, Counter>(
			INIT_ALLOC);

	/*
	 * This version (Transcriptome3) counts the number of times a read maps to a
	 * gene, as long as all of the best matches are to that gene only! If there
	 * are multiple genes that are among the best hit, it is discarded.
	 */

	private static HashMap<String, Counter> Transcriptome3 = new HashMap<String, Counter>(
			INIT_ALLOC);

	private static int sequences1 = 0;
	private static int sequences2 = 0;
	private static int sequences3 = 0;	

	private static int failed = 0;

	private static final Pattern pat1 = Pattern.compile("[\\w]*[.][\\d]+");

	private static int last_number_after_first_dot(String S) {
		Matcher fit = pat1.matcher(S);
		if (fit.lookingAt()) {
			return fit.end();
		}
		return -1;
	}

	private static final String get_ce_transcr_name(String tr, int P) {
		return tr.substring(0, P);
	}

	private static final String get_ce_transcr_version(String tr, int P) {
		return (tr.substring(P).replaceAll("[.]", ""));
	}

	private static void process_Vlines_tr1(AlignedRead[] A_lines) {
		for (AlignedRead line : A_lines) {
			if (Transcriptome1.containsKey(line.get_alignName())) {
				Transcriptome1.get(line.get_alignName()).increment();
			} else {
				Transcriptome1.put(line.get_alignName(), new Counter());
			}
		}
		sequences1++;
	}

	private static void process_grouped_tr2(String key) {
		if (Transcriptome2.containsKey(key)) {
			Transcriptome2.get(key).increment();
		} else {
			Transcriptome2.put(key, new Counter());
		}
		sequences2++;
	}

	private static void process_grouped_tr3(String key) {
		if (Transcriptome3.containsKey(key)) {
			Transcriptome3.get(key).increment();
		} else {
			Transcriptome3.put(key, new Counter());
		}
		sequences3++;
	}

	/**
	 * This program analyses sequence reads aligned against a transcriptome.
	 * alignName is the name of the transcript.
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
			return;
		}		

		String output_name = null; 
		String output_path = null;
		if (!Variables.containsKey("name")) {
			LB.error("Must provide a -name parameter on the command line");
			LB.die();
		} else {
			output_name = Variables.get("name");
		}
		if (!Variables.containsKey("output")) {
			LB.error("Must provide an -output path on the command line");
			LB.die();
		} else { 
			String tmp = Variables.get("output");
			if (!tmp.endsWith(System.getProperty("file.separator"))) {
				tmp = tmp.concat(System.getProperty("file.separator"));
				Variables.put("output", tmp);
			}
			LB.notice("Log File: " + Variables.get("output") + Variables.get("name") + ".log");
			LB.addLogFile(Variables.get("output") + Variables.get("name")  + ".log");
		}
		
		new CurrentVersion(LB);
		LB.Version("Transcript_analysis", "$Revision: 1587 $");		
		
		LB.notice("Processing Files...");
/*
		if (args.length < 4) {
			System.out.println("This program requires parameters:");
			System.out.println("java Transcript_analysis <output path> <output file name> <organism>"
							+ " <file1> [<file2> <file3> ... ] ");
			System.out.println("<organism can be: {bovine, elegans}");
			System.exit(0);
		}
*/		
		String organism = Variables.get("organism");
		String[] f = Variables.get("input").split(",");
		int l = 0;
		for (String file : f) {
			LB.notice("Files remaining to parse: " + (f.length - l));
			LB.notice("File being processed: " + file);

			ExonerateIterator A = new ExonerateIterator(LB, file);
			Vector<AlignedRead> V_lines = new Vector<AlignedRead>();

			while (A.hasNext()) {
				AlignedRead E = null;
				try {
					E = A.next();
				} catch (NoSuchElementException nsee) {
					continue;
				}
				if (V_lines.isEmpty()) {
					V_lines.add(E);
				} else {
					if ((E.get_name() != null)
							&& E.get_name().equals(V_lines.elementAt(0).get_name())) {
						V_lines.add(E);
					} else { // Process V_lines;
						AlignedRead[] A_lines = new AlignedRead[V_lines.size()];
						A_lines = V_lines.toArray(A_lines);
						V_lines.clear();
						V_lines.add(E);
						Arrays.sort(A_lines);
						String Name = null;
						process_Vlines_tr1(A_lines);

						/*
						 * slightly different information in fasta files between
						 * the two transriptomes. will probably need to create a
						 * human/mouse version as well.
						 */

						if (organism.equalsIgnoreCase("elegans") || organism.equalsIgnoreCase("celegans")) {
							/*
							 * need to create a string out of the transcr_name
							 * and all the transcr_versions, while
							 * simultaneously checking that each transcript name
							 * is appropriate, and we need to ensure the
							 * transcr_versions always occur in the same order.
							 * well.. ok then.
							 */

							int P = last_number_after_first_dot(A_lines[0].get_alignName());
							if (P == -1) {
								P = A_lines[0].get_alignName().indexOf(".");
							}
							Name = get_ce_transcr_name(A_lines[0].get_alignName(), P);
							String key = null;
							Boolean same_gene = true;
							String[] t_vers = new String[A_lines.length];

							if (A_lines.length > 1) {
								for (int X = 0; X < A_lines.length; X++) {
									P = last_number_after_first_dot(A_lines[X].get_alignName());
									if (P == -1) {
										P = A_lines[0].get_alignName().indexOf(".");
									}
									/* check that gene name is still the same. */
									if (get_ce_transcr_name(
											A_lines[X].get_alignName(), P).equals(
											Name)) {
										t_vers[X] = get_ce_transcr_version(
												A_lines[X].get_alignName(), P);
									} else {
										same_gene = false;
									}
								}
								if (same_gene) {
									process_grouped_tr3(Name);
									Arrays.sort(t_vers);
									key = t_vers[0]; // remove or ignore
									// duplicates
									for (int Y = 1; Y < t_vers.length; Y++) {
										if (!t_vers[Y].equals(t_vers[Y - 1])) {
											key += ";" + t_vers[Y];
										}
									}
									if (key.equals("")) {
										key = Name;
									} else {
										key = Name + "-" + key;
									}
									process_grouped_tr2(key);
								} else { // not the same gene each time
									failed++;
								}
							} else { // only one line
								String ver = get_ce_transcr_version(
										A_lines[0].get_alignName(), P);
								if (ver.equals("")) {
									key = Name;
								} else {
									key = Name + "-" + ver;
								}
								process_grouped_tr3(Name);
								process_grouped_tr2(key);
							}
							// End Test
						} else if (organism.equalsIgnoreCase("human")
								|| organism.equalsIgnoreCase("bovine")) {
							String key = null;
							if (A_lines.length > 1) {
								/*
								 * chromosome is actually the gene name in this
								 * case - legacy from the original C.Elegans
								 * run. May change this later.
								 */
								Name = A_lines[0].get_chromosome();
								Boolean same_gene = true;
								String[] t_vers = new String[A_lines.length];
								for (int X = 0; X < A_lines.length; X++) {
									/* check that gene name is still the same. */
									t_vers[X] = A_lines[X].get_alignName();
									if (!A_lines[X].get_chromosome().equals(Name)) {
										same_gene = false;
									}
								}
								if (same_gene) {
									process_grouped_tr3(Name);
									Arrays.sort(t_vers);
									key = t_vers[0];
									for (int Y = 1; Y < t_vers.length; Y++) {
										if (!t_vers[Y].equals(t_vers[Y - 1])) {
											key += ";" + t_vers[Y];
										}
									}
									if (key.equals("")) {
										key = Name;
									} else {
										key = Name + "-" + key;
									}
									process_grouped_tr2(key);
								} else { // not the same gene each time
									failed++;
								}
							} else { // only one line
								Name = A_lines[0].get_chromosome();
								if (A_lines[0].get_alignName().equals("")) {
									key = Name;
								} else {
									key = Name + "-" + A_lines[0].get_alignName();
								}
								process_grouped_tr3(Name);
								process_grouped_tr2(key);
							}
						} else {
							LB.error("Currently unsupoprted for human or mouse, c.elegans (elegans)");
							LB.die();
						}
					}
				}
			}
			A.close();
			l++;
		}
		LB.notice("Writing to disk...");
		FileOut fo1 = new FileOut(LB, output_path + output_name + ".ht1", false);
		FileOut fo2 = new FileOut(LB, output_path + output_name + ".ht2", false);
		FileOut fo3 = new FileOut(LB, output_path + output_name + ".ht3", false);

		ArrayList<String> keyList = new ArrayList<String>(Transcriptome1.keySet());
		Collections.sort(keyList);
		fo1.writeln(Integer.toString(sequences1) + " sequences used");
		for (String B : keyList) {
			fo1.writeln(B + " " + Transcriptome1.get(B));
		}
		fo1.close();
		LB.notice("Wrote to " + output_path + output_name + ".ht1");

		keyList = new ArrayList<String>(Transcriptome2.keySet());
		Collections.sort(keyList);
		fo2.writeln(Integer.toString(sequences2) + " sequences used");
		for (String B : keyList) {
			fo2.writeln(B + " " + Transcriptome2.get(B));
		}
		fo2.close();
		LB.notice("Wrote to " + output_path + output_name + ".ht2");

		keyList = new ArrayList<String>(Transcriptome3.keySet());
		Collections.sort(keyList);
		fo3.writeln(Integer.toString(sequences3) + " sequences used");
		for (String B : keyList) {
			fo3.writeln(B + " " + Transcriptome3.get(B));
		}
		fo3.close();
		LB.notice("Wrote to " + output_path + output_name + ".ht3");
		LB.notice("sequences mapping to more than Gene: " + failed);
		LB.close();
	}

}

package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;

import src.lib.Constants;
import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;

/**
 * @version $Revision: 1790 $
 * @author 
 */
public class ElandExtIterator implements AlignedReadsIterator{
	private static boolean display_version = true;
	String Name = null;
	BufferedReader br = null;
	int linecount = 0;
	private Log_Buffer LB;
	final int max_PET_len;
	int number_filtered;
	private boolean no_match_warning = true;
	private boolean multi_match_warning = true;
	private boolean qc_warning = true;
	private static final int DESC_FIELD = 10; 
	

	public ElandExtIterator(Log_Buffer log_file, String Name, String source_file, int max_PET_len) {
		LB = log_file;
		if (display_version) {
			LB.Version("ElandExtIterator", "$Revision: 1790 $");
			display_version = false;
		}
		this.max_PET_len = max_PET_len;
		this.Name = Name;
		this.number_filtered = 0;
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else if (source_file.endsWith(".gz")) {
				br = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(source_file))));
			} else {
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (IOException io) {
			if (source_file.endsWith(".gz")) {
				try {
					LB.warning("Couldn't find file: " + source_file);
					source_file = source_file.substring(0,source_file.length()-3);
					LB.warning("Trying file: " + source_file);
					br = new BufferedReader(new FileReader(source_file));
					LB.notice("Success");
				} catch (IOException f) {
					LB.error("Can't open Eland Ext. file (notzipped) " + source_file);
					LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
					LB.die();
				}
			} else {
				LB.error("Can't open Eland Ext. file " + source_file);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				if (source_file.endsWith(".gz")) {
					LB.error("Tried to open as gzip.");
				}
				LB.die();
			}
		}
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	
	/**
	 * @deprecated
	 */
	public void apply_filters(String f) {
		throw new UnsupportedOperationException();
	}
	
	public boolean reset() {
		try {
			br.reset();
			return true;
		} catch (IOException ioe) {
			LB.error("Could not reset input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	  } 
	
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close Eland Ext. file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Lines Filtered : " + this.number_filtered);
		}
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Eland Ext. Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}


// >2-112-75-545 GCAGGCGGAGGAGGAGGTGTCGCGGGG U2 0 0 1 1 154519232 R .. 1G 11G
	// new format
	// HWI-EAS163 1 271 76 621 ATCAAAATAAAAACCAATCTCTTATCTGCTCT
	// YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY chr10.fa 3000758 R 32 0

	// HWI-EAS272_3_FC301RCAAXX 2 64 753 1669
	// CATATCCATTGCTACTCGCATGTAGAGATTTCCACT TTTTTTTTTTTTTTTTTTTTTTTTTTTITTKKKKKK
	// chr2L.fa 7518 F 36 35
	// (Name ID ) Sequence quality chr position dir alignment QV
	
	
	
	public AlignedRead next() {
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				this.linecount++;	
				String[] elements = line.split("\t");				
				final String line_name = elements[0] + "_" + elements[1] + "_" + 
								elements[2] + "_" + elements[3] + "_" +
								elements[4] + "_" + elements[5];
				final String Sequence = 	elements[8]; 	
				if (elements[DESC_FIELD].equalsIgnoreCase("NM")) {
					if (no_match_warning) {
						LB.warning("Eland Extended file used contains no-match reads and has not been " +
								"filtered for unique hits!!!  Processing will continue, and no further warnings " +
								"will be given.  Please note that it is advised that pre-processing be done " +
								"on Eland Extended files ");
						this.no_match_warning = false;
					}
					continue;
				} else if (elements[DESC_FIELD].contains(":")) {
					if (multi_match_warning) {
						LB.warning("Eland Extended file used contains multi-match reads and has not been " +
								"filtered for unique hits!!!  Processing will continue, and no further warnings " +
								"will be given.  Please note that it is advised that pre-processing be done " +
								"on Eland Extended files ");
						this.multi_match_warning = false;
					}
					continue;
				} else if (elements[DESC_FIELD].equalsIgnoreCase("QC")) {
					if (qc_warning) {
						LB.warning("Eland Extended file used contains qc reads and has not been " +
								"filtered for unique hits!!!  Processing will continue, and no further warnings " +
								"will be given.  Please note that it is advised that pre-processing be done " +
								"on Eland Extended files ");
						this.qc_warning = false;
					}
					continue;
				}
				
				final int alignStart = 		Integer.parseInt(elements[12]); 	//154519232
				final String fit = 			elements[14]; 			
				
				int mismatches = 0;										//use information to fill in the fields below;
				char[] match_info = fit.toCharArray();
				for (char x : match_info) {
					if (Utilities.isBase(x)) {
						mismatches++;
					}
				}
				
				/* test conditions */
				if (this.max_PET_len != 0 && Sequence.length() > this.max_PET_len) {
					this.number_filtered++;
					continue;
				}
				
				final int alignLength   = Sequence.length();
				final int seqEnd		= Sequence.length() -1;
				final float percent 	= (Constants.PERCENT_100 - ((float)mismatches/(float)seqEnd)*Constants.PERCENT_100 );
				final double iden 		= Math.floor(((double)(seqEnd-mismatches)/(double)seqEnd) *10000);
				final int identity		= (int)(iden/Constants.PERCENT_100);

				String alignseq = (mismatches > 0) ? ElandExtUtilities.parse_mismatches(Sequence, match_info) : Sequence;

				// ESCA-JAVA0076:
				AlignedRead a = null;
				try {
					a = new AlignedRead(
						(elements[13].equals("R") ? '-' : '+'),	/* direction */
						line_name,
						Sequence,
						Integer.parseInt(elements[15]),			/*score*/
						0,										/*seqStart*/
						seqEnd,
						null, 									/*alignName*/
						(elements[11].equals("")) ? elements[10] : elements[11],	/* chromosome */
						alignStart,
						alignStart + Sequence.length() - 1,		/*alignEnd*/
						percent,
						0, 										/*P -->  used for Chastity filtering here.*/
						alignseq,
						mismatches,
						-alignStart,							/*sort_score*/
						0,										/*queryLength*/
						alignLength,
						0,										/*contigStart*/
						0,										/*contigEnd*/
						identity,
						null,									/*Match*/
						0,										/*matches_noError*/
						0,										/*matches_1error*/
						0,										/*matches_2error*/
						null,									/*N_reads*/
						null,									/*error1*/
						((elements.length > 21) 				/*error2*/
							? elements[21] : null),
						scale_scores(elements[9].getBytes()));				/*quality*/
				} catch (UnexpectedResultException URE) {
					LB.error("Line " + linecount + " has an invalid read:");
					LB.error(URE.getMessage());
				}
				return a;						
			}
			throw new NoSuchElementException("Could not get any more reads.");
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount + " of Eland Ext file.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return null;
	}

	
	private static byte[] scale_scores(byte[] b){
		for (int i = 0; i < b.length; i++) {
			b[i] -= 64;
		}
		return b;
	}
	

	
	/**
	 * Return the number of filtered read while iterating.
	 * TODO change this function if the Iterator start filtering
	 * @return 0 in every case
	 */
	public int get_NumberFilteredRead() {
		return this.number_filtered;
	}

}

		
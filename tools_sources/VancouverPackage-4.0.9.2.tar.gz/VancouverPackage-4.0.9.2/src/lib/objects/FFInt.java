package src.lib.objects;

public class FFInt {

	private float a;
	private float b;
	private int loc;
	
	public FFInt() {}
	
	public FFInt(float one, float two, int i) {
		a = one;
		b = two;
		loc = i;
	}
	
	public FFInt(double one, double two, int i) {
		a = (float) one;
		b = (float) two;
		loc = i;
	}
	public float get_first() { return a; }
	public float get_second() { return b; }
	public int get_location() { return loc; }
	
	public void set_first(float number) { a = number; }
	public void set_second(float number) { b = number; }
	public void set_location(int number) { loc = number; }
	
}

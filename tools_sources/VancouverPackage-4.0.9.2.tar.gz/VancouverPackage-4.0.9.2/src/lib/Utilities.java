package src.lib;

import java.text.DecimalFormat;
import java.text.NumberFormat;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import src.lib.Error_handling.GenericProcessingException;
import src.lib.Error_handling.UnexpectedCharacterException;


/**
 * @version $Revision: 1824 $
 * @author 
 */
// ESCA-JAVA0136:
public class Utilities {
	/** number of 2-bit characters in a Long. */
	public static final int LONG_SIZE_CHR = 32; //in characters, not in Bits!
	/** number of bits in a Long. */
	public static final int LONG_SIZE_BIT = 64;
	/** A fixed length to get the chr from the file name : Homo_sapiens.NCBI36.42.dna.chromosome*/
	public static final int STRING_38 = 38;
	
	public static final int TEN = 10;
	
	private Utilities() {}										// dummy  constructor

	/**
	 * Returns the reverse compliment of a string
	 * 
	 * @param x
	 *            The string to RC
	 * @return The RC of the input string
	 * @throws UnexpectedCharacterException
	 */
	public static String reverseCompliment(String x) throws UnexpectedCharacterException{

		char[] rc = new char[x.length()];		//needs to be created the same length as x
		int length = x.length()-1;				//highest number of cells is length -1
		for (int i = 0; i <= length; i++) {		//for each cell, reverse the character AND the order.
			rc[i] = reverseCompliment(x.charAt(length-i));
		}
		return new String(rc);					//return string
	}

	
	/**
	 * @param a
	 * @return
	 * @throws UnexpectedCharacterException
	 */
	public static char reverseCompliment(char a) throws UnexpectedCharacterException {
		if (Character.isLowerCase(a)) {
			if (a == 'a') { return 't';}
			if (a == 'c') { return 'g';}
			if (a == 'g') { return 'c';}
			if (a == 't') { return 'a';}
		} else {			
			if (a == 'A') { return 'T';}
			if (a == 'C') { return 'G';}
			if (a == 'G') { return 'C';}
			if (a == 'T') { return 'A';}
		}
		throw new UnexpectedCharacterException("Character " + a + " not recognized");
	}

	
	
	
	/**
	 * Returns the correct index for a given base.
	 * A:0 
	 * C:1
	 * G:2
	 * T:3
	 * +:4  <-probably not wanted
	 * -:5  <-probably not wanted
	 * Anything else gets a "-1" which will almost certainly cause problems. 
	 * @param c
	 * @return index for Base
	 * @throws UnexpectedCharacterException
	 */
	public static int getIndexForBase(char c) throws UnexpectedCharacterException{
		/*		slow version:
		 for (int i = 0; i < Chromosome.BASES.length; i++)
		 if (c == Chromosome.BASES[i])
		 return i;
		 return -1;*/

		if (c == 'A' || c == 'a') {		// fast(er) version
			return 0;
		} 
		if (c == 'C' || c == 'c') {
			return 1;
		}
		if (c == 'G' || c == 'g') {
			return 2;
		}
		if (c == 'T' || c == 't') {
			return 3;
		}
		if (c == '+') {
			return 4;
		}
		if (c == '-') {
			return 5;
		}
		throw new UnexpectedCharacterException("Did not recognize char: \"" + c + "\"");
	}
	
	
	
	/**
	 * Returns the location of the minimum value in the array provided. (Not the
	 * actual minimum itself)
	 * 
	 * @param array
	 * @param a
	 * @param b
	 * @return int: location of the minimum value in the array.
	 */
	public static int findmin(float[] array, int a, int b ) {
		float min = array[a];
		int loc = a;
		int x = a+1;
		while( x <= b) {
			if (array[x] < min) {
				min = array[x];
				loc = x;
				while (FloatingPoint.are_values_equal(array[x+1], min)) {
					x++;
				}
				if (loc != x) {
					loc = Math.round(((float)loc +x)/2);
				}
			}
			x++;
		}
		return loc;
	}	
	
	/**
	 * Returns the location of the minimum value in the array provided. (Not the
	 * actual minimum itself)
	 * 
	 * @param array
	 * @param a
	 * @param b
	 * @return int: location of the minimum value in the array.
	 */
	public static int findmin(int[] array, int a, int b ) {
		int min = array[a];
		int loc = a;
		int x = a+1;
		while( x <= b) {
			if (array[x] < min) {
				min = array[x];
				loc = x;
				while (array[x+1] == min) {
					x++;
				}
				if (loc != x) {
					loc = Math.round(((float)loc +x)/2);
				}
			}
			x++;
		}
		return loc;
	}	
	
	
	
	
	
	/**
	 * return a string representing the long value in binary format.
	 * 
	 * @param l
	 * @return A string giving the binary representation of the long value
	 *         provided
	 */
	public static String returnBinaryLong(long l) {
		StringBuffer sb = new StringBuffer();
		for (int i = LONG_SIZE_BIT-1; i >= 0; i--) {
			if (((1L << i) & l) != 0) {
				sb.append("1");
			} else {
				sb.append("0");
			}
		}
		return sb.toString();
	}
	
	
	/**
	 * Unit test.  Should me moved to a JUnit, when they're available.
	 */
	// ESCA-JAVA0266:
	public static void test_reverseCompliment () {
		String a = "ACTTTGGGGGTACCACACTATA";
		String b = null;
		try {
			b = reverseCompliment(a);
		} catch (UnexpectedCharacterException uce) {
			System.out.println(uce.getMessage());
		}
		System.out.println(a);
		System.out.println(b);
	}
	
	/**
	 * 
	 * @param x
	 * @param min_length
	 * @return String: a formatted number which looks pretty.
	 */
	public static String FormatNumberForPrinting (double x, int min_length) {
		NumberFormat nf = new DecimalFormat("#0.00");
		String s = nf.format(x);
		int per = s.indexOf('.');
		String s2 = "";
		int len = s.length();
		if (per != -1) {
			len = per;
		}
		for (int q = 1; q <= ((len-1)/3); q++) {
			s2 = new StringBuffer(s).insert((len-(q*3)), ",").toString();
			s = s2;
		}
		while (s.length() < min_length) {
			s = " " + s; 
		}
		return s;
	}
	
	/**
	 * 
	 * @param x
	 * @param min_length
	 * @return String: a formatted number which looks pretty.
	 */
	public static String FormatNumberForPrinting (float x, int min_length) { 
		String s = Float.toString(x); 
		int per = s.indexOf('.');
		int len = s.length();
		String s2 = "";
		if (per != -1) {
			len = per;
		}	
		for (int q = 1; q <= ((len-1)/3); q++) {
			s2 = new StringBuffer(s).insert((len-(q*3)), ",").toString();
			s = s2;
		}
		while (s.length() < min_length) {
			s = " " + s; 
		}
		return s;
	}
	
	public static String FormatNumberForPrinting (int x, int min_length) { 
		String s = Integer.toString(x); 
		int per = s.indexOf('.');
		int len = s.length();
		String s2 = "";
		if (per != -1) {
			len = per;
		}	
		for (int q = 1; q <= ((len-1)/3); q++) {
			s2 = new StringBuffer(s).insert((len-(q*3)), ",").toString();
			s = s2;
		}
		while (s.length() < min_length) {
			s = " " + s; 
		}
		return s;
	}
	
	
	public static String Fixed_width_justify_left(String s, int min_length) { 
		while (s.length() < min_length) {
			s += " "; 
		}
		return s;
	}
	
	public static String Fixed_width_justify_right(String s, int min_length) { 
		while (s.length() < min_length) {
			s = " " + s; 
		}
		return s;
	}
	
	public static final String strip_trailing_zeros(String x) {
		int e = x.indexOf('E');
		String mod = ""; 
		if (e > -1) {
			mod = x.substring(e);
			x = x.substring(0, e);
		}
		if (x.contains(".")) {
			while (x.endsWith("0") ) {
				x = x.substring(0, x.length()-1);	
			}
			if (x.endsWith(".")) {
				x = x.substring(0, x.length()-1);
			}
		}
		return x + mod;			
	}
	
	/**
	 * 
	 * @param x  Number to format
	 * @param y  Positions after decimal point
	 * @return Formatted String Version
	 */
	public static final String DecimalPoints(float x, int y) {
		return DecimalPoints((double) x, y);
	}
	
	/**
	 * Overloaded for floats and Doubles
	 * @param x  Number to format
	 * @param y  Positions after decimal point
	 * @return Formatted String Version
	 */
	public static String DecimalPoints(double x, int y) {
		String s = Double.toString(x);
		int p = s.indexOf('.');
		int e = s.indexOf('E');

		String mod = null;
		String ord = null;
		if (e > -1) {
			mod = s.substring(e);
			ord = s.substring(0, e);
		} else {
			mod = "";
			ord = s;
		}
		
		if (p + y + 1 < ord.length() && Character.getNumericValue(s.charAt(p+y+1)) > 4) {
			int g = 0;
			char[] t= ord.toCharArray();
			int z =p+y+1;
			z--;
			g = t[z] - '0' + 1;
			if (g == TEN) {
				t[z] = '0';
			} else {
				t[z] = String.valueOf(g).charAt(0);
			}
			while (t[z] =='0') {
				z--;
				if (z < 0) {
					return "1" + new String(t).substring(0,p+y+1) + mod;
				}
				if (t[z] == '.') {
					z--;
				}	
				g = t[z] - '0' + 1;
				if (g == TEN) {
					t[z] = '0';
				} else {
					t[z] = String.valueOf(g).charAt(0);
				}
			}
			return new String(t).substring(0,p+y+1) + mod;
		} else if (p + y + 1 < ord.length()) {
			return s.substring(0, p+y+1) + mod;
		} else {
			return s + mod;
		}
	}
	
	/**
	 * Simple function that provides the complementary base for any single char.
	 * If base is not a standard nucleotide, it throws a NoSuchElementException.
	 * @param base a standard nucleotide {ACGT}
	 * @return compliment to base 
	 */
	public static char Flip_Base(char base)
	{
		if (base == 'A') { return 'T'; }
		if (base == 'T') { return 'A'; }
		if (base == 'C') { return 'G'; }
		if (base == 'G') { return 'C'; }
			
		if (base == 'R') { return 'Y'; }
		if (base == 'Y') { return 'R'; }
		if (base == 'W') { return 'S'; }
		if (base == 'S') { return 'W'; }
		if (base == 'M') { return 'K'; }
		if (base == 'K') { return 'M'; }
		
		if (base == 'H') { return 'D'; }
		if (base == 'B') { return 'V'; }
		if (base == 'V') { return 'B'; }
		if (base == 'D') { return 'H'; }
		
		if (base == 'N') { return 'N'; }

		//System.out.println("Error - Flip_Base provided a sequence not in {ACGT}! " + base);
		throw new NoSuchElementException();
	}
	
	/**
	 * 
	 * @param one
	 * @param two
	 * @return char: the base representation of complex base annotation, minus a second base annotation.
	 * @throws GenericProcessingException 
	 */
	public static char non_canonical_subtract(char one, char two) throws GenericProcessingException {
		switch (one) {
		case 'R':
			if (two == 'A') {
				return 'G';
			} else if (two == 'G') {
				return 'A';
			}
			throw new GenericProcessingException("Couldn't subtract " + two + " from " + one);
		case 'Y':
			if (two == 'C') {
				return 'T';
			} else if( two == 'T') {
				return 'C';
			}
			throw new GenericProcessingException("Couldn't subtract " + two + " from " + one);
		case 'W':
			if (two == 'A') {
				return 'T';
			} else if ( two == 'T') {
				return 'A';
			}
			throw new GenericProcessingException("Couldn't subtract " + two + " from " + one);
		case 'S':
			if (two == 'C') {
				return 'G';
			} else if (two == 'G') {
				return 'C';
			}
			throw new GenericProcessingException("Couldn't subtract " + two + " from " + one);
		case 'M':
			if (two == 'A') {
				return 'C';
			} else if (two == 'C') {
				return 'A';
			}
			throw new GenericProcessingException("Couldn't subtract " + two + " from " + one);
		case 'K':
			if (two == 'G' ){
				return 'T';
			} else if (two == 'T') {
				return 'G';
			}
			throw new GenericProcessingException("Couldn't subtract " + two + " from " + one);
		default:
			throw new GenericProcessingException("Non_canonical_match - did not recognize input base: " + one);
		}
	}
	
	
	/**
	 * Subtract an item from a set
	 * currently not the most-efficient implementation
	 * 
	 * @param set
	 * @param item
	 * @return
	 */
	public static char[] subtract_base(char[] set, char item) {
		
		ArrayList<Character> n = new ArrayList<Character>(set.length-1);
		for (char t : set) {		
			if (item != t) {
				n.add(t);
			}
		}
		char[] r = new char[n.size()];
		int x = 0;
		for (char s : n) {
			r[x] = s;
			x += 1;
		}
		return r;

	}
	
	
	
	/**
	 * Assumes at least one of the bases is a canonical base (two, preferably).
	 * Throws a NoSuchElementException, if not found.
	 * 
	 * @param one
	 * @param two
	 * @return boolean
	 */
	public static boolean non_canonical_match(char one, char two){
		if (isBase(one)) {
			if (isBase(two)) {
				if (one == two) {
					return true;
				}
			} else {
				return non_canonical_match(two, one);
			}
		}
		if (one == 'R') {	return ((two == 'A' || two == 'G') ? true : false ); }
		if (one == 'Y') {	return ((two == 'C' || two == 'T') ? true : false ); }
		if (one == 'W') {	return ((two == 'A' || two == 'T') ? true : false ); }
		if (one == 'S') {	return ((two == 'C' || two == 'G') ? true : false ); }
		if (one == 'M') {	return ((two == 'A' || two == 'C') ? true : false ); }
		if (one == 'K') {	return ((two == 'G' || two == 'T') ? true : false ); }
		if (one == 'H') {	return ((two == 'A' || two == 'C' || two == 'T') ? true : false ); }
		if (one == 'B') {	return ((two == 'C' || two == 'G' || two == 'T') ? true : false ); } 
		if (one == 'V') {	return ((two == 'A' || two == 'C' || two == 'G') ? true : false ); }
		if (one == 'D') {	return ((two == 'A' || two == 'G' || two == 'T') ? true : false ); }
		if (one == 'N') {	return ((two == 'A' || two == 'G' || two == 'C' || two == 'T') ? true : false ); }
		throw new NoSuchElementException();					// Did not find what we were expecting to see. 
	}

	/**
	 * Attempts to compact two canonical bases to the equivalent one character expression.
	 * Throws a NoSuchElementException, if not found.
	 * 
	 * R	Purine (A or G)
	 * Y	Pyrimidine (C or T)
	 * N	Any nucleotide
	 * W	Weak (A or T)
	 * S	Strong (G or C)
	 * M	Amino (A or C)
	 * K	Keto (G or T)
	 * 
	 * @param one
	 * @param two
	 * @return char
	 */
	public static char get_canonical_char(char one, char two){
		
		/**
	 	
		 */		
		one = Character.toUpperCase(one);
		two = Character.toUpperCase(two);
		if (one == 'A') {
			if (two == 'A') 		{ return 'A'; } 
			else if (two == 'C') 	{ return 'M'; }
			else if (two == 'G') 	{ return 'R'; }
			else if (two == 'T') 	{ return 'W'; }
		} else if (one == 'C') {
		   	if (two == 'A') 		{ return 'M'; }
			else if (two == 'C') 	{ return 'C'; }
			else if (two == 'G') 	{ return 'S'; }
			else if (two == 'T') 	{ return 'Y'; }
		} else if (one == 'G') {
			if (two == 'A') 		{ return 'R'; }
			else if (two == 'C') 	{ return 'S'; }
			else if (two == 'G') 	{ return 'G'; }
			else if (two == 'T') 	{ return 'K'; }
		} else if (one == 'T') {
			if (two == 'A') 		{ return 'W'; }
			else if (two == 'C') 	{ return 'Y'; }
			else if (two == 'G') 	{ return 'K'; }
			else if (two == 'T') 	{ return 'T'; }
		} else {
			return 'N';
		}
		throw new NoSuchElementException();					// Did not find what we were expecting to see. 
	}
	
	/**
	 * Attempts to convert a non_canonical base back to a set of canonical bases.
	 * returns an array of chars matching the set described by the letter.
	 * 
	 * Assumes the input is an uppercase letter. 
	 * Assumes at least one of the bases is a canonical base (two, preferably).
	 * Throws a NoSuchElementException, if not found.
	 * 
	 * @param one
	 * @return boolean
	 */
	public static char[] non_canonical_expansion_uppercase(char one){
		
		if (one == 'A' || one == 'C' || one == 'G' || one == 'T' ) {
			char[] x = new char[1];
			x[0] = one;
			return x;
		}
		if (one == 'R') { char[] x = new char[2];	x[0] = 'A';		x[1] = 'G';		return x;	}		
		if (one == 'Y') { char[] x = new char[2];	x[0] = 'C';		x[1] = 'T';		return x;	} 
		if (one == 'W') { char[] x = new char[2];	x[0] = 'A';		x[1] = 'T';		return x;	} 
		if (one == 'S') { char[] x = new char[2];	x[0] = 'C';		x[1] = 'G';		return x;	} 
		if (one == 'M') { char[] x = new char[2];	x[0] = 'A';		x[1] = 'C';		return x;	} 
		if (one == 'K') { char[] x = new char[2];	x[0] = 'G';		x[1] = 'T';		return x;	} 
		
		if (one == 'H') { char[] x = new char[3];	x[0] = 'A';		x[1] = 'C';		x[2] = 'T';		return x;	}
		if (one == 'B') { char[] x = new char[3];	x[0] = 'C';		x[1] = 'G';		x[2] = 'T';		return x;	} 
		if (one == 'V') { char[] x = new char[3];	x[0] = 'A';		x[1] = 'C';		x[2] = 'G';		return x;	}
		if (one == 'D') { char[] x = new char[3];	x[0] = 'A';		x[1] = 'G';		x[2] = 'T';		return x;	}
		
		if (one == 'N') { char[] x = new char[4];	x[0] = 'A';		x[1] = 'C';		x[2] = 'G';		x[3] = 'T';		return x;	}
		throw new NoSuchElementException();					// Did not find what we were expecting to see. 
	}
	
	
	/**
	 * wrapper to non_canonical_expansion_uppercase - converts input to uppercase
	 * @param a
	 * @return
	 */
	public static char[] non_canonical_expansion(char a) {
		return non_canonical_expansion_uppercase(Character.toUpperCase(a));
	}
	
	
	
	
	/**
	 * 
	 * @param x
	 * @return boolean: true if it's an accepted canonical base (upper or lowercase)
	 */
	public static final boolean isBase(char x) {
		switch (x) {
		case 'A':
		case 'a':
		case 'C':
		case 'c':
		case 'G':
		case 'g':
		case 'T':
		case 't':
			return true;
		default:
			return false;
		}
	}
 	

	/**
	 * 
	 * @param input
	 * @return String: A stripped down chromosome name that can be used.
	 */
	public static String translate_Current_Chromosome(String input) {

		
		if (input.startsWith("Homo_sapiens.NCBI36.42.dna.chromosome")) {
			return input.substring(STRING_38, input.indexOf('.', STRING_38));
		}
		if (input.startsWith("chr") && input.length() > 3) {
			input = input.substring(3);
		}
		if (input.lastIndexOf("\\") != -1) {
			input = input.substring(input.lastIndexOf("\\")+1);
		}
		
		if (input.lastIndexOf(".") != -1) {						//strip off any file extensions
			input = input.substring(0, input.lastIndexOf("."));
		}
		if (input.equalsIgnoreCase("MT")) {
			input  = "M";
		}		
		return input;
	}
	
	/**
	 * Function for processing SNPs
	 * 
	 * @param Allele
	 * @param expected_base
	 * @param alt_base
	 * @return String indicating the SNP's status in variationDB.
	 */
	public static String is_expected_base(String Allele, char expected_base,
			char alt_base) {
		if (Allele.charAt(0) == expected_base) {
			for (int j = 2; j < Allele.length(); j += 2) {
				if (Allele.charAt(j) == alt_base) {
					return "known";
				}
			}
			return "newvariant";
		} else if (Allele.charAt(0) == Utilities.Flip_Base(expected_base)) {	// else if, do the same but flip all bases, 	
			for (int j = 2; j < Allele.length(); j += 2) {						// to see if on other strand
				if (Allele.charAt(j) == Utilities.Flip_Base(alt_base)) {
					return "known";
				}
			}
			return "newvariant";
		} else {
			return "unexpected:" + Allele.charAt(0) + "";		//Variation found does not match location.
		}
	}
	
	
	/**
	 * 
	 * @param codingDNA
	 * @param Species
	 * @return String: Removing spurious N's in a codingDNA sequence. Returns
	 *         the input string minus the N's.
	 */
	public static String remove_spurious_Ns(String codingDNA, String Species) {
		
		if (Species.equalsIgnoreCase("bovine")) {				//This is used for Bovine
/*			while (NewTranscript.indexOf("N") != -1) {
				NewTranscript.deleteCharAt(NewTranscript.indexOf("N"));
			}*/
			while (codingDNA.indexOf('N') != -1) {
				codingDNA = codingDNA.replace("N", "");
			}
		} else {  												//only bovine needs mid-sequence pruning of N's to run.  
			if (codingDNA.indexOf('N') != -1) {					//Others only need the initial N's removed.
				codingDNA = codingDNA.replace("N", "");
			}
		}
		return codingDNA;
		
	}	

	/**
	 * 
	 * @param codingDNA
	 * @return String: Removing spurious X in a codingDNA sequence. Returns
	 *         the input string minus the X.
	 */
	public static String remove_spurious_Xs(String codingDNA) {
		
		if (codingDNA.indexOf('X') != -1) {					//Some calls are getting X's attached to them,
			codingDNA = codingDNA.replace("X", "");			// when it's a non-canonical gene start.
		}
		return codingDNA;
		
	}	
	
	
	
	/**
	 * returns fragment of byte_array, inclusive of start and end positions.
	 * @param src
	 * @param start
	 * @param end
	 * @return
	 */
	public static byte[] part_of_byte_array(byte[] src, int start, int end) {
		final int cells = end - start + 1;
		byte[] n = new byte[cells];
		for (int x = 0; x < cells; x++) {
			n[x]= src[x + start];
		}
		return n;	
	}
	
	/**
	 * finds the number of times char c exists in string s
	 * @param s
	 * @param c
	 * @return
	 */
	public static int count_occurances (String s, char c) {
		int n = 0;
		char[] a = s.toCharArray();
		for (char b : a) {
			if (b == c) {
				n++;
			}
		}
		return n;
	}
	
	
}

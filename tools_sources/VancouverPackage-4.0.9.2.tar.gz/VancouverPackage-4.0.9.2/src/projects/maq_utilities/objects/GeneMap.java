package src.projects.maq_utilities.objects;

/**
 * @version $Revision: 558 $
 * @author 
 */
public class GeneMap {
	private String Accession = null;
	private int end_base = 0;
	
	public GeneMap(String a, int e) {
		this.Accession = a;
		this.end_base = e;
	}
	
	public void set_Accession(String x) { this.Accession = x; }
	public void set_end(int x) { this.end_base = x; }
	public String get_Accesssion() { return this.Accession; }
	public int get_end() { return this.end_base; }
	
}

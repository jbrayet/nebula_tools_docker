package src.projects.findPeaks.FDR;

import src.lib.RandomAlignedReadGenerator;
import src.lib.Utilities;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;

import src.projects.findPeaks.Distribution;
import src.projects.findPeaks.FPConstants;
import src.projects.findPeaks.PeakDataSetParent;
import src.projects.findPeaks.objects.Parameters;
import src.projects.findPeaks.objects.PeakStats;


/**
 * @version $Revision: 1548 $
 * @author 
 */
public class MC_Simulation {

	private MC_Simulation() {}
	
	private static Log_Buffer LB = null; 
	private static boolean display_version = true;

	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param coverage
	 * @param dist
	 * @param param
	 * @param chr_size
	 * @param Chromosome
	 * @param iterations
	 * @param verbose
	 * @return
	 */
	public static PeakStats[] Sim (
			int coverage,/*PeakStats obs_pstats,*/ 
			Distribution dist,
			Parameters param,
			int chr_size, 
			String Chromosome, 
			int iterations, 
			boolean verbose) {
		PeakStats[] chr_pkstats = new PeakStats[iterations]; 
		if (LB == null) { 
			LB = Parameters.get_Log_Buffer();
		}
		if (display_version) {
			LB.Version("MC_Simulation", "$Revision: 1548 $");
			display_version = false;
		}
		
		if (coverage > chr_size) {
			
			LB.notice("Coverage: " + coverage);
			LB.notice("Chr size: " + chr_size);
			LB.error("Observed coverage of this genome is greater than the effective length.");
			LB.error("This is likely if:");
			LB.error("1) your effective genome size is too small.");
			LB.error("2) your coverage is too big - not likely to be a ChIP-Seq expt.");
			LB.error("You may wish to adjust your input parameters accordingly.");
			LB.error("peakstats will not be run for this chromosome");
			LB.error("This error may be seen when data from unsorted reads is provided.");
			return null;
//			LB.die();
		}
		if (verbose) {
			LB.notice("");
			LB.notice("------------------------------------------------------------------------");
			LB.notice("Chromosome " + Chromosome + " Statistics");
			LB.notice("Estimated Chromosome Size : "
					+ Utilities.FormatNumberForPrinting(chr_size,
							FPConstants.FIELD_WIDTH_1));
		}
		chr_size *= param.get_eff_frac();
		if (verbose) {
			LB.notice("Using Effective chr size of " + param.get_eff_frac()
					+ " * estimated size : "
					+ Utilities.FormatNumberForPrinting(chr_size, 0));
			LB.notice("Observed Coverage         : " + Utilities.FormatNumberForPrinting(coverage,0));
		}

		int batch_size = coverage/1000;
		if (batch_size < FPConstants.MIN_BATCH) {
			batch_size = FPConstants.MIN_BATCH;
		}
		if (verbose) {
			LB.notice("Generating random reads in batches of : " + Utilities.FormatNumberForPrinting(batch_size,0));
			LB.notice("------------------------------------------------------------------------");
		}
		if (chr_size < coverage ) {
			//LB.warning("Coverage is greater than effective length! - moving to next chromosome.");
			LB.warning("Coverage is greater than effective length! - use coverage as chromosome size.");
			chr_size=Math.round(coverage/ param.get_eff_frac());
			//return null;
		}
		if (verbose) {
			LB.notice("Performing Simulations.");
		}
		for (int i = 0; i < iterations; i++ ) {
			if (verbose) {
				LB.notice(Integer.toString((i+1) % FPConstants.TENS));
			}
			RandomAlignedReadGenerator RARG = new RandomAlignedReadGenerator(LB, dist, batch_size, chr_size);  
			/*convert to "generic iterator"*/
			Generic_AlignRead_Iterator it = new Generic_AlignRead_Iterator(LB, RARG);
			PeakDataSetParent sim_peaks = new PeakDataSetParent(LB, param, it, dist);
			PeakStats sim_pstats = new PeakStats(LB, sim_peaks, param.get_number_of_bins(), param.get_hist_precision());
			while (sim_pstats.get_coverage() < coverage) {
				it.close();
				RARG.Add_More_Random_Sorted_Reads(dist, batch_size, chr_size);
				it = new Generic_AlignRead_Iterator(LB, RARG);
				sim_peaks = new PeakDataSetParent(LB, param, it, dist);
				sim_pstats = new PeakStats(LB, sim_peaks, param.get_number_of_bins(), param.get_hist_precision());
			}
			chr_pkstats[i] = sim_pstats;
		}
		return chr_pkstats;
	}
	
	
	
}

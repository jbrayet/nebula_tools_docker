package src.projects.findPeaks.objects;

public class PairDistance {

	private final int pk_idx_1;
	private final int pk_idx_2;
	private final int distance;
	private boolean allowed;
	private final int hint;

	public PairDistance(int dist, int a, int b, int hint) {
		if (dist < 0 && a != -1 && b != -1) {
			this.allowed = false;
		} else {
			this.allowed = true;
		}	
		this.pk_idx_1 = a;
		this.pk_idx_2 = b;
		this.distance = dist;
		this.hint = hint;
	}
	
	public final int get_pk_idx_1()		{	return this.pk_idx_1; }
	public final int get_pk_idx_2()		{	return this.pk_idx_2; }
	public final int get_distance() 	{	return this.distance; }
	public final boolean allowed() 		{	return this.allowed; }
	public final int get_hint() 		{ 	return this.hint;	}
	
	public final void not_allowed() {
		this.allowed = false;
	}
	
	public final String toString() {
		return this.distance + "\t" + this.pk_idx_1 + "\t" + this.pk_idx_2 + "\tallowed:" + this.allowed + "\t" + this.hint;
	}
	
}

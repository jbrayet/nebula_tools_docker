package src.lib.analysisTools;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;

import org.ensembl.datamodel.Location;
import org.ensembl.variation.datamodel.VariationFeature;

import src.lib.Ensembl;
import src.lib.SNPDB;
import src.lib.Utilities;

import src.lib.ioInterfaces.Bedwriter;
import src.lib.ioInterfaces.Log_Buffer;

import src.lib.objects.SNP;

/**
 * @version $Revision: 1482 $
 * @author 
 */
public class Process_SNPs {

	private Process_SNPs() {}
	
	//ESCA-JAVA0138:
	/**
	 * 
	 * This function processes SNPs, by retrieving all known snps for a given
	 * chromsome, before getting all observed snps (using a CLI passed
	 * variable). These two lists are then compared using a binary search to
	 * find the snps, and report on whether they're known, novel, or new for a
	 * given position
	 * @param LB
	 * @param Const
	 * @param CanonicalSequence
	 * @param current_chromosome
	 * @param snps
	 * @param output_path
	 */
	public static void snp_processing(Log_Buffer LB, Ensembl Const,
			String[] CanonicalSequence, int current_chromosome, SNP[] snps,
			String output_path) {

		BufferedWriter snpfile = null;
	
		LB.notice("Retrieving all known SNPs from dbSNP for chromosome...");
		SNPDB[] SNP_list = null;
		List<VariationFeature> variations_list = Ensembl.get_vfa(new Location(
				"chromosome", Const.get_chromosome(current_chromosome)));
		SNP_list = new SNPDB[variations_list.size()];
		for (int X = 0; X < variations_list.size(); X++) {
			VariationFeature A = variations_list.get(X);
			SNP_list[X] = new SNPDB();
			SNP_list[X].set_details(A.getAlleleString().toString());
			SNP_list[X].set_start(A.getLocation().getStart());
		}
		LB.notice("Done");

		LB.notice("Processing Simple SNPS in Chromosome...");
				
		String bedfile = output_path + Const.get_chromosome(current_chromosome) + ".SNP.bed.gz";
		Bedwriter bed = new Bedwriter(LB, bedfile);
		bed.BedHeader("SNPs", "SNPs found", false);
		int snpcnt = 0;
		
		try {
			for (SNP s : snps) {
				snpcnt++;
				int pos = s.get_position();
				char alt_base = s.get_new_base();
				
				assert (snpfile != null);
				
				/* wig files are 1 based, bed files are zero based.*/
				snpfile.write(Const.get_chromosome(current_chromosome) + "," + (pos + 1) + ",");
				snpfile.write(s.get_coverage_snp() + "," + s.get_total_coverage() + "," + alt_base + ",");				
	

				int index = SNPDB.SNPbinarySearch(SNP_list, pos + 1);
				if (index != -1) {								// check if in SNP_list
					String Allele = SNP_list[index].get_details();
					if (Allele.length() < 3) {
						LB.notice("Allele found, no SNP! :" + Allele);
						snpfile.write("novel(nosnp)");
						snpfile.newLine();
					} else {  
						snpfile.write(Utilities.is_expected_base(Allele,
								CanonicalSequence[1].charAt(pos), alt_base));
					}
				} else {										// else, does not match - no known snp.
					snpfile.write("novel");
					snpfile.newLine();
				}
			}
		} catch (IOException io) {
			LB.error("Can't write snp files");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		LB.notice("Done");
		LB.notice(snpcnt + " SNPS found");

		try {
			assert (snpfile != null);
			snpfile.close();
		} catch (IOException io) {
			LB.warning("Warning: Could not close buffered writer");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		bed.close();
	}

	
	
}

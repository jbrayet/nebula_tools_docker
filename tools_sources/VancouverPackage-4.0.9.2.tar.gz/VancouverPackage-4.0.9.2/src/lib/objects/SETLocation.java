package src.lib.objects;

/**
 * @version $Revision: 463 $
 * @author 
 */
public class SETLocation {
	private final String contig;
	private final int position;
	private final boolean direction;
	private final short length;
	private final boolean first_of_pair;
	
	public String get_contig() {
		return this.contig;
	}
	
	public int get_position() {
		return this.position;
	}
	
	public boolean get_direction() {
		return this.direction;
	}
	
	public short get_length() {
		return this.length;
	}
	
	public boolean get_first_of_pair() {
		return this.first_of_pair;
	}
	
	
	public SETLocation(String cf, int pf, boolean df, short lf, boolean fp) {
		this.contig = cf;
		this.position = pf;
		this.direction = df;
		this.length = lf;
		this.first_of_pair = fp;
	}
	
	
}

package src.projects.SNP_Database.SnpIterators;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import src.lib.Constants;
import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedCharacterException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;

/**
 * @version $Revision: 1729 $
 * @author 
 */
public class SAMSnpIterator implements Iterator<SNP>, SNPIterator {
	private static boolean display_version = true;
	private static Log_Buffer LB;

	BufferedReader br = null;
	int linecount = 0;
	final String filename;
	Vector<SNP> buffer;
	
	
	public SAMSnpIterator(Log_Buffer logbuffer, String source_file) {
		LB = logbuffer;
		this.filename = source_file;
		if (display_version) {
			LB.Version("SAMSnpIterator", "$Revision: 1729 $");
			display_version = false;
		}
		try {
			br = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException e) {
			LB.error("Can't find file " + filename);
			LB.die();
		}
		buffer = new Vector<SNP>();
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException ioe) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + ioe.getMessage());
		}
		LB.notice(filename + " closed successfully");
		
	}
	
	
	/** 
	 * Read in next line of the SNP file
	 * 
	 * http://samtools.sourceforge.net/pileup.shtml
	 * 
	 * Expected format:
	 * chr	   position ref    obs    cons q   snp q   map q   cover   readbases   base qualities
	 * 1       713663  G       C       29      29      60      1       c       >
	 * 1       713754  G       C       28      36      21      4       A$ccC   %=;B
	 * 1       713924  T       G       22      22      36      1       G       7
	 * 1       714068  C       M       56      65      22      46      .$.$T$T$TT.,,TAA,,aaA,.gTAT,Tat.ttttgt,t,tttt.tttg     
	 * 																			 +@%+%%%BB%@@+?>>AB1%%1%;%%%;%%%%%%%%%%%%%A%%%% 
	 * 
	 * 
	 * @return SNP object
	 */
	public SNP next() {
		String line = null;
		Vector<SNP> S =  new Vector<SNP>();
		if (!buffer.isEmpty()) {
			return buffer.remove(0);
		}
		try {
			if ((line = br.readLine()) != null) {
				this.linecount++;	
				
				String[] elements = line.split("\t");				
				if (elements.length < 11) {
					LB.error("Lack of fields in SNP file provided");
				}
				String chromosome 	= elements[0];
				int position 		= Integer.valueOf(elements[1]);
				char ref 			= elements[2].charAt(0);		
				char obs			= elements[3].charAt(0);

				//consensus quality, SNP quality and maximum mapping quality
//				int cons_qual			= Integer.valueOf(elements[4]);				//unused				
				int snp_qual			= Integer.valueOf(elements[5]);
//				int map_qual			= Integer.valueOf(elements[6]);				//unused
				int coverage			= Integer.valueOf(elements[7]);
				
				//strings:
				String read_bases 		= elements[8];
//				String basequal			= elements[9];				//unused
				
				
				int count_canonical = 0;
				int[] count_oth = new int[4];
				for (int x = 0; x < read_bases.length(); x++) {
					if (read_bases.charAt(x) == '.' || read_bases.charAt(x) == ',') {
						count_canonical+=1;
					} else if (read_bases.charAt(x) == 'A' || read_bases.charAt(x) == 'a') {
						count_oth[0]++;
					} else if (read_bases.charAt(x) == 'C' || read_bases.charAt(x) == 'c') {
						count_oth[1]++;
					} else if (read_bases.charAt(x) == 'G' || read_bases.charAt(x) == 'g') {
						count_oth[2]++;
					} else if (read_bases.charAt(x) == 'T' || read_bases.charAt(x) == 't') {
						count_oth[3]++;
					}
				}
				//Expand to all possible cases of multiple SNPs 
				char[] snps = Utilities.non_canonical_expansion(obs);
				for (char o : snps) {  // ESCA-JAVA0049: depth required for 2nd try/catch block
					if (o != ref) {
						int hits = 0;
						try {
							hits = Utilities.getIndexForBase(o);
						} catch (UnexpectedCharacterException e) {
							LB.error("Could not process base " + o	+ " while creating snp obect.");
							LB.error(e.getMessage());
							e.printStackTrace();
						}
						S.add(new SNP(chromosome, position, o, ref,
								count_oth[hits], count_canonical, coverage, -1,
								snp_qual, -1, null));
					}
				}
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
			}
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		if (S.size() > 1) {
			SNP first_snp = S.remove(0);
			buffer.addAll(S);
			return first_snp;
		} else {
			return S.firstElement();
		}
	}
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of SNPIterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

}

		
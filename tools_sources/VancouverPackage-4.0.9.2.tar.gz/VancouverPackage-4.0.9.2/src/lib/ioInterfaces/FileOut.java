package src.lib.ioInterfaces;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.zip.GZIPOutputStream;


/**
 * @version $Revision: 468 $
 * @author 
 */
public class FileOut {
	
	
	/**
	 * Killer information:  Unlike Wig files, Bed files are Zero based!!!!!
	 */
	
	private static boolean display_version = true;
	private BufferedWriter bw;
	private Log_Buffer LB;
	
	
	public FileOut(Log_Buffer log_file, String file, boolean gzip) {
		LB = log_file;
		if (display_version) {
			LB.Version("FileOut", "$Revision: 468 $");
			display_version = false;
		}
		if (!gzip ) {
			try {
				bw = new BufferedWriter(new FileWriter(file));
			} catch (IOException io) {
				LB.error("Couldn't create bed file : " + file);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
		} else {
			try {
				bw = new BufferedWriter(new OutputStreamWriter
						(new GZIPOutputStream(new FileOutputStream(file))));
			} catch (FileNotFoundException E) {
				LB.error("File Not Found : " + file);
				LB.die();
			} catch (IOException io) {
				LB.error("Couldn't create bed file : " + file);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
		}
	}
	

	
	public void writeln(String str) {
		try {
			bw.write(str);
			bw.newLine();
		} catch (IOException io) {
			LB.warning("Could not write \"" + str + "\"  to file. - FileOut.writeln ");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	public void write(String str) {
		try {
			bw.write(str);
		} catch (IOException io) {
			LB.warning("Could not write \"" + str + "\"  to file - FileOut.write");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	public void close() {
		try {
			bw.close();
		} catch (IOException io) {
			LB.warning("Could not close buffered writer");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
		
	
	
	
		
	
}
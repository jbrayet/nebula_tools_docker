package src.projects.findPeaks.FDR;

import java.util.Arrays;
import java.util.Vector;

import src.lib.Histogram;
import src.lib.Utilities;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Tuple;
import src.projects.findPeaks.PeakDataSetParent;
import src.projects.findPeaks.objects.PeakPairIdx;
import src.projects.findPeaks.objects.PeakStats;
import src.projects.findPeaks.objects.Peakdesc;

public class ApplyControl {
	
	float[] sample_peaks = null;
	float[] control_peaks = null;
	int sample_size = 0;
	int control_size = 0;
	
	
	
	private static boolean display_version = true;
	private static Log_Buffer LB;
	
	
	public ApplyControl (Log_Buffer logbuffer, PeakDataSetParent sample, PeakDataSetParent control) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Apply Control", "$Revision: 1342 $");
			display_version = false;
		}
		
		
		Peakdesc[] tmp = sample.get_array_of_peakdesc();
		sample_size = tmp.length;
		sample_peaks =  new float[sample_size];
		for (int x = 0; x < sample_size ; x++) {
			sample_peaks[x] = tmp[x].get_height();
		}
		Arrays.sort(sample_peaks);  // sorted least to greatest
		
		tmp = control.get_array_of_peakdesc();
		control_size = tmp.length;
		control_peaks =  new float[control_size];
		for (int x = 0; x < control_size ; x++) {
			control_peaks[x] = tmp[x].get_height();
		}
		Arrays.sort(control_peaks);
			
	}
	
	
	
	public ApplyControl (Log_Buffer logbuffer, PeakPairIdx[] pairs) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Apply Control", "$Revision: 1342 $");
			display_version = false;
		}
		Vector<Float> s = new Vector<Float>();
		Vector<Float> c = new Vector<Float>();
		
		for (PeakPairIdx p : pairs) {			//sample	
			if (p.get_pk_idx_1() != -1) {
				sample_size++;
				s.add(p.get_height_1());
			}
			if (p.get_pk_idx_2() != -1) {		//control
				control_size++;
				c.add(p.get_height_2());
			}
		} 
		
		sample_peaks = new float[sample_size];
		control_peaks = new float[control_size];

		int n = 0;
		for (Float f: s) {
			sample_peaks[n] = f;
			n++;
		}
		n = 0;
		for (Float f: c) {
			control_peaks[n] = f;
			n++;
		}
		
		Arrays.sort(sample_peaks);  // sorted least to greatest
		Arrays.sort(control_peaks);  // sorted least to greatest
		
	}
	
	
	public Histogram get_sample_peaks_histogram(int histogram_size, int precision) {
		Histogram r = new Histogram(LB, histogram_size*precision, 0 , histogram_size, false);
		for (float f : sample_peaks) {
			r.bin_value(f);
		}
		return r;
	}
	
	
	public Histogram get_control_peaks_histogram(int histogram_size, int precision) {
		Histogram r = new Histogram(LB, histogram_size*precision, 0 , histogram_size, false);
		for (float f : control_peaks) {
			r.bin_value(f);
		}
		return r;
	}
	


	public ApplyControl (Log_Buffer logbuffer, int control_size, int sample_size) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Apply Control", "$Revision: 1342 $");
			display_version = false;
		}
		this.sample_size = sample_size; 
		this.control_size = control_size;
		control_peaks = null;
	}
	
		
	/**
	 *
	 * @param sample
	 * @param control
	 * @param fp
	 * @return  if value returned is -1, compare was unsuccessful, otherwise, will return the min cutoff height.
	 */
	public int generate_histogram (PeakStats sample, PeakStats control, float fp) {
		
		/*get the two histograms.  */
		Histogram s = sample.get_histogram();
		Histogram c = control.get_histogram();
		
		/*normalize the two histograms*/
		int s1s = sample.get_LW_singles();
		int s2s = sample.get_LW_doubles();
		int c1s = control.get_LW_singles();
		int c2s = control.get_LW_doubles();
		
		double ratio1s = (double)s1s/(double)c1s;
		double ratio2s = (double)s2s/(double)c2s;
		double r_avg = ((ratio1s + ratio2s)/2);
		LB.notice("Ratio of 1s: " + ratio1s);
		LB.notice("Ratio of 2s: " + ratio2s);
		LB.notice("Average: " + r_avg);
		
		int num_bin = s.get_num_bins();
		float min_val = s.get_min_value();
		float max_val = s.get_max_value();
		float binsize = s.get_bin_size();
		
		/* make sure things are correct. */
		
		// ESCA-JAVA0078:
		if (num_bin != c.get_num_bins() || min_val != c.get_min_value() || max_val != c.get_max_value()) {
			LB.error("Cannot compare histograms - different sizes.");
			return -1;
		}
		double[] dif = new double[num_bin+1];
		
		
		if (binsize != 1.0) {
			//TODO: make this work.
			LB.error("-control can not currently be run if the bin size (hist_precision) is not one");
			LB.die();
		}
		
		
		LB.notice("Bin\tValue\tsample\tcontrol\tn.control\tdifference");
		for (int i=0; i < num_bin; i++) {
			dif[i] = (s.get_bin_value(i) - (c.get_bin_value(i)*r_avg));
			LB.notice(i + "\t" + ((i*binsize)+ min_val) 
					+ "\t" + s.get_bin_value(i) 
					+ "\t" + c.get_bin_value(i) 
					+ "\t" + Utilities.DecimalPoints((c.get_bin_value(i)*r_avg), 2) 
					+ "\t" + Utilities.DecimalPoints((s.get_bin_value(i) - (c.get_bin_value(i)*r_avg)), 2));
		}
		if (fp >= 0) {
			int thr = get_threshold(s, c, fp, r_avg);
			LB.notice("Autothreshold for this chromosome is " + thr);
			return thr;
		}
		return -1;
		
	}

	
	private static double get_average_normal_factor(Tuple<Integer, Integer> s_LW_pair, Tuple<Integer, Integer> c_LW_pair) {
		return get_average_normal_factor(s_LW_pair.get_first(), 
				s_LW_pair.get_second(), c_LW_pair.get_first(), c_LW_pair.get_second());
	
	}
	
	private static double get_average_normal_factor(int s_singles, int s_doubles, int c_singles, int c_doubles) {
		/*normalize the two histograms*/
	
		double ratio1s = (double)s_singles/(double)c_singles;
		double ratio2s = (double)s_doubles/(double)c_doubles;
		double r_avg = ((ratio1s + ratio2s)/2);
		LB.notice("Ratio of 1s: " + ratio1s);
		LB.notice("Ratio of 2s: " + ratio2s);
		LB.notice("Average: " + r_avg);

		return r_avg;
		
		}

	/**
	 * 
	 * @param s
	 * @param c
	 * @param s_LW_pair
	 * @param c_LW_pair
	 * @param fp
	 *            the false positive threshold desired.
	 * @return the cutoff estimated for that false positive threshold. Will return -1 if number is not valid.
	 * 
	 */
	public int generate_histogram(Histogram s, Histogram c,
			Tuple<Integer, Integer> s_LW_pair,
			Tuple<Integer, Integer> c_LW_pair, float fp) {
		

		if (s_LW_pair == null || c_LW_pair == null) {
			return -1;
		}
		double r_avg = get_average_normal_factor(s_LW_pair, c_LW_pair);
		
		int num_bin = s.get_num_bins();
		float min_val = s.get_min_value();
		float max_val = s.get_max_value();
		float binsize = s.get_bin_size();
		
		/* make sure things are correct. */
		
		// ESCA-JAVA0078:
		if (num_bin != c.get_num_bins() || min_val != c.get_min_value() || max_val != c.get_max_value()) {
			LB.error("Cannot compare histograms - different sizes.");
			return -1;
		}
		double[] dif = new double[num_bin+1];
		
		
		if (binsize != 1.0) {
			//TODO: make this work.
			LB.error("-control can not currently be run if the bin size (hist_precision) is not one");
			LB.die();
		}
		
		
		LB.notice("Bin\tValue\tsample\tcontrol\tn.control\tdifference");
		for (int i=0; i < num_bin; i++) {
			dif[i] = (s.get_bin_value(i) - (c.get_bin_value(i)*r_avg));
			LB.notice(i + "\t" + ((i*binsize)+ min_val) 
					+ "\t" + s.get_bin_value(i) 
					+ "\t" + c.get_bin_value(i) 
					+ "\t" + Utilities.DecimalPoints((c.get_bin_value(i)*r_avg), 2) 
					+ "\t" + Utilities.DecimalPoints((s.get_bin_value(i) - (c.get_bin_value(i)*r_avg)), 2));
		}

		if (fp >= 0) {
			int thr = get_threshold(s, c, fp, r_avg);
			LB.notice("Autothreshold for this chromosome is " + thr);
			return thr;
		} else {
			LB.notice("Autothreshold was not set.  No cutoff will be used.  " +
					"If you are performing a saturation analyis, this will cause incorrect answers.");
		}
		return -1;
		
	}
	
	/**
	 *
	 * @param s
	 * @param s_LW_singles
	 * @param s_LW_doubles
	 * @param control
	 * @param fp
	 * @return  if value returned is -1, compare was unsuccessful, otherwise, will return the min cutoff height.
	 */
	public int generate_histogram (Histogram s, int s_LW_singles, int s_LW_doubles, PeakStats control, float fp) {
		
		/*get the two histograms.  */
		Histogram c = control.get_histogram();
		 
		int num_bin = s.get_num_bins();
		float min_val = s.get_min_value();
		float max_val = s.get_max_value();
		float binsize = s.get_bin_size();
		
		
		double r_avg = get_average_normal_factor(s_LW_singles, s_LW_doubles, control.get_LW_singles(), control.get_LW_doubles());
		/* make sure things are correct. */
		
		// ESCA-JAVA0078:
		if (num_bin != c.get_num_bins() || min_val != c.get_min_value() || max_val != c.get_max_value()) {
			LB.error("Cannot compare histograms - different sizes.");
			return -1;
		}
		double[] dif = new double[num_bin+1];
		
		
		if (binsize != 1.0) {
			//TODO: make this work.
			LB.error("-control can not currently be run if the bin size (hist_precision) is not one");
			LB.die();
		}
		
		
		LB.notice("Bin\tValue\tsample\tcontrol\tn.control\tdifference");
		for (int i=0; i < num_bin; i++) {
			dif[i] = (s.get_bin_value(i) - (c.get_bin_value(i)*r_avg));
			LB.notice(i + "\t" + ((i*binsize)+ min_val) 
					+ "\t" + s.get_bin_value(i) 
					+ "\t" + c.get_bin_value(i) 
					+ "\t" + Utilities.DecimalPoints((c.get_bin_value(i)*r_avg), 2) 
					+ "\t" + Utilities.DecimalPoints((s.get_bin_value(i) - (c.get_bin_value(i)*r_avg)), 2));
		}
		
	
		if (fp >= 0) {
			int thr = get_threshold(s, c, fp, r_avg);
			LB.notice("Autothreshold for this chromosome is " + thr);
			return thr;
		}
		return -1;
		
	}

	/**
	 *
	 * @param sample
	 * @param c
	 * @param c_LW_pair
	 * @param fp
	 * @return  if value returned is -1, compare was unsuccessful, otherwise, will return the min cutoff height.
	 */
	public int generate_histogram (PeakStats sample, Histogram c, Tuple<Integer, Integer> c_LW_pair, float fp) {
		
		/*get the two histograms.  */
		Histogram s = sample.get_histogram();
		 
		int num_bin = s.get_num_bins();
		float min_val = s.get_min_value();
		float max_val = s.get_max_value();
		float binsize = s.get_bin_size();
		
		
		double r_avg = get_average_normal_factor(sample.get_LW_pair(), c_LW_pair);
		/* make sure things are correct. */
		
		// ESCA-JAVA0078:
		if (num_bin != c.get_num_bins() || min_val != c.get_min_value() || max_val != c.get_max_value()) {
			LB.error("Cannot compare histograms - different sizes.");
			return -1;
		}
		double[] dif = new double[num_bin+1];
		
		
		if (binsize != 1.0) {
			//TODO: make this work.
			LB.error("-control can not currently be run if the bin size (hist_precision) is not one");
			LB.die();
		}
		
		
		LB.notice("Bin\tValue\tsample\tcontrol\tn.control\tdifference");
		for (int i=0; i < num_bin; i++) {
			dif[i] = (s.get_bin_value(i) - (c.get_bin_value(i)*r_avg));
			LB.notice(i + "\t" + ((i*binsize)+ min_val) 
					+ "\t" + s.get_bin_value(i) 
					+ "\t" + c.get_bin_value(i) 
					+ "\t" + Utilities.DecimalPoints((c.get_bin_value(i)*r_avg), 2) 
					+ "\t" + Utilities.DecimalPoints((s.get_bin_value(i) - (c.get_bin_value(i)*r_avg)), 2));
		}
		
	
		if (fp >= 0) {
			int thr = get_threshold(s, c, fp, r_avg);
			LB.notice("Autothreshold for this chromosome is " + thr);
			return thr;
		}
		return -1;
		
	}
	
	
	private static int get_threshold(Histogram s, Histogram c, float fp, double r_avg) {

		for (int x = 2; x < s.get_num_bins(); x++) {
			
			int c_c = c.count_greater_than_value(x);
			int c_s = s.count_greater_than_value(x);
			double p = ((double)c_c /(c_s) * r_avg);
			if (p < fp) {
				return x;
			}
		}	
		return 0;
	}
	

	/**
	 * 
	 * @param ht		the height of the sample.
	 * @param normalize  This is the slope of the line calculated during normalization.
	 * @return
	 */
	public float get_significance(float ht, float normalize) {
		
		
		if (control_peaks == null || sample_peaks == null) {
			LB.error("significance can not be calculated for this ApplyContol Object, since " +
					"both datasets were not initialized.  Please use another initialization " +
					"method for apply control, if you require significance calculations.");
			Thread.dumpStack();
			LB.die();
		}
		//LB.debug("Getting significance for height : "+ ht +"\t control size is " + control_size +"\t sample: " + sample_size);
		int count_control = 1;
		
		//calculate area of tail / area of entire curve.
		//are of tail is the sum of all 
			
		for (int x = 0; x < control_size-1; x++){
			if (control_peaks[x] > (ht * normalize)) {
				count_control++;
			}
		}
		float s = ((float)count_control/control_size);
		return s;
		
	}
	
	
	
}
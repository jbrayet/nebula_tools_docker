package src.lib.objects;


/**
 * @version $Revision: 640 $
 * @author 
 */
public class MAQRyanMap {

	private final String chr;
	private final int start;
	private final int end;
	private final boolean direction;
	private final int fa_coord_fw;						//really redundant
	private final int fa_coord_rv;						//really redundant
	
	// ESCA-JAVA0138:
	public MAQRyanMap (String chr, int st, int end, boolean dir, int fa_st, int fa_end 
			) {
		this.chr = chr;
		this.start = st;
		this.end = end;
		this.direction = dir;
		this.fa_coord_fw = fa_st;				///this should die.
		this.fa_coord_rv = fa_end;				///so should this. 
	}
	
	public String get_chr()				{ return this.chr; }
	public int get_start()				{ return this.start; }
	public int get_end()				{ return this.end; }
	public boolean get_direction() 		{ return this.direction; }
	public int get_fa_coord_st()		{ return this.fa_coord_fw; }
	public int get_fa_coord_end()		{ return this.fa_coord_rv; }


}

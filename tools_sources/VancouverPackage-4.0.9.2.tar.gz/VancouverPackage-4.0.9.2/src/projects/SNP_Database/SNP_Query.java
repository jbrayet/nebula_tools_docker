package src.projects.SNP_Database;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.IterableIterator;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.Error_handling.PSQLInterfaceException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;
import src.projects.SNP_Database.SnpIterators.Generic_SNP_Iterator;
/**
 * example file:
 * /archive/solexa1_4/analysis2/MT0023/meta_maq/302P8AAXX_8.snp
 * 
 *  
 *  NC_002755.2     4378023 T       G       255     114     1.00    63      62      K       22      T
NC_002755.2     4385802 N       G       157     83      1.00    63      62      S       107     C
NC_002755.2     4386614 A       M       36      21      1.00    63      6       A       65      C
NC_002755.2     4390730 G       A       255     117     1.00    63      62      R       33      G
NC_002755.2     4392545 G       A       255     104     1.00    63      62      M       54      C
NC_002755.2     4393168 T       G       255     142     1.00    63      62      N       67      N

 *  
 * @version $Revision: 1586 $
 * @author 
 */
// ESCA-JAVA0100:
public class SNP_Query {	
	
	 /*input variables*/
	private static String input_file;
	private static String output_path;
	private static String psql_file;
	private static String name;
	private static String format;

	
	/*run statistics*/
	
	private SNP_Query() {}
	
	private static Log_Buffer LB = null;
	
	/**
	 * Processing command line arguments for program.
	 * 
	 * @param Variables
	 *            Command line arguments: input path, output path, Species,
	 *            Chromosome(s), min snp percent, min snp observed.
	 */
	private static void parse_input(HashMap<String, String> Variables) {
		if (Variables == null) {
			usage();
		}
		assert (Variables != null);

		if (Variables.containsKey("help")) {
			usage();
		}

		/* Do bootstrap calls here */
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.notice("file names must be supplied with -name flag");
			usage();
		}	
			
		if (Variables.containsKey("output")) {		
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + name  + ".log");
			LB.addLogFile(output_path + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			usage();
		}	
		
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output file name  : " + output_path);		
		LB.notice(" * Name              : " + name);
				
		if (Variables.containsKey("format")) {		
			CommandLine.test_parameter_count_min(LB, "format", Variables.get("format"), 1);
			format= Variables.get("format");
			LB.notice(" * Input format      : " + format);
		} else {
			LB.error("snp file format must be supplied with -format flag");
			usage();
		}

		if (Variables.containsKey("psql")) {
			CommandLine.test_parameter_count(LB, "psql", Variables.get("psql"), 1);
			psql_file = Variables.get("psql");
			LB.notice(" * PSQL config file  : " + psql_file);
		} else {
			LB.error("Must specify psql config file with the -psql flag");
			usage();
		}

		if (Variables.containsKey("input_file")) {
			CommandLine.test_parameter_count(LB, "input_file", Variables.get("input_file"), 1);
			input_file = Variables.get("input_file");
			LB.notice(" * Input file        : " + input_file);
			if (Variables.containsKey("input")) {
				LB.warning("Ignoring -input flag.  Redundant with -input_file flag.");
			}
		} else { 
			LB.error("An input file must be supplied with the -input_file flag" );
			usage();
		}

		/*remove standard ht entries. Then process whatever is left with a warning:*/

		Variables.remove("input_file");
		Variables.remove("format");
		Variables.remove("output");
		Variables.remove("psql");
		Variables.remove("name");
		
		

		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  * " + k);
			}
			LB.die();
		}
	}

	private static void usage() {
		LB.notice("This program requires the following parameters:");
		LB.notice(" -input_file    | <String> | provide the full path to the aligned file.");
		LB.notice(" -output        | <String> | provide a valid path for the output.");
		LB.notice(" -format        | <String> | The format of the Snp file to read.");
		LB.notice(" -name          | <String> | Provides an identifier at the start of each file name.");
		LB.notice(" -conf          | <String> | The location of the configuration file to use.");
		LB.notice(" -psql          | <String> | The location of the psql configuration file to use.");
		LB.die();
	}

	
	/**
	 * Main function for processing Transcriptome data.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables);									//interprets command line args.
		
		new CurrentVersion(LB);
		LB.Version("SNP_Parser", "$Revision: 1586 $");
		
		PSQLInterface.init(LB, psql_file);
		Generic_SNP_Iterator gsi = new Generic_SNP_Iterator(LB, format, input_file);
		ArrayList<SNP> VSNP = new ArrayList<SNP>();
		while (gsi.hasNext()) {
			SNP s = gsi.next();
			VSNP.add(s);
		}	
		String results = null;
		try {
			results = PSQLInterface.search_SNPs(VSNP, "hg18");
		} catch (PSQLInterfaceException e) {
			LB.notice(e.getMessage());
		} 		
		
		LB.notice(results);
		
		LB.close();
	}

}
package src.lib.Error_handling;

/**
 * @version $Revision: 320 $
 * @author 
 *
 */
public class DoesNotMatchException extends Exception {
       
	
	/**
	 * Generated serialVersion.  I have no idea how this works.
	 */
	private static final long serialVersionUID = 1103414336570560499L;

	public DoesNotMatchException(String message) {
		super(message);
	}
	
}

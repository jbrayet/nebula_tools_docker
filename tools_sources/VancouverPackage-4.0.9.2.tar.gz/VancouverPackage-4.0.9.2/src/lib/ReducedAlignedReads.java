package src.lib;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Vector;

import src.lib.Error_handling.DoesNotMatchException;
import src.lib.Error_handling.OverflowException;
import src.lib.ioInterfaces.ElandIterator;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;

import src.lib.objects.AlignedRead;
import src.lib.objects.ReducedAlignedRead;

import src.projects.findPeaks.objects.Parameters;
import src.projects.findPeaks.objects.PeakStats;

// ESCA-JAVA0136:
/**
 * @version $Revision: 1559 $
 * @author 
 */
public class ReducedAlignedReads implements Iterable<AlignedRead>{
	/*CONSTANTS*/
	private static final int INIT_SIZE = 1000000;
	
	/* Array to hold the aligned reads: */
	private ReducedAlignedRead[] sorted_reads;
	private String Chromosome;									//the formal string of a chromosome; 
	private String chr_s;										//what the last chromosome was in the data file;
	private AlignedRead current_read;
	
	private final Log_Buffer LB;
	private static boolean display_version = true;

	/** Generic Iterator to read the AlignedReads*/
	private Generic_AlignRead_Iterator it;

	
	public int get_AlignStart(int a) {
		return this.sorted_reads[a].get_alignStart();
	}
	
	public char get_direction(int a) {
		return this.sorted_reads[a].get_direction();
	}
	
	public int get_AlignEnd(int a) {
		return this.sorted_reads[a].get_alignEnd();
	}
	
	public int get_reads_length() {
		return this.sorted_reads.length;
	}
	
	
	public ReducedAlignedReads(Log_Buffer logbuffer) {
		this.LB = logbuffer;
		if (display_version) {
			LB.Version("ReducedAlignedReads", "$Revision: 1559 $");
			display_version = false;
		}
		this.Chromosome = null;
		this.sorted_reads = null;
		this.current_read = null;
		
	}
	
	public final boolean hasMoreChr() {
		if (this.Chromosome == null) {							//if the chromosome hasn't been initialized yet
			return true;										//then we still want this to be true - it has more
		}														//but hasn't had time to pick up a next read.
		return (current_read == null) ? false : true;
	}

	public Iterator<AlignedRead> iterator() {
	    return this.it.iterator();
	}
	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param aligner
	 * @param chr
	 * @param max_extended_length
	 * @param maq_len the size of the read length in a maq file (128 or 64)
	 * @param qualityfilter the threshold of the quality of read (used only with MAQ)
	 * @param filter filters PET flag, only for use with MAQ
	 * @param max_PET_len 
	 * @return
	 */
	public String process_chromosome(String aligner, String chr,
			int max_extended_length, int qualityfilter, int maq_len,
			String filter, int max_PET_len) {
		LB.notice("Loading: " + chr);	
		String Chr_name = this.loadReducedReads(aligner, chr,
				max_extended_length, qualityfilter, maq_len, filter,
				max_PET_len);	
		return Chr_name;
	}

	/**
	 * SET method used to find the last read in a "cluster of reads".
	 * @param i
	 * @param max_extended_length
	 * @return index of last read in the area of enrichment
	 */
	public int find_peak_last_read(int i, int max_extended_length) {
		if (i == this.sorted_reads.length - 1) {
			return i;
		}
		while ((i + 1 < this.sorted_reads.length)
				&& ((this.sorted_reads[i].get_alignStart() + max_extended_length - 1) 
						>= this.sorted_reads[i + 1].get_alignStart())) {
			i++;
		}
		return i;
	}
	
	
	/**
	 * PET version of method to find last read. 
	 * @param i
	 * @return index of last read in the area of enrichment
	 */
	public int find_peak_last_read_PET(int i) {
		if (i == this.sorted_reads.length - 1) {
			return i;
		}
		int greatest_end = this.sorted_reads[i].get_alignEnd();
		while ((i + 1 < this.sorted_reads.length)
				&& (greatest_end >= this.sorted_reads[i + 1].get_alignStart())) {
			i++;												//increment i - move to next read
			if (greatest_end < this.sorted_reads[i].get_alignEnd()) {		//if the next read has an end greater than 
				greatest_end = this.sorted_reads[i].get_alignEnd();			//the last, use that, otherwise, keep using 
			}																//the greatest end encountered so far.
		}
		return i;
	}
	

	/**
	 * Gets the coverage over a chromosome or contig.
	 * @param extension_length
	 * @return
	 */
	public int find_coverage(int extension_length) {
		int coverage = 0;
		int i = 0;
		while (i < this.sorted_reads.length) {
			int LastHit = find_peak_last_read(i, extension_length);
			coverage += (sorted_reads[LastHit].get_alignStart() + extension_length) - sorted_reads[i].get_alignStart();
			i= LastHit + 1;
		}
		return coverage;
	}

	/**
	 * Code to count duplicate tags in data set - Uses sorted data to find the
	 * full number of tags. **Assumes data is sorted in correct order**
	 * 
	 * @param unfiltered
	 * @return array of AlignedReads filtered to remove duplicates
	 */
	public static ReducedAlignedRead[] filterDuplicateTags(ReducedAlignedRead[] unfiltered) {
		/*use a vector so that we can add an indeterminate number of objects into it.*/
		Vector<ReducedAlignedRead> filtered = new Vector<ReducedAlignedRead>();
		for (int x = 0; x < unfiltered.length - 1; x++) {
			if (unfiltered[x].get_alignStart() != unfiltered[x + 1].get_alignStart()) {
				ReducedAlignedRead cp = new ReducedAlignedRead();
				cp = unfiltered[x];
				filtered.add(cp);
			} else {
				if (unfiltered[x].get_direction() != unfiltered[x + 1].get_direction()) {
					ReducedAlignedRead cp = new ReducedAlignedRead();
					cp = unfiltered[x];
					filtered.add(cp);
				}
			}
		}
		/*
		 * You must always add the last record. If it's not a repeat, it won't
		 * have been added above, and if it is a repeat, the ones before it
		 * won't have been added.
		 */
		filtered.add(unfiltered[unfiltered.length - 1]);		// convert back to an array
		
		ReducedAlignedRead[] filter_reads = new ReducedAlignedRead[filtered.size()];
		filter_reads = filtered.toArray(filter_reads);
		return filter_reads;
	} 
	
	
	/**
	 * Since FindPeaks always uses starts to determine the location of the
	 * fragment, even when it's on the reverse strand, changing the fragment
	 * length will necessitate changing the start position of all reverse strand
	 * reads. This function automates that process.
	 * 
	 * @param max_length
	 */
	public void adjust_starts(int max_length) {
		for (int a = 0; a < this.sorted_reads.length; a++) {
			if (this.sorted_reads[a].get_direction() == '-') {
				this.sorted_reads[a].set_alignStart((this.sorted_reads[a].get_alignEnd() + 1) - (max_length - 1));
				this.sorted_reads[a].set_sort_score((double)this.sorted_reads[a].get_alignStart());
			}
		}
		Arrays.sort(this.sorted_reads);
	}
	
	/**
	 * This function takes in an AlignedRead Object and strips it down to a
	 * Reduced Algined Read. This provides a major memory saving for
	 * applications that only need a small amount of information, and don't
	 * retain the sequence of the reads.
	 * 
	 * @param a
	 * @param max_length
	 * @return
	 */
	private static ReducedAlignedRead Reduce_alignread(AlignedRead a, int max_length) {
		ReducedAlignedRead RAR = new ReducedAlignedRead(
				a.get_direction(), a.get_alignStart(),
				a.get_alignEnd(), a.get_sort_score()); 
	
		if (RAR.get_direction() == '-') {
			if (max_length != 0) {  		//when you're in mode 3, you don't have a max_length, so 
				RAR.set_alignStart(RAR.get_alignEnd() - (max_length - 1));		//we will only do this when we
				RAR.set_alignEnd(RAR.get_alignEnd()-1);							//have a max_length value
			}
			if (RAR.get_alignStart() < 0 || RAR.get_alignEnd() < 0) {
				return null;
			}
		}
		/*	set the sort_score, so it will be inherited by all clones*/
		RAR.set_sort_score( (double) -RAR.get_alignStart());
		return RAR;
	}

	/**
	 * Each Iterator requires a different non-generic object to be able to use
	 * the .close() routine, so this function will open up whatever iterator is
	 * required, and then pass the generic iterator interface so that it can be
	 * read. Reduced duplication of code.
	 * 
	 * @param aligner
	 * @param st
	 * @param file
	 * @param qualityfilter
	 *            the threshold of the quality of read (used only with MAQ)
	 * @param read_len
	 *            maq read len, default to 128 for version >0.7.1, otherwise 64.
	 * @param filter
	 *            PET flag filter for MAQ only.
	 * @param max_PET_len
	 *            if the fragment length is longer than this, throw away the
	 *            read. (If no length is set, it should be zero.)
	 * @return
	 */
	private Generic_AlignRead_Iterator get_Iterator(String aligner, String st,
			String file, int qualityfilter, int read_len, String filter, int max_PET_len) {
		
		if (it == null) {
			it = new Generic_AlignRead_Iterator(LB, aligner, st, file, qualityfilter, read_len, filter, max_PET_len,false);
		}
		return it;
	}
	
	
	/**
	 * This program uses any iterator that produces an Aligned Read object, and
	 * then strips it down into a Reduced Aligned Read, used by FindPeaks.
	 * 
	 * @param aligner
	 * @param file
	 * @param max_length
	 * @param qualityfilter the threshold of the quality of read (used only with MAQ)
	 * @param maq_len default to 128 for version 0.7.1, otherwise 64
	 * @param filter filters PET tag, only for use with maq
	 * @param max_PET_len
	 * @return
	 */
	public Vector<ReducedAlignedRead> GetReducedReads(String aligner, String file, int max_length,
			int qualityfilter, int maq_len, String filter, int max_PET_len) {
		Vector<ReducedAlignedRead> live_len_hits = new Vector<ReducedAlignedRead>(INIT_SIZE);
		//This allocation is not necessary and is done only for clarity.
		it = get_Iterator(aligner, "source", file, qualityfilter, maq_len,
				filter, max_PET_len); // gets the right iterator, but only inits it if null
		
		if (current_read != null ) {								//process first read of the new chromosome.
			this.chr_s = current_read.get_chromosome();
			this.Chromosome = Utilities.translate_Current_Chromosome(this.chr_s);
			LB.notice("Now processing Chromosome: " + this.Chromosome);
			ReducedAlignedRead RAR = Reduce_alignread(current_read, max_length);
			if (RAR != null) {
				live_len_hits.add(RAR);
			}
			//Doesn't have a first read we are at the beginning of the file need to initialize
		} else {												//Bootstrap
			if (it.hasNext() ) {
				try {
					current_read = it.next();
					this.chr_s = current_read.get_chromosome();
					this.Chromosome = Utilities.translate_Current_Chromosome(this.chr_s);
					LB.notice("Now processing Chromosome: " + this.Chromosome);
					ReducedAlignedRead RAR = Reduce_alignread(current_read, max_length);
					live_len_hits.add(RAR); //removed null check in favour of NoSuchElementException
				} catch (NoSuchElementException nsee) {
					//don't need to do anything here - this just means MAQ last element has been found.
				}
				
			} else {											//can't read record #1
				LB.error("Can't read first line of input file");
			}
		}
		
		boolean keep_going = true;
		while (it.hasNext() && keep_going) {
			try {
				current_read = it.next();
			} catch (NoSuchElementException nsee) {
				keep_going = false;
				continue;
			}
			if (this.chr_s.equals(current_read.get_chromosome())) {
				ReducedAlignedRead RAR = Reduce_alignread(current_read, max_length);
				if (RAR != null) {
					live_len_hits.add(RAR);
				}
			} else {
				keep_going = false;
			}
		} 
		if (!it.hasNext()) {
			current_read = null;
			it.close();
			it = null;		//this must be set to null, as .close only sets the interior it value to null.
		}
		return live_len_hits;
	}
	

	/**
	 * Loads the reads into a vector for each sequence in the database.  Depending
	 * on what type of object is returned for each iterator, a different
	 * function is used. Most of them return an AlignedRead object, so they can
	 * all use a common function.
	 * 
	 * @param aligner
	 * @param file
	 * @param max_length
	 * @param qualityfilter the threshold of the quality of read (used only with MAQ)
	 * @param maq_len
	 * @param filter
	 * @param max_PET_len
	 * @return
	 */
	public String loadReducedReads(String aligner, String file, int max_length,
			int qualityfilter, int maq_len, String filter, int max_PET_len) {
		Vector<ReducedAlignedRead> Reads = null;				
		LB.notice("Loading tags :");								
		Reads = GetReducedReads(aligner, file, max_length, qualityfilter, maq_len, filter, max_PET_len);

		/*convert to array and sort.*/
		this.sorted_reads = new ReducedAlignedRead[Reads.size()];
		this.sorted_reads = Reads.toArray(this.sorted_reads);
		Reads.clear();
		try {
			Arrays.sort(this.sorted_reads);
		} catch (NullPointerException npe) {
			LB.error("Null Pointer Exception caught while sorting reads.  This is likely to have happened because of "
					+ "an error in the creation of the .map file being imported.  Please verify that all combined lanes"
					+ "came from the same version of Maq, and that the appropriate -maq_read_size variable is used");
		}
		return this.Chromosome;
	}
	
	/**
	 * @param LB
	 * @param elandfile
	 * @param chr
	 * @param Const
	 * @param current_chromosome
	 * @return
	 */
	public static int LoadElandReads(Log_Buffer LB, String elandfile, Chromosome chr, Ensembl Const, int current_chromosome) {
		int read_count = 0;
		int fail_count = 0;
		boolean success = false;
		LB.notice("Loading Reads...                                                      ");
		
		ElandIterator ei = new ElandIterator(LB, "source", elandfile, 0);
		while (ei.hasNext()) {
			AlignedRead alnrd = ei.next();
			try {
				success = chr.addHitRawBaseCount(alnrd, 1, true);
			} catch (DoesNotMatchException e) {
				LB.warning("Failed to Parse Eland Read: " + e.getMessage());
				LB.warning(alnrd.toString());
				success = false;
			} catch (OverflowException e) {
				LB.warning(e.getMessage());
				LB.warning(alnrd.toString());
				success = false;
			}
			if (success) {
				read_count++;
			} else {
				fail_count++;
			}
		}
		ei.close(false);
		LB.notice("Done");
		LB.notice("Chromosome "
				+ Const.get_chromosome(current_chromosome) + " Reads passed: "
				+ read_count + " Reads Failed: " + fail_count);
		return read_count;
	}
	
	/**
	 * @param LB
	 * @param elandfile
	 * @param chr
	 * @param Const
	 * @param current_chromosome
	 * @return
	 */
	public static int LoadElandReads(Log_Buffer LB, String elandfile, Chromosome chr, ConstantsFile Const, int current_chromosome) {
		int read_count = 0;
		int fail_count = 0;
		boolean success = false;
		LB.notice("Loading Reads...                                                      ");
		
		ElandIterator ei = new ElandIterator(LB, "source", elandfile, 0);
		while (ei.hasNext()) {
			AlignedRead alnrd = ei.next();
			try {
				success = chr.addHitRawBaseCount(alnrd, 1, true);
			} catch (DoesNotMatchException e) {
				LB.warning("Failed to Parse Eland Read: " + e.getMessage());
				LB.warning(alnrd.toString());
				success = false;
			} catch (OverflowException e) {
				LB.warning(e.getMessage());
				LB.warning(alnrd.toString());
				success = false;
			}
			if (success) {
				read_count++;
			} else {
				fail_count++;
			}
		}
		ei.close(false);
		LB.notice("Done");
		LB.notice("Chromosome "
				+ Const.get_chromosome(current_chromosome) + " Reads passed: "
				+ read_count + " Reads Failed: " + fail_count);
		return read_count;
	}
	
	
	public void destroy() {
		this.sorted_reads = null;
		this.Chromosome = null;									//the formal string of a chromosome; 
		this.chr_s = null;										//what the last chromosome was in the data file;
		this.current_read = null;
	}
	
	
	public void Generate_Random_Reads(PeakStats[] chr_pkstats, int i,
			PeakStats obs_pkstats, Parameters param, int batch_size, int chr_size) {
		//Generate the random reads to fit the coverage of peak
		Random generator = new Random();
		int b = 0;
		Vector<ReducedAlignedRead> dataset = new Vector<ReducedAlignedRead>();
		while (chr_pkstats[i].get_coverage() < obs_pkstats.get_coverage()) 
		{	
			b++;
			for (int x = 0; x < batch_size; x++) {
				int start = (generator.nextInt(chr_size) + 1);
				dataset.add(new ReducedAlignedRead(
						(generator.nextBoolean() ? '+' : '-'),
						start,start + param.get_max_len(),-start));  
			}
			this.sorted_reads = new ReducedAlignedRead[dataset.size()];
			this.sorted_reads = dataset.toArray(this.sorted_reads);
			
			dataset.clear();
			//need to have the read sorted to calculate the coverage of the random reads.
			Arrays.sort(this.sorted_reads);
			dataset = new Vector<ReducedAlignedRead>(Arrays.asList(this.sorted_reads));
		}
		
	}
	
	/*public ReducedAlignedReads subsample(float fraction) {
		
		int total = (int)(fraction * this.sorted_reads.length);
		ReducedAlignedReads rar = new ReducedAlignedReads(LB);
		
		return rar;
	}
	*/

	
}

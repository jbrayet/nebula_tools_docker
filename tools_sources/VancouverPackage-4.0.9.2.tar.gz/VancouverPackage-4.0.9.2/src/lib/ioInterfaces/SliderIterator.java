package src.lib.ioInterfaces;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import org.ensembl.datamodel.Location;

import src.lib.Constants;
import src.lib.objects.SliderSNP;

/**
 * @version $Revision: 735 $
 * @author 
 */
public class SliderIterator implements Iterator<SliderSNP>  {
	private static boolean display_version = true;
	private static Log_Buffer LB;
	
	String Name = null;
	BufferedReader br = null;
	int linecount = 0;
	int UXcnt = 0;

	public SliderIterator(Log_Buffer logbuffer, String Name, String source_file) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("SliderIterator", "$Revision: 735 $");
			display_version = false;
		}
		this.Name = Name;
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else {
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (FileNotFoundException io) {
			LB.error("Can't find file " + source_file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		try {
			// temporarily deal with 4 or 5 header lines of Nawar's output file
			br.readLine();
			br.readLine();
			br.readLine();
			br.readLine();
			br.readLine();
		} catch (IOException io) {
			LB.error("can't get past header of Slider iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public void close() {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file - continuing.");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		LB.notice("--- " + this.Name + " ---");
		LB.notice("Processed " + this.linecount + " records");
		LB.notice("Ux records : " + this.UXcnt);
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}
	
	/*
	
        New format:
	header: 	U0	sc	U1	score	ref	da	pA	pC	pG	pT	
	7424477	0	0	1	1.17	G	T	0	0	0	99.97
	7428553	0	0	1	1.2		T	C	0	99.97	0	0

	New format:  will require a complete rewrite.
	SNPid   address map     m0Count m1Count SNP%    Score0  Score1  Ref     MPB     P(A)    P(C)    P(G)    P(T)
	---------------------------------------------------------------
	0       6220    64      0       1       100.0%  0.0     1.14    C       G       0.0     0.0     99.97   0.0
	1       8025    64      0       1       100.0%  0.0     1.2     A       G       0.0     0.0     99.97   0.0
	2       8880    64      0       1       100.0%  0.0     1.17    T       G       0.0     0.0     99.97   0.0
	
	April 2008 format
	SNPid   Location map   cmCount mCount  nmCount  wSNP%   cSNP%   ncSNP%  cmScore nmScore1Ref     MPB     
																Pm(A)   Pm(C)   Pm(G)   Pm(T)   Pnm(A)  Pnm(C)  Pnm(G)  Pnm(T)
	-----   -----   -----   -----   -----   -----   -----   -----   -----   -----   -----   -----   -----   
																-----   -----   -----   -----   -----   -----
	0       939     64      36      1       36      50.44%  50.0%   0.32%   31.87   32.45   A       T       
																98.11   1.56    0.01    0.31    0.0     0.0     0.05    99.92
	1       11302   64      3       3       3       55.64%  50.0%   66.82%  2.2     2.75    G       T       
																0.0     0.01    33.16   66.8    0.0     0.01    0.0     99.96
	2       59774   64      4       0       2       40.15%  33.33%  0.0%    2.25    1.5     A       G       
																0.0     0.0     0.0     0.0     0.0     0.02    99.95   0.0
	3       128053  64      3       2       2       44.01%  40.0%   36.54%  1.87    1.47    G       T       
																0.0     0.0     63.44   36.53   0.0     0.0     0.01    99.96
	
	*/


	/**
	 * @return SliderSNP
	 */
	public SliderSNP next() {
		String line = null;
//		System.out.println("help!");
		
		
		try {
			if ((line = br.readLine()) != null) {
				this.linecount++;
				StringTokenizer st = new StringTokenizer(line, "\t");
				SliderSNP ns = new SliderSNP(
				/*ns.set_SNPid*/ 		Integer.valueOf(st.nextToken()),
				/*ns.set_position	*/	Integer.valueOf(st.nextToken()),
				/*ns.set_mapability*/	Integer.valueOf(st.nextToken()),
				/*ns.set_u0count*/		Integer.valueOf(st.nextToken()),
				/*ns.set_uncount	*/	Integer.valueOf(st.nextToken()),
				/*ns.set_u1count*/		Integer.valueOf(st.nextToken()),
				/*ns.set_wSNP_per*/		st.nextToken().charAt(0),
				/*ns.set_cSNP_per*/		st.nextToken().charAt(0),
				/*ns.set_ncSNP_per*/	st.nextToken().charAt(0),
				/*ns.set_cmScore*/		Float.valueOf(st.nextToken()),
				/*ns.set_nmScore*/		Float.valueOf(st.nextToken()),
				/*ns.set_ref*/			st.nextToken().charAt(0),
				/*ns.set_obs*/			st.nextToken().charAt(0),
				/*ns.set_PmA*/			Float.valueOf(st.nextToken()),
				/*ns.set_PmC*/			Float.valueOf(st.nextToken()),
				/*ns.set_PmG*/			Float.valueOf(st.nextToken()),
				/*ns.set_PmT*/			Float.valueOf(st.nextToken()),
				/*ns.set_PmA*/			Float.valueOf(st.nextToken()),
				/*ns.set_PmC*/			Float.valueOf(st.nextToken()),
				/*ns.set_PmG*/			Float.valueOf(st.nextToken()),
				/*ns.set_PmT*/			Float.valueOf(st.nextToken()));
								
				
				/*StringTokenizer st = new StringTokenizer(line, "\t");
				ns.SNPid		= Integer.valueOf(st.nextToken());
				ns.position 	= Integer.valueOf(st.nextToken());
				ns.mapability 	= Integer.valueOf(st.nextToken());
				ns.u0count		= Integer.valueOf(st.nextToken());
				ns.uncount		= Integer.valueOf(st.nextToken());
				ns.u1count		= Integer.valueOf(st.nextToken());
				ns.SNP_per		= st.nextToken().charAt(0);
				ns.score0	 	= Float.valueOf(st.nextToken());
				ns.score1		= Float.valueOf(st.nextToken());
				ns.ref			= st.nextToken().charAt(0);
				ns.obs			= st.nextToken().charAt(0);
				ns.A		 	= Float.valueOf(st.nextToken());
				ns.C		 	= Float.valueOf(st.nextToken());
				ns.G		 	= Float.valueOf(st.nextToken());
				ns.T		 	= Float.valueOf(st.nextToken());
				*/
				
				//StringTokenizer st = new StringTokenizer(line, "\t");
				/*
				ns.SNPid		= Integer.valueOf(st.nextToken());
				ns.position 	= Integer.valueOf(st.nextToken());
				ns.u0count		= Integer.valueOf(st.nextToken());
				ns.u1count		= Integer.valueOf(st.nextToken());
				ns.score	 	= Float.valueOf(st.nextToken());
				ns.ref			= st.nextToken().charAt(0);
				ns.obs			= st.nextToken().charAt(0);
				ns.A		 	= Float.valueOf(st.nextToken());
				ns.C		 	= Float.valueOf(st.nextToken());
				ns.G		 	= Float.valueOf(st.nextToken());
				ns.T		 	= Float.valueOf(st.nextToken());
				//*/
				return ns;
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
			}
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		throw new NoSuchElementException("Could not get any more reads.");
	}
	
	
	//TODO: needs a real chromosome.
	/**
	 * @param ns
	 * @return Location
	 */
	public static final Location get_location(SliderSNP ns) {
		return new Location("chromosome", "1" , ns.get_position()+1, ns.get_position()+1);
	}

}

		

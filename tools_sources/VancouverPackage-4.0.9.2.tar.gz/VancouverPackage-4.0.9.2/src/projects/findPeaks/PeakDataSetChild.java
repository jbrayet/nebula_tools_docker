package src.projects.findPeaks;

import java.util.Vector;

import src.lib.Coverage;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.AlignedRead;
import src.lib.objects.Tuple;

import src.projects.findPeaks.objects.MinPeakDesc;
import src.projects.findPeaks.objects.Parameters;
import src.projects.findPeaks.objects.SaturationDataHolder;

// ESCA-JAVA0100:
// ESCA-JAVA0136:
/**
 * @version $Revision: 1830 $
 * @author 
 */
public class PeakDataSetChild implements Runnable{
	
	private static Log_Buffer LB; 
	private float threshold;
	private int iteration;
	private int reads_used;
	private final SaturationDataHolder store;
	private Parameters param;
	private Distribution dist;
	private boolean terminate = false;
	private Vector<float[]> rand_set = new Vector<float[]>(); ;
	private Vector<AlignedRead[]> buffer = new Vector<AlignedRead[]>();
	private Object buffer_flag = new Object();
	
	
	
	/**
	 * 
	 */
	// ESCA-JAVA0266:
	public void run() {
		while (!terminate) {
			try {
				synchronized (buffer_flag) {
					buffer_flag.wait();
				}
			} catch (InterruptedException e) {
				System.out.println("Something went bad in the wait state.");
				System.out.println(e.getMessage());
			}
			clear_buffer();
		}
		shutdown();
	}


	// ESCA-JAVA0138:
	public PeakDataSetChild(Log_Buffer logbuffer, SaturationDataHolder store,
			Parameters param, Distribution dist, float value, int iteration) {
		LB = logbuffer;
		this.param = param;
		this.dist = dist;
		this.threshold = value;
		this.iteration = iteration;
		this.reads_used = 0;
		this.store = store;
	}
		
	private void clear_buffer() {
		
		while (!buffer.isEmpty()) {			
			float[] rnd = null;
			AlignedRead[] reads = null;
			synchronized (buffer_flag) {
				rnd = rand_set.remove(0);
				reads = buffer.remove(0);
			}
			if (dist.get_dist_type() == 3) {
				process_peaks_PET(reads, rnd);
			} else {
				process_peaks(reads, rnd);
			}
		}
	}
	

	
	public boolean close() {
		LB.notice("Reads used by child (threshold " + this.threshold + "): " + this.reads_used);
		this.store.process_reads_used(this.reads_used, this.threshold, this.iteration);
		this.terminate = true;
		synchronized (buffer_flag) {
			buffer_flag.notifyAll();
		}
		return true;
		
	}
	
	private void shutdown() {
		clear_buffer();
		this.store.signal_complete();
	}
	
	
	public void receive_arrays(AlignedRead[] read_set, float[] random_vars) {
		synchronized (buffer_flag) {
			rand_set.add(random_vars);
			buffer.add(read_set);
			buffer_flag.notifyAll();
		}
	}
	
	
	
	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param read_set
	 * @param rnd_set
	 * @param ar_pos
	 * @param max_length
	 * @param cur_peak_end
	 * @param overlap_farenough
	 * @return 				position of next read that is to be used.  Returns a -1 if no more reads, or not in overlap
	 */
	private int next_overlap_read(AlignedRead[] read_set, float[] rnd_set, int ar_pos, 
			int max_length,	int cur_peak_end, Boolean[] overlap_farenough) {
		
		while (ar_pos < read_set.length && rnd_set[ar_pos] > this.threshold ) {
			ar_pos++;
		}
		if (ar_pos >= read_set.length ) {
			overlap_farenough[1] = true;
			return -1;
		}
		AlignedRead ar_tmp= read_set[ar_pos]; 
		if (ar_tmp.get_direction() == '+')  {
			if (ar_tmp.get_alignStart()- cur_peak_end > max_length) {
				overlap_farenough[1] =  true;
				return -1;
			} else if (ar_tmp.get_alignStart() <= cur_peak_end) {
				overlap_farenough[0] = true;		//returns the next "good" peak.
			}
		} else {  // negative strand - these are the ones we have to "worry about"
			if (ar_tmp.get_alignEnd() - max_length <= cur_peak_end) {
				overlap_farenough[0] = true;
			} else if (ar_tmp.get_alignEnd() > max_length + cur_peak_end) {
				overlap_farenough[1] = true;
				return -1;
			}
		}
		return ar_pos;
	}

	
	private int next_overlap_read_PET(AlignedRead[] read_set, float[] rnd_set, int ar_pos,
			int cur_peak_end, Boolean[] overlap_farenough) {
		while (ar_pos < read_set.length && rnd_set[ar_pos] > this.threshold ) {
			ar_pos++;
		}
		if (ar_pos >= read_set.length ) {
			overlap_farenough[1] = true;
			return -1;
		}
		AlignedRead ar_tmp= read_set[ar_pos];
		
		if (ar_tmp.get_alignStart() <= cur_peak_end) { 
			overlap_farenough[0] = true;
		} else if (ar_tmp.get_alignStart() - cur_peak_end > PeakDataSetParent.WINDOW_SIZE) {
			overlap_farenough[1] = true;
			return -1;
		}
		return ar_pos;
	}
	
	
	
	// ESCA-JAVA0138:
	/**
	 * 
	 * @param cur_reads
	 * @param param
	 * @param dist
	 * @param cur_peak_start
	 * @param cur_peak_end
	 * @param subpeaks
	 * @return
	 */
	private static Vector<MinPeakDesc> process_int_based(Vector<AlignedRead> cur_reads,
			Parameters param, Distribution dist, int cur_peak_start,
			int cur_peak_end, boolean subpeaks) {
			int[] coverage_array = Coverage.generatePeakHeight_ld_int(cur_reads, dist, cur_peak_start, cur_peak_end);
			return PeakLocatorSaturation.process(LB, param, coverage_array,	//generate the peak description
						cur_peak_start, cur_peak_end, subpeaks);
	}
	
	
	private static Vector<MinPeakDesc> process_float_based(Vector<AlignedRead> cur_reads, Parameters param,
			Distribution dist, int cur_peak_start, int cur_peak_end,
			boolean subpeaks) {
		float[] coverage_array = Coverage.generatePeakHeight_ld_float(cur_reads, dist, cur_peak_start, cur_peak_end); 
		return PeakLocatorSaturation.process(LB, param, coverage_array,	//generate the peak description
					cur_peak_start, cur_peak_end, subpeaks); 
		
	}


	/**
	 *  Peak Locator - will be the new peak locator for FindPeaks 4.0
	 * @param read_set
	 * @param rnd_set
	 */
	public void process_peaks(AlignedRead[] read_set, float[] rnd_set) {

		int cur_peak_start = 0;
		int cur_peak_end = 0;
		int reads_filtered = 0;
		
		Vector<AlignedRead> cur_reads = new Vector<AlignedRead>(0);
		int frag_start = 0;
		int frag_end  = 0;
		
		boolean subpeaks = 			this.param.get_subpeaks();
		boolean filter = 			this.param.get_filterDupes();
		AlignedRead ar = null;
		Vector<Integer> local_buffer = new Vector<Integer>();
		
		int max_length = this.dist.get_max_ext_len() -1 ; //max_ext_len is zero based.
		
		int ar_pos = 0; 
		
		
		
		while (ar_pos < read_set.length) {
			while (ar_pos < read_set.length && rnd_set[ar_pos] > this.threshold ) {
				ar_pos++;
				if (ar_pos >= read_set.length) {
					return;
				}
			}
			ar=read_set[ar_pos];
			ar_pos++;
			if (ar.get_direction() == '+') {
				cur_peak_start = ar.get_alignStart();
				cur_peak_end = ar.get_alignStart() + max_length;
			} else {
				cur_peak_start = ar.get_alignEnd() - max_length;
				cur_peak_end = ar.get_alignEnd();
			}
			cur_reads.add(ar);
		
			Boolean[] overlap_farenough = new Boolean[2]; 	//overlap and far_enough
			overlap_farenough[0] = false;
			overlap_farenough[1] = false;
			int ar_lastunused_pos = ar_pos;
			while (!overlap_farenough[1] && ar_pos < read_set.length){
				int nxt_gd_rd = next_overlap_read(read_set, rnd_set, ar_pos, max_length, cur_peak_end, overlap_farenough);
				if (nxt_gd_rd != -1) {
					local_buffer.add(nxt_gd_rd);
					ar_pos = (nxt_gd_rd + 1);
				}
				if (overlap_farenough[0]) {   				//if overlaps
					for (int i: local_buffer) {				//Adding read from local buffer
						AlignedRead a = read_set[i];									
						frag_start = (a.get_direction() == '+') ? a.get_alignStart() : a.get_alignEnd() - max_length;  
						frag_end   = (a.get_direction() == '+') ? a.get_alignStart() + max_length : a.get_alignEnd();
						cur_peak_end = (frag_end > cur_peak_end) ? frag_end : cur_peak_end;
						cur_peak_start = (frag_start < cur_peak_start) ? frag_start : cur_peak_start;
						ar_lastunused_pos = ar_pos;
						cur_reads.add(a);
					}
					local_buffer.clear();
				} else if (overlap_farenough[1]) {			//went far enough
					ar_pos = ar_lastunused_pos;				//Local buffer cleared and setting ar_pos bacK
					local_buffer.clear();
				}
			}
			if (filter) {									//filter duplicates
				int filtered_reads = cur_reads.size();
				cur_reads = DuplicateFiltering.simplefilter(cur_reads);
				filtered_reads -= cur_reads.size();
				reads_filtered += filtered_reads;
			}
			
			Tuple<Integer,Integer> LW = new Tuple<Integer,Integer>(0,0);
			if (cur_reads.size() == 1) {					//LanderWaterman Stats
				LW.set_first(1);
			} else if (cur_reads.size() == 2) {
				LW.set_second(1);
			}				

			
			if (this.dist.intbased()) {						//Get the profile for the peak - store into Hashmap of int[]/float[]
				Vector<MinPeakDesc> a = process_int_based(cur_reads, param, dist, cur_peak_start, cur_peak_end, subpeaks);
				if (a.size() > 0) {
					this.store.new_peak(a, this.threshold, this.iteration, LW);
				}
			} else {
				Vector<MinPeakDesc> a = process_float_based(cur_reads, param, dist, cur_peak_start, cur_peak_end, subpeaks);
				if (a.size() > 0) {
					this.store.new_peak(a, this.threshold, this.iteration, LW);
				}
			}
			this.reads_used += cur_reads.size();
			cur_reads.clear(); 

			if (local_buffer.size() > 0) {					//clearing local buffer
				ar_pos = ar_lastunused_pos;
				local_buffer.clear();					
			}			
		}		
	}

	
	/**
	 *  Peak Locator - will be the new peak locator for FindPeaks 4.0
	 * @param read_set
	 * @param rnd_set
	 */
	private void process_peaks_PET(AlignedRead[] read_set, float[] rnd_set) {
		
		int cur_peak_start = 0;
		int cur_peak_end = 0;
		
		Vector<AlignedRead> cur_reads = new Vector<AlignedRead>(0);
		int frag_start = 0;
		int frag_end  = 0;
		
		
		AlignedRead ar = null;
		Vector<Integer> local_buffer = new Vector<Integer>();
		int ar_pos = 0;
		
		while (ar_pos < read_set.length) {
			while (ar_pos < read_set.length && rnd_set[ar_pos] > this.threshold ) {
				ar_pos++;
				if (ar_pos >= read_set.length) {
					return;
				}
			}
			ar=read_set[ar_pos];
			ar_pos++;
		
			cur_peak_start = ar.get_alignStart();
			cur_peak_end = ar.get_alignEnd();
			cur_reads.add(ar);
			
			Boolean[] overlap_farenough = new Boolean[2]; //overlap and far_enough
			overlap_farenough[0] = false;
			overlap_farenough[1] = false;
			int ar_lastunused_pos = ar_pos; 
			while (!overlap_farenough[1] && ar_pos < read_set.length){
				int nxt_gd_rd = next_overlap_read_PET(read_set, rnd_set, ar_pos, cur_peak_end, overlap_farenough);
				if (nxt_gd_rd != -1) {
					local_buffer.add(nxt_gd_rd);
					ar_pos = (nxt_gd_rd + 1);
				}
				if (overlap_farenough[0]) {
					for (int i : local_buffer) {
						AlignedRead a = read_set[i];
						frag_start = a.get_alignStart();
						frag_end = a.get_alignEnd();
						cur_peak_end = (frag_end > cur_peak_end) ? frag_end : cur_peak_end; 	
						cur_peak_start = (frag_start < cur_peak_start) ? frag_start : cur_peak_start; 
						ar_lastunused_pos = ar_pos;
						cur_reads.add(a);
					}
					local_buffer.clear();
				} else if (overlap_farenough[1]) {
					ar_lastunused_pos = ar_pos;
					local_buffer.clear();
				} 
			}
			process_far_enough(cur_reads, cur_peak_start, cur_peak_end);
			if (local_buffer.size() > 0) {
				ar_pos = ar_lastunused_pos;
				local_buffer.clear();
			}
		}
	}

	private void process_far_enough(Vector<AlignedRead> cur_reads, int cur_peak_start, int cur_peak_end) {
		boolean subpeaks = 			this.param.get_subpeaks();
		boolean filter = 			this.param.get_filterDupes();
		
		if (filter) {						//filter duplicates
			cur_reads = DuplicateFiltering.simplefilter(cur_reads);
		}			
		/*Get the profile for the peak - store into Hashmap of int[]*/
		int[] coverage_array = Coverage.generatePeakHeight_PET(cur_reads, cur_peak_start, cur_peak_end);
		Vector<MinPeakDesc> a = PeakLocatorSaturation.process(LB, param, 	//generate the peak description
				coverage_array, cur_peak_start, cur_peak_end, subpeaks);
		
		Tuple<Integer, Integer> LW = new Tuple<Integer,Integer>(0,0);
		if (cur_reads.size() == 1) {		//LanderWaterman Stats
			LW.set_first(1);
		} else if (cur_reads.size() == 2) {
			LW.set_second(1);
		}	
		
		if (a.size() > 0) {
			this.store.new_peak(a, this.threshold, this.iteration, LW);
		}
		this.reads_used  += cur_reads.size();
		cur_reads.clear();		
	}
	
	
	
	
}

package src.projects.SNP_Database.SnpIterators;

import java.util.Iterator;

import src.lib.objects.SNP;

/**
 * AligneReadsIterator is an Iterator that also contain a File reader.
 * It can read alignedreads from different alignment formats.
 * @author tcezard
 * @version $Revision: 1444 $
 *
 */
public interface SNPIterator extends Iterator<SNP>
{
	/**
	 * Close the file reader and other specific stuff.
	 * @param verbose
	 */
	void close(boolean verbose);
	
}

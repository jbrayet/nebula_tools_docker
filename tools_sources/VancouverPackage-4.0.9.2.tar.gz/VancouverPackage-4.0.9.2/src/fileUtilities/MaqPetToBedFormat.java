package src.fileUtilities;


import java.util.Collection;
import java.util.HashMap;
import java.util.NoSuchElementException;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.Histogram;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.Bedwriter;
import src.lib.ioInterfaces.FileOut;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.MAQmapIterator;
import src.lib.objects.AlignedRead;
import src.lib.objects.SETLocation;

/**
 * @version $Revision: 1581 $
 * @author 
 *
 */
public class MaqPetToBedFormat {
	private static final String Forward = "/1";
	private static final String Reverse = "/2";
	private static final int trim_f = Forward.length();  //length of "_forward" and "_reverse";
	//private static final int trim_r = Reverse.length();  //length of "_forward" and "_reverse";
	
	
	private static final int LINE_DARKNESS = 1000;
	private static final int FULL_COLOUR = 255;
	private static final int OUTPUT_FREQ = 1000000;
	private static final int DEFAULT_HIST_SIZE = 1000;
	
	private MaqPetToBedFormat() {}
	private static Log_Buffer LB = null;
	
	private static int hist_size;
	private static int max_pet_size;
	private static int unpaired = 0;
	private static int canonical = 0;
	private static int contig_span = 0;
	private static boolean nobed_mode;
	private static boolean only18 = false;
	
	private static final String PARM_INPUT = "input";
	private static final String PARM_OUTPUT = "output";
	private static final String PARM_MAQ_READ_SIZE = "maq_read_size";
	private static final String PARM_BRIDGE = "bridge";
	private static final String PARM_MAX_PET_SIZE = "max_pet_size";
	private static final String PARM_NOFLAG = "noflag";
	private static final String PARM_NOBED_MODE = "nobed_mode";
	private static final String PARM_HIST_SIZE = "hist_size";
	private static final String PARM_QUALITY_FILTER = "qualityfilter";
	private static final String PARM_NAME = "name";
	private static final String PARM_PET_FILTER_18 = "filter18only";
	
	// ESCA-JAVA0138:
	/**
	 * @param name
	 * @param bridge
	 *            whether to use bridging mode, which shows a thin line between
	 *            pairs, or to use the default mode, which shows the whole thing
	 *            as a single fat line.
	 * @param end1
	 * @param end2
	 * @param bw1
	 * @param fo
	 * @param fo2
	 * @param H
	 */
	private static void process_tag_pair(String name, boolean bridge,
			SETLocation end1, AlignedRead end2, Bedwriter bw1, FileOut fo, FileOut fo2,
			Histogram H) {
		int compare = end1.get_contig().compareTo(end2.get_chromosome());
		if (compare == 0) {
			if (end1.get_position() < end2.get_alignStart()) {
				if (nobed_mode) {
					fo2.writeln("1:\t" 
							+ end1.get_contig() + "\t"
							+ end1.get_position() + "\t"
							+ ((end1.get_direction()) ? "+" : "-") + "\t"
									
							+ "2:\t"
							+ end2.get_chromosome() + "\t"
							+ end2.get_alignStart() + "\t"
							+ end2.get_direction()  + "\t"
							
							+ ((end2.get_name().endsWith(Reverse)) ? "R" : ((end2.get_name().endsWith(Forward)) ? "F" : ""))
							+ "\t"	
							+ end2.get_identity() + "\t"
							+ end2.get_name().substring(0,
									(end2.get_name().endsWith(Reverse) || end2.get_name().endsWith(Forward)) 
												? end2.get_name().length() - trim_f 
												: end2.get_name().length()));
				} else if (bridge) {
					bw1.writelnExt(end1.get_contig(), end1.get_position(), end2.get_alignStart() + end2.get_alignLength(),
								name, LINE_DARKNESS, '+', end1.get_position(), end2.get_alignStart() + end2.get_alignLength(),
								FULL_COLOUR, 0, 0, 2, end1.get_length() + "," + end2.get_alignLength(), 
								"0," + (end2.get_alignStart()-end1.get_position()));
				} else {
					bw1.writeln(end1.get_contig(), end1.get_position(), end2.get_alignStart() + end2.get_alignLength());
				}
				H.bin_value(end2.get_alignStart() - end1.get_position());
			} else {   // reverse order on chromosome.  How well this works is debatable.
				if (nobed_mode) {
					fo2.writeln("2:\t" 
							+ end2.get_chromosome() + "\t"
							+ end2.get_alignStart() + "\t"
							+ end2.get_direction() + "\t"
							
							+ "1:\t"
							+ end1.get_contig() + "\t"
							+ end1.get_position() + "\t"
							+ ((end1.get_direction()) ? "+" : "-") + "\t"
							
							+ ((end2.get_name().endsWith(Reverse)) ? "R" : ((end2.get_name().endsWith(Forward)) ? "F" : ""))
							+ "\t"
							+ end2.get_identity() + "\t"
							+ end2.get_name().substring(0, 
									(end2.get_name().endsWith(Reverse) || end2.get_name().endsWith(Forward))
												? end2.get_name().length() - trim_f 
												: end2.get_name().length()));
				} else if (bridge) {
					bw1.writelnExt(end1.get_contig(), end2.get_alignStart(), end1.get_position() + end1.get_length(),
							name, LINE_DARKNESS, '-', end2.get_alignStart(), end1.get_position() + end1.get_length(),
							0, 0, FULL_COLOUR, 2, end2.get_alignLength() + "," + end1.get_length(), 
							"0," + (end1.get_position()-end2.get_alignStart()));
				} else {
					bw1.writeln(end1.get_contig(), end2.get_alignStart(), end1.get_position() + end1.get_length());
				}
				H.bin_value(end1.get_position() - end2.get_alignStart());
			}
			canonical++;
		} else if (compare < 0) {								//else not on same chromosome
			contig_span++;
			fo.writeln("1:\t" 
					+ end1.get_contig() + "\t"
					+ end1.get_position() + "\t"
					+ ((end1.get_direction()) ? "+" : "-") + "\t"
							
					+ "2:\t"
					+ end2.get_chromosome() + "\t"
					+ end2.get_alignStart() + "\t"
					+ end2.get_direction()  + "\t"
					
					+ ((end2.get_name().endsWith(Reverse)) ? "R" : ((end2.get_name().endsWith(Forward)) ? "F" : ""))
					+ "\t"	
					+ end2.get_identity() + "\t"
					+ end2.get_name().substring(0,
							(end2.get_name().endsWith(Reverse) || end2.get_name().endsWith(Forward)) 
										? end2.get_name().length() - trim_f 
										: end2.get_name().length()));
		} else if (compare > 0) {
			contig_span++;
			fo.writeln("2:\t" 
					+ end2.get_chromosome() + "\t"
					+ end2.get_alignStart() + "\t"
					+ end2.get_direction() + "\t"
					
					+ "1:\t"
					+ end1.get_contig() + "\t"
					+ end1.get_position() + "\t"
					+ ((end1.get_direction()) ? "+" : "-") + "\t"
					
					+ end2.get_direction()  + "\t"
					+ ((end2.get_name().endsWith(Reverse)) ? "R" : ((end2.get_name().endsWith(Forward)) ? "F" : ""))
					+ "\t"
					+ end2.get_identity() + "\t"
					+ end2.get_name().substring(0, (end2.get_name().endsWith(Reverse) || end2.get_name().endsWith(Forward)) 
										? end2.get_name().length() - trim_f 
										: end2.get_name().length()));
		}
	}	

	
	public static void main(String[] args) {
		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
			return;
		}
		
		
		if (!Variables.containsKey(PARM_NAME)) {
			LB.error("Must provide an -" + PARM_NAME + " on the command line");
			LB.die();
		}
		
		if (Variables.containsKey(PARM_OUTPUT)) { 
			String tmp = Variables.get(PARM_OUTPUT);
			if (!tmp.endsWith(System.getProperty("file.separator"))) {
				tmp = tmp.concat(System.getProperty("file.separator"));
				Variables.put(PARM_OUTPUT, tmp);
			}
			LB.notice("Log File: " + Variables.containsKey(PARM_OUTPUT) + Variables.containsKey(PARM_NAME)  + ".log");
			LB.addLogFile(Variables.get(PARM_OUTPUT) + Variables.get(PARM_NAME) + ".log");
		} else {
			LB.error("Must provide an -" + PARM_OUTPUT + " path on the command line");
			LB.die();
		}
		
		new CurrentVersion(LB);
		LB.Version("MaqPetToBedFormat", "$Revision: 1581 $");
		
		
		if (!Variables.containsKey(PARM_INPUT)) {
			LB.error("Must provide an -" + PARM_INPUT + " file on the command line");
			LB.die();
		}
		
		if (!Variables.containsKey(PARM_MAQ_READ_SIZE)) {
			LB.error("Must provide an -" + PARM_MAQ_READ_SIZE + " file on the command line.");
			LB.error("use 64 for maq versions < 0.7, 128 for maq versions >= 0.7");
			LB.die();
		}
		boolean bridge_mode = Variables.containsKey(PARM_BRIDGE)?true:false;
		if (bridge_mode) {
			LB.notice(" * Tag and Bridge mode is on. (-" + PARM_BRIDGE + ")");
		} else {
			LB.notice(" * Tag and Bridge mode is off - using default single block BED format. (-" + PARM_BRIDGE + " not used)");
		}

		if (Variables.containsKey(PARM_MAX_PET_SIZE)) {
			max_pet_size = Integer.valueOf(Variables.get(PARM_MAX_PET_SIZE));
		} else {
			max_pet_size = 0;
		}
		LB.notice(" * Maximum PET fragment size set : " + ((max_pet_size == 0 ) ? "Off" : max_pet_size));
		
		boolean noflag_mode = Variables.containsKey(PARM_NOFLAG)? true: false;
		if (noflag_mode) {
			LB.notice(" * Noflag mode is on. (-" + PARM_NOFLAG + ")");
		} else {
			LB.notice(" * Flags expected \"/1\" and \"/2\"");
		}
		
		nobed_mode = Variables.containsKey(PARM_NOBED_MODE)? true: false;
		if (noflag_mode) {
			LB.notice(" * no bed mode is on. (-" + PARM_NOBED_MODE + ")");
		} else {
			LB.notice(" * BED Mode On - wig generation will occur for pairs aligned to same chromosome");
		}
		
		if (nobed_mode && bridge_mode) {
			LB.notice ("Can't use nobed and bridge modes at the same time.  Please select only one.");
		}
		
		
		if (Variables.containsKey(PARM_HIST_SIZE)) {
			hist_size = Integer.valueOf(Variables.get(PARM_HIST_SIZE));
		} else {
			hist_size = DEFAULT_HIST_SIZE;
		}
		LB.notice(" * Histogram size set to " + hist_size + " bins");
		
		int quality_threshold=0;
		//TODO not the best parameter name for this
		if (!Variables.containsKey(PARM_QUALITY_FILTER)) {
			LB.notice(" * No quality filtering, use -" + PARM_QUALITY_FILTER + " <threshold> to enable");
		} else { 
			try { 
				quality_threshold = Integer.parseInt(Variables.get(PARM_QUALITY_FILTER));
			}catch (NumberFormatException e ) {
				LB.error("Must provide a positive integer for quality filtering");
				LB.die();
			}catch (NullPointerException e) {
				LB.error("Must provide a positive integer for quality filtering");
				LB.die();
			}
			LB.notice(" * filtering below " + quality_threshold);
		}
		
		if (Variables.containsKey(PARM_PET_FILTER_18)) {
			only18 = true;
		} else {
			only18 = false;
		}
		
		HashMap<String, SETLocation> store = new HashMap<String, SETLocation>();
		Histogram H_obs = new Histogram(LB, hist_size, 0, hist_size, false);
		Histogram H_maq = new Histogram(LB, hist_size, 0, hist_size, false);
		
		MAQmapIterator mi = new MAQmapIterator(LB, "sourcefile", Variables			//the filtering is done by the MAQmapIterator
				.get(PARM_INPUT), quality_threshold, Integer.valueOf(Variables.get(PARM_MAQ_READ_SIZE)), max_pet_size);
		
		/*File writers*/
		Bedwriter bw1 = null; 
		FileOut fo = new FileOut(LB, Variables.get(PARM_OUTPUT) + Variables.get(PARM_NAME) + "_paired-spaning.txt", false);
		FileOut fo2 = null;
		if (nobed_mode) { 
			fo2 = new FileOut(LB, Variables.get(PARM_OUTPUT) + Variables.get(PARM_NAME) + "_paired-local.txt", false); 
		} else {
			bw1 = new Bedwriter(LB, Variables.get(PARM_OUTPUT) + Variables.get(PARM_NAME) + "_paired-local.bed.gz");
			bw1.BedHeader(Variables.get(PARM_NAME), "paired_reads", false);
		}
		Bedwriter bw2 = new Bedwriter(LB, Variables.get(PARM_OUTPUT) + Variables.get(PARM_NAME) + "_paired-SET.bed.gz");
		
		bw2.BedHeader(Variables.get(PARM_NAME), "unpaired_reads", false);
		
		LB.notice("Processing...");
		int cnt = 0;
		while (mi.hasNext()) {
			AlignedRead line = null;
			try {
				 line = mi.next();
			} catch (NoSuchElementException nsee) {
				continue;
			}
			cnt++;
			
			if (cnt % OUTPUT_FREQ == 0) {
				LB.notice(cnt + " reads processed");
			}
			
			if (only18 && line.get_identity() != 18 ) {
				unpaired++;
				continue;
			}
			
			if (line.get_identity() == 192) {
				unpaired++;
				continue;
			}
			if (line.get_identity() == 64) {
				bw2.writelnExt(line.get_chromosome(), line.get_alignStart(), line.get_alignEnd(), 
						line.get_sequence(), 0, line.get_direction(), line.get_alignStart(), 
						line.get_alignEnd(), FULL_COLOUR, FULL_COLOUR, FULL_COLOUR, 0, "" ,"");
				unpaired++;
				continue;
			}
				
			boolean fw = false;
			
			if (!noflag_mode && line.get_name().endsWith(Forward)) {
				fw = true;
				H_maq.bin_value(line.get_maq_PET_insert_sz());
			}
			
			String name_key  = null;
			if (!noflag_mode) {
				name_key = line.get_name().substring(
					0,
					((line.get_name().endsWith(Reverse) || line
									.get_name().endsWith(Forward)) ? line
									.get_name().length() - trim_f : line.get_name().length()));
			} else {
				name_key = line.get_name();
			}
			
			if (store.containsKey(name_key)) {				//test if already there	
				SETLocation hr = store.get(name_key);
				if (!noflag_mode && 
					((hr.get_first_of_pair() && fw)				//hr.get_first_of_pair() == true, and fw
						||  (!hr.get_first_of_pair() && !fw))) {			//hr.get_first_of_pair() == false, and !fw
					LB.error("Duplicate tag end : " +((fw)?"forward":"reverse") + " " + name_key);
					LB.die();
				} else {
					process_tag_pair(name_key, bridge_mode, hr, line, bw1, fo, fo2, H_obs);
					store.remove(name_key);						//remove from map
					if (noflag_mode) {
						H_obs.bin_value(line.get_maq_PET_insert_sz());
					}
				}
			} else {
				SETLocation l = new SETLocation(line.get_chromosome(), line
						.get_alignStart(), (line.get_direction() == '+') ? true
						: false, (short) line.get_alignLength(), fw);
				store.put(name_key, l);
			}
		}
		
		
		if (bw1 != null) {
			bw1.close();
		} 
		if (fo2 != null) {
			fo2.close();
		}
		fo.close();
		
		
		/* Now process left over tags. */
		if (store.size() > 0) {
			Collection<SETLocation> locs = store.values();
			for (SETLocation end : locs) {	//write out unpaired tags, in case there are any because of filtering. 
				bw2.writelnExt(end.get_contig(), end.get_position(), (end.get_position() + end.get_length()-1), 
						"", 0, (end.get_direction()) ? '+' : '-', end.get_position(), 
						(end.get_position() + end.get_length()-1), FULL_COLOUR, FULL_COLOUR, FULL_COLOUR, 0, "" ,"");
				unpaired++;
			}
		}
		
		bw2.close();
		
		LB.notice(" Total unpaired tags: " + unpaired);
		LB.notice(" Total paired on same contig: " + canonical  + " (" + (canonical*2) + " tags)");
		LB.notice(" Total paired spanning contigs: " + contig_span + " (" + (contig_span*2) + " tags)"); 
		LB.notice(" Total filtered: " + mi.get_NumberFilteredRead());
		
		H_obs.print_bins(Variables.get(PARM_OUTPUT) + "Histogram_obs.txt");
		if (!noflag_mode) {
			H_maq.print_bins(Variables.get(PARM_OUTPUT) + "Histogram_maq.txt");
		}
		LB.close();
	}
	
	
	
}

package src.projects.findPeaks;

import java.io.FileWriter;
import java.io.IOException;

import src.lib.ioInterfaces.Log_Buffer;
import src.projects.findPeaks.objects.Parameters;

/**
 * @version $Revision: 1056 $
 * @author 
 */
public class RFunctions {
	private static boolean display_version = true;
	private static Log_Buffer LB = null; 
	private static float scanned_height;
	
	private RFunctions() {}
	
	/**
	 * Initialises and writes headers for R script files files.
	 * @param Rfile
	 * @param genome_size
	 * @param file
	 * @param m
	 * @param scan_ht
	 */
	public static void initialize_R_files(FileWriter Rfile, float genome_size, String file, int m, float scan_ht) {
		if (LB == null) {
			LB = Parameters.get_Log_Buffer();
		}
		if (display_version) {
			LB.Version("RFunctions", "$Revision: 1056 $");
			display_version = false;
		}
		scanned_height = scan_ht;
		try {
			Rfile.write("postscript(file=\"" + file + "\", width = 43.0, height = 1.0, paper =\"special\")\n");
			//Rfile.write("par(fig=c(0,1.0,0,0.5))\n"); //#Aspect ratio control
			Rfile.write("par(mar=c(0,0,0,0))\n"); //#Aspect ratio control
			//#Overall plot
			Rfile.write("plot(c(1/"
				+ m	+ ", "
				+ genome_size + "/"
				+ m	+ "), c(0,"
				+ scanned_height 
				+ "), type = \"n\", xlab=\"\", ylab=\"\", main = \"\",axes=F,frame.plot=F)\n");
		    //#Show start of genome as vertical line (to be overwritten by chr name
			//Rfile.write("rect(1/"+ m +", 0, "+ genome_size + "/" + m + ", " + scanned_height + ", col=\"white\",border=NA)\n");
			Rfile.write("abline(v=1.0/" + m + ",col=\"darkgray\",lwd=0.5)\n");
		    Rfile.write("abline(h="+scanned_height+",col=\"darkgray\",lwd=0.5)\n");  //TRIAL		    
		//    Rfile.write("text(1/" + m + "," 
		//    	+ (scanned_height - (scanned_height/10)) 
		//      + ",\"Chromosome 17\",adj=0.0,col=\"black\",cex=0.3)\n");
			//Rfile.write("lines(c(0,0),c(0,100), lwd=0.3, col=\"red\")\n");
		} catch (IOException io) {
			LB.error("Can't initialize files!");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	
	/**
	 * This function writes a line in the R script file.
	 * @param FW		FileWriter handle
	 * @param pk_start	start of the peak
	 * @param m			
	 * @param height	height of the peak
	 */
	public static void write_R_line(FileWriter FW, int pk_start, int m, float height) {
		if (height > scanned_height ){
			height = 0.95f * scanned_height;
		}
		try {
			FW.write("lines(c("+pk_start + "/" + m + ","+pk_start + "/" + m+"),c(0.2," + height+"), lwd=0.1, col=\"blue\")\n");
		} catch (IOException io) {
			LB.error("Error writing to R file.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}	
	}
	
	
	public static void closeRfile(FileWriter Rfile) {
		try {
			//Rfile.write("abline(v=" + genome_size + "/" + m  + ",col=\"darkgray\",lwd=0.5)\n");
			Rfile.write("dev.off()\n");
			Rfile.close();
		} catch (IOException io) {
			LB.warning("Can't close output files - continuing anyhow");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	
	/************************* END R File Processing ******************************/
	
	
	
}

package src.fileUtilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.MAQmapIterator;
import src.projects.findPeaks.objects.Parameters;

public class MapHeaderInfo
{
private Log_Buffer LB = null;
	
	private static MapHeaderInfo singleton=new MapHeaderInfo();
	
	
	private MapHeaderInfo(){} 
	
	public static void main(String args[]){
		MapHeaderInfo c=MapHeaderInfo.singleton;
		c.execute(args);
	}
	public void execute(String[] args){
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		new CurrentVersion(LB);
		LB.Version("Map_header_info", "$Revision: 1533 $");
		
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
			return;
		}
		boolean error=false;
		if (!Variables.containsKey(Parameters.INPUT_PARAM)) {
			LB.error("Must provide an -"+Parameters.INPUT_PARAM+" map file on the command line");
			error=true;
		}
		if (!Variables.containsKey(Parameters.OUTPUT_PARAM)) {
			LB.error("Must provide an -"+Parameters.OUTPUT_PARAM+" file on the command line");
			error=true;
		}
		if (error){
			LB.die();
		}
		
		MAQmapIterator iterator =new MAQmapIterator(LB,"",Variables.get(Parameters.INPUT_PARAM),0,128,-1);
		String[] all_chr=iterator.get_chromosomes();
		iterator.close(false);
		try {
			File output_file=new File(Variables.get(Parameters.OUTPUT_PARAM));
			if (output_file.isDirectory()){
				LB.error(Variables.get(Parameters.OUTPUT_PARAM)+ "must be a file name");
				LB.die();
			}
			BufferedWriter bo= new BufferedWriter(new FileWriter(output_file));
			for (String chr : all_chr)
			{
				bo.write(chr);
				bo.newLine();
				//System.out.println(chr);
			}
			bo.close();
		}catch(IOException ioe){
			LB.error(ioe.getMessage());
		}
		LB.die();
	}
	
}

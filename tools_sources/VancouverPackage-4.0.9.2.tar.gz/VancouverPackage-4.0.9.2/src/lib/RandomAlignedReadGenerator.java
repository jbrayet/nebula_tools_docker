package src.lib;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Vector;

import src.lib.Error_handling.UnexpectedResultException;
import src.lib.ioInterfaces.AlignedReadsIterator;
import src.lib.ioInterfaces.Log_Buffer;

import src.lib.objects.AlignedRead;
import src.lib.objects.ReducedAlignedRead;
import src.projects.findPeaks.Distribution;


public class RandomAlignedReadGenerator implements AlignedReadsIterator, Iterable<AlignedRead> {

	private static Log_Buffer LB;
	private static Random generator;
	private static boolean display_version = true;
	private Vector<AlignedRead> AR;	
	private Iterator<AlignedRead> it;
	
	public RandomAlignedReadGenerator(Log_Buffer logbuffer, Distribution dist, int number_of_reads, int chr_size) {

		LB = logbuffer;
		if (display_version) {
			LB.Version("RandomAlignedReadGenerator", "$Revision: 1831 $");
			display_version = false;
		}
		generator = new Random();
		/*Generate an array of Reduced Aligned Reads*/
		Generate_Sorted_Random_Reads(dist, number_of_reads, chr_size);
		
	}
	
	public boolean mark() {
		LB.error("Can not mark random alined read iterator. Method not supported");
		return false;
	}
	
	/**
	 * @deprecated
	 */
	public void apply_filters(String f) {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Return the number of filtered read while iterating.
	 * TODO change this function if the Iterator start filtering
	 * @return 0 in every case
	 */
	public int get_NumberFilteredRead() {
		return 0;
	}
	
	public boolean reset() {
		it = AR.iterator();
		return true;
	}
	
	
	public void Add_More_Random_Sorted_Reads(Distribution dist, int number_to_add, int chr_size) {
		Vector<AlignedRead> dataset = new Vector<AlignedRead>(number_to_add);
		for (int x = 0; x < number_to_add; x++) {
			int start = (generator.nextInt(chr_size) + 1);
			try {
				dataset.add(new ReducedAlignedRead(
					(generator.nextBoolean() ? '+' : '-'),
					start, start + dist.get_max_ext_len() -1 , -start).toAlignedRead()); //max_ext_len is 0 based  
			} catch (UnexpectedResultException URE) {
				//ESCA-JAVA0119:  do over if read generation failed.
				x -= 1;
			}
		}
		AR.addAll(dataset);

		AlignedRead[] temp = AR.toArray(new AlignedRead[AR.size()]);
		Arrays.sort(temp);
		AR = new Vector<AlignedRead>(Arrays.asList(temp));
		this.reset();
	}	
	
	public void Generate_Sorted_Random_Reads(Distribution dist,int number_of_reads, int chr_size) {

		AlignedRead[] dataset = new AlignedRead[number_of_reads];
		for (int x = 0; x < number_of_reads; x++) {
			int start = (generator.nextInt(chr_size) + 1);
			try {
				dataset[x] = new ReducedAlignedRead(
					(generator.nextBoolean() ? '+' : '-'),
					start, start + dist.get_max_ext_len() -1, -start).toAlignedRead();  //max_ext_len is zero based.
			} catch (UnexpectedResultException URE) {
				// ESCA-JAVA0119:  do over if read generation failed.
				x -= 1;
			}
		}
		Arrays.sort(dataset);
		AR = new Vector<AlignedRead>(Arrays.asList(dataset));
		this.reset();
	}
	
	
	public boolean hasNext() {
		return it.hasNext();
	}
	
	public AlignedRead next() {
		if (hasNext()) {
			return it.next();
		} else {
			throw new NoSuchElementException("Could not get any more reads.");
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}

	public void close(boolean verbose) {
		if (verbose) {
			LB.notice("Closing Random AlignedRead Iterator, but leaving dataset");
		}
		it = null;
	}

	public Iterator<AlignedRead> iterator() {
		return it;
	}



}

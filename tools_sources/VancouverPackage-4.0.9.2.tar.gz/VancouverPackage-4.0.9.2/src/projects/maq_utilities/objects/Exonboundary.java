package src.projects.maq_utilities.objects;

/**
 * @version $Revision: 558 $
 * @author 
 */
public class Exonboundary {
	
	public Exonboundary(int s, int e) {
		this.start = s;
		this.end = e;
	}
	
	private int start;
	private int end;
		
	public void set_start(int x) { this.start = x; }
	public void set_end(int x) { this.end = x; }
	public int get_start() { return this.start; }
	public int get_end() { return this.end; }
	
}

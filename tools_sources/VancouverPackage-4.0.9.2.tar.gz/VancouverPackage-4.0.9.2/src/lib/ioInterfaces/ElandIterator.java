package src.lib.ioInterfaces;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;

import src.lib.Constants;
import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;

/**
 * @version $Revision: 1790 $
 * @author 
 *
 */
public class ElandIterator implements AlignedReadsIterator{
	private static boolean display_version = true;
	private static final int MIN_FIELDS_REQ = 10;
	private static final int FIELD_10 = 10;
	String Name = null;
	BufferedReader br = null;
	int linecount = 0;
	int UXcnt = 0;
	private Log_Buffer LB;
	final int max_PET_len;
	int number_filtered;
	

	public ElandIterator(Log_Buffer log_file, String Name, String source_file, int max_PET_len) {
		LB = log_file;
		if (display_version) {
			LB.Version("ElandIterator", "$Revision: 1790 $");
			display_version = false;
		}
		this.max_PET_len = max_PET_len;
		this.Name = Name;
		this.number_filtered = 0;
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else if (source_file.endsWith(".gz")) {
				br = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(source_file))));
			} else {
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (FileNotFoundException e) {
			if (source_file.endsWith(".gz")) {
				try {
					LB.warning("Couldn't find file: " + source_file);
					source_file = source_file.substring(0,source_file.length()-3);
					LB.warning("Trying file: " + source_file);
					br = new BufferedReader(new FileReader(source_file));
					LB.notice("Success");
				} catch (FileNotFoundException f) {
					LB.error("Can't open Eland file (notzipped) " + source_file);
					LB.die();
				}
			} else {		
				LB.error("Can't open Eland file " + source_file);
				if (source_file.endsWith(".gz")) {
					LB.error("Tried to open as gzip.");
				}
				LB.die();
			}
		} catch (IOException io) {
			LB.error("Couldn't Open Gziped File");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		
	}
	
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	} 
	
	/**
	 * @deprecated
	 */
	public void apply_filters(String f) {
		throw new UnsupportedOperationException();
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close Eland file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Ux records : " + this.UXcnt);
			LB.notice("Lines Filtered : " + this.number_filtered);
		}
	}
	
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Eland file Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

	
	private static int mismatches(String type) {
		if (type.equals("U0")) {
			return 0;
		} else if (type.equals("U1")) { 
			return 1;
		} else if (type.equals("U2")) {
			return 2;
		} else {
			return -1;
		}
	}
	
	private static char direction(String dir) {
		if (dir.equals("R")) {
			return '-';
		} else {
			return '+';
		}
	}
	
	
	private static String align_sequence(String Sequence, int mismatches, String error1, String error2, char direction) {
		StringBuffer alnseq = new StringBuffer(Sequence);
		if (mismatches > 0) {
			char base = error1.charAt(error1.length()-1);
			int index = Integer.valueOf(error1.substring(0, error1.length()-1));
			if (direction == '+') {
				alnseq.setCharAt(index-1, base);
			} else {
				base = Utilities.Flip_Base(base);
				if (alnseq.length() > Constants.ILLUMINA_BASE_MAX_32 ) {
					index = Constants.ILLUMINA_BASE_MAX_32 - index;
				} else {
					index = alnseq.length() - index;
				}
				alnseq.setCharAt(index, base);
			}
		}
		if (mismatches == 2) {
			char base = error2.charAt(error2.length()-1);
			int index = Integer.valueOf(error2.substring(0, error2.length()-1));
			if (direction == '+') {
				alnseq.setCharAt(index-1, base);
			} else {
				base = Utilities.Flip_Base(base);
				if (alnseq.length() > Constants.ILLUMINA_BASE_MAX_32) {
					index = Constants.ILLUMINA_BASE_MAX_32 - index;
				} else {
					index = alnseq.length() - index;
				}
				alnseq.setCharAt(index, base);
			}
		}
		return alnseq.toString();		
	}
	
	
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public boolean reset() {
		try {
			br.reset();
			return true;
		} catch (IOException ioe) {
			LB.error("Could not reset input file for read buffer.");
			return false;
		}
	}
	
	//>2-112-75-545   GCAGGCGGAGGAGGAGGTGTCGCGGGG     U2      0       0       1       1       154519232       
	//R       ..      1G      11G

	public AlignedRead next() {
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				this.linecount++;	
				String[] fields = line.split("\t");
				if (fields.length < MIN_FIELDS_REQ) {
					LB.error("This Eland File line does not have enough fields:");
					LB.error(line);
					LB.die();
				}
				String read_name = fields[0];				//>2-112-75-545
				if (read_name.charAt(0) == '>') {
					read_name = read_name.substring(1);		//2-112-75-545
				}										
				String Sequence = fields[1];			//GCAGGCGGAGGAGGAGGTGTCGCGGGG
				int mismatches = 0;						
				String Match = fields[2];				//U2
				if (Match.equals("NM") || Match.equals("QC") ||
						   Match.equals("RM") ||	Match.equals("R0") || 
						   Match.equals("R1") ||	Match.equals("R2")) {	//do nothing 
					
				} else {		
					mismatches = mismatches(Match);
					this.UXcnt++;
					int alignStart 			= Integer.parseInt(fields[7]); //154519232
					String dir 				= fields[8];					//R
					String N_reads 			= fields[9];					//..
					if ((mismatches ==1 && fields.length < MIN_FIELDS_REQ+1) 
							|| (mismatches == 2 && fields.length < MIN_FIELDS_REQ+2)) {
						LB.error("Eland files with U1 or U2 must provide information about the mismatch." +
								"  There are missing fields!");
						LB.error("The failing line is:");
						LB.error(line);
						LB.die();
					}

					String error1 	= ((mismatches > 0)  ? fields[FIELD_10]: null);	//changed to FIELD_10 to constant  
					String error2 	= ((mismatches == 2) ? fields[11]: null);		//to avoid a warning from Enerjy 
					
					char direction = direction(dir);
					
					/* test for criteria */
					
					if (this.max_PET_len != 0 && Sequence.length() > this.max_PET_len) {
						this.number_filtered++;
						continue;
					}
					
					/* Fill in other parts of the AlignedRead Object: */ 

					int seqEnd			= Sequence.length() -1; 
					double percent 		= (Constants.PERCENT_100 - ((float)mismatches/(float)seqEnd)*Constants.PERCENT_100 );
					double iden 		= ((double)(seqEnd-mismatches)/(double)seqEnd);
					iden				= Math.floor(iden*10000);
					int identity		= (int)(iden/Constants.PERCENT_100);
					
					String alignseq = (mismatches > 0) 
							? align_sequence(Sequence, mismatches, error1, error2, direction) 
							: Sequence;
		
					AlignedRead A = null;
					try {
						A = new AlignedRead(
							direction,
							read_name,
							Sequence,
							0,									/*score*/
							0,									/*seqStart*/
							seqEnd,
							null,								/*alignName*/
							fields[6],							/*chromosome*/
							alignStart,
							alignStart + Sequence.length() - 1,	/*alignEnd*/
							percent,
							0,									/*P*/
							alignseq,
							mismatches,
							-alignStart,						/*sort_score*/
							0,									/*queryLength*/
							Sequence.length(),					/*alignLength*/
							0,									/*contigStart*/
							0,									/*contigEnd*/
							identity,
							Match,
							Integer.parseInt(fields[3]),		/*matches_noError*/
							Integer.parseInt(fields[4]), 		/*matches_1error*/
							Integer.parseInt(fields[5]),		/*matches_2error*/
							N_reads,
							error1,
							error2,
							null);								/*quality*/

					
					} catch (UnexpectedResultException URE) {
						LB.error("Line " + linecount + " has an invalid read:");
						LB.error(URE.getMessage());
					}
					return A;
				}			
			} 
			throw new NoSuchElementException("Could not get any more reads.");
		} catch (IOException io) {
			LB.error("Error reading Eland file on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return null;
	}

	/**
	 * Return the number of filtered read while iterating.
	 * @return number of filtered reads
	 */
	public int get_NumberFilteredRead() {
		return this.number_filtered;
	}
}

		
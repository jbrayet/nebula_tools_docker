#!/usr/bin/perl

#filter out dulpicates from SAMPLE (optional) and create a control dataset w/o duplicates with the same number of reads as in the SAMPLE

use strict;
use warnings;
use diagnostics;

my $usage = qq{
    $0

    -----------------------------
    mandatory parameters:
    
    -f outputOfChipMunk
    -o output file
    -----------------------------
    optional parameters:

    
    none			
};

if(scalar(@ARGV) == 0){
    print $usage;
    exit(0);
}

## mandatory arguments

my $filename = "";
my $output_fname = "";
my $numberOfMotifs = 0;

## optional arguments

## parse command line arguments

while(scalar(@ARGV) > 0){
    my $this_arg = shift @ARGV;
    if ( $this_arg eq '-h') {print "$usage\n"; exit; }

    elsif ( $this_arg eq '-f') {$filename = shift @ARGV;}
    elsif ( $this_arg eq '-o') {$output_fname = shift @ARGV;}

    elsif ( $this_arg =~ m/^-/ ) { print "unknown flag: $this_arg\n";}
}

if ( $filename eq ""){
    die "you should specify chip file\n";
}
if( $output_fname eq ""){
    die "you should specify output filename\n";
}


open FILE, "< $filename " || die "$filename : $!\n";

my $motifcount = 0;
my $count = 0;

open OUT, "> $output_fname" || die "$output_fname: $!\n";

while(<FILE>){
    chomp;
    
    if (m/INFO/) {
	
	$motifcount++;
	print OUT "Motif $motifcount\n";	

    } elsif (m/(^[ACGT])\|(\d.*)/) {
	#A|1101.999999999997 297.0 1521.9999999999968 0.0 162.00000000000028 1608.9999999999998 1692.9999999999968 25.0 375.9999999999988 247.0	
	print OUT $1."|"; 
	my @values = split /\s/, $2;
	for my $value (@values) {
	    print OUT " ",int($value);	    
	}
	print OUT "\n";
    } elsif (m/OCCS/) {
	my $str = $_;	
    }
}

close FILE;
close OUT;
print $motifcount;

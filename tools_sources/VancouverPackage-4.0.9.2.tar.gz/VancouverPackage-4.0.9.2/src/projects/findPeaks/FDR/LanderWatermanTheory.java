package src.projects.findPeaks.FDR;

import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import src.lib.Histogram;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Tuple;
import src.projects.findPeaks.Distribution;
import src.projects.findPeaks.objects.Parameters;


/**
 * 
 * @author mbilenky
 * @author Tim cezard Sept. 2 2008 Calculates randomly expected number of peaks
 *         using Lander-Waterman theory. Code based on Misha's
 *         LanderWatermanTheory for FP2 adapted for FP3 and float height.
 * @version $Revision: 1828 $
 */
public class LanderWatermanTheory {

	private LanderWatermanTheory() {
	}

	public static double getHeightForFDR(double[] cumNumRndPeaks, Histogram exp_stats, int Size_Hist,
			int precision, double fdr_threshold) {
	
		long[] cumulative_obs = new long[(Size_Hist*precision)+1];
		cumulative_obs[(Size_Hist*precision)] = exp_stats.get_overflows();
	
		for (int bins = (Size_Hist*precision) -1; bins >= 0; bins--) {
			cumulative_obs[bins] = cumulative_obs[bins + 1] + exp_stats.get_bin_value(bins);  
		}
		double closest_height=0;
		double abs_diff=Double.MAX_VALUE;
		for (int i=0;i<cumNumRndPeaks.length;i++){
			double fdr=cumNumRndPeaks[i]/cumulative_obs[i];
			if (Math.abs(fdr-fdr_threshold)<abs_diff){
				abs_diff=Math.abs(fdr-fdr_threshold);
				closest_height=i/(double)precision;
			}
		}
		return closest_height;
	}
/*	 number of random iterations to calculate height configurations for island
	 of a given nReads*/

	// ESCA-JAVA0138:
	/**
	 * This function predicts expected number of connected islands for specific
	 * height
	 * 
	 * @param NJ1_J2
	 *            Number of Peaks of height 1 (get_first()) and number of Peaks of height 2 (get_second())
	 * @param maxNReads
	 *            maximum number of reads used to create the random peak
	 * @param lengthDist
	 *            The fragment length distribution.
	 * @param nRepeats
	 *            number of time the random peak will be generated.
	 * @param precision
	 *            the
	 * @return
	 */
	public static double[] randomlyExpectedPeaks(Tuple<Integer, Integer> NJ1_J2,
			int maxNReads, Distribution lengthDist, int nRepeats, int precision) {
		// Precision of the binning of the height ==> bin Size = 0.1

		Log_Buffer LB = Parameters.get_Log_Buffer();
		if (NJ1_J2.get_first() < 1 || NJ1_J2.get_second() < 1 || maxNReads < 1 || nRepeats < 1) {
			return new double[] {};
		}
/*		 ------------------
		 Main expressions:
		 -----------------

		 Number of peaks ( islands )
		 N(j) = Nr * A^2 * ( 1 - A )^(j-1),
		 where
		 Nr - total effective number of random reads
		 A = exp(-c), with C=l*Nr/L,
		 l - read length,
		 L - effective (mappable) chromosome length
		 L=l*Nr/c = -l*Nr/log(A)

		 calculate A
		 N1 = Nr * A^2
		 N2 = N1 * (1 - A) ==> A=1-N2/N1
		 ==> N = N1^2/(N1-N2)
*/
		double A = 1. - (double) NJ1_J2.get_second() / (double) NJ1_J2.get_first();
		// Number of background reads
		// TODO reference to Lander-Waterman theory
		int Nr = (int) (NJ1_J2.get_first() / (A * A));
		LB.notice("Number of background reads: " + Nr);
		//
		LB.notice("Effective genome/chromosome length: "
				+ -(lengthDist.get_max_ext_len()-1) * Nr / Math.log(A));		//max_ext_len is zero based
		double[] peaksCountVsNReads = new double[maxNReads + 1];
		double[] peaksCountVsHeight = new double[(maxNReads * precision) + 1];
		double[] peaksCountVsNReadsCum = new double[maxNReads + 1];
		double[] peaksCountVsHeightCum = new double[(maxNReads * precision) + 1];

		peaksCountVsNReads[0] = 0; 		// number of peak of read 1
		peaksCountVsNReadsCum[0] = 0; 	// number of peak of read one or less
		peaksCountVsNReads[1] = NJ1_J2.get_first(); 	// number of peak of read 1
		peaksCountVsNReadsCum[1] = NJ1_J2.get_first(); 	// number of peak of read one or less

		int nReads = 1;
		while (nReads <= maxNReads) {
			if (nReads > 1) {
				peaksCountVsNReads[nReads] = peaksCountVsNReads[nReads - 1]
						* (1 - A);
			}
			// MC step to convert nReads into height distribution
			double[] dist = getHeightDistribution(nReads, precision,
					lengthDist, nRepeats);

			for (int l = 0; l < dist.length; l++) {
				peaksCountVsHeight[l] += peaksCountVsNReads[nReads] * dist[l];
			}

			peaksCountVsNReadsCum[0] += peaksCountVsNReads[nReads];
			nReads++;

		}

		for (int i = 0; i < peaksCountVsHeightCum.length; i++) {
			peaksCountVsHeightCum[0] += peaksCountVsHeight[i];
		}

		for (int i = 0; i < peaksCountVsHeightCum.length - 1; i++) {
			peaksCountVsHeightCum[i + 1] = peaksCountVsHeightCum[i]
					- peaksCountVsHeight[i];
		}

		return peaksCountVsHeightCum;
	}

	/**
	 * This function generate a distribution of maximum height based on MC
	 * repartition of overlapping reads. It return an array containing a value
	 * for each number of read * precision. The height distribution is discrete
	 * but the precision allow two assess some value inside between two integer.
	 * 
	 * @param nReads
	 *            The number of reads randomly generated.
	 * @param readLengthDist
	 *            The distribution of the read length.
	 * @param nRepeats
	 *            The number of time the reads will be generated.
	 * @param precision
	 * @return an
	 */
	private static double[] getHeightDistribution(int nReads, int precision,
			Distribution readLengthDist, int nRepeats) {
		double[] hist = new double[(nReads * precision) + 1];

		for (int j = 0; j < nRepeats; j++) {
			Integer[] readStarts = generateReads(nReads,
					readLengthDist.get_max_ext_len());

			// outputReads(readStarts,readLengthDist.ld.length);

			double maxHeight = max_height(readStarts, readLengthDist);
			hist[(int) (Math.round(maxHeight * precision))]++;
		}
		double[] dist = new double[(nReads * precision) + 1];
		for (int j = 0; j < dist.length; j++) {
			dist[j] = hist[j] / nRepeats;
		}

		return dist;

	}

	/**
	 * This method calculate the profile of reads given in an array of start and
	 * report the maximum height of the profile.
	 * 
	 * @param readStarts
	 *            And array of Integer containing the start location of the
	 *            reads.
	 * @param dist
	 *            The distribution of the read length.
	 * @return the maximum height of the profile.
	 */
	private static double max_height(Integer[] readStarts, Distribution dist) {
		Random r = new Random();
		int zeroValue = readStarts[0];
		// create a profile of length span of the reads start + max length of a
		// read.
		int profileLength = readStarts[readStarts.length - 1] - zeroValue
				+ dist.get_max_ext_len() -1;				//max_ext_len is zero based
		double[] profile = new double[profileLength];
		// fill the profile of the reads
		for (Integer i : readStarts) {
			boolean strand = r.nextBoolean();
			if (strand) {
				for (int j = 0; j < dist.get_max_ext_len(); j++) {
					profile[i - zeroValue + j] += dist.value_at(j);
				}
			} else {
				for (int j = 0; j < dist.get_max_ext_len(); j++) {
					profile[i - zeroValue + j] += dist.value_at(dist.get_max_ext_len() - j - 1);
				}
			}
		}
		// get the maximum height
		double height = 1.0;
		for (int i = 1; i < profileLength; i++) {
			if (profile[i] > height) {
				height = profile[i];
			}
		}
		return height;
	}

	/**
	 * This function generate a random set of unstranded overlapping reads.
	 * 
	 * @param nReads
	 *            The number of reads in this island
	 * @param maxReadLength
	 *            The maximum length of each read.
	 * @return A set of read start.
	 */
	private static Integer[] generateReads(int nReads, int maxReadLength) {

		Random r = new Random();

		int regionStart = 0;
		int regionEnd = maxReadLength;
		int potRegionLength = 0;
		int potRegionStart = 0;

		Set<Integer> readStarts = new TreeSet<Integer>();
		readStarts.add(new Integer(0));

		while (readStarts.size() < nReads) {

			potRegionStart = regionStart - maxReadLength - 1;
			potRegionLength = regionEnd - regionStart + 1 + maxReadLength;

			int readStart = potRegionStart + r.nextInt(potRegionLength);

			readStarts.add(new Integer(readStart));

			regionStart = Math.min(regionStart, readStart);
			regionEnd = Math.max(regionEnd, readStart + maxReadLength);

		}
		return readStarts.toArray(new Integer[readStarts.size()]);
	}

	

	

}

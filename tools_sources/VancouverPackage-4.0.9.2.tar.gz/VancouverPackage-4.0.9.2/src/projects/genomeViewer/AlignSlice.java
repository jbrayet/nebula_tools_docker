package src.projects.genomeViewer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.Coverage;
import src.lib.CurrentVersion;
import src.lib.Ensembl;
import src.lib.IterableIterator;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.ElandIterator;
import src.lib.ioInterfaces.FastaIterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.WigwriterBuffered;
import src.lib.objects.AlignedRead;


// ESCA-JAVA0100:
/**
 * This module will do a simple alignment of dna sequences in an eland file
 * against the genome sequence, given only an eland file, a chromosome, and the
 * base numbers of the ends of the sequence of interest.
 * 
 * hooks left in for two improvements: 1. Compressing alignments 2. module for
 * including "long_reads", where only a portion of the read was aligned, and the
 * remainder must be locally aligned manually. (Currently will align all
 * sequence provided, whether used or not.)
 * 
 * Example syntax: java -cp .:../MNBLIB/ -Xmx6500M AlignSlice 1 91176417
 * 					91179454 /home/afejes/Desktop/alinger.out
 * 					/home/afejes/Desktop/output/patient4long/lane_*.um.eland
 * 
 * @author Genome Sciences Centre
 * @version $Revision: 1766 $
 */


public class AlignSlice {
	/**
	 * the mappability of the chromosome of interest
	 */
	private static short[] mappability; 
	/**
	 * The size of the map to use for mappability;
	 */
	private static final short mapsize		= 27;
	private static final int SEPARATION		= 40;
	private static final float MIN_COV = 0.00f;
	
	
	private static String[] files 			= null;
	private static String input_species		= null;
	private static String output_file		= null;
	private static String chromosome		= null;
	private static String conf_file			= null;
	private static String name				= null;
	private static String prepend			= "";
	private static int start_position		= 0;
	private static int end_position			= 0;
	private static int fixed_size			= 0;
	private static boolean text				= false;
	private static boolean map				= false;
	
	
	private AlignSlice() {}
	
	private static Log_Buffer LB;
	
	private static void usage() {
		LB.notice("Usage: AlignSlice Parameters:");
		LB.notice("********************************************************************************");
		LB.notice(" -help         |           | Prints this option list");
		LB.notice(" -text         |           | uses the text mode, otherwise generates wigs.");
		LB.notice(" -chr          | <string>  | which chromosome to load.");
		LB.notice(" -start        | <integer> | start of region of interest.");
		LB.notice(" -end          | <integer> | end of region of interest.");
		LB.notice(" -out          | <string>  | complete path and name of output file.");
		LB.notice(" -size         | <integer> | fixed length (xset) size to use.");
		LB.notice(" -species      | <string>  | name of the species of interest.");
		LB.notice(" -input        | <strings> | location and name of eland files.  wildcards ok.");
		LB.notice(" -map          |           | turns on mappability wig/track generation.");
		LB.notice(" -conf         | <string>  | location of conf file to use.");
		LB.notice(" -prepend      | <String>  | allows a string to be prepended to the chromosome name" );
		LB.notice("********************************************************************************");
		LB.die();
	}

	
	/**
	 * Process the variables passed in on the command line, and assign them to
	 * the local variables. Since all of my programs use this, maybe its worth
	 * just making this a single function.
	 * 
	 * @param Variables
	 */
	private static void parse_input(HashMap<String,String> Variables) {
		
		if (Variables == null)				 {	usage();	}
		assert (Variables != null);
		if (Variables.containsKey("help"))	 {	usage();	}
		
		/* Do bootstrap calls here */
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.notice("file names must be supplied with -name flag");
			usage();
		}
		
		if (Variables.containsKey("output")) {		
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_file = Variables.get("output");
			if (!output_file.endsWith(System.getProperty("file.separator"))) {
				output_file = output_file.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_file + name  + ".log");
			LB.addLogFile(output_file + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			usage();
		}	
		
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output file name  : " + output_file);		
		LB.notice(" * Name              : " + name);
		
		
		if (Variables.containsKey("text")) {
			CommandLine.test_parameter_count(LB, "text", Variables.get("text"), 0);
			text = true;
			LB.notice(" * Text mode         : On");
		} else {
			text = false;
			LB.notice(" * Text mode         : Off");
		}
		
		if (Variables.containsKey("map")) {
			CommandLine.test_parameter_count(LB, "map", Variables.get("map"), 0);
			map = true;
			LB.notice(" * Mappability       : On");
		} else {
			map = false;
			LB.notice(" * Mappability       : Off");
		}
		
		if (Variables.containsKey("prepend")) {
			CommandLine.test_parameter_count(LB, "prepend", Variables.get("prepend"), 1);
			prepend = Variables.get("prepend");
			LB.notice(" * Chr name prepend  : " + Variables.get("prepend"));
		} else {
			prepend = "";
			LB.notice(" * Chr name prepend  : none");
		}
		
		if (Variables.containsKey("chr")) {		
			CommandLine.test_parameter_count(LB, "chr", Variables.get("chr"), 1);
			chromosome = Variables.get("chr");
			LB.notice(" * Chromosome in use : " + chromosome);
		} else {
			LB.notice("chomosome must be supplied with -chr flag");
			usage();
		}
	
		if (Variables.containsKey("conf")) {		
			CommandLine.test_parameter_count(LB, "conf", Variables.get("conf"), 1);
			conf_file = Variables.get("conf");
			LB.notice(" * Config file       : " + conf_file);
		} else {
			LB.notice("Must specify config file with the -conf flag");
			usage();
		}
		
		if (Variables.containsKey("start")) {		
			CommandLine.test_parameter_count(LB, "start", Variables.get("start"), 1);
			start_position = Integer.valueOf(Variables.get("start"));
			LB.notice(" * Start position    : " + start_position);
		} else {
			LB.notice("start position must be supplied with -start flag");
			usage();
		}
		
		if (Variables.containsKey("end")) {		
			CommandLine.test_parameter_count(LB, "end", Variables.get("end"), 1);
			end_position = Integer.valueOf(Variables.get("end"));
			LB.notice(" * End position      : " + end_position);
		} else {
			LB.notice("end position must be supplied with -end flag");
			usage();
		}
		
		if (Variables.containsKey("size")) {		
			CommandLine.test_parameter_count(LB, "size", Variables.get("size"), 1);
			fixed_size = Integer.valueOf(Variables.get("size"));
			LB.notice(" * Xset size         : " + fixed_size);
		} else {
			if (!text) {
				LB.notice("Xset size must be specified with the -size flag when not in text mode");
				usage();
			}
		}
		
		if (Variables.containsKey("species")) {		
			CommandLine.test_parameter_count(LB, "species", Variables.get("species"), 1);
			input_species =Variables.get("species");
			LB.notice(" * Input Species     : " + input_species);
		} else {
			LB.notice("input species must be supplied with -input flag");
			usage();
		}
		
		
		
		if (Variables.containsKey("input")) {
			files = Variables.get("input").split(",");
			if (files.length == 0) {
				LB.notice("-input flag must be followed by a list of files to process");
				LB.die();
			}
		} else { 
			LB.notice("Input file(s) must be provided must be supplied with the -input flag" );
			usage();
		}
		
		
		LB.notice("Files in use:");		
		for (String f : files) {
			LB.notice("\t" + f);	
		}
		
		if (start_position > end_position) {
			LB.notice("Start position must be less than end position");
		}

		Variables.remove("help");								// remove standard ht entries. 
		Variables.remove("text");								// Then process whatever is left with a warning:
		Variables.remove("map");
		Variables.remove("chr");
		Variables.remove("conf");
		Variables.remove("start");
		Variables.remove("end");
		Variables.remove("output");
		Variables.remove("size");
		Variables.remove("species");
		Variables.remove("input");
		Variables.remove("name");
		Variables.remove("prepend");
		
		Iterator<String> keys = Variables.keySet().iterator();
		
		if (keys.hasNext()) {
			LB.notice("keys : " + keys);
			LB.notice("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.notice("  " + k);
			}
			LB.die();
		}
		
	}
	
	
	/**
	 * includes the human chromosome map, but from a hard coded location.  Must change this!
	 * @param length
	 */
	private static void Init_map(int length) {
		if ( input_species.equalsIgnoreCase("Human")) {
			//TODO: should not be hardcoded.
			String mapfile = "/archive/solexa1_1/analysis_1/mappability/MAP_FILES/human/Homo_sapiens.NCBI36.42.dna.chromosome."
					+ chromosome + ".fa." + mapsize + "mappability";
			FastaIterator fim = new FastaIterator(LB, mapfile);
			String[] seq = fim.next();

			if (length != (seq[1].length()/2)) {
				LB.error("Mappability input does not match chromosome length: "+ length +", " +(seq[1].length()/2));
				LB.die();
			}
			mappability = new short[length];
			for (int q = 0; q < length; q++) {
				mappability[q] = Short.valueOf(seq[1].substring((2*q), (2*(q+1))));
			}
			fim.close();	
		} else {
			LB.warning("mappability Not Yet defined for species " + input_species);
			LB.warning("will skip mappability.");
			map = false;
		}
	}
	
	
	private static void draw_mappability(PrintWriter result_file) {
		if (input_species.equals("Human") || input_species.equals("human")) {
			for (int x= start_position-1; x<end_position-1; x++) {
				char a = ' ';
				float tmp =  ((float)mappability[x]/(float)mapsize);
				if (tmp < .20) {
					a = ' ';
				} else if (tmp < .40 ) {
					a = '_';
				} else if (tmp < .60 ) {
					a = '.';
				} else if (tmp < .80 ) {
					a = '-';
				} else {
					a = '^';
				}	
				result_file.write(a);
			}
			result_file.write("\n");
		}
	}
	
	
	private static Vector<AlignedRead> process_file(String f) {
		LB.notice("Processing files.");
		Vector<AlignedRead> Sequences = new Vector<AlignedRead>();
		ElandIterator ci = new ElandIterator(LB, "source", f, 0);	//open the source files
		while(ci.hasNext()) {
			AlignedRead alnrd = null;
			try {
				alnrd = ci.next();
			} catch (NoSuchElementException nsee) {
				continue;
			}
			if (alnrd.get_chromosome().compareToIgnoreCase(chromosome) == 0) {	//check if on correct chromosome
				alnrd.set_sort_score(-alnrd.get_alignStart());	 	//force comparator to give ascending scores.  	  
				if (alnrd.get_direction() == '+') {				//check for overlap between locations
					if ((alnrd.get_alignStart() > start_position) && (alnrd.get_alignEnd() < end_position)) {
						Sequences.add(alnrd);
						/*System.out.print(">");*/
					}	
				} else {
					if ((alnrd.get_alignStart() > start_position) && (alnrd.get_alignEnd() < end_position)) {
						
						Sequences.add(alnrd.clone_rc());
						/*System.out.print("<");*/
					}
				} 											// end else
			}												// end chromosome check
		}													// end while
		ci.close(false);
		return Sequences;
	}




	public static void main(String[] args) {

		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		new CurrentVersion(LB);
		LB.Version("AlignSlice", "$Revision: 1766 $");
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables);									//interprets command line args.

		LB.notice("Starting...");
		
		Ensembl ensembl = new Ensembl(LB, input_species);
		ensembl.get_ext_constants(conf_file);
		ensembl.loadEns();	
		ensembl.species_constants(chromosome);			

		LB.notice("Retrieving canonical sequence for chromosome...");

		String ffile = ensembl.getFastaFilename(chromosome, prepend);			//use location object to get canonical sequence
		FastaIterator fi = new FastaIterator(LB, ffile);					// for Chromosome (Fasta)
		String[] canonicalSequence = null;								//get one record at a time.  there should only ever be one.
		while (canonicalSequence == null && fi.hasNext()) {
			canonicalSequence = fi.next();
		}
		fi.close();

		LB.notice("Retrieving mappability/sequencability...");
		int length = canonicalSequence[1].length();
		if (map) {
			Init_map(length);
		}

		LB.notice("Searching for Reads in selection...");
		Vector<AlignedRead> Sequences = new Vector<AlignedRead>();
		for (String f : files) {
			Sequences.addAll(process_file(f));
		}

		if (Sequences.size() == 0) {
			LB.warning("No sequences found in selected region.  Terminating.");
			LB.die();
		}

		LB.notice("Sorting...");						//sort by start position		
		AlignedRead[] matching_reads = Sequences.toArray( new AlignedRead[Sequences.size()]); 
		Arrays.sort(matching_reads);

		if (text) {												//collapse using greedy algorithm and 
			ArrayList<String> strings = new ArrayList<String>();		//set distance between alignments.
			String temp = "";									//first string to boot strap 
			for (int spaces = 0; spaces < ((matching_reads[0].get_alignStart() - start_position)); spaces++ ) {
				temp = temp.concat(" ");
			}
			temp = temp.concat(matching_reads[0].get_sequence() + " "
					+ matching_reads[0].get_direction() + " "
					+ matching_reads[0].get_name());
			strings.add(temp);

			for (int rw = 1; rw < matching_reads.length; rw++) {//build remaining strings
				boolean success = false;
				int lines = 0;
				while(lines < strings.size() && !success) {
					if ((matching_reads[rw].get_alignStart() - start_position) > (strings
							.get(lines).toString().length() + SEPARATION)) {
						temp = strings.get(lines).toString();	//add to same line
						for (int spaces = temp.length(); spaces < ((matching_reads[rw]
								.get_alignStart() - start_position)); spaces++) {
							temp = temp.concat(" ");
						}
						temp = temp.concat(matching_reads[rw].get_sequence() + " "
								+ matching_reads[rw].get_direction() + " "
								+ matching_reads[rw].get_name());
						strings.set(lines, temp);
						success = true;
					}
					lines++;
				}
				if (!success) {
					temp = "";									//create a new line
					for (int spaces = 0; spaces < ((matching_reads[rw].get_alignStart() - start_position)); spaces++ ) {
						temp = temp.concat(" ");
					}
					temp = temp.concat(matching_reads[rw].get_sequence() + " "
							+ matching_reads[rw].get_direction() + " "
							+ matching_reads[rw].get_name());
					strings.add(temp);
				}
			}
				
			
			LB.notice("Opening output file...");		//open output_file;
			FileWriter fw = null;
			try {	
				fw = new FileWriter(output_file + name + ".txt");
			} catch (IOException io) {
				LB.error("Can't open output file " + output_file + name + ".txt");
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter result_file = new PrintWriter(bw);

			LB.notice("Printing sequences...");		//print out each row of the array

			for (int iterate = strings.size()-1; iterate >= 0; iterate--) {
				result_file.write(strings.get(iterate));
				result_file.write("\n");
			}

			result_file.write("\n");							//rulers and guides
			result_file.write(canonicalSequence[1].substring(start_position-1,end_position-1));
			result_file.write("\n");

			if (map) {											//draw mappability track
				draw_mappability(result_file);
			}

			int row_length = end_position - start_position;
			for (int col = 0; col < row_length; col++) {
				int here = ((start_position+col) % Constants.MOD_TEN);
				result_file.write(Integer.toString(here));
			}
			result_file.write("\n");

			int ruler_rows =0;

			String S_start_position= String.valueOf(start_position);
			String S_end_position = String.valueOf(end_position);
			if (S_start_position.length() > S_end_position.length()) {
				ruler_rows = S_start_position.length();
			} else {
				ruler_rows = S_end_position.length();
			}

			for (int rw = 1; rw < ruler_rows; rw++) {
				int tens = (int)Math.pow(10d,(double)rw);
				result_file.write(Integer.toString(((int)Math.floor((float)start_position / tens)) % (Constants.MOD_TEN)));
				for (int cols = 1; cols < row_length; cols++) {
					int cur_pos = start_position+cols;
					if ((cur_pos % tens) == 0 )  {
						result_file.write(Integer.toString(((int)Math.floor((float)cur_pos / tens)) % (Constants.MOD_TEN)));
					} else {
						result_file.write(" ");
					}
				}
				result_file.write("\n");	
			}

			LB.notice("Cleaning up...");
			result_file.close();								//close file
			LB.notice("Complete.");
		} else { 												//wig writer
			WigwriterBuffered wig = new WigwriterBuffered(LB, output_file + ".wig.gz", prepend, 1, MIN_COV);
			int[] cov = Coverage.generatePeakHeights_fixed_width(matching_reads, fixed_size);
			wig.browser_postion(chromosome, start_position, start_position + cov.length);
			wig.header("genome section", "Track Generated by AlignSlice");
			wig.section_header(chromosome, start_position + 1);
			for (int x : cov) {
				wig.writeln(x);
			}
			wig.close();

			if (map) {
				WigwriterBuffered mapf = new WigwriterBuffered(LB, output_file + "_map.wig.gz", prepend, 1, MIN_COV);
				mapf.header("mappability section", "Mapability - Track Generated by AlignSlice");
				mapf.section_header(chromosome, start_position + 1);
				for (int x= start_position-1; x<end_position-1; x++) {
					mapf.writeln(mappability[x]);
				}
				mapf.close();
			}
		}		
	
	}
	
}

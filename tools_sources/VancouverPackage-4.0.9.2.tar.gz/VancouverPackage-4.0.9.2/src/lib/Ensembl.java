package src.lib;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import org.ensembl.datamodel.Exon;
import org.ensembl.datamodel.Gene;
import org.ensembl.datamodel.Location;
import org.ensembl.datamodel.Transcript;

import org.ensembl.driver.AdaptorException;
import org.ensembl.driver.CoreDriver;
import org.ensembl.driver.CoreDriverFactory;
import org.ensembl.driver.ExonAdaptor;
import org.ensembl.driver.GeneAdaptor;
import org.ensembl.driver.TranscriptAdaptor;
import org.ensembl.variation.datamodel.VariationFeature;
import org.ensembl.variation.driver.VariationDriver;
import org.ensembl.variation.driver.VariationDriverFactory;
import org.ensembl.variation.driver.VariationFeatureAdaptor;

import src.lib.ioInterfaces.Log_Buffer;

// ESCA-JAVA0100:
/**
 * @version $Revision: 1290 $
 * @author 
 */
public class Ensembl {
	private static Hashtable<String, String> Variables = new Hashtable<String, String>();
	private static CoreDriver coreDriver;
	private static TranscriptAdaptor ta;
	private static ExonAdaptor xa;
	private static VariationFeatureAdaptor vfa;
	private static VariationDriver variationDriver;
	private static GeneAdaptor ga;
	
/*  Not using the following adaptor
 *	private static SequenceAdaptor sa;	
*/	
	
	/**
	 * Must set species when initializing a constants object
	 */
	private String species = null;
	/**
	 * Strings for connectivity and keeping track of chromosomes
	 */
	private String filepath = null;
	private String[] CHROMOSOMES = null;
	
	/**
	 * Log_buffer
	 */
	private static Log_Buffer LB;
	private static boolean display_version = true;
	
	/**
	 * @param i
	 * @return
	 */
	public final String get_chromosome(int i) {
		return this.CHROMOSOMES[i];
	}
	
	/**
	 * 
	 * @return
	 */
	public final int get_number_of_chromosomes() {
		return this.CHROMOSOMES.length;
	}

	public final int index_chromosomes(String x) {
		for (int a = 0; a < this.CHROMOSOMES.length; a++) {
			if (x.equals(this.CHROMOSOMES[a])) {
				return a;
			}
		}
		return -1;
	}
	
	
	/**
	 * @param logbuffer
	 * @param input_species
	 * @param conf_file
	 * @param input_chr
	 * @return
	 */
	public static Ensembl init(Log_Buffer logbuffer, String input_species, String conf_file, String input_chr) {
		Ensembl Const = new Ensembl(logbuffer, input_species);
		if (display_version) {
			LB.Version("Ensembl", "$Revision: 1290 $");
			display_version = false;
		}
		Const.get_ext_constants(conf_file);
		LB.notice("Initializing Ensembl DB/Ensembl Var DB connections.");
		Const.loadEns();
		Const.loadVariation();
		Const.species_constants(input_chr);
		LB.notice("Done");
		Const.print_setup();
		return Const;
	}
	
	/**
	 * 
	 * @return
	 */
	public static String get_sql_connect_string() {
		String sql_con = "jdbc:mysql://";
		sql_con += Ensembl.Variables.get("host") + ":"; 
		sql_con += Ensembl.Variables.get("port") + "/"; 
		sql_con += Ensembl.Variables.get("database") + "?user="; 
		sql_con += Ensembl.Variables.get("user") + "&password=";
		sql_con += Ensembl.Variables.get("password");
		return sql_con;
	}
	
	
	/**
	 * Print out keys in use.
	 */
	public void print_setup() {
		LB.notice("Variables in use:");	
		Enumeration<String> keys = Variables.keys();
		
		while (keys.hasMoreElements()) {
			String k = keys.nextElement();
			String l = " * " + k;
			for (int x = 0; x < 18-k.length(); x++ ) {
				l = l.concat(" ");
			}
			l = l.concat(": " + Variables.get(k));
			LB.notice(l);
			
		}	
	}
	
	/**
	 * 
	 * @param loc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Transcript> get_ta(Location loc) {
		List<Transcript> l = null;
		try {
			l = ta.fetch(loc);
		} catch (AdaptorException ae) {
			LB.error("Could not fetch from Transcript Adaptor.");
			LB.error("Message from Java environment (could be null): " + ae.getMessage());
			LB.die();
		}
		return l;
	}
	
	
	/**
	 * 
	 * @param loc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Gene> get_ga(Location loc) {
		List<Gene> l = null;
		try {
			l = ga.fetch(loc);
		} catch (AdaptorException ae) {
			LB.error("Could not fetch from Gene Adaptor.");
			LB.error("Message from Java environment (could be null): " + ae.getMessage());
			LB.die();
		}
		return l;
	}	
	
	
	/**
	 * 
	 * @param loc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<VariationFeature> get_vfa(Location loc) { 
		List<VariationFeature> l = null;
		try {
			l = vfa.fetch(loc);
		} catch (AdaptorException ae) {
			LB.error("Could not fetch from VariationFeature Adaptor.");
			LB.error("Message from Java environment (could be null): " + ae.getMessage());
			LB.die();
		}
		return l;
	}
	
	/**
	 * 
	 * @param loc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Exon> get_xa(Location loc) { 
		List<Exon> l = null;
		try {
			l = xa.fetch(loc);
		} catch (AdaptorException ae) {
			LB.error("Could not fetch from Exon Adaptor.");
			LB.error("Message from Java environment (could be null): " + ae.getMessage());
			LB.die();
		}
		return l;
	}
	
	/**
	 * 
	 */
	public void destroy() {
		coreDriver = null;
		ta = null;
		xa = null;
		vfa = null;
		variationDriver = null;
		ga = null;
/*		sa = null;
 */
		
		this.species = null;
		this.filepath = null;
		this.CHROMOSOMES = null;
	}
	
	/**
	 * 
	 * @param logbuffer
	 * @param species
	 */
	public Ensembl(Log_Buffer logbuffer, String species) {
		LB = logbuffer;
		this.species = species;
	}
	
	/**
	 * 
	 * @param chr
	 * @return
	 */
	public String getFastaFilename(int chr){	
		return this.filepath + get_chr_filename(chr);
	}
	
	
	/**
	 * Used for AlignSlice.  This could be cleaned up to use the above designation, though.
	 * @param chromosome
	 * @param prepend
	 * @return
	 */
	public String getFastaFilename(String chromosome, String prepend){
		if (chromosome.equals("M")) {
			return this.filepath + prepend + "MT";
		} else {
			return this.filepath + prepend + chromosome;
		}
	}
	/**
	 * 
	 * @param chr
	 * @return
	 */
	public String get_chr_filename(int chr) {
		if (CHROMOSOMES[chr].charAt(0) == 'M') {
			return "MT";
		} else {
			return CHROMOSOMES[chr];
		}
	}
	
	/**
	 * 
	 * @param chr
	 * @return
	 */
	public String get_chr_ucsc(int chr) {
		if (CHROMOSOMES[chr].equals("MT")) {
			return "M";
		} else {
			return CHROMOSOMES[chr];
		}
	}
	
	
	/**
	 * 
	 * @param chr
	 */
	public void species_constants(String chr) {
		this.filepath = Variables.get("filepath");
		String temp = null;
		if (chr.equals("A")) {
			temp = Variables.get("CHR");
		} else {
			temp = chr;
		}
		this.CHROMOSOMES = temp.split(",");
	}
	
	/**
	 * 
	 */
	public void loadEns() {
		try {
			coreDriver = CoreDriverFactory.createCoreDriver(
				Variables.get("host"),
				Integer.valueOf(Variables.get("port")),
				Variables.get("database"),
				Variables.get("user"),
				Variables.get("password"));
			ga = coreDriver.getGeneAdaptor();
/*		sa = coreDriver.getSequenceAdaptor(); */
			xa = coreDriver.getExonAdaptor();
			ta = coreDriver.getTranscriptAdaptor();
		} catch (AdaptorException ae) {
			LB.error("Could not initialize Ensembl Database Connection. Please check config file.");
			LB.error("Message from Java environment (could be null): " + ae.getMessage());
			LB.die();
		}
   } 
	
	/**
	 * This function loads the variation driver database and the associated adaptors
	 */	
	public void loadVariation()	{
		try {
			variationDriver = VariationDriverFactory.createVariationDriver(
					Variables.get("host"),
					Integer.valueOf(Variables.get("port")),
					Variables.get("SNPvardb"),
					Variables.get("user"),
					Variables.get("password"));
			variationDriver.setCoreDriver(coreDriver);
			vfa = variationDriver.getVariationFeatureAdaptor();
			if (vfa == null) {
				LB.error("Variation Database could not be loaded!");
				LB.die();
			}
		} catch (AdaptorException ae) {
			LB.error("Could not initialize Variation Database Connection. Please check config file.");
			LB.error("Message from Java environment (could be null): " + ae.getMessage());
			LB.die();
		}
	}
	
	/**
	 * 
	 * @param file
	 */
	public void get_ext_constants(String file) {
		
		BufferedReader br = null;
		String line = "";
		try {													//open file
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException fnf) {
			LB.error("Could not find file: " + file);
			LB.die();
		}
		assert (br != null);
		
		try {													//find Connection section in file		
			while (!line.trim().equalsIgnoreCase("[Connection]")) {
				line = br.readLine();							
			}
			line = br.readLine().trim();
			while (!line.startsWith("[") && (br.ready())) {  	//iterate until line starts with "["
				if (!line.startsWith("#") && line.trim().length() > 0 ) {
					String[] st = line.split("=");
					Variables.put(st[0], st[1]);
				}
				line = br.readLine(); 
			}
			br.close();
				
			try {												//open file again, to return to start,
				br = new BufferedReader(new FileReader(file));	// in case sections are out of order
			} catch (FileNotFoundException fnf) {
				LB.error("Could not find file " + file);
				LB.die();
			}
			
			while (!line.trim().equalsIgnoreCase("[" + this.species + "]")) {
				line = br.readLine();	
			}
			line = br.readLine().trim();
			while (!line.startsWith("[") && (br.ready())) {		//iterate until line starts with "["  
				if (!line.startsWith("#") && (line.length() > 2)) {
					String[] st = line.split("=");
					Variables.put(st[0], st[1].trim());
				}
				line = br.readLine(); 
			}
			br.close();
		} catch (IOException io) {
			LB.error("Error while reading constants. line = " + line);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}	
	}
	
	
}	
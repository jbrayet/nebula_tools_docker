package src.projects.SNP_Database.SnpIterators;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import src.lib.Constants;
import src.lib.Utilities;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;

/**
 * @version $Revision: 1631 $
 * @author 
 */
public class dbSNP126Iterator implements Iterator<SNP>, SNPIterator {
	private static boolean display_version = true;
	private static Log_Buffer LB;

	private static final int MAX_FIELDS = 7;
	private BufferedReader br = null;
	private int linecount = 0;
	private final String filename;
	private Vector<SNP> buffer;
	
	public dbSNP126Iterator(Log_Buffer logbuffer, String source_file) {
		LB = logbuffer;
		this.filename = source_file;
		if (display_version) {
			LB.Version("MaqSnpIterator", "$Revision: 1631 $");
			display_version = false;
		}
		try {
			br = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException e) {
			LB.error("Can't find file " + filename);
			LB.die();
		}
		buffer = new Vector<SNP>();
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		LB.notice(filename + " closed successfully");
		
	}
	
	
	/** 
	 * Read in next line of the SNP file
	 * 
	 * Expected format:
	 * chr     position ref    		   strand  ref     alt	   misc
	 * 1       544358  rs28482208      +       T       G       unknown exact
	 * 1       544598  rs9438503       +       G       A       locus   exact
	 * 1       544658  rs4120956       +       C       G       coding-nonsynon exact
	 * 
	 * @return SNP object
	 */
	public SNP next() {
		String line = null;
		Vector<SNP> S =  new Vector<SNP>();
		if (buffer.size() > 0) {
			return buffer.remove(0);
		}
		try {
			if ((line = br.readLine()) != null) {
				this.linecount++;	
				
				String[] elements = line.split("\t");				
				if (elements.length < MAX_FIELDS) {
					LB.error("Lack of fields in SNP file provided");
				}
				String chromosome 	= elements[0];
				int position 		= Integer.valueOf(elements[1]);
				//String misc			= elements[2] + " " + elements[6] + " " + elements[7];  //put in id field.
				char canonical		= elements[4].charAt(0);
				char alt 			= elements[5].charAt(0);
			
				
				char[] snps = Utilities.non_canonical_expansion(alt);
				for (char o : snps) {
					if (o != canonical) {
						S.add(new SNP(chromosome, position, o, canonical, -1, -1,
						 -1, -1, -1, -1, null));
					}
				}				
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
			}
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		if (S.size() > 1) {
			SNP first_snp = S.remove(0);
			buffer.addAll(S);
			return first_snp;
		} else {
			return S.firstElement();
		}
	}
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of SNPIterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

}

		
package src.projects.findPeaks.FDR;

import java.util.Vector;

import src.projects.findPeaks.PeakDataSetParent;
import src.projects.findPeaks.objects.MinPeakDesc;
import src.projects.findPeaks.objects.PairDistance;
import src.projects.findPeaks.objects.PeakPairIdx;
import src.projects.findPeaks.objects.Peakdesc;

public class MakePairs {

	private MakePairs() {}
	
	public static PeakPairIdx[] makepairs_window (PeakDataSetParent st1, PeakDataSetParent st2, int window_size) {
		Peakdesc[] s1  = st1.get_peak_store().get_array_of_peaks();
		Peakdesc[] s2  = st2.get_peak_store().get_array_of_peaks();
		Vector<PeakPairIdx> np = new Vector<PeakPairIdx>();
		int idx_1 = 0;
		int idx_2 = 0;

		while (idx_1 < s1.length && idx_2 < s2.length) {						//create a list of pairs
			Vector<PairDistance> possible_pairs = new Vector<PairDistance>();
			boolean keep_going = true;
			int pkm_loc1 = s1[idx_1].get_max_loc() + s1[idx_1].get_offset();
			int pkm_loc2 = s2[idx_2].get_max_loc() + s2[idx_2].get_offset(); 
			
			/*Add lower bound peak*/
			if (pkm_loc1 <= pkm_loc2) { 		//if they're equal, then this will just be a placeholder
				possible_pairs.add(new PairDistance( -1, idx_1, -1, idx_2));
			} else if (pkm_loc1 > pkm_loc2) {
				possible_pairs.add(new PairDistance( -1, -1, idx_2, idx_1));
			} 
				
			boolean need_upper_bound = true;
			while (keep_going) {
				if (idx_1 >= s1.length -1  || idx_2 >= s2.length -1 || Math.abs(pkm_loc1-pkm_loc2) > window_size) {
					break;
				}	
				if (pkm_loc1 == pkm_loc2) {
					possible_pairs.add(new PairDistance(0, idx_1, idx_2, -1));
					possible_pairs.add(new PairDistance(-1, idx_1, idx_2, -1)); //sets an allowed = false buffer between pairs.
					idx_1++;
					idx_2++;
					need_upper_bound = false;
				} else if (pkm_loc1 < pkm_loc2) { 
					if (s1[idx_1 + 1].get_max_loc() + s1[idx_1+1].get_offset() < pkm_loc2) {
						keep_going = false;
					} else {
						possible_pairs.add(new PairDistance(pkm_loc2-pkm_loc1, idx_1, idx_2, -1));
						idx_1++;
						need_upper_bound = true;								//pair entry, move to next;
					}			
				} else if (pkm_loc2 < pkm_loc1) { 
					if (s2[idx_2 + 1].get_max_loc() + s2[idx_2 + 1].get_offset() < pkm_loc1) {
						keep_going = false;
					} else {
						possible_pairs.add(new PairDistance(pkm_loc1-pkm_loc2, idx_1, idx_2, -1));
						idx_2++;
						need_upper_bound = true;								//pair entry, move to next;
					}			
				}
				pkm_loc1 = s1[idx_1].get_max_loc() + s1[idx_1].get_offset();
				pkm_loc2 = s2[idx_2].get_max_loc() + s2[idx_2].get_offset();
			}
			
			/*Add upperbound peak*/
			if (possible_pairs.size() > 1) {  //only add if there's more here than just one peak on it's own.
				if (need_upper_bound) { //if it's equal, this won't be needed
					if (pkm_loc1 <= pkm_loc2) { 
						possible_pairs.add(new PairDistance( -1, idx_1, -1, idx_2));
					} else if (pkm_loc1 > pkm_loc2) {
						possible_pairs.add(new PairDistance( -1, -1, idx_2, idx_1));
					}  
				}
			} 
			if (pkm_loc1 <= pkm_loc2) {
				idx_1++;
			} else {
				idx_2++;
			}
			PairDistance[] cluster = possible_pairs.toArray(new PairDistance[possible_pairs.size()]); 
		
			/*Process cluster of peaks*/
			boolean ok = true;
			int remaining = cluster.length;
			while (ok) {
				if (cluster.length == 1) {
					break;
				}
				for (int x = 1; x < cluster.length-1; x++) {  //first and last are markers, and don't need to be iterated over
					if (!cluster[x].allowed()) {
						continue;
					}
					if ((cluster[x].get_distance() < cluster[x-1].get_distance() 
							|| cluster[x-1].get_distance() == -1 
							|| !cluster[x-1].allowed())
					&&  (cluster[x].get_distance() < cluster[x+1].get_distance() 
							|| cluster[x+1].get_distance() == -1 
							|| !cluster[x+1].allowed())) {
						/*make the pair and send back.*/
						int i1 = cluster[x].get_pk_idx_1();
						int i2 = cluster[x].get_pk_idx_2();
						np.add(new PeakPairIdx(i1, i2, s1[i1].get_height(), s2[i2].get_height())); 
						cluster[x-1].not_allowed();
						cluster[x].not_allowed();
						cluster[x+1].not_allowed();
					}
				}
				/*check if anything left;*/
				int tmp = 0;
				for (int x =1; x < cluster.length-1; x++) {
					if (cluster[x].allowed()) {
						tmp++;
					}
				}
				if (tmp == 0) {
					ok = false;		//only reach this point if the peaks are all paired, used.
				}
				if (tmp != remaining) {
					remaining = tmp;
				} else {
					PeakPairIdx[] ties = break_ties(cluster, st1, st2, s1, s2, window_size);
					for(PeakPairIdx t: ties) {
						np.add(t);
					}
				}
			}
			/*check if either of the ends need to be paired*/
			PeakPairIdx tmp = check_ends(st1, st2, s1, s2, cluster[0], window_size);
			if (tmp != null) {
				np.add(tmp);
			}
			tmp = check_ends(st1, st2, s1, s2, cluster[cluster.length-1], window_size);
			if (tmp != null) {
				np.add(tmp);
			}			
		} // return to next cluster of peaks, or continue to return the set of peaks found.
		return np.toArray(new PeakPairIdx[np.size()]);
	}

	public static PeakPairIdx[] makepairs_window (MinPeakDesc[] sample, PeakDataSetParent ctrl, int window_size) {
		Peakdesc[] control  = ctrl.get_peak_store().get_array_of_peaks();
		Vector<PeakPairIdx> np = new Vector<PeakPairIdx>();
		int idx_1 = 0;
		int idx_2 = 0;

		while (idx_1 < sample.length && idx_2 < control.length) {						//create a list of pairs
			Vector<PairDistance> possible_pairs = new Vector<PairDistance>();
			boolean keep_going = true;
			int pkm_loc1 = sample[idx_1].get_max_loc() + sample[idx_1].get_offset();
			int pkm_loc2 = control[idx_2].get_max_loc() + control[idx_2].get_offset(); 
			
			/*Add lower bound peak*/
			if (pkm_loc1 <= pkm_loc2) { 		//if they're equal, then this will just be a placeholder
				possible_pairs.add(new PairDistance( -1, idx_1, -1, idx_2));
			} else if (pkm_loc1 > pkm_loc2) {
				possible_pairs.add(new PairDistance( -1, -1, idx_2, idx_1));
			} 
				
			boolean need_upper_bound = true;
			while (keep_going) {
				if (idx_1 >= sample.length -1  || idx_2 >= control.length -1 || Math.abs(pkm_loc1-pkm_loc2) > window_size) {
					break;
				}	
				if (pkm_loc1 == pkm_loc2) {
					possible_pairs.add(new PairDistance(0, idx_1, idx_2, -1));
					possible_pairs.add(new PairDistance(-1, idx_1, idx_2, -1)); //sets an allowed = false buffer between pairs.
					idx_1++;
					idx_2++;
					need_upper_bound = false;
				} else if (pkm_loc1 < pkm_loc2) { 
					if (sample[idx_1 + 1].get_max_loc() + sample[idx_1+1].get_offset() < pkm_loc2) {
						keep_going = false;
					} else {
						possible_pairs.add(new PairDistance(pkm_loc2-pkm_loc1, idx_1, idx_2, -1));
						idx_1++;
						need_upper_bound = true;								//pair entry, move to next;
					}			
				} else if (pkm_loc2 < pkm_loc1) { 
					if (control[idx_2 + 1].get_max_loc() + control[idx_2 + 1].get_offset() < pkm_loc1) {
						keep_going = false;
					} else {
						possible_pairs.add(new PairDistance(pkm_loc1-pkm_loc2, idx_1, idx_2, -1));
						idx_2++;
						need_upper_bound = true;								//pair entry, move to next;
					}			
				}
				pkm_loc1 = sample[idx_1].get_max_loc() + sample[idx_1].get_offset();
				pkm_loc2 = control[idx_2].get_max_loc() + control[idx_2].get_offset();
			}

			/*Add upperbound peak*/
			if (possible_pairs.size() > 1) {  //only add if there's more here than just one peak on it's own.
				if (need_upper_bound) { //if it's equal, this won't be needed
					if (pkm_loc1 <= pkm_loc2) { 
						possible_pairs.add(new PairDistance( -1, idx_1, -1, idx_2));
					} else if (pkm_loc1 > pkm_loc2) {
						possible_pairs.add(new PairDistance( -1, -1, idx_2, idx_1));
					}  
				}
			} 
			if (pkm_loc1 <= pkm_loc2) {
				idx_1++;
			} else {
				idx_2++;
			}
			PairDistance[] cluster = possible_pairs.toArray(new PairDistance[possible_pairs.size()]); 

			/*Process cluster of peaks*/
			boolean ok = true;
			int remaining = cluster.length;
			while (ok) {
				if (cluster.length == 1) {
					break;
				}
				for (int x = 1; x < cluster.length-1; x++) {  //first and last are markers, and don't need to be iterated over
					if (!cluster[x].allowed()) {
						continue;
					}
					if ((cluster[x].get_distance() < cluster[x-1].get_distance() 
							|| cluster[x-1].get_distance() == -1 
							|| !cluster[x-1].allowed())
					&&  (cluster[x].get_distance() < cluster[x+1].get_distance() 
							|| cluster[x+1].get_distance() == -1 
							|| !cluster[x+1].allowed())) {
						/*make the pair and send back.*/
						int i1 = cluster[x].get_pk_idx_1();
						int i2 = cluster[x].get_pk_idx_2();
						np.add(new PeakPairIdx(i1, i2, sample[i1].get_height(), control[i2].get_height())); 
						cluster[x-1].not_allowed();
						cluster[x].not_allowed();
						cluster[x+1].not_allowed();
					}
				}
				/*check if anything left;*/
				int tmp = 0;
				for (int x =1; x < cluster.length-1; x++) {
					if (cluster[x].allowed()) {
						tmp++;
					}
				}
				if (tmp == 0) {
					ok = false;		//only reach this point if the peaks are all paired, used.
				}
				if (tmp != remaining) {
					remaining = tmp;
				} else {
					PeakPairIdx[] ties = break_ties_asym(cluster, ctrl, sample, control, window_size);
					for(PeakPairIdx t: ties) {
						np.add(t);
					}
				}
			}
			/*check if either of the ends need to be paired*/
			PeakPairIdx tmp = check_ends_asym(ctrl, sample, control, cluster[0], window_size);
			if (tmp != null) {
				np.add(tmp);
			}
			tmp = check_ends_asym(ctrl, sample, control, cluster[cluster.length-1], window_size);
			if (tmp != null) {
				np.add(tmp);
			}			
		} // return to next cluster of peaks, or continue to return the set of peaks found.
		return np.toArray(new PeakPairIdx[np.size()]);
	}
	

	// ESCA-JAVA0138:
	/**
	 *   Performs checks on ends of each cluster region.
	 * @param smpl
	 * @param ctrl
	 * @param sample
	 * @param control
	 * @param pd
	 * @param window_size
	 * @return
	 */
	private static PeakPairIdx check_ends(PeakDataSetParent smpl, PeakDataSetParent ctrl,
			Peakdesc[] sample, Peakdesc[] control, PairDistance pd, int window_size) {
		
		if (pd.allowed()) {
			if (pd.get_pk_idx_1() != -1) {
				int idx = pd.get_pk_idx_1();
				int pkm_loc = sample[idx].get_max_loc() + sample[idx].get_offset();
				float pk_height = sample[idx].get_height();
				int start = (sample[idx].get_offset() > pkm_loc - window_size) 
					? sample[idx].get_offset() : (pkm_loc - window_size);
				int end = (sample[idx].get_length() + sample[idx].get_offset()  < pkm_loc + window_size) 
					? sample[idx].get_length() + sample[idx].get_offset() : (pkm_loc + window_size);
				pd.not_allowed();
				return new PeakPairIdx(idx, -1, pk_height, get_tallest_point(ctrl, control, start, end, pd.get_hint()));
			} else {
				int idx = pd.get_pk_idx_2();
				int pkm_loc = control[idx].get_max_loc() + control[idx].get_offset();
				float pk_height = control[idx].get_height();
				int start = (control[idx].get_offset() > pkm_loc - window_size) 
					? control[idx].get_offset() : (pkm_loc - window_size);
				int end = (control[idx].get_length() + control[idx].get_offset()  < pkm_loc + window_size) 
					? control[idx].get_length() + control[idx].get_offset() : (pkm_loc + window_size);
				pd.not_allowed();
				return new PeakPairIdx(-1, idx, get_tallest_point(smpl, sample, start, end, pd.get_hint()), pk_height);
			}
		}
		return null;
	}
	
	// ESCA-JAVA0138:
	/**
	 *   Performs checks on ends of each cluster region.
	 * @param ctrl
	 * @param sample
	 * @param control
	 * @param pd
	 * @param window_size
	 * @return
	 */
	private static PeakPairIdx check_ends_asym(PeakDataSetParent ctrl,
			MinPeakDesc[] sample, Peakdesc[] control, PairDistance pd, int window_size) {
		
		if (pd.allowed()) {
			if (pd.get_pk_idx_1() != -1) {
				int idx = pd.get_pk_idx_1();
				int pkm_loc = sample[idx].get_max_loc() + sample[idx].get_offset();
				float pk_height = sample[idx].get_height();
				int start = (sample[idx].get_offset() > pkm_loc - window_size) 
					? sample[idx].get_offset() : (pkm_loc - window_size);
				int end = (sample[idx].get_length() + sample[idx].get_offset()  < pkm_loc + window_size) 
					? sample[idx].get_length() + sample[idx].get_offset() : (pkm_loc + window_size);
				pd.not_allowed();
				return new PeakPairIdx(idx, -1, pk_height, get_tallest_point(ctrl, control, start, end, pd.get_hint()));
			} else {
				return null;								//not intersted in peaks called in control;
			}
		}
		return null;
	}
	
	
	// ESCA-JAVA0138:
	private static PeakPairIdx[] break_ties(PairDistance[] pd, PeakDataSetParent st1, PeakDataSetParent st2,
			Peakdesc[] s1, Peakdesc[] s2, int window_size) {
		Vector<PeakPairIdx> tmp = new Vector<PeakPairIdx>();
		boolean repeat = false;
		for (int x=1; x < pd.length-1; x++) {
			if (pd[x].allowed()
					&& (pd[x].get_distance() == pd[x+1].get_distance()
					|| pd[x].get_distance() == pd[x-1].get_distance())) {
				repeat = true;
				pd[x].not_allowed();
				tmp.add(process_smaller(pd[x], st1, st2, s1, s2, window_size));
			} else if (repeat) {
				tmp.add(process_larger(pd[x-1], st1, st2, s1, s2, window_size));
				repeat = false;
			}
		}
		return tmp.toArray(new PeakPairIdx[tmp.size()]);
	}
	
	
	// ESCA-JAVA0138:
	private static PeakPairIdx[] break_ties_asym(PairDistance[] pd, PeakDataSetParent ctrl,
			MinPeakDesc[] sample, Peakdesc[] control, int window_size) {
		Vector<PeakPairIdx> tmp = new Vector<PeakPairIdx>();
		boolean repeat = false;
		for (int x=1; x < pd.length-1; x++) {
			if (pd[x].allowed()
					&& (pd[x].get_distance() == pd[x+1].get_distance()
					|| pd[x].get_distance() == pd[x-1].get_distance())) {
				repeat = true;
				pd[x].not_allowed();
				PeakPairIdx a = process_smaller_asym(pd[x], ctrl, sample, control, window_size);
				if (a != null ) {
					tmp.add(a);
				}
			} else if (repeat) {
				PeakPairIdx a = process_larger_asym(pd[x-1], ctrl, sample, control, window_size); 
				if (a != null) {
					tmp.add(a);
				}
				repeat = false;
			}
		}
		return tmp.toArray(new PeakPairIdx[tmp.size()]);
	}
	

	
	// ESCA-JAVA0138:
	private static PeakPairIdx process_smaller(PairDistance pd, PeakDataSetParent st1, PeakDataSetParent st2,
			Peakdesc[] s1, Peakdesc[] s2, int window_size) {
		
		int idx_1 = pd.get_pk_idx_1();
		int idx_2 = pd.get_pk_idx_2();
	
		int pkm_loc1 = s1[idx_1].get_max_loc() + s1[idx_1].get_offset();
		int pkm_loc2 = s2[idx_2].get_max_loc() + s2[idx_2].get_offset();
		if (pkm_loc1 < pkm_loc2) {
			float pk_height = s1[idx_1].get_height();
			int start = (s1[idx_1].get_offset() > pkm_loc1 - window_size) 
				? s1[idx_1].get_offset() : (pkm_loc1 - window_size);
			int end = (s1[idx_1].get_length() + s1[idx_1].get_offset()  < pkm_loc1 + window_size) 
				? s1[idx_1].get_length() + s1[idx_1].get_offset() : (pkm_loc1 + window_size);
			return new PeakPairIdx(idx_1, -1, pk_height, get_tallest_point(st2, s2, start, end, idx_2));
		} else {
			float pk_height = s2[idx_2].get_height();
			int start = (s2[idx_2].get_offset() > pkm_loc2 - window_size) 
				? s2[idx_2].get_offset() : (pkm_loc2 - window_size);
			int end = (s2[idx_2].get_length() + s2[idx_2].get_offset()  < pkm_loc2 + window_size) 
				? s2[idx_2].get_length() + s2[idx_2].get_offset() : (pkm_loc2 + window_size);
			return new PeakPairIdx(-1, idx_2, get_tallest_point(st1, s1, start, end, idx_1), pk_height);		
		}
	}	
	
	// ESCA-JAVA0138:
	private static PeakPairIdx process_smaller_asym(PairDistance pd, PeakDataSetParent ctrl,
			MinPeakDesc[] sample, Peakdesc[] control, int window_size) {
		
		int idx_1 = pd.get_pk_idx_1();
		int idx_2 = pd.get_pk_idx_2();
	
		int pkm_loc1 = sample[idx_1].get_max_loc() + sample[idx_1].get_offset();
		int pkm_loc2 = control[idx_2].get_max_loc() + control[idx_2].get_offset();
		if (pkm_loc1 < pkm_loc2) {
			float pk_height = sample[idx_1].get_height();
			int start = (sample[idx_1].get_offset() > pkm_loc1 - window_size) 
				? sample[idx_1].get_offset() : (pkm_loc1 - window_size);
			int end = (sample[idx_1].get_length() + sample[idx_1].get_offset()  < pkm_loc1 + window_size) 
				? sample[idx_1].get_length() + sample[idx_1].get_offset() : (pkm_loc1 + window_size);
			return new PeakPairIdx(idx_1, -1, pk_height, get_tallest_point(ctrl, control, start, end, idx_2));
		} else {
			return null;						//ignore peaks that are called from the control.
		}
	}	

	// ESCA-JAVA0138:
	private static PeakPairIdx process_larger(PairDistance pd, PeakDataSetParent st1, PeakDataSetParent st2,
			Peakdesc[] s1, Peakdesc[] s2, int window_size) {
		int idx_1 = pd.get_pk_idx_1();
		int idx_2 = pd.get_pk_idx_2();
		int pkm_loc1 = s1[idx_1].get_max_loc() + s1[idx_1].get_offset();
		int pkm_loc2 = s2[idx_2].get_max_loc() + s2[idx_2].get_offset();
		if (pkm_loc1 > pkm_loc2) {
			float pk_height = s1[idx_1].get_height();
			int start = (s1[idx_1].get_offset() > pkm_loc1 - window_size) 
				? s1[idx_1].get_offset() : (pkm_loc1 - window_size);
			int end = (s1[idx_1].get_length() + s1[idx_1].get_offset()  < pkm_loc1 + window_size) 
				? s1[idx_1].get_length() + s1[idx_1].get_offset() : (pkm_loc1 + window_size);
			return new PeakPairIdx(idx_1, -1, pk_height, get_tallest_point(st2, s2, start, end, idx_2));
		} else {
			float pk_height = s2[idx_2].get_height();
			int start = (s2[idx_2].get_offset() > pkm_loc2 - window_size) 
				? s2[idx_2].get_offset() : (pkm_loc2 - window_size);
			int end = (s2[idx_2].get_length() + s2[idx_2].get_offset()  < pkm_loc2 + window_size) 
				? s2[idx_2].get_length() + s2[idx_2].get_offset() : (pkm_loc2 + window_size);
			return new PeakPairIdx(-1, idx_2, get_tallest_point(st1, s1, start, end, idx_1), pk_height);		
		}
	}

	// ESCA-JAVA0138:
	private static PeakPairIdx process_larger_asym(PairDistance pd, PeakDataSetParent ctrl,
			MinPeakDesc[] sample, Peakdesc[] control, int window_size) {
		int idx_1 = pd.get_pk_idx_1();
		int idx_2 = pd.get_pk_idx_2();
		int pkm_loc1 = sample[idx_1].get_max_loc() + sample[idx_1].get_offset();
		int pkm_loc2 = control[idx_2].get_max_loc() + control[idx_2].get_offset();
		if (pkm_loc1 > pkm_loc2) {
			float pk_height = sample[idx_1].get_height();
			int start = (sample[idx_1].get_offset() > pkm_loc1 - window_size) 
				? sample[idx_1].get_offset() : (pkm_loc1 - window_size);
			int end = (sample[idx_1].get_length() + sample[idx_1].get_offset()  < pkm_loc1 + window_size) 
				? sample[idx_1].get_length() + sample[idx_1].get_offset() : (pkm_loc1 + window_size);
			return new PeakPairIdx(idx_1, -1, pk_height, get_tallest_point(ctrl, control, start, end, idx_2));
		} else {
			return null;				//ignore peaks called from control;
		}
	}


	/**
	 * 
	 * @param pds
	 * @param s
	 * @param start
	 * @param end
	 * @param idx_start
	 * @return
	 */
	private static float get_tallest_point(PeakDataSetParent pds, Peakdesc[] s, int start, int end, int idx_start) {
		float max_ht = 0;
		int idx = idx_start;		
		while (idx >= 0 && s[idx].get_offset() + s[idx].get_length() > start) {
			final int offset = s[idx].get_offset();
			if ((offset < end && offset > start) 							//we have overlap
					|| (s[idx].get_length() + offset > start  && s[idx].get_length() + offset < end) ) {
				float point = pds.highest_point(idx, start, end);			//search overlap for tallest point...
				if (point > max_ht) {
					max_ht  = point;
				}
			}					
			idx--;
		}
		idx = idx_start;
		while (idx < s.length && s[idx].get_offset() < end) {
			final int offset = s[idx].get_offset();
			if ((offset < end && offset > start)							//we have overlap 
					|| (s[idx].get_length() + offset > start  && s[idx].get_length() + offset < end) ) {
				float point = pds.highest_point(idx, start, end);			//search overlap for tallest point...
				if (point > max_ht) {
					max_ht  = point;
				}
			}
			idx++;
		}
		return max_ht;
	}	
	
	
	
	
	
}

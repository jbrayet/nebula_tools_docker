package src.lib.objects;

/**
* @author Genome Sciences Centre
* @version $Revision: 1019 $
*/
public class Aberation_SNP extends Aberation {

	
	
	private final float spans_short;
	private final float spans_expected;
	private final float spans_long;
	
	// ESCA-JAVA0138:
	public Aberation_SNP(char type, String chromosome, int start, int span,
			String comment, float shorter, float expected, float longer) {
		super(type, chromosome, start, span, comment);
		this.spans_short = shorter;
		this.spans_expected = expected;
		this.spans_long = longer;
	}

	
	public float get_spans_short() { return this.spans_short; }
	public float get_spans_exp() { return this.spans_expected; }
	public float get_spans_long() { return this.spans_long; }
	
	
}

package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;

import src.lib.Constants;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;

/**
 * @version $Revision: 1790 $
 * @author 
 */
public class MapviewMAQIterator implements AlignedReadsIterator {
	private static boolean display_version = true;
	String name = null;
	BufferedReader br = null;
	int linecount = 0;
	int UXcnt = 0;
	private int number_filtered;
	private Log_Buffer LB;
	final int max_PET_len;
	private final int qualityfilter;
	private int[] PET_filters = null;
	
	public MapviewMAQIterator(Log_Buffer log_file, String name, String source_file,
			int qualityfilter, int max_PET_len) {
		LB = log_file;
		if (display_version) {
			LB.Version("MapviewMAQIterator", "$Revision: 1790 $");
			display_version = false;
		}
		this.max_PET_len = max_PET_len;
		this.name = name;
		this.qualityfilter=qualityfilter;
		try {
			if (source_file.equals("PIPE")){
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			else if (source_file.endsWith(".gz")) {
				br = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(source_file))));
			} else {
				
				br = new BufferedReader(new FileReader(source_file));
			}
		} catch (FileNotFoundException e) {
			if (source_file.endsWith(".gz")) {
				try {
					LB.warning("Couldn't find Mapview file: " + source_file);
					source_file = source_file.substring(0,source_file.length()-3);
					LB.warning("Trying file: " + source_file);
					br = new BufferedReader(new FileReader(source_file));
					LB.notice("Success");
				} catch (FileNotFoundException f) {
					LB.error("Can't find Mapview file (notzipped) " + source_file);
					LB.die();
				}
			} else {
				LB.error("Can't open Mapview file " + source_file);
				if (source_file.endsWith(".gz")) {
					LB.error("Tried to open as gzip.");
				}
				LB.die();
			}
		} catch (IOException io) {
			LB.error("Couldn't open file: " + source_file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	
	public void apply_filters(String filters) {
		String[] tmp = filters.split(",");
		this.PET_filters= new int[tmp.length];
		for (int a = 0;  a < tmp.length; a++) {
			this.PET_filters[a] = Integer.valueOf(tmp[a]);
		} 
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public boolean reset() {
		try {
			br.reset();
			return true;
		} catch (IOException ioe) {
			LB.error("Could not reset input file for read buffer.");
			return false;
		}
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Ux records : " + this.UXcnt);
		}
	}
	
	public boolean apply_PET_filter(int flag) {
		boolean cont = false;
		for (int b : this.PET_filters) {
			if (b == flag) {
				cont = true;
			}
		}
		return cont;
	}
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of Iterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}
	


/* read name,
 * chromosome, 
 * position, 
 * strand, 
 * insert size from the outer coorniates of a pair, 
 * paired flag, 
 * mapping quality, 
 * single-end mapping quality, 
 * alternative mapping quality, 
 * number of mismatches of the best hit, 
 * sum of qualities of mismatched bases of the best hit, 
 * number of 0-mismatch hits of the first 24bp, 
 * number of 1-mismatch hits of the first 24bp on the reference, 
 * length of the read, 
 * read sequence and its quality
 * */
	
	
/*	SET
	6_171_609_863_reverse scaffold_1 79342 - 0 0 22 22 22 0 0 3 6  36
	6_79_732_595_reverse scaffold_1  79347 + 0 0 19 19 19 0 0 1 12 36
	7_48_500_640_forward scaffold_1  79349 - 0 0 0  0  0  0 0 2 15 36
	6_108_995_988_forward scaffold_1 79351 - 0 0 20 20 20 0 0 1 9  36
*/
	
/*	PET
	6_2_168_638/2	scaffold_0	52	+	188	130	0	0	36	5	200	0	0	36
	6_120_780_550/1	scaffold_0	85	+	191	18	99	0	0	1	30	1	1	36
	5_135_515_678/1	scaffold_0	128	+	0	64	0	0	0	1	30	2	0	36
	6_70_346_124/1	scaffold_0	130	+	0	64	0	0	0	2	60	2	0	36
	7_76_522_530/1	scaffold_0	184	+	174	130	0	0	99	4	160	0	0	36
	6_29_299_721/1	scaffold_0	194	+	185	18	99	57	57	0	0	1	0	36
*/
	

	// ESCA-JAVA0076:
	public AlignedRead next() {
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				String[] fields = line.split("\t");
				boolean cont=true;
				this.linecount++;	
				int alignStart 		= Integer.parseInt(fields[2]); 	//79342
				int alignlength 	= Integer.parseInt(fields[13]);
				//do not use fields 4, 5, 7, 8 or 10:		
				/* test conditions */
				if (Integer.parseInt(fields[6]) < qualityfilter){
					cont=false;
				}
				else if (this.PET_filters != null) {
					cont = apply_PET_filter(Integer.parseInt(fields[5]));
				}
				else if (this.max_PET_len > 0 && alignlength > this.max_PET_len) {
					cont=false;
				}
				if (cont) {
					AlignedRead a = null;
					try {
						new AlignedRead(
							fields[3].charAt(0),					/*direction*/
							fields[0],								/*seq_name*/
							fields[14],								/*Sequence*/
							Integer.parseInt(fields[6]), 			/*score*/
							0,										/*seqStart*/
							0,										/*seqEnd*/
							null,									/*alignName*/
							fields[1],								/*chromosome*/
							alignStart,
							alignStart + alignlength,				/*alignEnd = alignStart + alignEnd*/
							0,										/*percent*/
							0,										/*P*/
							null,									/*alignseq*/
							Integer.parseInt(fields[9]),				/*mismatches*/
							0,										/*sort_score*/
							0,										/*queryLength*/
							0,										/*alignLength*/
							0,										/*contigStart*/
							0,										/*contigEnd*/
							0,										/*identity*/
							null,									/*Match*/
							Integer.parseInt(fields[11]),			/*matches_noError*/
							Integer.parseInt(fields[12]),			/*matches_1error*/
							0,										/*matches_2error*/
							null,									/*N_reads*/
							null,									/*error1*/
							null,									/*error2*/
							null);									/*quality*/
					} catch (UnexpectedResultException URE) {
						LB.error("Line " + linecount + " has an invalid read:");
						LB.error(URE.getMessage());
					}
					return a;
				}else{
					number_filtered++;
					continue;
				}
			} 
		} catch (IOException io) {
			LB.error("Error reading Mapview file on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		throw new NoSuchElementException("Could not get any more reads.");
	}

	/**
	 * Return the number of filtered read while iterating.
	 * @return the number of read filtered
	 */
	public int get_NumberFilteredRead()
	{
		return number_filtered;
	}
}

		
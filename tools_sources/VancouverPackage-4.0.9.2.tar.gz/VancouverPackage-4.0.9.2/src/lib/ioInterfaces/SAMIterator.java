package src.lib.ioInterfaces;

import java.io.File;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


import net.sf.samtools.AlignmentBlock;
import net.sf.samtools.SAMFileReader;
import net.sf.samtools.SAMRecord;
import net.sf.samtools.util.CloseableIterator;

import src.lib.CurrentVersion;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;

// ESCA-JAVA0100:
/**
 * @version $Revision: 936 $
 * @author
 */
public class SAMIterator implements AlignedReadsIterator {

	public static final int ALLOWS_SPLIT_READ = 1;
	public static final int NO_SPLIT_READ = 2;

	private static boolean display_version = true;
	String Name = null;
	int type;
	int max_PET_len;
	int qualityfilter;
	private SAMFileReader inputSam = null;
	private CloseableIterator<SAMRecord> iterator = null;
	private SAMRecord next_valid_record = null;
	private LinkedList<AlignedRead> buffer_read = new LinkedList<AlignedRead>();
	//private SortedSet<AlignedRead> buffer_read= new TreeSet<AlignedRead>();
	int linecount = 0;
	// final int max_PET_len;
	private Log_Buffer LB;
	int number_filtered;
	
	
	// ESCA-JAVA0138:  too many fields - it's sometimes necessary.
	/**
	 * Create a SamIterator
	 * @param log_file
	 * @param Name
	 * @param source_file
	 * @param max_PET_len
	 * @param qualityfilter
	 * @param type
	 * @param silence_warning
	 */
	public SAMIterator(Log_Buffer log_file, String Name, String source_file,
			int max_PET_len, int qualityfilter, int type, boolean silence_warning) {
		LB = log_file;
		if (display_version) {
			LB.Version("SAMIterator", "$Revision: 936 $");
			display_version = false;
		}
		this.number_filtered = 0;
		this.max_PET_len = max_PET_len;
		this.qualityfilter = qualityfilter;
		this.Name = Name;
		this.type = type;
		// ESCA-JAVA0166: SAMFileReader can throw about 10 different types of exception, none of which can be handled here.
		try {
			if (source_file.equals("PIPE")) {
				inputSam = new SAMFileReader(System.in);
			} else {
				inputSam = new SAMFileReader(new File(source_file));
			}
			if (silence_warning){
				inputSam.setValidationStringency(SAMFileReader.ValidationStringency.SILENT);
			}
			else {
				inputSam.setValidationStringency(SAMFileReader.ValidationStringency.LENIENT);
			}
			iterator = inputSam.iterator();
		} catch (Exception e) {
			LB.error("Exception was caught in SamIterator contruction.");
			LB.error("Exception type=" + e.getClass().toString());
			LB.error("Exception message=" + e.getMessage());
			LB.die();
		}
	}
	
	// ESCA-JAVA0138: more parameters than 5.  It happens.
	/**
	 * Create SamIterator that enable warnings
	 * @param log_file
	 * @param Name
	 * @param source_file
	 * @param max_PET_len
	 * @param qualityfilter
	 * @param type
	 */
	public SAMIterator(Log_Buffer log_file, String Name, String source_file,
			int max_PET_len, int qualityfilter, int type) {
		this(log_file, Name, source_file, max_PET_len, qualityfilter, type, false);
	}

	/**
	 * @deprecated
	 */
	public void apply_filters(String f) {
		throw new UnsupportedOperationException();
	}

	public boolean mark() {
		return false;
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

	public boolean reset() {
		return false;
	}

	public void close(boolean verbose) {
		try {
			iterator.close();
			inputSam.close();
		} catch (Exception e) {
			LB.error("Exception was caught while closing SAMIterator.");
			LB.error("Exception type=" + e.getClass().toString());
			LB.error("Exception message=" + e.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.Name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Lines Filtered: " + this.number_filtered);
		}
	}

	public boolean hasNext() {
		if (buffer_read.size() > 0) {
			return true;
		}
		SAMRecord record = get_valid_SAMRecord();
		if (record == null) {
			return false;
		} else {
			return true;
		}
	}

	private SAMRecord get_valid_SAMRecord() {
		if (next_valid_record != null) {
			return next_valid_record;
		}
		while (iterator.hasNext() && next_valid_record == null){
			next_valid_record = iterator.next();
			linecount += 1;
			if (next_valid_record.getReadUnmappedFlag()) {
				next_valid_record = null;
				number_filtered += 1;
			} else if (this.type == NO_SPLIT_READ
					&& next_valid_record.getAlignmentBlocks().size() > 1) {
				next_valid_record = null;
				number_filtered += 1;
			} else if (next_valid_record.getMappingQuality() < this.qualityfilter) {
				next_valid_record = null;
				number_filtered += 1;
			} else if (this.max_PET_len > 0
					&& next_valid_record.getReadLength() > this.max_PET_len) {
				next_valid_record = null;
				number_filtered += 1;
			} 
		}
		
		return next_valid_record;
	}

	
	private AlignedRead create_AlignedRead_From_AlignmentBlock(
			SAMRecord record, AlignmentBlock block) {
		AlignedRead A = null;
		try {
			String block_sequence = record.getReadString().substring(
					block.getReadStart() - 1,
					block.getReadStart() - 1 + block.getLength());
			byte[] block_qualities = Arrays.copyOfRange(record
					.getBaseQualities(), block.getReadStart() - 1, block
					.getReadStart()
					- 1 + block.getLength());
			int alt_qual=0;
			Object r=record.getAttribute("AM");
			if (r!=null){
				if (r instanceof Short)
				{
					Short n = (Short) r;
					alt_qual=n;
				}else{
					alt_qual=(Integer) r;
				}
			}
			int nb_mismatch=0;
			r=record.getAttribute("NM");
			if (r!=null){
				if (r instanceof Short)
				{
					Short n = (Short) r;
					nb_mismatch=n;
				}else{
					nb_mismatch=(Integer) r;
				}
			}
			A = new AlignedRead(
					record.getReadNegativeStrandFlag() ? '-' : '+', /* char direction */
				record.getReadName(),								/* String Name */
				block_sequence, 									/* String Sequence */
				record.getMappingQuality(), 						/* int score */
				alt_qual, 											/* int seqStart */
				0, 													/* int seqEnd */
				null, 												/* String alignName */
				record.getReferenceName(), 							/* String chromosome */
				block.getReferenceStart(), 							/* int alignStart */
				block.getReferenceStart() + block.getLength() - 1, 	/* int alignEnd */
				0.0, 												/* double percent */
				0.0, 												/* double P */
				null, 												/* String alignseq */
				// TODO: Should we keep the number of mismatches when several blocks???
				nb_mismatch,										/* int mismatches */
				-block.getReferenceStart(), 						/* double sort_score */
				0, 													/* int queryLength */
				block.getLength(),									/* int alignLength */
				0,													/* int contigStart */
				0,													/* int contigEnd */
				0,													/* int identity */
				null,													/* String Match */
				0,													/* int matches_noError */
				0,													/* int matches_1error */
				0,													/* int matches_2error */
				null,												/* String N_reads */
				null,												/* String error1 */
				null,												/* String error2 */
				block_qualities										/* byte[] quality */
			);
		} catch (UnexpectedResultException URE) {
			LB.error("Line " + linecount + " has an invalid read:");
			LB.error(URE.getMessage());
		}
		return A;
	}

	public AlignedRead next() {
		
		SAMRecord record = get_valid_SAMRecord();
		if (record!=null){
			// check the buffer of reads first.
			if (buffer_read.size() > 0) {
				AlignedRead tmp_read =buffer_read.getFirst();
				if (tmp_read.get_chromosome().compareTo(record.getReferenceName()) != 0 
						|| tmp_read.get_alignStart() <= record
								.getAlignmentStart()) {
					buffer_read.remove(0);
					return tmp_read;
				}
			}
		
			// here I know that the buffer is empty or contains reads that are
			// further than the current record
			List<AlignmentBlock> list_block = record.getAlignmentBlocks();
			Iterator<AlignmentBlock> iter_block = list_block.iterator();
			AlignedRead read_to_return = create_AlignedRead_From_AlignmentBlock(
					record, iter_block.next());
			if (list_block.size() > 1) {
				// other parts of a split read
				while (iter_block.hasNext()) {
					AlignedRead read = create_AlignedRead_From_AlignmentBlock(
							record, iter_block.next());
					sorted_insert_in_List(read);
				}
			}
			next_valid_record = null;
			return read_to_return;
		}
		
		if (buffer_read.size() > 0) {
			AlignedRead tmp_read =buffer_read.getFirst();
			buffer_read.remove(0);
			return tmp_read;
		}
		return null;
	}
	
	private void sorted_insert_in_List(AlignedRead current_read){
		int pos=0;
		for (Iterator<AlignedRead> iter=buffer_read.iterator();iter.hasNext();pos++){
			int res= current_read.compareTo(iter.next());
			if (res<=0){
				break;
			}
		}
		buffer_read.add(pos,current_read);
	}

	/**
	 * Return the number of filtered read while iterating.
	 * 
	 * @return the number of filtered read
	 */
	public int get_NumberFilteredRead() {
		return number_filtered;
	}
	
	// ESCA-JAVA0266: Ignore system out printstream.
	public static void main(String args[]) {
		String sam_file = "/projects/wtsspipeline/dev/New_pipeline_test/HS1400_1_lane_merged.bam";
		Log_Buffer LB = Log_Buffer.getLogBufferInstance();
		LB.addPrintStream(System.out);
		new Thread(LB).start();
		new CurrentVersion(LB);
		SAMIterator sam_iterator = new SAMIterator(LB, "SAM_file_test",
				sam_file, 2000, 0, SAMIterator.ALLOWS_SPLIT_READ);
		// SAMIterator sam_iterator=new
		// SAMIterator(LB,"SAM_file_test",sam_file,2000,0,SAMIterator.NO_SPLIT_READ);
		int i = 0;
		int prev_start = 0;
		String prev_chr = "";
		while (sam_iterator.hasNext() && i < 100) {
			AlignedRead read = sam_iterator.next();
			int start = read.get_alignStart();
			String chr = read.get_chromosome();
			// LB.notice("start="+read.get_alignStart()+"\tlength="+
			//(read.get_alignEnd()-read.get_alignStart()+1)+"\tread_length="+read.get_alignLength());
			if (read.get_alignLength() < 50) {
				LB.notice(read.get_sequence());
				LB.notice("" + read.get_alignLength());
			}
			if (chr.compareTo(prev_chr) == 0 && start < prev_start) {
				LB.error("previous start " + prev_chr + ":" + prev_start
						+ " is > than start " + chr + ":" + start);
			}
			prev_start = start;
			prev_chr = chr;
			i++;

		}
		LB.notice(i + " reads");
		sam_iterator.close(false);
		LB.die();
	}

}

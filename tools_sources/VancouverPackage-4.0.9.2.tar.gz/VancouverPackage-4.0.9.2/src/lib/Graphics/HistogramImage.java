package src.lib.Graphics;

import src.lib.Histogram;
import src.lib.ioInterfaces.Log_Buffer;

public class HistogramImage extends BasicImage {

	
	private static final int GRAPH_MAX_HT = 1000;
	private static final int GRAPH_MAX_WD = 1000;
	private static final int GRAPH_MARGIN = 23;
	private static final int GRAPH_GAP = 6;
	
	/**
	 * Creates a 1000x1000 graph with a 23 pixel border.
	 * 
	 * to print, use the .write_to_file method.
	 * don't forget to use .close() afterwards.
	 * 
	 * 
	 * @param log_buffer
	 * @param file_type
	 * @param H
	 */
	public HistogramImage(Log_Buffer log_buffer, String file_type, Histogram H) {
		
		
		super(log_buffer, file_type, GRAPH_MARGIN + GRAPH_MAX_HT + 1, GRAPH_MARGIN + GRAPH_MAX_WD + 1);  //1024x1024
		draw_axes();
		draw_bins(H);
	}
	
	public void draw_axes() {
		g2d.drawLine(GRAPH_MARGIN, 0, GRAPH_MARGIN, GRAPH_MAX_HT);
		g2d.drawLine(GRAPH_MARGIN, GRAPH_MAX_HT, GRAPH_MARGIN + GRAPH_MAX_WD, GRAPH_MAX_HT);
	}
	
	private void draw_bins(Histogram H) {
		int num_bins = H.get_num_bins();
		if (num_bins >= GRAPH_MAX_WD) {
			LB.warning("capping histogram image at 800 bins");
			num_bins = GRAPH_MAX_WD-1;
		}
		int g_bin_width = (int) Math.floor((double)GRAPH_MAX_WD/num_bins);
		int spacing = 0;
		if ((g_bin_width/4) > 1) {
			spacing = (int) Math.floor((double)g_bin_width/4);
			g_bin_width -= spacing;
		}
		//normalize
		long max_ht = 0;
		//long min_ht = 0;
		for (int x = 0; x < num_bins; x++)  {
			long t = H.get_bin_value(0);
			if (max_ht < t) {
				max_ht = t;
			}
/*	currently assuming all bins are positive.
 * 
 * 		if (min_ht > t) {
				min_ht = t;
			}
*/		} 
		//put some labels on the graph
		g2d.drawString(Long.toString(max_ht), GRAPH_GAP, 3);
		g2d.drawString("0", GRAPH_GAP, GRAPH_MAX_HT);
		g2d.drawString("0", GRAPH_MARGIN, GRAPH_MAX_HT + GRAPH_GAP);
		g2d.drawString("0", GRAPH_MAX_WD-GRAPH_MARGIN, GRAPH_MAX_HT + GRAPH_GAP);
		for (int x = 0; x < num_bins; x++) {
			long t = H.get_bin_value(0);
			g2d.drawRect(GRAPH_MARGIN + (x * g_bin_width) + (x * spacing),		//x
					GRAPH_MAX_HT-(int)Math.floor((double)t/max_ht),				//y
					g_bin_width,												//width
					(int)Math.floor((double)t/max_ht));							//height
		}
	}
	
}

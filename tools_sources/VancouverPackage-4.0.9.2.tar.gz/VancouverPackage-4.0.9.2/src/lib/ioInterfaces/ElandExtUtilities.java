package src.lib.ioInterfaces;

public class ElandExtUtilities {

	private ElandExtUtilities() {}
	
	
	public static String parse_mismatches(String Sequence, char[] match_info) {
		StringBuffer alnseq = new StringBuffer(Sequence);
		String shift = "";
		int curr_pos = 0;
		for (char x : match_info) {
			if (!Character.isDigit(x)) {
				if (!shift.equals("")) {
					curr_pos += Integer.parseInt(shift); 
				}
				alnseq.setCharAt(curr_pos, x);
				curr_pos++;
				shift = "";
			} else {
				//is not base
				shift += x;
			}
		}
		return alnseq.toString();
	}
	
	public static String undo_parse_mismatches(String Sequence, String alinseq) /*char[] match_info)*/ {
		
		StringBuffer s = new StringBuffer();
		int lastwrite = 0;
		for (int x = 0; x < Sequence.length(); x++) {
			if (Sequence.charAt(x) != alinseq.charAt(x)) {
				int pos = x-lastwrite;
				s.append( ((pos == 0) ? "" : String.valueOf(pos)) + alinseq.charAt(x));
				lastwrite = x+1;
			}
		}
		s.append(Sequence.length()-lastwrite);
		return s.toString();
	}
	
	
	
	
}

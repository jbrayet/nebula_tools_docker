#!/usr/bin/env python
''' this script writes a new config file (in the CWD). The input configfile does not contains motifnames and possibly no letter frequencies parameters. This scripts create a new configfile with the missing parameters included.

	in :  old config_file, flag : [name_freq|name], LetterFreqFile
		name : it indicates that the letterFreqFile will not be used. The script will write motif names lines only (BASIC)
		name_freq : indicates that LetterFreqFile must be used. So the script will write both MotifFilename AND letterFreqFile lines
	out:  new complete, ready-to-use config file
	
	run example : python replaceLine.py configfile.txt name_freq Path_to_LetterFreqFile
	This script could be improved.
	'''
import sys

configfile=sys.argv[1]
if (sys.argv[2] == "name_freq"):
	letterFreqFile=sys.argv[3]

f_in=open(configfile, "rw")
f_out=open("new_config.txt", "w")
i=0

for line in f_in.readlines():
	if line.startswith("MotifFilename"):
		motifLine=line.replace("MotifFilename", "MotifFilename motif_%i.txt" % i)
		f_out.write(motifLine)
		i+=1
		
 	elif line.startswith("LetterFreqFile"):
 		motifLine=line.replace("LetterFreqFile", "LetterFreqFile %s" % letterFreqFile)
		f_out.write(motifLine)
 	else:
		f_out.write(line)

f_in.close()
f_out.close()



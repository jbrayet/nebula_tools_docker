package src.projects.findPeaks.objects;

import java.math.BigDecimal;
import java.util.Vector;

import src.lib.StatisticsTools;
import src.lib.Utilities;
import src.lib.ioInterfaces.Log_Buffer;

// ESCA-JAVA0100:
public class LinearRegressionPerpendicular {

	private static Log_Buffer LB;
	private static boolean display_version = true;
	
	private PeakPairIdx[] dataset;  //first value is x, second value is y
	private int n;
	private double slope;
	private double intercept = 0;
	private double sigma = 0;
	private BigDecimal Sxy = BigDecimal.ZERO;
	private BigDecimal Sy2 = BigDecimal.ZERO; //Sum (yi^2)
	private BigDecimal Sx2 = BigDecimal.ZERO; //sum (xi^2);
	private BigDecimal Sy = BigDecimal.ZERO;
	private BigDecimal Sx = BigDecimal.ZERO;
	private double Sdd = 0;
	private double Sd = 0;

	private double X_bar = 0;
	private double Y_bar = 0;

	/**
	 * This module works only for linear regression in the positive quadrant. If
	 * values are negative, it will result in excessive recalculations.
	 * 
	 * @param logbuffer
	 * @param d
	 */
	public LinearRegressionPerpendicular(Log_Buffer logbuffer, PeakPairIdx[] d) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("LinearRegressionPerpendicular", "$Revision: 1525 $");
			display_version = false;
		}
		this.n = d.length * 5; //puts in 10 [0,0]'s for each value. Anchor at zero,zero
		if (d.length == 0) {
			LB.warning("Can't run a Linear Regression calculation with zero points.");
			this.dataset = null;  //first value is x, second value is y
			this.slope = Double.NaN;
			return;
		}
		this.dataset = new PeakPairIdx[d.length];
		System.arraycopy(d, 0, this.dataset, 0, d.length);
		
		if (this.dataset.length < 120) {
			LB.warning("sample size is smaller than 120, so t values used are probably not accurate.");
		}
		Sums_and_squares();
		slope();
		distribution_from_line();
		LB.notice("Best Fit line for Regression:  y = (" + 
				Utilities.DecimalPoints(this.slope, 5) + ")x + " +  
				Utilities.DecimalPoints(intercept, 5));
	}
		
	public void new_dataset(PeakPairIdx[] pairs) {
		this.dataset = new PeakPairIdx[pairs.length];
		System.arraycopy(pairs, 0, this.dataset, 0, pairs.length);
	}
	
	
	/**
	 * Function to get slope, from wolfram:
	 * http://mathworld.wolfram.com/LeastSquaresFittingPerpendicularOffsets.html
	 */
	private final void slope() {
		BigDecimal t1 = Sy2.subtract(BigDecimal.valueOf(n * Y_bar * Y_bar));
		BigDecimal t2 = Sx2.subtract(BigDecimal.valueOf(n * X_bar * X_bar));
		BigDecimal t3 = BigDecimal.valueOf(n * X_bar * (Y_bar));		
		t1 = t1.subtract(t2);
		t3 = t3.subtract(Sxy);								//Sxy is not the same as in other linear regression.
		if (t3.compareTo(BigDecimal.ZERO) == 0) {
			t3 = BigDecimal.ONE;
			LB.error("division by zero averted by change to divide by one. " +
					"Calculations will go on - but should not be used for this chromosome.");
		}
		t2 = t1.divide(t3, BigDecimal.ROUND_HALF_EVEN);		// reuse t2 variable.  
		t1 = t2.divide(BigDecimal.valueOf(2));				//t1 = B
		BigDecimal sqrtB = BigDecimal.valueOf(Math.sqrt(((t1.multiply(t1)).add(BigDecimal.ONE)).doubleValue()));
		/* calculate slope */
		t2 = ((BigDecimal.ZERO).subtract(t1)).subtract(sqrtB);					//slope 1
		t3 = ((BigDecimal.ZERO).subtract(t1)).add(sqrtB);						//slope 2	
		double slope1 = t2.doubleValue();
		double slope2 = t3.doubleValue();		
		if (slope1 <= 0) { 
			this.slope = slope2;
		} else if (slope2 <= 0 ) {
			this.slope = slope1;
		} else {
			LB.notice("Both slopes calculated are greater than zero: " + slope1 + "\t" + slope2);
		}
		/* calculate intercept */
		this.intercept = Y_bar - (X_bar * this.slope);
	}
		
	private final void Sums_and_squares() {	
		for (PeakPairIdx a : this.dataset) { 
			Sx  = Sx .add(BigDecimal.valueOf(a.get_height_1()));
			Sx2 = Sx2.add(BigDecimal.valueOf(a.get_height_1() * a.get_height_1()));
			Sy  = Sy .add(BigDecimal.valueOf(a.get_height_2()));
			Sy2 = Sy2.add(BigDecimal.valueOf(a.get_height_2() * a.get_height_2()));
			Sxy = Sxy.add(BigDecimal.valueOf(a.get_height_1() * a.get_height_2()));
		}
		this.X_bar = Sx.doubleValue()/n;
		this.Y_bar = Sy.doubleValue()/n;
	}
	
	
	private final void distribution_from_line() {
		double[] values = new double[this.dataset.length];
		for (int x = 0; x < this.dataset.length; x++) {
			values[x] = distance_to_line(this.dataset[x].get_height_1(), this.dataset[x].get_height_2());
			this.Sd += values[x];
			this.Sdd += (values[x] * values[x]);
		}
		this.sigma = Math.sqrt(this.Sdd / (this.dataset.length - 2));
	}
	
	public void recalculate_sigma() {
		double[] values = new double[this.dataset.length];
		for (int x = 0; x < this.dataset.length; x++) {
			values[x] = distance_to_line(this.dataset[x].get_height_1(), this.dataset[x].get_height_2());
			this.Sd += values[x];
			this.Sdd += (values[x] * values[x]);
		}
		this.sigma = Math.sqrt(this.Sdd / (this.dataset.length - 2));
		this.n = this.dataset.length;
	}
	
	
	/**
	 * Returns the signed distance
	 * @param x
	 * @param y
	 * @return
	 */
	private final double distance_to_line(double x, double y) {
		//distance is (mx+ay+b)/sqrt(m^2 + a^2)  (a is always -1 in this case)
		return ((this.slope*x) - y + this.intercept) / Math.sqrt((this.slope * this.slope) + 1);
	}
	
	private static final double get_sigma_n(double alpha) {
		double ci = 1-alpha;
		return Math.sqrt(2) * StatisticsTools.erfi(ci);
	}
		
	
	private static final float get_alpha(double sigma) {
		return (float) (1 - StatisticsTools.erf(sigma/Math.sqrt(2)));
	}
	
	
	
	
	public final PeakPairIdx[] filter(double alpha, int minimum) {
		
		if (Double.isNaN(this.slope)) {
			LB.warning("Can not apply filter. A valid slope was not obtained from the analysis.");
			PeakPairIdx[] d = new PeakPairIdx[this.dataset.length];
			System.arraycopy(this.dataset, 0, d, 0, this.dataset.length);
			return d;
		}
		
		Vector<PeakPairIdx> f = new Vector<PeakPairIdx>();
		double t_compare = get_sigma_n(alpha);
		for (PeakPairIdx d : this.dataset) { 
			if (minimum >= 1 && d.get_height_1() < minimum && d.get_height_2() < minimum) {
				continue;
			}
			float x = d.get_height_1();
			float y = d.get_height_2();
			
			// heights may be less than zero if the log transform is on, but
			// they should be treated as though they were zeros, otherwise the
			// distance to the line will be exagerated.
			if (x < 0) { x = 0; } 
			if (y < 0) { y = 0; }
			
			final double g = (distance_to_line(x, y));
			double b = (g * g) / (Sdd - ((Sd * Sd)/n));
			final double e = b + (1d/ n) + 1;
			b = Math.sqrt(e * (this.sigma * this.sigma));
			//e = t*b;
			
			double t_obs = g/b; 
			double p = get_alpha(((g > 0) ? g : -g)/b);			//use only -g for calculating p value.
			d.set_p_value((p < 0) ? 0 : p);
			
			
			if (t_obs <= -t_compare && d.get_pk_idx_2() != -1) {
				f.add(d);
			} else if (t_obs >= t_compare && d.get_pk_idx_1() != -1) {
				f.add(d);
			}
		}		
		return f.toArray(new PeakPairIdx[f.size()]);
	}
	
	
	public final PeakPairIdx[] filter_below_only(double alpha, int minimum) {
		
		if (Double.isNaN(this.slope)) {
			LB.warning("Can not apply filter. A valid slope was not obtained from the analysis.");
			PeakPairIdx[] d = new PeakPairIdx[this.dataset.length];
			System.arraycopy(this.dataset, 0, d, 0, this.dataset.length);
			return d;
		}
		
		Vector<PeakPairIdx> f = new Vector<PeakPairIdx>();
		double t_compare = get_sigma_n(alpha * 2);
		for (PeakPairIdx d : this.dataset) { 
			if (minimum >= 1 && d.get_height_1() < minimum && d.get_height_2() < minimum) {
				continue;
			}
			final double g = distance_to_line(d.get_height_1(), d.get_height_2());
			double b = (g * g) / (Sdd - ((Sd * Sd)/n));
			final double e = b + (1d/ n) + 1;
			b = Math.sqrt(e * (this.sigma * this.sigma));
			//e = t*b);
			
			double t_obs = (g/b); 
			double p = get_alpha(((g > 0) ? g : -g)/b);			//use only -g for calculating p value.
			d.set_p_value((p < 0) ? 0 : p);
			
			//TODO: verify this.
			if ( t_obs >= t_compare && d.get_pk_idx_1() != -1) {
				f.add(d);
			} 
		}		
		return f.toArray(new PeakPairIdx[f.size()]);
	}
	
	public final float get_slope() {
		return (float) this.slope;
	}
	
	public final float get_intercept() {
		return (float) this.intercept;
	}
	
		
	public final void write_data() {
		LB.notice("n:         " + this.n);
		LB.notice("Sx:        " + this.Sx);
		LB.notice("Sy:        " + this.Sy);
		LB.notice("X_bar:     " + this.X_bar);
		LB.notice("Y_bar:     " + this.Y_bar);
		LB.notice("Sxy:       " + this.Sxy);
		LB.notice("Sx2:       " + this.Sx2);
		LB.notice("Sy2:       " + this.Sy2);
		LB.notice("slope:     " + this.slope);
		LB.notice("intercept: " + this.intercept);		
	}
	
}

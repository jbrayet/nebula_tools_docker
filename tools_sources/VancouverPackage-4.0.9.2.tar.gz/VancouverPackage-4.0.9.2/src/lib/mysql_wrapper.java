package src.lib;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.HashMap;

import src.lib.Error_handling.CanNotConnectException;

import src.lib.ioInterfaces.Log_Buffer;

/**
 * @version $Revision: 488 $
 * @author 
 */
public class mysql_wrapper {

	private static Log_Buffer LB;
	private static boolean display_version = true;

	private static boolean initialized;
	private static Connection mysql_connection;


	/**
	 * A good source of fibre, and examples for how to use the mysql connector:
	 * 
	 * http://dev.mysql.com/doc/refman/5.0/en/connector-j-usagenotes-basic.html#connector-j-examples-connection-drivermanager
	 */
	
	
	public void destroy() {
		mysql_connection = null;
		initialized = false;
	}
	
	
	public static mysql_wrapper init(Log_Buffer logbuffer) {
		mysql_wrapper m = new mysql_wrapper(logbuffer);
		return m;
	}
	
	

	public mysql_wrapper(Log_Buffer logbuffer) {
		LB = logbuffer; 
		if (display_version) {
			LB.Version("mysql_wrapper", "$Revision: 488 $");
			display_version = false;
		}
		//TODO:shoud probably get constants.
		
		String sql_con = Ensembl.get_sql_connect_string();
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();	
		} catch (IllegalAccessException iae) {
			LB.error("Failed to load mysql jdbc driver");
			LB.error("Message thrown by Java environment (may be null):" + iae.getMessage());
			LB.die();	
		} catch (InstantiationException ie) {
			LB.error("Failed to instantiate mysql jdbc driver");
			LB.error("Message thrown by Java environment (may be null):" + ie.getMessage());
			LB.die();	
		} catch (ClassNotFoundException cnfe) {
			LB.error("Could not find mysql jdbc driver class");
			LB.error("Message thrown by Java environment (may be null):" + cnfe.getMessage());
			LB.die();	
		}
			
		try {
			
			mysql_connection =  DriverManager.getConnection(sql_con);
		} catch (SQLException ex) {	
			LB.error("SQLException: " + ex.getMessage());
			LB.error("SQLState: " + ex.getSQLState());
			LB.error("VendorError: " + ex.getErrorCode());
			LB.die();
		}

		
		initialized = true;
	}
	
	
	
	public static ResultSet get_exon_ids(long transcript_id) throws Exception {
		if (!initialized) {
			LB.warning("attempted to use get_exon_transcript_mapings without initializing connection first");
			throw new Exception();
		}
		Statement stmt = mysql_connection.createStatement();
	    String query = "SELECT exon_id FROM exon_transcript WHERE transcript_id = " + transcript_id + " ORDER BY rank";
	    return stmt.executeQuery(query);
	}

	
	
	
	
		///********************* Functions for retrieving information **********************/
 
	
	
	/**
	 * 
	 * @return result set as a hash table, string and integer of exon to transcript mappings.
	 * @throws CanNotConnectException
	 */
	public HashMap<String, Integer> get_exon_transcript_mapings() throws CanNotConnectException {
		if (!initialized) {
			throw new CanNotConnectException("attempted to use get_exon_transcript_mapings without initializing connection first");
		}
		ResultSet rs = null;
		HashMap<String, Integer> map = new HashMap<String, Integer>();
	    String key = null;
	    Integer value = 0;
		
		try {
			Statement stmt = mysql_connection.createStatement();
		    String query = "SELECT exon_id, transcript_id, rank FROM exon_transcript";
			rs = stmt.executeQuery(query);
			while (rs.next()) {
		    	key = rs.getInt("transcript_id") + "-" + rs.getInt("rank");
		    	value = rs.getInt("exon_id");
		    	map.put(key, value);
		    }
			stmt.close();
			rs.close();
		} catch (SQLException sql) {
			throw new CanNotConnectException(sql.getMessage());
		}
		
   	    return map;
	}		

	
}


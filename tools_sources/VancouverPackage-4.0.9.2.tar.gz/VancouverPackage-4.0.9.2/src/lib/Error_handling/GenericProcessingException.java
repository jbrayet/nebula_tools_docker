package src.lib.Error_handling;

/**
 * @author GPL Software
 * @version "$Revision: 558 $"
 */

public class GenericProcessingException extends Exception {

	/**
	 * Generated serialVersion.  I have no idea how this works.
	 */
	private static final long serialVersionUID = -5229108092768466661L;
	
	public GenericProcessingException(String message) {
		super(message);
	}
	
}

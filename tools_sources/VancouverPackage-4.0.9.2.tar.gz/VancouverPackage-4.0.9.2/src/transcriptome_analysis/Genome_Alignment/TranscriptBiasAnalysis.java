package src.transcriptome_analysis.Genome_Alignment;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.ensembl.datamodel.Location;
import org.ensembl.datamodel.Transcript;

import src.lib.Chromosome;
import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.CurrentVersion;
import src.lib.Ensembl;
import src.lib.Histogram;
import src.lib.IterableIterator;
import src.lib.ReducedAlignedReads;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.analysisTools.Transcript_Bias;
import src.lib.ioInterfaces.FastaIterator;
import src.lib.ioInterfaces.Log_Buffer;

// ESCA-JAVA0100:
/**
 * @version $Revision: 1667 $
 * @author 
 */
public class TranscriptBiasAnalysis {
	/* current state for Transcriptome processor*/
	private static Ensembl Const;
	private static Chromosome Chr;
	private static int current_chromosome;
	private static Log_Buffer LB = null;

	/* Histogram size */
	private static final int HIST_BINS = 140;
	private static final int HIST_START = -20;
	private static final int HIST_WIDTH = 120;

	/* whole genome stats*/
	private static int[] Bias_start = new int[Constants.BIAS_PERCENT];
	private static int[] Bias_end = new int[Constants.BIAS_PERCENT];
	private static Histogram Bias_overall = new Histogram(LB, HIST_BINS,
			-HIST_START, HIST_WIDTH, false);

	/* input variables*/
	private static String elandfile_path;
	private static String output_path;
	private static String input_species;
	private static String input_chr;
	private static float min_percent;
	private static int min_observed;
	private static String conf_file;
	private static String name;

	private TranscriptBiasAnalysis() {
	}

	/**
	 * Processing command line arguments for program.
	 * 
	 * @param Variables
	 *            Command line arguments: input path, output path, Species,
	 *            Chromosome(s), min snp percent, min snp observed.
	 */
	private static void parse_input(HashMap<String, String> Variables) {

		if (Variables == null) {
			usage();
		}

		assert (Variables != null);

		if (Variables.containsKey("help")) {
			usage();
		}

		
		/* Do bootstrap calls here */
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.notice("file names must be supplied with -name flag");
			usage();
		}
		
		if (Variables.containsKey("output")) {
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + name  + ".log");
			LB.addLogFile(output_path + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag");
			usage();
		}
		
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output directory  : " + output_path);		
		LB.notice(" * Name              : " + name);
		
		
		if (Variables.containsKey("force32")) {
			CommandLine.test_parameter_count(LB, "force32", Variables.get("force32"), 0);
			Chromosome.set_force32(true);
			LB.notice(" * Filter Duplicates : On");
		} else {
			Chromosome.set_force32(false);
			LB.notice(" * Filter Duplicates : Off");
		}

		if (Variables.containsKey("min_alt")) {
			CommandLine.test_parameter_count(LB, "min_alt", Variables.get("min_alt"), 1);
			min_percent = Float.parseFloat(Variables.get("min_alt"));
			if (min_percent > 1 || min_percent < 0) {
				LB.error("Min_alt value must be in the range of zero to one.");
				LB.close();
				System.exit(0);
			}
		} else {
			LB.error("Must specify minimum alternative base percent for SNP positions with the -min_alt flag");
			usage();
		}
		LB.notice(" * Min. change fract : " + min_percent);

		if (Variables.containsKey("min_obs")) {
			CommandLine.test_parameter_count(LB, "min_obs", Variables.get("min_obs"), 1);
			min_observed = Integer.parseInt(Variables.get("min_obs"));
		} else {
			LB.error("Must specify minimum observed base count for SNP positions with the -min_obs flag");
			usage();
		}
		LB.notice(" * Minimum coverage  : " + min_observed);

		if (Variables.containsKey("conf")) {
			CommandLine.test_parameter_count(LB, "conf", Variables.get("conf"), 1);
			conf_file = Variables.get("conf");
			LB.notice(" * Config file       : " + conf_file);
		} else {
			LB.error("Must specify config file with the -conf flag");
			usage();
		}

		if (Variables.containsKey("chr")) {
			CommandLine.test_parameter_count_min(LB, "chr", Variables.get("chr"), 1);
			input_chr = Variables.get("chr");
			LB.notice(" * Chromosome in use : " + input_chr);
		} else {
			LB.error("chomosome must be supplied with -chr flag");
			usage();
		}

		if (Variables.containsKey("species")) {
			CommandLine.test_parameter_count(LB, "species", Variables.get("species"), 1);
			input_species = Variables.get("species");
			LB.notice(" * Input Species     : " + input_species);
		} else {
			LB.error("input species must be supplied with -input flag");
			usage();
		}

		if (Variables.containsKey("input")) {
			CommandLine.test_parameter_count(LB, "input", Variables.get("input"), 1);
			elandfile_path = Variables.get("input");
			if (!elandfile_path.endsWith(System.getProperty("file.separator"))) {
				elandfile_path = elandfile_path.concat(System.getProperty("file.separator"));
			}
			LB.notice(" * Input directory   : " + elandfile_path);
		} else {
			LB.error("An input directory must be supplied with the -input flag");
			usage();
		}

		Variables.remove("input"); //remove standard ht entries. 
		Variables.remove("output"); //Then process whatever is left with a warning:
		Variables.remove("species");
		Variables.remove("chr");
		Variables.remove("min_alt");
		Variables.remove("min_obs");
		Variables.remove("force32");
		Variables.remove("conf");
		Variables.remove("name");

		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  " + k);
			}
			LB.die();
		}
	}

	private static void usage() {
		LB.notice("This program requires six parameters:");
		LB.notice(" -input   | <String> | provide the full path to the eland files.");
		LB.notice(" -output  | <String> | provide a valid path for the output.");
		LB.notice(" -species | <String> | Provide a Species handled in the conf file");
		LB.notice(" -chr     | <String> | Indicate which chromosome to run, or \"A\" for all.");
		LB.notice(" -min_alt | <Float>  | Indicate the minimum fraction for calling a snp (eg 0.5");
		LB.notice(" -min_obs | <Int>    | Indicate the minimum coverage that must be observed to call. (eg 4)");
		LB.notice(" -force32 |          | use to force the maximum read length to be 32 bases.");
		LB.notice(" -conf    | <String> | The location of the configuration file to use.");
		LB.close();
		System.exit(0);
	}

	

	private static void write_whole_transcript_bias() {
		BufferedWriter bias_file = null;
		int bias_width = Constants.BIAS_PERCENT / 2;
		try {
			bias_file = new BufferedWriter(new FileWriter(output_path
					+ "Transcriptome.bias"));
			bias_file.write("Start Bias:\n");
			for (int N = 0; N < Bias_start.length; N++) {
				bias_file.write((N - bias_width) + " " + Bias_start[N] + "\n");
			}
			bias_file.write("End Bias:" + "\n");
			for (int N = 0; N < Bias_end.length; N++) {
				bias_file.write((N - bias_width) + " " + Bias_end[N] + "\n");
			}
			bias_file.write("Overall Bias:" + "\n");
			Bias_overall.print_bins(bias_file);
			bias_file.close();
		} catch (IOException io) {
			LB.error("Can't write bias files");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}

	}

	/**
	 * Main function for processing Transcriptome data.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();

		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables); //interprets command line args.

		new CurrentVersion(LB);
		LB.Version("TranscriptBiasAnalysis", "$Revision: 1667 $");
		
		Const = Ensembl.init(LB, input_species, conf_file, input_chr);

		int read_count = 0;
		int fail_count = 0;
		int coverage = 0;
		int total_coverage = 0;

		for (current_chromosome = 0; current_chromosome < Const
				.get_number_of_chromosomes(); current_chromosome++) {
			read_count = 0;
			fail_count = 0;
			LB.notice("*** Begin Processing Chromosome "
					+ Const.get_chromosome(current_chromosome));
			LB.notice("Creating Chromosome...                                                ");
			String ffile = Const.getFastaFilename(current_chromosome);
			FastaIterator fi = new FastaIterator(LB, ffile);
			String[] rrr = null;
			while (rrr == null && fi.hasNext()) { //Just get the first line, but check to make sure it's there
				rrr = fi.next(); //TODO: better error handling?
			}
			fi.close();
			Chr = new Chromosome(LB, rrr[1], "chr" + current_chromosome, 0); //as long as this is eland only, 
																			 //we can set min_base_qual to zero
			LB.notice("Done");

			LB.notice("Loading Reads...                                                      ");

			/*Process Eland Files*/

			String elandfile = elandfile_path
					+ Const.get_chr_filename(current_chromosome)
					+ ".part.eland.gz";
			ReducedAlignedReads.LoadElandReads(LB, elandfile, Chr, Const,
					current_chromosome);

			LB.notice("Done");

			/*process Eland Extended Files*/

			LB.notice("Chromosome " + Const.get_chromosome(current_chromosome)
					+ " Reads passed: " + read_count + " Reads Failed: "
					+ fail_count);
			total_coverage += coverage;

			LB.notice("Fetching Exon Locations...                                            ");
			Location loc = new Location("chromosome",
					Const.get_chromosome(current_chromosome));
			List<Transcript> list = Ensembl.get_ta(loc);
			LB.notice("Done");

			Transcript_Bias.check_bias(LB, Const, Chr, list, Bias_overall,
					Bias_start, Bias_end, current_chromosome, output_path,
					HIST_BINS, HIST_START, HIST_WIDTH);

			if (Const.get_number_of_chromosomes() > 1) {
				LB.notice("Writing Complete Transcriptome files...                               ");
				write_whole_transcript_bias();
				LB.notice("Done");
			}

			Chr.destroy();
		} // end chromosome
		LB.close();
	}

}

package src.lib.objects;

/**
 * @version $Revision: 320 $
 * @author 
 */
// ESCA-JAVA0136:
public class SliderSNP {
	private final int SNPid;  // comments below indicate name of these variables from the SNP file.
	private final int position;  // "Location" in SNP file
	private final int mapability;  // "map" in SNP file
	private final int u0count;  // "cmCount" = crisp match
	private final int uncount;  // "mCount" = non-crisp matches
	private final int u1count;  // "nmCount" = non-match count
	private final char wSNP_per; // "wSNP%" 
	private final char cSNP_per; // "cSNP%"
	private final char ncSNP_per; // "ncSNP%"
	private final float cmScore;
	private final float nmScore;
	private final char ref; // "Ref"
	private final char obs; // "MPB" = Most Probable Sequence
	private final float PmA; 
	private final float PmC;
	private final float PmG;
	private final float PmT;
	private final float PnmA; 
	private final float PnmC;
	private final float PnmG;
	private final float PnmT;
	
		
	/*
	 * TODO: There really should be gets and sets for all of the objects
	 * above... but I'm not sure how much effort I want to put into this at the
	 * moment
	 */	
	
	public int get_SNPid() { return this.SNPid; }  
	public int get_position() { return this.position; }
	public int get_mapability() { return this.mapability; }
	public int get_u0count() { return this.u0count; }  
	public int get_uncount() { return this.uncount; } 
	public int get_u1count() { return this.u1count; }  
	public char get_wSNP_per() { return this.wSNP_per; }
	public char get_cSNP_per() { return this.cSNP_per; }
	public char get_ncSNP_per() { return this.ncSNP_per; }
	public float get_cmScore() { return this.cmScore; }
	public float get_nmScore() { return this.nmScore; }
	public char get_ref() { return this.ref; } 
	public char get_obs() { return this.obs ; }
	public float get_PmA() { return this.PmA; }
	public float get_PmC() { return this.PmC; }
	public float get_PmG() { return this.PmG; }
	public float get_PmT() { return this.PmT; }
	public float get_PnmA() { return this.PnmA; }
	public float get_PnmC() { return this.PnmC; }
	public float get_PnmG() { return this.PnmG; }
	public float get_PnmT() { return this.PnmT; }
	
	// ESCA-JAVA0138:
	public SliderSNP(final int SNPid, final int position, final int mapability,
			final int u0count, final int uncount, final int u1count,
			final char wSNP_per, final char cSNP_per, final char ncSNP_per,
			final float cmScore, final float nmScore, final char ref,
			final char obs, final float PmA, final float PmC, final float PmG,
			final float PmT, final float PnmA, final float PnmC,
			final float PnmG, final float PnmT) {
		this.SNPid		= SNPid	;  // comments below indicate name of these variables from the SNP file.
		this.position 	= position;  // "Location" in SNP file
		this.mapability = mapability;  // "map" in SNP file
		this.u0count	= u0count;  // "cmCount" = crisp match
		this.uncount	= uncount;  // "mCount" = non-crisp matches
		this.u1count	= u1count;  // "nmCount" = non-match count
		this.wSNP_per	= wSNP_per; // "wSNP%" 
		this.cSNP_per	= cSNP_per; // "cSNP%"
		this.ncSNP_per	= ncSNP_per; // "ncSNP%"
		this.cmScore	= cmScore;
		this.nmScore	= nmScore;
		this.ref		= ref; // "Ref"
		this.obs		= obs; // "MPB" = Most Probable Sequence
		this.PmA		= PmA; 
		this.PmC		= PmC;
		this.PmG		= PmG;
		this.PmT		= PmT;
		this.PnmA		= PnmA; 
		this.PnmC		= PnmC;
		this.PnmG		= PnmG;
		this.PnmT		= PnmT;
	}
		
}

package src.lib.ioInterfaces;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import src.lib.Constants;
import src.lib.objects.PSNP;

/**
 * @version $Revision: 558 $
 * @author 
 */
public class PSNPIterator implements Iterator<PSNP> {
	BufferedReader br = null;
	int linecount = 0;
	private static Log_Buffer LB;
	private static boolean display_version = true;

	public PSNPIterator(Log_Buffer logbuffer, String source_file) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("PSNPIterator", "$Revision: 558 $");
			display_version = false;
		}
		try {
			br = new BufferedReader(new FileReader(source_file));
		} catch (FileNotFoundException e) {
			LB.error("Can't find file " + source_file);
			LB.die();
		}
		
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public void close() {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	/** 
	 * Read in next line of the SNP file
	 * @return SNP object
	 */
	public PSNP next() {
		String line = null;
		try {
			if ((line = br.readLine()) != null) {
				this.linecount++;	
				StringTokenizer st = new StringTokenizer(line, "\t");
				if (st.countTokens() < 8 ) {
					LB.warning(line);
				}
				
				PSNP P = new PSNP(st.nextToken(),				// Chromosome
						Integer.valueOf(st.nextToken()),		// position
						st.nextToken(),							// transcript
						st.nextToken(),							// name
						Integer.valueOf(st.nextToken()),		// aaposition
						st.nextToken(),							// substitution
						Integer.valueOf(st.nextToken()),		// observed
						Integer.valueOf(st.nextToken()),		// coverage
						br.readLine() );						// Sequence is on the next line.
				
				return P;
			} else {
				throw new NoSuchElementException();
			}
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		throw new NoSuchElementException("Could not get any more reads.");
	}
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of SNPIterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}
}

		
package src.fileUtilities;

import java.io.DataInputStream;
import java.util.HashMap;
import java.util.Vector;

import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.CurrentVersion;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.AceWriter;
import src.lib.ioInterfaces.FastaIterator;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.AlignedRead;
import src.projects.findPeaks.objects.Parameters;

/**
 * 
 * @author Timothee Cezard Detail description of the ace format is available at
 *         http://bozeman.mbt.washington.edu/consed/consed.html
 *         http://bozeman.mbt.washington.edu/consed/distributions/README.19.0.txt
 *         Extract from documentation 16.14) CREATING YOUR OWN ACE FILES
 *         (INSTEAD OF ACE FILES CREATED BY PHRAP)
 * 
 * Some people have tried creating their own ace files, try Consed on it, and
 * when Consed starts up ok, they don't understand when later some feature in
 * Consed doesn't work. This is because Consed does not check everything about
 * an ace file when it starts up. If you are going to write software to create
 * ace files, here is a partial list of Consed features you should check before
 * you think your ace files are fine for Consed:
 * 
 * assembly view restriction digest read all traces complement contig and then
 * read all traces add new reads
 * 
 * @version $Revision: 1573 $
 * 
 */

public class ConvertToAce {
	private Log_Buffer LB = null;

	private static ConvertToAce singleton = new ConvertToAce();

	private ConvertToAce() {
	}

	public static void main(String args[]) {
		ConvertToAce c = ConvertToAce.singleton;
		c.execute(args);
	}

	/**
	 * Execute the main program: Read and check the input parameters and create
	 * the output ace file from the input aligned reads and the fasta sequence
	 * of the contig.
	 * 
	 * @param args
	 */
	public void execute(String[] args) {
		/* bootstrap log file parameter: */
		LB = Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		

		HashMap<String, String> Variables = null;
		try {
			Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
			return;
		}

		/* Do bootstrap calls here */
		if (Variables.containsKey(Parameters.NAME_PARAM)) {		
			CommandLine.test_parameter_count(LB, Parameters.NAME_PARAM, Variables.get(Parameters.NAME_PARAM), 1);
		} else {
			LB.notice("file names must be supplied with -name flag");
			LB.die();
		}
		if (Variables.containsKey(Parameters.OUTPUT_PARAM)) {		
			CommandLine.test_parameter_count(LB, Parameters.OUTPUT_PARAM, Variables.get(Parameters.OUTPUT_PARAM), 1);
			String tmp = Variables.get(Parameters.OUTPUT_PARAM);
			if (!tmp.endsWith(System.getProperty("file.separator"))) {
				tmp= tmp.concat(System.getProperty("file.separator"));
			}
			Variables.put(Parameters.OUTPUT_PARAM, tmp);
			LB.notice("Log File: " + Variables.get(Parameters.OUTPUT_PARAM) + Variables.get(Parameters.NAME_PARAM) + ".log");
			LB.addLogFile(Variables.get(Parameters.OUTPUT_PARAM) + Variables.get(Parameters.NAME_PARAM)  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			LB.die();
		}	

		/*  Done bootstrap  - print version info*/
		new CurrentVersion(LB);
		LB.Version("ConvertToAce", "$Revision: 1573 $");

		
		/* process remaining parameters */
		if (!Variables.containsKey(Parameters.INPUT_PARAM)) {
			LB.error("Must provide an -" + Parameters.INPUT_PARAM
					+ " file on the command line");
			LB.die();
		} else if (Variables.get(Parameters.INPUT_PARAM).equals("PIPE")) {
			new DataInputStream(System.in);
		}
		if (!Variables.containsKey("contig")) {
			LB.error("Must provide an -contig fasta file on the command line");
			LB.die();
		}
		if (!Variables.containsKey(Parameters.ALIGNER_PARAM)) {
			LB.error("Must provide an -aligner on the command line");
			LB.die();
		}
		int maq_read_size = 128;
		int filter_qual = 0;

		if (Variables.get(Parameters.ALIGNER_PARAM).equals(
				Constants.FILE_TYPE_MAQ)
				|| Variables.get(Parameters.ALIGNER_PARAM).equals(
						Constants.FILE_TYPE_MAPVIEW)) {
			if (!Variables.containsKey(Parameters.MAQ_FILE_FORMAT_PARAM)) {
				LB.warning("default value for "
						+ Parameters.MAQ_FILE_FORMAT_PARAM + "=128");
				LB
						.warning("use 64 for maq versions < 0.7, 128 for maq versions >= 0.7");
			} else {
				maq_read_size = Integer.parseInt(Variables
						.get(Parameters.MAQ_FILE_FORMAT_PARAM));
			}
			if (!Variables.containsKey(Parameters.FILTER_QUAL_PARAM)) {
				LB.warning("default value for " + Parameters.FILTER_QUAL_PARAM
						+ "=0");
			} else {
				filter_qual = Integer.parseInt(Variables
						.get(Parameters.FILTER_QUAL_PARAM));
				LB.notice("Quality filter: " + filter_qual);
			}
			// if (!Variables.containsKey(Parameters.PET_FLAGS_PARAM)) {
			// Variables.put(Parameters.PET_FLAGS_PARAM, "");
			// }
			if (!Variables.containsKey(Parameters.MAX_PET_SIZE_PARAM)) {
				Variables.put(Parameters.MAX_PET_SIZE_PARAM, "0");
			}
		} else {
			LB.error("Only support maq or mapview for now");
			LB.die();
		}

		Generic_AlignRead_Iterator it = new Generic_AlignRead_Iterator(LB,
				Variables.get(Parameters.ALIGNER_PARAM), "sourcefile",
				Variables.get(Parameters.INPUT_PARAM), filter_qual,
				maq_read_size, Variables.get(Parameters.PET_FLAGS_PARAM),
				Integer.parseInt(Variables.get(Parameters.MAX_PET_SIZE_PARAM)),false);
		if (Variables.containsKey("region")) {
			create_ace_file_filtered(it, Variables);
		} else {
			create_ace_file(it, Variables);
		}
	}

	private void create_ace_file_filtered(Generic_AlignRead_Iterator it,
			HashMap<String, String> Variables) {
		String contig_file = Variables.get("contig");
		String prefixes = Variables.get("prefix");
		String[] prefixes_arrays = new String[0];
		if (prefixes != null) {
			prefixes_arrays = prefixes.split(",");
		}

		String region = null;
		String reg_chr = null;
		int reg_start = -1;
		int reg_end = Integer.MAX_VALUE;

		region = Variables.get("region");
		String[] temp_reg = region.split(":");
		reg_chr = temp_reg[0];
		if (temp_reg.length > 1) {
			temp_reg = temp_reg[1].split("-");
			reg_start = Integer.parseInt(temp_reg[0]);
			if (temp_reg.length > 1) {
				reg_end = Integer.parseInt(temp_reg[1]);
			}
		}
		boolean found = false;

		Vector<AlignedRead> all_reads_for_cur_chr = new Vector<AlignedRead>();
		String cur_chr = "";
		int count = 0;
		while (it.hasNext()) {
			AlignedRead read = it.next();
			count++;
			if (count % 1000000 == 0) {
				LB.notice(count + " reads");
			}
			if (read == null) {
				break;
			}
			// We're not on the required chromosome
			if (!read.get_chromosome().equals(reg_chr)) {
				if (found) {
					break;
				}
				if (!read.get_chromosome().equals(cur_chr)) {
					cur_chr = read.get_chromosome();
					LB.notice("skipping reads from chromosome " + cur_chr);
				}
				continue;
			}
			found = true;
			if (!read.get_chromosome().equals(cur_chr)) {
				cur_chr = read.get_chromosome();
				LB.notice("loading reads from region " + region);
			}
			// check if we're on the required portion
			if (read.get_alignStart() > reg_start
					&& read.get_alignEnd() < reg_end) {
				all_reads_for_cur_chr.add(read);
			}
		}
		LB.notice(count + " reads");
		if (all_reads_for_cur_chr.size() > 0) {
			// Load the consensus or fasta
			LB.notice("process " + region);
			String[] good_fasta_sequence = load_consensus(contig_file, cur_chr,
					prefixes_arrays);

			if (good_fasta_sequence != null) {
				String output_file = Variables.get(Parameters.OUTPUT_PARAM)
						+ Variables.get(Parameters.NAME_PARAM) + "_" + region
						+ ".ace";
				String contig_sequence = good_fasta_sequence[1];
				if (reg_start > 0) {
					if ((reg_end) < good_fasta_sequence[1].length()) {
						contig_sequence = contig_sequence.substring(
								reg_start - 1, reg_end - 1);
					} else {
						contig_sequence = contig_sequence
								.substring(reg_start - 1);
					}
				}
				AceWriter a = new AceWriter(LB, output_file);
				a.process_contig_and_reads(all_reads_for_cur_chr,
						contig_sequence, region, reg_start);
				LB.notice("Found the contig " + cur_chr);
				LB.die();
			} else {
				LB.warning("can't find " + cur_chr + " in " + contig_file);
			}
		}
	}

	private void create_ace_file(Generic_AlignRead_Iterator it,
			HashMap<String, String> Variables) {
		String contig_file = Variables.get("contig");
		String prefixes = Variables.get("prefix");
		String[] prefixes_arrays = new String[0];
		if (prefixes != null) {
			prefixes_arrays = prefixes.split(",");
		}
		Vector<AlignedRead> all_reads_for_cur_chr = new Vector<AlignedRead>();
		String cur_chr = "";
		while (it.hasNext()) {
			AlignedRead read = it.next();
			if (read.get_chromosome().equals(cur_chr)) {
				all_reads_for_cur_chr.add(read);
			} else {
				if (all_reads_for_cur_chr.size() > 0) {
					// Load the consensus or fasta
					LB.notice("process " + cur_chr);
					FastaIterator fasta_iter = new FastaIterator(LB,
							contig_file);
					String[] good_fasta_sequence = null;
					while (fasta_iter.hasNext()) {
						String[] fasta_sequence = fasta_iter.next();
						LB.notice("load fasta sequence "
								+ fasta_sequence[0].replace(">", ""));
						if (equal_with_prefixes(fasta_sequence[0].replace(">",
								""), cur_chr, prefixes_arrays)) {
							LB.notice("loaded "
									+ fasta_sequence[0].replace(">", ""));
							good_fasta_sequence = fasta_sequence;
							break;
						}
					}
					if (good_fasta_sequence != null) {
						String output_file = Variables
								.get(Parameters.OUTPUT_PARAM)
								+ Variables.get(Parameters.NAME_PARAM)
								+ "_"
								+ cur_chr + ".ace";
						AceWriter a = new AceWriter(LB, output_file);
						a.process_contig_and_reads(all_reads_for_cur_chr,
								good_fasta_sequence[1], cur_chr, 1);
						LB.notice("Found the contig " + cur_chr);
						LB.die();
					} else {
						LB.warning("can't find " + cur_chr + " in "
								+ contig_file);
					}
				}
				cur_chr = read.get_chromosome();
				LB.notice("load reads from chromosome " + cur_chr);
				all_reads_for_cur_chr = new Vector<AlignedRead>();
			}
		}
	}

	private String[] load_consensus(String contig_file, String cur_chr,
			String[] prefixes_arrays) {
		FastaIterator fasta_iter = new FastaIterator(LB, contig_file);
		String[] good_fasta_sequence = null;
		while (fasta_iter.hasNext()) {
			String[] fasta_sequence = fasta_iter.next();
			LB.notice("load fasta sequence "
					+ fasta_sequence[0].replace(">", ""));
			if (equal_with_prefixes(fasta_sequence[0].replace(">", ""),
					cur_chr, prefixes_arrays)) {
				LB.notice("loaded " + fasta_sequence[0].replace(">", ""));
				good_fasta_sequence = fasta_sequence;
				break;
			}
		}
		return good_fasta_sequence;
	}

	/**
	 * Check if a matches b with or without a prefix. This is use to handle the
	 * fact that some reads contig doesn't contain chr
	 * 
	 * @param a
	 * @param b
	 * @param prefixes_array
	 * @return
	 */
	private static boolean equal_with_prefixes(String a, String b,
			String[] prefixes_array) {
		if (a.equals(b)) {
			return true;
		} else {
			if (a.length() > b.length()) {
				String tmp = a;
				a = b;
				b = tmp;
			}
			for (String prefix : prefixes_array) {
				if ((prefix + a).equals(b)) {
					return true;
				}
			}
		}
		return false;
	}

}

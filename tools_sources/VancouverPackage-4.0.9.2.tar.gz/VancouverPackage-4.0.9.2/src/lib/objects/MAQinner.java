package src.lib.objects;

/**
 * @version $Revision: 912 $
 * @author 
 */
public class MAQinner {
	
	
	//public static final int MAX_READLEN = 128;						//simulate.c:#define MAX_READLEN 64
	public static final int MAX_NAMELEN = 36;					//maqmap.h:#define MAX_NAMELEN 36
	public static final int MAQ_SHIFT_MAGIC = 0xF;				//I don't know why they use this number, but it's used.
	public static final int MAQ_SHIFT_6 = 6;					//I don't know why they use this number, but it's used.
	public static final int CAST_UNSIGNED = 0xFF;				//casts to unsigned byte
	public static final int EMPTY_CHAR = 0x00;					//basically a null, but not explicitly.
	public static final int MAQ_QUAILTY_MASK = 0x3F;			//used to mask the sequence to get the quality score.
	
	private final byte[] seq; 
	private final byte size;
	private final byte map_qual;
	private final byte info1;
	private final byte info2;
	private final byte[] c = new byte[2];
	private final byte flag;
	private final byte alt_qual;
	private final int seqid;
	private final int pos;
	private final int dist;
	private final char[] name = new char[MAX_NAMELEN];
	private final MAQouter outer;
	
	
	// ESCA-JAVA0138:
	public MAQinner(byte[] a, byte size, byte map_qual,
			byte info1, byte info2, byte[] c, byte flag, byte alt_qual,
			int seqid, int pos, int dist, char[] name, MAQouter outer) {
		this.seq = new byte[a.length];
		for (int x = 0; x < a.length; x++) {
			this.seq[x] = a[x];
		}
		this.size = size;
		this.map_qual = map_qual;
		this.info1 = info1;
		this.info2 = info2;
		
		this.c[0] = c[0];
		this.c[1] = c[1];
		
		this.flag = flag;
		this.alt_qual = alt_qual;
		this.seqid = seqid;
		this.pos = pos;
		this.dist = dist;
		for (int x = 0; x < MAX_NAMELEN; x++) {
			this.name[x] = name[x];
		}
		this.outer = outer;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(this.get_name() + "\t");						// name of read
		sb.append(this.get_chromosome() + "\t");				// chromosome?
		sb.append(this.get_pos() + "\t");						// position
		sb.append(this.get_direction() + "\t");					// direction
		sb.append(this.dist + "\t");							// insert size between pairs (PET only)
		sb.append(this.get_flag() + "\t");						// PET flag
		sb.append(this.map_qual + "\t");						// mapping qual(SET/PET) indel position(PET-SW)
		sb.append(this.get_SET_qual() + "\t");					// mapping quality(SET) -indel length(PET-SW)
		sb.append(this.get_alt_qual() + "\t");					// mapping quality of mate (PET)
		sb.append(this.get_mismatches() + "\t");				//
		sb.append(this.get_info2() + "\t");						//
		sb.append(this.c[0] + "\t");							//
		sb.append(this.c[1] + "\t");							//
		sb.append(this.size + "\t");							//
		sb.append(this.get_sequence() + "\t");
		//sb.append(new String(this.get_quality()) +"\t");
		return sb.toString();
	}
	
	public final int get_pos() 				{ return ((this.pos)>>>1) + 1; }
	public final char get_direction() 		{ return ((this.pos & 1) != 0)? '-': '+'; }
	public final int get_SET_qual()			{ return (int)this.seq[this.seq.length -1]; }
	public final int get_map_qual()			{ return this.map_qual; }
	public final int get_size()				{ return this.size; }
	public final int get_mismatches()		{ return this.info1 & MAQ_SHIFT_MAGIC; }
	public final int get_zero_mismatch()	{ return this.c[0]; }
	public final int get_one_mismatch()		{ return this.c[1]; }
	public final int get_info2()			{ return this.info2 & CAST_UNSIGNED; }
	public final int get_flag()				{ return this.flag & CAST_UNSIGNED; }
	public final int get_alt_qual()			{ return this.alt_qual & CAST_UNSIGNED; }
	public final int get_dist()				{ return this.dist; }				
	
	
	public final String get_name() { 
		StringBuffer a = new StringBuffer();
		for (int x = 0; x < MAX_NAMELEN -1; x++) {
			if (name[x] != EMPTY_CHAR) {
				a.append(name[x]);
			}
		}
		return a.toString(); 
	}
	
	public final String get_chromosome()	{ 
		StringBuffer a = new StringBuffer();
		int x = 0;
		char[] tmp = this.outer.get_refname(this.seqid);
		while (tmp[x] != EMPTY_CHAR) { 
			a.append(tmp[x]);
			x++;
		}
		return a.toString();
	}
	
	public final String get_sequence() {
		StringBuffer sb = new StringBuffer();
		for (int x = 0; x < this.size; x++) {
			if (this.seq[x] == 0) {
				sb.append('n');
			} else if ((this.seq[x] & MAQ_QUAILTY_MASK) < 27) {
				sb.append(get_lower_case(this.seq[x]>>>(MAQ_SHIFT_6) & 3));
			} else {
				sb.append(get_upper_case(this.seq[x]>>>(MAQ_SHIFT_6) & 3));
			}
		}
		return sb.toString();
	}
	
	public final byte[] get_quality() {
		byte[] q = new byte[this.size];
		for (int x =0; x < this.size; x++) {
			q[x] = (byte)(this.seq[x] & MAQ_QUAILTY_MASK);
		}	
		return q;
	}
	
	
	private static char get_lower_case(int x) {
		if (x == 0 ) { return 'a'; }
		else if (x == 1 ) { return 'c'; }
		else if (x == 2 ) { return 'g'; }
		else if (x == 3 ) { return 't'; }
		else { return 'n'; }
	}
	
	private static char get_upper_case(int x) {
		if (x == 0 ) { return 'A'; }
		else if (x == 1 ) { return 'C'; }
		else if (x == 2 ) { return 'G'; }
		else if (x == 3 ) { return 'T'; }
		else { return 'N'; }
	}
	
}

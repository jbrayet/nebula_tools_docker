package src.lib.ioInterfaces;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.zip.GZIPInputStream;

import src.lib.BitOperations;
import src.lib.Constants;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.objects.AlignedRead;
import src.lib.objects.MAQinner;
import src.lib.objects.MAQouter;

/**
 * @version $Revision: 1790 $
 * @author 
 */
public class MAQmapIterator implements AlignedReadsIterator{
	private static boolean display_version = true;

	String name = null;
	GZIPInputStream br = null;
	int linecount = 0;
	private boolean EOF;
	private final int qualityfilter;
	private int[] PET_filters = null;
	private int number_filtered;
	final Log_Buffer LB;
	public final int MAX_READ_LENGTH; 
	final int max_PET_len;

	private static final int PRIMARY_FIELDS = 20;

	private MAQouter header; 

	/**
	 * 
	 * @param log_buffer
	 * @param name
	 *            Name of the file (descriptive)
	 * @param source_file
	 *            Location of the file
	 * @param qualityfilter
	 *            optional minimum quality value to accept
	 * @param read_length
	 *            The expected length of the read field - 64 for versions before
	 *            MAQ 0.7.0, 128 for versions after Maq 0.7.0
	 * @param max_PET_len
	 *            Throw away reads longer than this value. (suggested ~2kbp)
	 */
	// ESCA-JAVA0138:
	public MAQmapIterator(Log_Buffer log_buffer, String name, 
			String source_file, int qualityfilter, int read_length, int max_PET_len) {
		LB = log_buffer;
		if (display_version) {
			LB.Version("MAQmapIterator", "$Revision: 1790 $");
			display_version = false;
		}
		this.max_PET_len = max_PET_len;
		this.MAX_READ_LENGTH = read_length;
		this.name = name;
		this.qualityfilter=qualityfilter;
		this.number_filtered = 0;
		try {
			if (source_file.equals("PIPE")){
				br = new GZIPInputStream(new DataInputStream(System.in));
			}else{
				br = new GZIPInputStream(new FileInputStream(source_file));
			}
		} catch (FileNotFoundException f) {
//			f.printStackTrace();
			LB.error("Can't find MAQ map file" + source_file);
			LB.die();
		} catch (IOException io) {
			LB.error("Couldn't open MAQ map file: " + source_file);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		} catch (NullPointerException npe) {
			LB.error("Couldn't open MAQ map file: " + source_file);
			LB.error("please check that the correct input flag (-input or -input_file) was used");
			LB.die();
		}
		header = maq_map_read_header();
	}

	public void apply_filters(String filters) {
		String[] tmp = filters.split(",");
		this.PET_filters= new int[tmp.length];
		for (int a = 0;  a < tmp.length; a++) {
			this.PET_filters[a] = Integer.valueOf(tmp[a]);
		} 
	}

	public boolean mark() {
		if (br.markSupported()) {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} else {
			return false;
		}
	}

	public boolean reset() {
		try {
			br.reset();
			return true;
		} catch (IOException ioe) {
			LB.error("Could not reset input file for read buffer.");
			return false;
		}
	}

	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		if (verbose) {
			LB.notice("--- " + this.name + " ---");
			LB.notice("Processed " + this.linecount + " records");
			LB.notice("Lines Filtered : " + this.number_filtered);
		}
	}

	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}

	public boolean hasNext() {
		return (!EOF);
	}

	public String[] get_chromosomes() {
		int count = this.header.get_count_of_refnames();
		String[] r = new String[count];
		for (int x = 0; x < count; x++) {
			char[] ch = this.header.get_refname(x);
			StringBuffer sb = new StringBuffer();
			for (char y : ch) {
				sb.append(y);			
			}
			r[x] = sb.toString().trim();
		}
		return r;
	}

	/**
	 * Read header of MAQ Map file. It contains the name an number of all reads present in the file.
	 * @return
	 */
	private MAQouter maq_map_read_header() {
		try {
			int format = get_int();
			if (format != MAQouter.MAQMAP_FORMAT_NEW) {
				LB.error("OBSOLETE MAQ MAP FORMAT.");
				LB.error("please use 'mapass2maq' from the maq package to convert this map file to map format");
				LB.die();
			}
			assert (format == MAQouter.MAQMAP_FORMAT_NEW);
			int n_ref = get_int(); 
			char[][] ref_names = new char[n_ref][]; 
			for (int x = 0; x < n_ref; x++) {
				Integer len = get_int();
				ref_names[x] = new char[len];
				for (int l = 0; l < len; l++) {
					 ref_names[x][l] = (char)br.read();
				}
			}
			long n_mapped_reads = get_long();
			LB.notice("number of mapped reads in header: " + n_mapped_reads);
			MAQouter maq_set = new MAQouter(n_ref, ref_names, n_mapped_reads);
			return maq_set;
		} catch (IOException io) {
			LB.error(io.getStackTrace().toString());
			LB.error("Error reading header of MAQ map file.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}

		//MAQouter mm = new MAQouter();
		return null;
	}

	private long get_long() {
		int[] l = new int[BitOperations.BYTES_IN_LONG];
		try {
			for (int n = 0; n < l.length; n++) {
				l[n] = br.read();
			}
		} catch (IOException io) {
			LB.warning("Error getting long while reading header of MAQ map file.");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		return BitOperations.bytes_to_long(l);
	}

	private int get_int() {
		int[] l = new int[4];
		try {
			for (int n = 0; n < l.length; n++) {
				l[n] = br.read();
			}
		} catch (IOException io) {
			LB.warning("Error getting long while reading header of MAQ map file.");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		return BitOperations.bytes_to_int(l);
	}

	/**
	 * Read core of each read.  Can return nulls! wrapper must be able to handle that.
	 * 
	 * @return
	 */
	private MAQinner maq_map_read_core() {

		try {
			final int read_size = this.MAX_READ_LENGTH + PRIMARY_FIELDS + MAQinner.MAX_NAMELEN;
			byte[] b = new byte[read_size];
			int bytes_read = br.read(b);
			if (bytes_read < 0) {
				EOF = true;
				return null;
			}
			while (bytes_read < read_size) {
				byte[] b2 = new byte[read_size-bytes_read];
				int bytes_read2 = br.read(b2);
				for (int x = 0; x < bytes_read2; x++) {
					b[bytes_read + x] = b2[x];
				}
				bytes_read += bytes_read2;
			}
			if (br.available() == 0) {
				EOF = true;
				//System.out.println("EOF found after reading next chars");
				return null;
			}

			byte[] seq = new byte[this.MAX_READ_LENGTH];
			for (int x = 0; x < this.MAX_READ_LENGTH; x++) {						//read 16 ints
				seq[x] = BitOperations.bytes_to_bytes(b[x]);
			}

			byte size 		= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 0]);
			byte map_qual 	= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 1]);
			byte info1 		= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 2]);
			byte info2 		= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 3]);
			byte[] c 		= new byte[2];
			c[0]			= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 4]);
			c[1]			= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 5]);
			byte flag		= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 6]);
			byte alt_qual	= BitOperations.bytes_to_bytes(b[this.MAX_READ_LENGTH + 7]);
			byte[] tmp 		= new byte[4];
			{
				tmp[0] = b[this.MAX_READ_LENGTH + 8];
				tmp[1] = b[this.MAX_READ_LENGTH + 9];
				tmp[2] = b[this.MAX_READ_LENGTH + 10];
				tmp[3] = b[this.MAX_READ_LENGTH + 11];
			}
			int seqid = BitOperations.bytes_to_int(tmp);				//	get_int();	
			{
				tmp[0] = b[this.MAX_READ_LENGTH + 12];
				tmp[1] = b[this.MAX_READ_LENGTH + 13];
				tmp[2] = b[this.MAX_READ_LENGTH + 14];
				tmp[3] = b[this.MAX_READ_LENGTH + 15];
			}
			int pos = BitOperations.bytes_to_int(tmp);
			{
				tmp[0] = b[this.MAX_READ_LENGTH + 16];
				tmp[1] = b[this.MAX_READ_LENGTH + 17];
				tmp[2] = b[this.MAX_READ_LENGTH + 18];
				tmp[3] = b[this.MAX_READ_LENGTH + 19];
			}
			int dist = BitOperations.bytes_to_int(tmp);
			char[] seqname = new char[MAQinner.MAX_NAMELEN];		//read 9 ints (36 byte)
			for (int x = 0; x < MAQinner.MAX_NAMELEN; x++) {
				seqname[x] = (char)(b[this.MAX_READ_LENGTH + PRIMARY_FIELDS + x]);
			}
			MAQinner maq_inner = new MAQinner(seq, size, map_qual, info1, info2,
					c, flag, alt_qual, seqid, pos, dist, seqname, header);

			//Enable the following two lines to test the maq iterator. (does not print quality information.)
			/*if(maq_inner.get_flag() == 130 && maq_inner.get_SET_qual() != 0) {
				System.out.println(maq_inner.toString());
				System.out.println(maq_inner.get_sequence());
			}*/

			if (br.available() == 0) {
				LB.notice("EOF found");
				EOF = true;
			}

			//System.out.println(maq_inner.toString());
			return maq_inner;

		} catch (IOException io) {
			LB.error("Error reading MAQ map file.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return null;
	}

	public boolean apply_PET_filter(int flag) {
		boolean cont = false;
		for (int b : this.PET_filters) {
			if (b == flag) {
				cont = true;
			}
		}
		return cont;
	}

	/**
	 * This function will iterate until it finds a good read, or hits the end of file.  End of file is marked by a 
	 * NoSuchElementException exception.
	 * @return AlignedRead
	 */
	public AlignedRead next() {
		AlignedRead a = null;
		while (!EOF) {
			MAQinner row = maq_map_read_core();
			boolean cont = true;
			if (row != null) {
				this.linecount++;
				if (this.PET_filters != null) {
					cont = apply_PET_filter(row.get_flag());
				}
				if (this.max_PET_len > 0 && row.get_size() > this.max_PET_len) {
					this.number_filtered++;
					continue;
				}
				if (row.get_map_qual() >= qualityfilter && cont) {
					a = null;
					try {
						a = new AlignedRead(
							row.get_direction(),					// direction
							row.get_name(),							// Sequence Name
							row.get_sequence(), 					// Sequence 
						//	TODO Check if this could be used to store the mapping alternative quality.
							row.get_map_qual(),						// score - maq alt quality = quality if SET
																	// 	and lower quality of the two ends if PET.
							row.get_alt_qual(),						// seqStart 
							row.get_SET_qual(),						// seqEnd
							null, 									// alignName
							row.get_chromosome(),					// Chromosome 
							row.get_pos(), 							// alignStart	 
							row.get_pos() + row.get_size()-1,		// alignEnd 
							//row.get_pos() + row.get_size(),
							0, 										// percent
							0, 										// P
							null, 									// alignseq
							row.get_mismatches(),					// mismatches 
							0, 										// sort_score
							row.get_dist(), 						// queryLength
							row.get_size(),							// alignLength
							0, 										// contigStart  - used to store insert size
							0, 										// contigEnd
							row.get_flag(),							// identity - used to store Flag for Maq.
							null,									// Match
							row.get_zero_mismatch(),				// matches_noError  
							row.get_one_mismatch(),					// matches_1error 
							0, 										// matches_2error
							null, 									// N_reads
							null, 									// error1
							null, 									// error2 
							row.get_quality()); 					// base quality
					} catch (UnexpectedResultException URE) {
						LB.error("Line " + linecount + " has an invalid read:");
						LB.error(URE.getMessage());
					}
				} else {
					number_filtered++;
				}
				if (a != null && a.get_score() >= qualityfilter && cont) {
					return a;
				} else {
					number_filtered++;
				}
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
			}
		}
		throw new NoSuchElementException("Could not get any more reads.");
	}

	/**
	 * get the number of filtered reads by the quality score.
	 * @return the number of filtered reads.
	 */
	public int get_NumberFilteredRead() {
		return number_filtered;
	}

}

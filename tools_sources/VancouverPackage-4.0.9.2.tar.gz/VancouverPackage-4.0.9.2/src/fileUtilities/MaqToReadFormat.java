package src.fileUtilities;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.NoSuchElementException;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.IterableIterator;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.MAQmapIterator;
import src.lib.objects.AlignedRead;

/**
 * Standalone tools that transform a Maq alignment file into one reads file per chromosome.
 * using Misha format.
 * @author T. Cezard
 * @author Anthony Fejes
 * @version $Revision: 1582 $
 */
public class MaqToReadFormat {
	
	private static Log_Buffer LB = null;
	
	private MaqToReadFormat() {}
	
	public static void main(String[] args) {
		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		//process parameters
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
			return;
		}
		
		if (!Variables.containsKey("name")) {
			LB.error("Must provide a -name parameter on the command line");
			LB.die();
		}
		
		if (Variables.containsKey("output")) { 
			String tmp = Variables.get("output");
			if (!tmp.endsWith(System.getProperty("file.separator"))) {
				tmp = tmp.concat(System.getProperty("file.separator"));
				Variables.put("output", tmp);
			}
			LB.notice("Log File: " + Variables.get("output") + Variables.get("name")  + ".log");
			LB.addLogFile(Variables.get("output") + Variables.get("name")  + ".log");		
		} else {
			LB.error("Must provide an -output path on the command line");
			LB.die();
		}

		/* end bootstrapping*/
		new CurrentVersion(LB);
		LB.Version("MaqToReadFormat", "$Revision: 1582 $");
		
		if (!Variables.containsKey("input")) {
			LB.error("Must provide an -input path on the command line");
			LB.die();
		}

		
		
		if (!Variables.containsKey("readsize")) {
			LB.error("Must provide -readsize on the command line. use 64 for maq version 0.6, 128 for version 0.7+");
			LB.die();
		}
		
		
		MAQmapIterator mi = new MAQmapIterator(LB, "sourcefile", Variables.get("input"), 0,
				Integer.valueOf(Variables.get("readsize")), 0);
		
		HashMap<String, PrintWriter> hashPrintWriter=new HashMap<String, PrintWriter>();
		LB.notice("Processing...");
		processSET(Variables,hashPrintWriter,mi);
		LB.notice("Done");
		LB.close();
	}
	
	
	private static void processSET(HashMap<String, String> Variables,
			HashMap<String, PrintWriter> hashPrintWriter, MAQmapIterator mi)
	{
		int count=0;
		try {
			PrintWriter pw=null;
			for (AlignedRead line : new IterableIterator<AlignedRead>(mi)) {
				pw=hashPrintWriter.get(line.get_chromosome());
				if (pw==null){
					pw = new PrintWriter(new File(Variables.get("output")
							+ Variables.get("name"))
							+ "_" + line.get_chromosome() + ".reads");
					hashPrintWriter.put(line.get_chromosome(), pw);
				}
				if (line.get_direction()=='+') {
					pw.write(line.get_alignStart()+"\t"+line.get_direction()+"\t1\n");
				} else  {
					pw.write(line.get_alignEnd()+"\t"+line.get_direction()+"\t1\n");
				}
				count++;
				if (count%500000 == 0) {
					System.out.println(count);
				}
			}
		} catch(IOException io) {
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		} catch (NoSuchElementException nsee) {
			//don't need to do anything.
		}
		
		Iterator<PrintWriter> iter_pw = hashPrintWriter.values().iterator();
		for ( PrintWriter pw : new IterableIterator<PrintWriter>(iter_pw) ) {
			pw.close();
		}

	}
	
}

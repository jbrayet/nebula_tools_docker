package src.lib;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import src.lib.ioInterfaces.Log_Buffer;


// ESCA-JAVA0136:
/**
 * @version $Revision: 1197 $
 * @author 
 */
public class Histogram { 
	private final int num_bins;
	private final float max_value;
	private final float min_value;
	private long [] bins 						= null;
	private int underflows 						= 0;
	private int overflows 						= 0;
	private final float binsize;
	private int count							= 0;
		
	private static Log_Buffer LB;
	private static boolean display_version = true;
		
	/**
	 *  initialization for histogram
	 * @param logbuffer
	 * @param num_bins
	 * @param low_value
	 * @param high_value
	 * @param verbose
	 */
	public Histogram (Log_Buffer logbuffer, int num_bins, float low_value, float high_value, boolean verbose) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Histogram", "$Revision: 1197 $");
			display_version = false;
		}
		this.num_bins = num_bins;
		this.max_value = high_value;
		this.min_value = low_value;
		this.binsize = ((high_value - low_value))/(float)(num_bins);
		if (verbose) {
			LB.notice("histogram created - bins:" + num_bins + " low: "
					+ low_value + " high: " + high_value + " binsize: "
					+ binsize);
		}
		bins = new long[num_bins];
		reset();
	}
	
	/**
	 * Return the number in the bin of the histogram corresponding to given value
	 * @param value the value use to get the bin.
	 * @return
	 */
	public final long get_hist_value(float value) {
		if ( value < min_value) {
		     return underflows;
		} else if ( value >= max_value) { 
			return overflows;
		} else {
		     int bin = (int)((value-min_value)/binsize);
		     if (bin >=0 && bin < num_bins) {
		    	 return bins[bin];
		     }
		     else {
		    	 LB.warning("Histogram: Bin Miscalculation!!!!");			    
		     }
		}
		return 0;
	}
	
	/**
	 * Returns the value in bin i.
	 * @param i
	 * @return
	 */
	public final long get_bin_value(int i) {
		return bins[i];
	}
	
	/**
	 * returns the number of values that were too small, and were not included in the histogram
	 * @return
	 */
	public final int get_underflows() {
		return underflows;
	}

	/**
	 * returns the number of values that were too big, and were not included in the histogram
	 * @return
	 */
	public final int get_overflows() {
		return overflows;
	}
	
	/**
	 * 
	 */
	private final void reset() {
		for (int i=0; i < num_bins; i++) {
		      bins[i] = 0;
		}
	}
	
	/**
	 * 
	 * @param value
	 */
	public final void bin_value(int value) {
		bin_value((float)value);
	}
	
	/**
	 * 
	 * @param value
	 * @param observed
	 */
	public final void bin_value(int value, int observed) {
		bin_value((float)value, observed);
	}
	
	/**
	 * 
	 * @param value
	 */
	public final void bin_value(double value) {
		bin_value((float)value);
	}
	
	/**
	 * 
	 * @param value
	 * @param observed
	 */
	public final void bin_value(double value, int observed) {
		bin_value((float)value, observed);
	}
	
	/**
	 * 
	 * @param value
	 * @param observed
	 */
	public final void bin_value(float value, int observed) {
		bin_value(value, (long)observed);
	}

	/**
	 * getters
	 * @return
	 */
	public final int get_num_bins() 			{ return this.num_bins; }
	public final float get_min_value()			{ return this.min_value; }
	public final float get_max_value() 			{ return this.max_value; }
	public final float get_bin_size()			{ return this.binsize; }
	
	/**
	 * Number of values binned
	 * @return
	 */
	public final int get_count()				{ return this.count; }
	
	
	/**
	 * 
	 * @param value
	 */	
	public void bin_value(float value) {
		if ( value < min_value) {
		     underflows++;
		} else if ( value >= max_value) { 
		     overflows++;
		} else {
		     int bin = (int)((value-min_value)/binsize);
		     if (bin >=0 && bin < num_bins) {
		    	 bins[bin]++;
		     }
		     else {
		    	 LB.warning("Histogram: Bin Miscalculation!!!!");
		     }
		}
		this.count++;
	}
	
	/**
	 * 
	 * @param value
	 * @param observed
	 */
	public void bin_value(float value, long observed ) {
		if ( value < min_value) {
		     underflows++;
		} else if ( value >= max_value) { 
		     overflows++;
		} else {
			int bin = (int)((value-min_value)/binsize);
			if (bin >=0 && bin < num_bins) {
				bins[bin] += observed;
			} else {
				LB.warning("Histogram: Bin Miscalculation!!!!");		    
			}
		}
		this.count += observed;
	}
	
	
	public int count_greater_than_value(int value) {
		return count_greater_than_value((float) value);
	}
	
	public int count_greater_than_value(float value) {
		if (value < min_value) {
			int sum = 0;
			for (int i=0; i < num_bins; i++) {
				sum += bins[i];
			}
			return (underflows + overflows + sum); 
		} else if (value > max_value) {
			return overflows;
		} else {
			int bin = (int)((value-min_value)/binsize);
			int sum = 0;
			for (int i=bin; i < num_bins; i++) {
				sum += bins[i];
			}
			return (overflows + sum); 
		}
	}
	
	
	
	/**
	 * 
	 */
	public final void print_bins() {
		for (int i=0; i < num_bins; i++) {
		      LB.notice(((i*binsize)+ min_value) + "\t" + bins[i]);
		}
		LB.notice(" ");
		LB.notice("underflows: " + underflows);
		LB.notice("overflows:  " + overflows);
	}
	
	/**
	 * 
	 * @param bw
	 */
	public void print_bins(BufferedWriter bw) {
		try {
			for (int i=0; i < num_bins; i++) {
				bw.write(((i*binsize)+ min_value) + "\t" + bins[i]);
				bw.newLine();
			}
			bw.newLine();
			bw.write("underflows: " + underflows);
			bw.newLine();
			bw.write("overflows:  " + overflows);
			bw.newLine();
		} catch (IOException io) {
			LB.error("Error writing out Histogram Data.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}	
	}
	
	/**
	 * 
	 * @param fname
	 */
	public void print_bins(String fname) {
		try {
			FileWriter f = new FileWriter(fname);
			BufferedWriter bw = new BufferedWriter(f);
			print_bins(bw);
			bw.close();
			f.close();
		} catch (IOException io) {
			LB.error("Could not create FileWriter.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
	}
	
	/**
	 * Return the number in the bin of the histogram corresponding to given
	 * value
	 * 
	 * @param value
	 *            the value use to get the bin.
	 * @return
	 */
	public final long get_all_bins_by_value(int value) {
		if (value < min_value) {
			return underflows;
		} else if (value >= max_value) {
			return overflows;
		} else {
			int bin_low = (int) ((value - min_value) / binsize);
			int bin_hi = (int) (((value + 1) - min_value) / binsize);
			int ret = 0;
			if (bin_low >= 0 && bin_hi >= 0 && bin_low < num_bins
					&& bin_hi < num_bins) {
				for (int x = bin_low; x < bin_hi; x++) {
					ret += bins[x];
				}
				return ret;
			} else {
				LB.warning("Histogram: Bin Miscalculation!!!!");
			}
		}
		return 0;
	}
	
}
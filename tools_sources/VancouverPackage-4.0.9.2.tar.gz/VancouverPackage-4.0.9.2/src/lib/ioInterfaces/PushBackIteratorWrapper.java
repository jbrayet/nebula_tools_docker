package src.lib.ioInterfaces;

import java.util.Vector;

import src.lib.objects.AlignedRead;

public class PushBackIteratorWrapper
{
	private Vector<AlignedRead> buffer_ahead;
	private Generic_AlignRead_Iterator it;
	
	public PushBackIteratorWrapper(Generic_AlignRead_Iterator it){
		this.it=it;
		buffer_ahead = new Vector<AlignedRead>(0);
	}
	
	public boolean has_next(){
		return it.hasNext() || buffer_ahead.size() > 0;
	}
	
	public AlignedRead next(){
		if (buffer_ahead.size() > 0) {
			return buffer_ahead.remove(0);
		} else {
			return it.next();
		}
	}
	public void add_back(AlignedRead ar){
		buffer_ahead.add(ar);
	}
	
	public void add_back(Vector<AlignedRead> buffer){
		for (int r = 0; r < buffer.size(); r++) {
			buffer_ahead.add(buffer.get(r));
		}
	}
	
	public void push_back(AlignedRead ar){
		buffer_ahead.insertElementAt(ar, 0);
	}
	
	public void push_back(Vector<AlignedRead> buffer){
		for (int r = 0; r < buffer.size(); r++) {
			buffer_ahead.insertElementAt(buffer.get(r), r);
		}
	}
		
}

package src.lib.Error_handling;

/**
 * @author GPL Software
 * @version "$Revision: 558 $"
 */

public class UnexpectedResultException extends Exception {
       
	/**
	 * Generated serialVersion.
	 */
	private static final long serialVersionUID = -8615121461725166234L;

	public UnexpectedResultException(String message) {
		super(message);
	}
	
}

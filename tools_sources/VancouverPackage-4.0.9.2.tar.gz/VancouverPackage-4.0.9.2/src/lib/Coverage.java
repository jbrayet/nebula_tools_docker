package src.lib;

import java.util.Vector;

import src.lib.objects.AlignedRead;


import src.projects.findPeaks.Distribution;

/**
 * @version $Revision: 596 $
 * @author 
 */
public class Coverage {

	private Coverage() {}

	
	/**
	 * This generates the coverage heights at each position in the peak. Note:
	 * The offset is different from other Coverage functions!
	 * 
	 * @param reads  Uses a Vector of Aligned reads - not reduced aligned reads!
	 * @param start
	 * @param end
	 * @param dist
	 * @return
	 */
	public static float[] generatePeakHeight_ld_float(Vector<AlignedRead> reads, Distribution dist, int start, int end) {
		//stores coverage height at each position in the peak
		int max_len = dist.get_max_ext_len();
		int offset = start;
		int span = end - start + 1;
		float[] coverageHeights = new float[span];
		for (AlignedRead ar : reads) {
			if (ar.get_direction() == '-') {
				for (int q = 0; q < max_len; q++) {  //reverse strand/direction
					coverageHeights[(ar.get_alignEnd() - offset) - q] += dist.value_at(q);
				}		
			} else {
				for (int q = 0; q < max_len; q++) {	//forward strand/direction
					coverageHeights[(ar.get_alignStart() - offset) + q] += dist.value_at(q);
				}
			}
		}
		return coverageHeights;
	}
	
	/**
	 * This generates the coverage heights at each position in the peak. Note:
	 * The offset is different from other Coverage functions!
	 * 
	 * @param reads  Uses a Vector of Aligned reads - not reduced aligned reads!
	 * @param start
	 * @param end
	 * @param dist
	 * @return
	 */
	public static int[] generatePeakHeight_ld_int(Vector<AlignedRead> reads, Distribution dist, int start, int end) {
		//stores coverage height at each position in the peak
		int max_len = dist.get_max_ext_len();
		int offset = start;
		int span = end - start + 1;
		int[] coverageHeights = new int[span];
		for (AlignedRead ar : reads) {
			if (ar.get_direction() == '-') {
				for (int q = 0; q < max_len; q++) {  //reverse strand/direction
					coverageHeights[(ar.get_alignEnd() - offset) - q] += (int)dist.value_at(q);
				}		
			} else {
				for (int q = 0; q < max_len; q++) {	//forward strand/direction
					coverageHeights[(ar.get_alignStart() - offset) + q] += (int)dist.value_at(q);
				}
			}
		}
		return coverageHeights;
	}
	
	
	

	/**
	 * Function to generate an int array that represents the height at each
	 * position in a peak for PET array.
	 * 
	 * @param reads
	 * @param start
	 * @param end
	 * @return
	 */
	public static int[] generatePeakHeight_PET(Vector<AlignedRead> reads, int start, int end) { 
		int span = end - start + 1;
		int[] coverageHeights = new int[span];
		for (AlignedRead ar : reads) {
			for (int q = ar.get_alignStart(); q <= ar.get_alignEnd(); q++) {
				coverageHeights[(q - start)] += 1;
			}
		}
		return coverageHeights;
	}
	
	
	/**
	 * Function to generate an int array that represents the height at each
	* position in a peak.
	*
	* @param ar
	* @param fixed_size
	* @return
	*/
	public static int[] generatePeakHeights_fixed_width(AlignedRead[] ar,
			int fixed_size) {
		// this will store the coverage at each position in the peak

		int last_hit = ar.length - 1;
		int span = fixed_size
				+ (ar[last_hit].get_alignStart() - ar[0].get_alignStart());
		int offset = ar[0].get_alignStart();
		int[] coverageHeights = new int[span];
		for (int y = 0; y <= last_hit; y++) {
			for (int q = 0; q < fixed_size; q++) {
				if (ar[y].get_direction() == '-') {
					coverageHeights[(ar[y].get_alignStart() - offset) + q] += 1;
				} else { // forward Strand
					coverageHeights[(ar[y].get_alignStart() - offset) + q] += 1;
				}
			}
		}
		return coverageHeights;
	}

	
	
}

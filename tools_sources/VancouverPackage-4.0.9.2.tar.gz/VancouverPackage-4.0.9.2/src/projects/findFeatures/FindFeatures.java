package src.projects.findFeatures;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.ensembl.datamodel.Exon;
import org.ensembl.datamodel.Gene;
import org.ensembl.datamodel.Location;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.Ensembl;
import src.lib.IterableIterator;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.analysisTools.Exon_Overlap;
import src.lib.ioInterfaces.GSC_Aberation_Iterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Aberation;
import src.lib.objects.Aberation_Deletion;
import src.lib.objects.Aberation_Insertion;
import src.lib.objects.Aberation_SNP;



// ESCA-JAVA0100:
public class FindFeatures {
	private static Log_Buffer LB;
	private static String conf_file;
	private static Ensembl Const;
	private static String input_chr;
	private static String input_species;
	private static String prepend;
	private static String output_path;
	private static String input_file;
	private static String input_dir;
	private static String name;
	private static int ext_width;

	private static final String PARM_ALIGNER = "aligner";  
	
	private FindFeatures() {}
	
	private static void usage() {
		LB.notice("This program requires six parameters:");
		LB.notice(" -input   | <String> | provide the full path to the eland files.");
		LB.notice(" -output  | <String> | provide a valid path for the output.");
		LB.notice(" -species | <String> | Provide a Species handled in the conf file");
		LB.notice(" -chr     | <String> | Indicate which chromosome to run, or \"A\" for all.");
		LB.notice(" -conf    | <String> | The location of the configuration file to use.");
		LB.notice(" -prepend | <String> | allows a string to be prepended to the chromosome name" );
		LB.die();	
	}
	
	
	private static void parse_input(HashMap<String, String> Variables) {

		if (Variables == null) {
			usage();
		}
		
		assert(Variables != null);
		
		if (Variables.containsKey("help")) {
			usage();
		}
		
		
		/* Do bootstrap calls here */
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.notice("file names must be supplied with -name flag");
			usage();
		}
		
		if (Variables.containsKey("output")) {		
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + name  + ".log");
			LB.addLogFile(output_path + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			usage();
		}	
		
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output file name  : " + output_path);		
		LB.notice(" * Name              : " + name);
				
		if (Variables.containsKey("conf")) {		
			CommandLine.test_parameter_count(LB, "conf", Variables.get("conf"), 1);
			
			conf_file = Variables.get("conf");
			LB.notice(" * Config file       : " + conf_file);
		} else {
			LB.error("Must specify config file with the -conf flag");
			usage();
		}
		
		if (Variables.containsKey("chr")) {		
			CommandLine.test_parameter_count_min(LB, "chr", Variables.get("chr"), 1);
			input_chr = Variables.get("chr");
			LB.notice(" * Chromosome in use : " + input_chr);
		} else {
			LB.error("chomosome must be supplied with -chr flag");
			usage();
		}
		
		if (Variables.containsKey("prepend")) {
			CommandLine.test_parameter_count(LB, "prepend", Variables.get("prepend"), 1);
			prepend = Variables.get("prepend");
			LB.notice(" * Chr name prepend  : " + Variables.get("prepend"));
		} else {
			prepend = "";
			LB.notice(" * Chr name prepend  : none");
		}
		
		if (Variables.containsKey("ext_width")) {
			CommandLine.test_parameter_count(LB, "ext_width", Variables.get("ext_width"), 1);
			ext_width = Integer.valueOf(Variables.get("ext_width"));
		} else {
			ext_width = 0;
		}
		LB.notice(" * Extension width   : " + Variables.get("ext_width"));
		
		
		if (Variables.containsKey("species")) {		
			CommandLine.test_parameter_count(LB, "species", Variables.get("species"), 1);
			input_species =Variables.get("species");
			LB.notice(" * Input Species     : " + input_species);
		} else {
			LB.error("input species must be supplied with -species flag");
			usage();
		}
		
				
		if (Variables.containsKey("input_file")) {
			CommandLine.test_parameter_count(LB, "input_file", Variables.get("input_file"), 1);
			input_file = Variables.get("input_file");
			LB.notice(" * Input file        : " + input_file);
			if (Variables.containsKey("input")) {
				LB.warning("Ignoring -input flag.  Redundant with -input_file flag.");
			}
		} else if (Variables.containsKey("input")) {
			CommandLine.test_parameter_count(LB, "input", Variables.get("input"), 1);
			input_dir = Variables.get("input");
			if (!input_dir.endsWith(System.getProperty("file.separator"))) {
				input_dir = input_dir.concat(System.getProperty("file.separator"));
			}
			LB.notice(" * Input directory   : " + input_dir);
		} else { 
			LB.error("An input file must be supplied with the -input_file flag or a directory with the -input flag" );
			usage();
		}
		
		
		/*remove standard ht entries. Then process whatever is left with a warning:*/
		Variables.remove(PARM_ALIGNER);
		Variables.remove("input_file");
		Variables.remove("input");
		Variables.remove("output");
		Variables.remove("species");
		Variables.remove("chr");
		Variables.remove("conf");
		Variables.remove("name");
		Variables.remove("ext_width");
		Variables.remove("prepend");
		
		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  " + k);
			}
			LB.die();
		}
	}	
	

	
	
	/**
	 * Main function for processing Aberration data
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
	
		/* This code bootstraps the log file */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}	
		parse_input(Variables);											//interprets command line args.

		new CurrentVersion(LB);
		LB.Version("FindFeatures", "$Revision: 1591 $");
		
		Const = Ensembl.init(LB, input_species, conf_file, input_chr);	// build the Ensembl interface

		//int current_chromosome = Integer.valueOf(input_chr) - 1;
		
		
		for (int current_chromosome = 0; current_chromosome < Const.get_number_of_chromosomes(); current_chromosome++) {
			LB.notice("*** Begin Processing Chromosome " + Const.get_chromosome(current_chromosome));
			
			//This may be optional.
			String file = null;
			if (input_file != null) {
				file = input_file;
			} else {
				file = input_dir + prepend + Const.get_chr_filename(current_chromosome) + ".aberations";
			}
			String file2 = output_path + Const.get_chr_filename(current_chromosome) + ".exons.ovlp"; 
			GSC_Aberation_Iterator it = new GSC_Aberation_Iterator(LB, "aberations", file, true);
			//create iterator
			ArrayList<Aberation_Deletion> dels = new ArrayList<Aberation_Deletion>();  
			ArrayList<Aberation_Insertion> ins = new ArrayList<Aberation_Insertion>();
			ArrayList<Aberation_SNP> snps = new ArrayList<Aberation_SNP>();
			ArrayList<Aberation> othr = new ArrayList<Aberation>();
			
			//iterate over features - sorted
			for (Object a : new IterableIterator<Object>(it)) {
				if (((Aberation)a).get_type() == 'D') {
					dels.add((Aberation_Deletion)a);
				} else if (((Aberation)a).get_type() == 'S') {
					snps.add((Aberation_SNP)a);
				} else if (((Aberation)a).get_type() == 'I') {
					ins.add((Aberation_Insertion)a);
				} else if (((Aberation)a).get_type() == 'C') {
					//TODO: Add code for C type
				} else {
					othr.add((Aberation)a);		//type P is here.
				}
			}
			
			Aberation_Deletion[] deletions = new Aberation_Deletion[dels.size()];
			deletions = dels.toArray(deletions);
			dels.clear();
			
			Aberation_Insertion[] insertions = new Aberation_Insertion[ins.size()];
			insertions = ins.toArray(insertions);
			ins.clear();
			
			Aberation_SNP[] polymorphisms = new Aberation_SNP[snps.size()];
			polymorphisms = snps.toArray(polymorphisms);
			snps.clear();
			
			Aberation[] others= new Aberation[othr.size()];
			others= othr.toArray(others);
			othr.clear();
			
			// for when we do complex.
/*			Aberation_Complex[] complex= new Aberation_Complex[comp.size()];
			deletions = comp.toArray(deletions);
			comp.clear();
			comp = null;
*/			
			
			
			//identify if any overlaps exist.
			
			BufferedWriter bw = null;
			try {
				bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file2)));
			} catch (IOException io) {
				LB.error("Can't create file for output: " + file2);
				LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
				LB.die();
			}
			assert (bw != null);
			
			Location loc = new Location("chromosome", Const.get_chromosome(current_chromosome));
			LB.notice("Fetching Transcript/Exon Locations for chromosome...");
			List<Exon> exon_list = Ensembl.get_xa(loc);
			Exon[] exons = new Exon[exon_list.size()];
			exons = exon_list.toArray(exons);

			LB.notice("Fetching Transcript/Gene Locations for chromosome...");
			List<Gene> gene_list = Ensembl.get_ga(loc);
			Gene[] genes = new Gene[gene_list.size()];
			genes = gene_list.toArray(genes);
			

			LB.notice("Processing " + deletions.length + " Deletions...");
			Exon_Overlap.process_exons(LB, deletions, genes, exons,  ext_width, bw);
			
			LB.notice("Processing " + insertions.length + " Insertions...");
			Exon_Overlap.process_exons(LB, insertions, genes, exons, ext_width, bw);
			
			LB.notice("Processing " + polymorphisms.length + " polymorphisms...");
			Exon_Overlap.process_exons(LB, polymorphisms, genes, exons, ext_width, bw);
			
/*			LB.notice("Processing Complex...");
			Exon_Overlap.process_exons(LB, complex, genes, exons, ext_width, bw);
*/
			LB.notice("Curently skipping complex features.");
			
			LB.notice("Processing " + others.length + " Peaks/Other Aberations...");
			Exon_Overlap.process_exons(LB, others, genes, exons, ext_width, bw);
			
			try {
				bw.close();
			} catch (IOException io) {
				LB.warning("Can't close file - continuing.");
				LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
			}
		} 														// end chromosome
		 
		Const.destroy();
		Const = null;		
		LB.notice ("Statistics:");
		//LB.notice ("Total sequence reads used:" + reads_used);
		LB.close();
		
	}
}

package src.transcriptome_analysis.Genome_Alignment;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Vector;

import org.ensembl.datamodel.Location;
import org.ensembl.datamodel.Transcript;

import org.ensembl.variation.datamodel.VariationFeature;

import src.lib.Chromosome;
import src.lib.CommandLine;
import src.lib.Constants;
import src.lib.CurrentVersion;
import src.lib.Ensembl;
import src.lib.Histogram;
import src.lib.IterableIterator;
import src.lib.ReducedAlignedReads;
import src.lib.SNPDB;
import src.lib.Utilities;
import src.lib.mysql_wrapper;

import src.lib.Error_handling.CanNotConnectException;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.Error_handling.DoesNotMatchException;
import src.lib.Error_handling.OverflowException;

import src.lib.analysisTools.Exon_Junction_Map;
import src.lib.analysisTools.Process_Exons;
import src.lib.analysisTools.Transcript_Bias;
import src.lib.ioInterfaces.Bedwriter;
import src.lib.ioInterfaces.FastaIterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.MAQmapIterator;
import src.lib.ioInterfaces.SAMIterator;

import src.lib.objects.AlignedRead;
import src.lib.objects.MAQRyanMap;
import src.lib.objects.SNP;
import src.lib.objects.SimpleAlignedRead;



/**
 * @version $Revision: 1702 $
 * @author 
 */
// ESCA-JAVA0100:
public class GenomicAlignmentAnalysis {
	private static final int JUNCTION_HALF_WIDTH_36 = 35;
	private static final String JUNCTION_READ_NAME_36 = "all_junctions.36.version2";
	private static final int JUNCTION_HALF_WIDTH_42 = 41;
	private static final String JUNCTION_READ_NAME_42 = "all_junctions.42.version2";	
	private static final int JUNCTION_HALF_WIDTH_50 = 49;
	private static final String JUNCTION_READ_NAME_50 = "all_junctions.50.version2";
	
	private static int JUNCTION_HALF_WIDTH;
	private static String JUNCTION_READ_NAME;
	
	/* current state for Transcriptome processor*/
	private static Ensembl Const;
	private static Chromosome Chr;
	private static int current_chromosome;
	private static mysql_wrapper mysql;


	/*state for junctions*/
	private static boolean junctions;
	private static String junction_map;
	private static int junctionsize;

	/*input variables*/
	private static String aligned_file_path;
	private static String input_file;
	private static String output_path;
	private static String input_species;
	private static String input_chr;
	private static float min_percent;
	private static int min_observed;
	private static String conf_file;
	private static String aligner;
	private static String prepend;
	private static String name;
	private static int maq_read_size;
	private static int min_aln_quality;
	private static int min_base_quality;
	private static boolean transcript_profile = false;
	private static boolean process_exons = true;
	private static boolean snp_process = false;
	
	private static boolean wig_file;
	private static boolean cov;
	
	/*for transcript bias*/
	private static final int HIST_BINS = 140;
	private static final int HIST_START = -20;
	private static final int HIST_WIDTH = 120;
	static final int end_bias_size = 100;
	
	static int[] Bias_start;
	static int[] Bias_end;
	static Histogram Bias_overall;
	
	/*run statistics*/
	static int reads_used = 0;
	static HashMap<String, Integer> map_transcript_exon;
	
	static final int INIT_VECTOR_SIZE = 100;

	private static Log_Buffer LB = null;

	private GenomicAlignmentAnalysis() {} 
	
	/**
	 * Processing command line arguments for program.
	 * 
	 * @param Variables
	 */
	private static void parse_input(HashMap<String, String> Variables) {
		if (Variables == null) {
			usage();
		}
		assert (Variables != null);

		if (Variables.containsKey("help")) {
			usage();
		}

		/* Do bootstrap calls here */
		if (Variables.containsKey("name")) {		
			CommandLine.test_parameter_count(LB, "name", Variables.get("name"), 1);
			name =Variables.get("name");
		} else {
			LB.notice("file names must be supplied with -name flag");
			usage();
		}
		
		if (Variables.containsKey("output")) {		
			CommandLine.test_parameter_count(LB, "output", Variables.get("output"), 1);
			output_path = Variables.get("output");
			if (!output_path.endsWith(System.getProperty("file.separator"))) {
				output_path = output_path.concat(System.getProperty("file.separator"));
			}
			LB.notice("Log File: " + output_path + name  + ".log");
			LB.addLogFile(output_path + name  + ".log");
		} else {
			LB.error("An output directory must be supplied with the -output flag" );
			usage();
		}	
		
		/* end bootstrap  - print out results of bootstrapped variables*/ 
		LB.notice(" * Output directory  : " + output_path);		
		LB.notice(" * Name              : " + name);
		
		if (Variables.containsKey("aligner")) {		
			CommandLine.test_parameter_count_min(LB, "aligner", Variables.get("aligner"), 1);
			aligner = Variables.get("aligner");
			LB.notice(" * Input aligner     : " + aligner);
		} else {
			LB.error("aligner must be supplied with -aligner flag");
			usage();
		}

		if (Variables.containsKey("force32")) {
			CommandLine.test_parameter_count(LB, "force32", Variables.get("force32"), 0);
			Chromosome.set_force32(true);
			LB.notice(" * Filter Duplicates : On");
		} else {
			Chromosome.set_force32(false);
			LB.notice(" * Filter Duplicates : Off");
		}

		if (Variables.containsKey("min_alt")) {
			CommandLine.test_parameter_count(LB, "min_alt", Variables.get("min_alt"), 1);
			min_percent = Float.parseFloat(Variables.get("min_alt"));
			if (min_percent >1 || min_percent < 0) {
				LB.error("Min_alt value must be in the range of zero to one.");
				LB.die();
			}
		} else { 
			LB.error("Must specify minimum alternative base percent for SNP positions with the -min_alt flag");
			usage();
		}
		LB.notice(" * Min. change fract : " + min_percent);
		
		if (Variables.containsKey("min_obs")) {
			CommandLine.test_parameter_count(LB, "min_obs", Variables.get("min_obs"), 1);
			min_observed = Integer.parseInt(Variables.get("min_obs"));
		} else { 
			LB.error("Must specify minimum observed base count for SNP positions with the -min_obs flag");
			usage();
		}
		LB.notice(" * Minimum coverage  : " + min_observed);

		if (Variables.containsKey("conf")) {
			CommandLine.test_parameter_count(LB, "conf", Variables.get("conf"), 1);
			conf_file = Variables.get("conf");
			LB.notice(" * Config file       : " + conf_file);
		} else {
			LB.error("Must specify config file with the -conf flag");
			usage();
		}
		
		if (Variables.containsKey("junctionmap")) {		
			if (!aligner.equalsIgnoreCase(Constants.FILE_TYPE_MAQ)) { 
				LB.error("This parameter may only be used with -aligner maq");
				LB.die();
			}
			CommandLine.test_parameter_count(LB, "junctionmap", Variables.get("junctionmap"), 1);
			junction_map = Variables.get("junctionmap");
			junctions = true;
			LB.notice(" * Junction map file : " + junction_map);
		} else {
			junctions = false;
			LB.notice(" * Junctions         : Skipped");
		}

		if (Variables.containsKey("junctionsize")) {		
			if (!junctions) { 
				LB.error("the -junctionsize parameter may only be used if the -junctionmap parameter is used.");
				LB.die();
			}
			CommandLine.test_parameter_count(LB, "junctionsize", Variables.get("junctionsize"), 1);
			junctionsize = Integer.valueOf(Variables.get("junctionsize"));
			LB.notice(" * Map junction size : " + junctionsize);
			if (junctionsize == 36) {
				JUNCTION_HALF_WIDTH = JUNCTION_HALF_WIDTH_36;
				JUNCTION_READ_NAME = JUNCTION_READ_NAME_36;
			} else if (junctionsize == 42) {
				JUNCTION_HALF_WIDTH = JUNCTION_HALF_WIDTH_42;
				JUNCTION_READ_NAME = JUNCTION_READ_NAME_42;
			} else if (junctionsize == 50) {
				JUNCTION_HALF_WIDTH = JUNCTION_HALF_WIDTH_50;
				JUNCTION_READ_NAME = JUNCTION_READ_NAME_50;
			} else {
				LB.notice("Supported junction sizes are : 36, 42 and 50.  Specified junction size of " +
						junctionsize + " is not currently available.");
				LB.die();
			}
		} else {
			if (junctions) { 
				LB.error("Must specify junction size with the -junctionsize flag, if junctions are in use");
				usage();
			}
		}
		
		if (Variables.containsKey("override_mapname")) {
			CommandLine.test_parameter_count(LB, "override_mapname", Variables.get("override_mapname"), 1);
			JUNCTION_READ_NAME = Variables.get("override_mapname");
		}
		
/*		if (Variables.containsKey("transcript_profile")) {
			CommandLine.test_parameter_count(LB, "transcript_profile", Variables.get("transcript_profile"), 0);
			transcript_profile = true;
		} else {
*/			transcript_profile = false;
/*
		}
		LB.notice(" * Transcript profile: " +  ((transcript_profile) ? "On" : "Off"));
*/		
/*		if (Variables.containsKey("wig_file")) {
			wig_file = true;
		} else {
			wig_file = false;
		}
		LB.notice(" * Transcript profile: " +  ((wig_file) ? "On" : "Off"));
*/		
/*		if (Variables.containsKey("coverage")) {
			cov = true;
		} else {
			cov = false;
		}
		LB.notice(" * Calculate coverage: " +  ((cov) ? "On" : "Off"));
*/		
	cov = true;



		if (Variables.containsKey("prepend")) {
			CommandLine.test_parameter_count(LB, "prepend", Variables.get("prepend"), 1);
			prepend = Variables.get("prepend");
			LB.notice(" * Chr name prepend  : " + Variables.get("prepend"));
		} else {
			prepend = "";
			LB.notice(" * Chr name prepend  : none");
		}
		
		if (aligner.equals("maq")) {
			if (Variables.containsKey("maq_read_size")) {
				CommandLine.test_parameter_count(LB, "maq_read_size", Variables.get("maq_read_size"), 1);
				maq_read_size = Integer.valueOf(Variables.get("maq_read_size"));
				LB.notice(" * Maq read size     : " + maq_read_size);
			} else {
				LB.error("Must specify list of size of the maq reads with the -maq_read_size flag."
						+ " Use 64 for maq 0.6.x use 128 for maq 0.7+");
				usage();
			}
		}
		
		if (Variables.containsKey("min_aln_quality")) {
			if (!aligner.equals("maq") && !aligner.equals("sam")) {
				LB.notice("-min_aln_quality only used for maq or sam aligner");
				usage();
			}
			CommandLine.test_parameter_count(LB, "min_aln_quality", Variables.get("min_aln_quality"), 1);
			min_aln_quality = Integer.valueOf(Variables.get("min_aln_quality"));
			LB.notice(" * Min align quality : " + min_aln_quality);
		} else {
			min_aln_quality = 0;
		}

		if (Variables.containsKey("min_base_quality")) {
			if (!aligner.equals("maq") && !aligner.equals("sam")) {
				LB.notice("-min_base_quality only used for maq or sam aligners");
				usage();
			}
			CommandLine.test_parameter_count(LB, "min_base_quality", Variables.get("min_base_quality"), 1);
			min_base_quality = Integer.valueOf(Variables.get("min_base_quality"));
			LB.notice(" * Min base quality  : " + min_base_quality);
		} else {
			min_base_quality = 0;
		}

		if (Variables.containsKey("chr")) {
			CommandLine.test_parameter_count_min(LB, "chr", Variables.get("chr"), 1);
			input_chr = Variables.get("chr");
			LB.notice(" * Chromosome in use : " + input_chr);
		} else {
			LB.error("chomosome must be supplied with -chr flag");
			usage();
		}

		if (Variables.containsKey("species")) {
			CommandLine.test_parameter_count(LB, "species", Variables.get("species"), 1);
			input_species =Variables.get("species");
			LB.notice(" * Input Species     : " + input_species);
		} else {
			LB.error("input species must be supplied with -species flag");
			usage();
		}

		if (Variables.containsKey("input_file")) {
			CommandLine.test_parameter_count(LB, "input_file", Variables.get("input_file"), 1);
			input_file = Variables.get("input_file");
			LB.notice(" * Input file        : " + input_file);
			if (Variables.containsKey("input")) {
				LB.warning("Ignoring -input flag.  Redundant with -input_file flag.");
			}
		} else if (Variables.containsKey("input")) {
			CommandLine.test_parameter_count(LB, "input", Variables.get("input"), 1);
			aligned_file_path = Variables.get("input");
			if (!aligned_file_path.endsWith(System.getProperty("file.separator"))) {
				aligned_file_path = aligned_file_path.concat(System.getProperty("file.separator"));
			}
			LB.notice(" * Input directory   : " + aligned_file_path);
		} else { 
			LB.error("An input file must be supplied with the -input_file flag or a directory with the -input flag" );
			usage();
		}

		/*remove standard ht entries. Then process whatever is left with a warning:*/
		Variables.remove("input_file");
		Variables.remove("input");
		Variables.remove("output");
		Variables.remove("species");
		Variables.remove("chr");
		Variables.remove("conf");
		Variables.remove("name");
		Variables.remove("min_alt");
		Variables.remove("min_obs");
		Variables.remove("force32");
		Variables.remove("aligner");
		Variables.remove("junctionmap");
		Variables.remove("junctionsize");
		Variables.remove("maq_read_size");
		Variables.remove("min_aln_quality");
		Variables.remove("min_base_quality");
		Variables.remove("transcript_profile");
		Variables.remove("override_mapname");
		Variables.remove("prepend");
		Variables.remove("coverage");
		
		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  * " + k);
			}
			LB.die();
		}
	}

	private static void usage() {
		LB.notice("This program requires the following parameters:");
		LB.notice(" -input         | <String> | provide the full path to the aligned file.");
		LB.notice(" -output        | <String> | provide a valid path for the output.");
		LB.notice(" -species       | <String> | Provide a Species handled in the conf file");
		LB.notice(" -chr           | <String> | Indicate which chromosome to run, or \"A\" for all.");
		LB.notice(" -min_alt       | <Float>  | Indicate the minimum fraction for calling a snp (eg 0.5");
		LB.notice(" -min_obs       | <Int>    | Indicate the minimum coverage that must be observed to call. (eg 4)");
		LB.notice(" -force32       |          | use to force the maximum read length to be 32 bases.");
		LB.notice(" -aligner       | <String> | Name of the aligner that provided the reads (defines file format).");
		LB.notice(" -name          | <String> | Provides an identifier at the start of each file name.");
		LB.notice(" -conf          | <String> | The location of the configuration file to use.");
		LB.notice(" -junctionmap   | <String> | The location of the junction map file to use.");
		LB.notice(" -maq_read_size | <int>    | The length of the seq field in the binary map value (64 or 128)");
		LB.notice(" -maq_aln_quality  | <int> | The minimum alignment quality value for maq/sam reads.");
		LB.notice(" -min_base_quality | <int> | The minimum base quality value for maq/sam reads.");
		LB.notice(" -transcript_profile       | Turns on transcript profiling.");
		LB.die();
	}

	/**
	 * 
	 * @param Const
	 * @param current_chr
	 * @param prepend
	 * @param min_base_qual
	 * @return
	 */
	private static Chromosome new_chr_from_fasta_file (Ensembl Const, int current_chr, int min_base_qual, String prepend) {
		FastaIterator fi = new FastaIterator(LB, Const.getFastaFilename(current_chr));
		String[] rrr = fi.next();
		fi.close();
		return new Chromosome(LB, rrr[1], prepend + Const.get_chr_filename(current_chr), min_base_qual);
	}

	/**
	 * 
	 * @param filename
	 * @param chrname
	 * @param min_base_qual
	 * @return
	 */
	private static Chromosome new_chr_from_fasta_file (String filename, String chrname, int min_base_qual) {
		FastaIterator fi = new FastaIterator(LB, filename);
		String[] rrr = fi.next();
		fi.close();
		return new Chromosome(LB, rrr[1], chrname, min_base_qual);
	}

	private static int add_spanned_reads_to_chr(Vector<SimpleAlignedRead> mapped_junctions, String last_chromosome) {
		int number_of_mapped_reads = 0;
		for (SimpleAlignedRead x : mapped_junctions) {
			if (last_chromosome.equals(x.get_chr())) {
				try {
					Chr.addSimpleAlignedReadBaseCount(x, 1);
					number_of_mapped_reads++;
				} catch (DoesNotMatchException dnme) {
					LB.warning("Failed to Parse Eland Read: " + dnme.getMessage());
					LB.warning(x.toString());
				} catch (OverflowException oe) {
					LB.warning(oe.getMessage());
					LB.warning(x.toString());
				}	
			}	
		}
		return number_of_mapped_reads;
	}

	//TODO: Blankly moved over.. Needs update.
	
	private static int Maq_process() {
		int number_of_added_reads = 0;
		MAQRyanMap[] all_junctions = null;
		if (junctions) {
			LB.notice("Reading in Ryan's junction to genome mappings");
			all_junctions = Exon_Junction_Map.get_all_junctions_map(LB, junction_map);
		}
		LB.notice("First Pass - getting chromosome names");
		LB.notice("input_file : " + input_file);
		MAQmapIterator m = new MAQmapIterator(LB, "mapfile", input_file, min_aln_quality, maq_read_size, 0); //create maq iterator
		String[] chromosome_names = m.get_chromosomes();		// get list of chromosomes
		for (String c : chromosome_names) {						// print list of chromosomes
			LB.notice(c);
		}

		if (transcript_profile) {
			LB.notice("Init Transcript bias variables");
			Bias_start = new int[end_bias_size];
			Bias_end = new int[end_bias_size];
			Bias_overall = new Histogram(LB, HIST_BINS, HIST_START, HIST_WIDTH, false);
		}
		boolean first_pass_needed = false;
		Vector<SimpleAlignedRead> mapped_junctions = null; 
		if (junctions) {
			mapped_junctions = new Vector<SimpleAlignedRead>();
			if (junctions && !chromosome_names[0].trim().equals(JUNCTION_READ_NAME)) {
				first_pass_needed = true;
				LB.notice("Will process in two passes");
			} else {
				first_pass_needed = false; //don't need two passes.
				LB.notice("Will process in one pass only");
			}
		}

		if (first_pass_needed) {
			assert(mapped_junctions != null);
			LB.notice("first pass started");
			int count_processed = 0;
			int count_failed = 0;
			while (m.hasNext()) {
				AlignedRead x = null;
				try {
					x = m.next();
				} catch (NoSuchElementException nsee) {
					continue;
				}
				if (x.get_chromosome().equals(JUNCTION_READ_NAME)) {
					Vector<SimpleAlignedRead> tmp = Exon_Junction_Map.TranslateJunction(LB, x, all_junctions, JUNCTION_HALF_WIDTH);
					if (tmp != null) {
						mapped_junctions.addAll(tmp);
						count_processed++;
						number_of_added_reads++;
					} else {
						LB.notice("Skipped a junction - could not map it.");
						LB.notice("Sequence: " + x.get_sequence());
						count_failed++;
						continue;
					}
				}
			}
			LB.notice("first pass ended. " + count_processed + "reads processed and " + count_failed + " reads failed");
			m.close(false);
			LB.notice("creating maq map iterator.");
			m = new MAQmapIterator(LB, "mapfile", input_file, min_aln_quality, maq_read_size, 0); //recreate maq iterator
		}

		int nbLoop=0;
		String last_chromosome = "";
		String Chromosome_name = "";
		LB.notice("beginning to process aligned .map file.");
		while (m.hasNext()) {
			nbLoop++;
			AlignedRead x = null;
			try {
				//x = m.next().toSimpleAlignedRead();
				x = m.next();
			} catch (NoSuchElementException nsee) {
				continue;
			}
			if (junctions) {
				assert(mapped_junctions != null);
				if (x.get_chromosome().equals(JUNCTION_READ_NAME)) {		//if it's a junction, break it up and translate
					Vector<SimpleAlignedRead> tmp = Exon_Junction_Map.TranslateJunction(LB, x, all_junctions, JUNCTION_HALF_WIDTH);
					if (tmp != null) {
						mapped_junctions.addAll(tmp);
						number_of_added_reads++;
					} else {
						/*LB.notice("Skipped a junction - could not map it.");*/
						/*LB.notice("Sequence: " + x.get_seq());
						LB.notice("Quality: " + x.get_prb_string());*/
						continue;
					}
				}
			}
			/*if (x.get_chr().equals(JUNCTION_READ_NAME)) {
				mapped_junctions.addAll(TranslateJunction(x, all_junctions));
				continue;
			}*/
			if (!last_chromosome.equals(x.get_chromosome())) {
				current_chromosome = Const.index_chromosomes(Utilities.translate_Current_Chromosome(last_chromosome));
				if (current_chromosome >= 0) {	
					if (junctions) {			//Add in reads from translated gaps. 					
						LB.notice("Adding in mapped Spanning reads");
						add_spanned_reads_to_chr(mapped_junctions, last_chromosome);
					}

					if (transcript_profile || process_exons) {
						Location loc = new Location("chromosome", Const.get_chromosome(current_chromosome));
						List<Transcript> list = Ensembl.get_ta(loc);
						if (process_exons) {
							Process_Exons.process_exons(LB, Const, Chr, list,
								current_chromosome, input_species, output_path,
								min_percent, min_observed);
						}
						if (transcript_profile) {
							Transcript_Bias.check_bias(LB, Const, Chr, list,
								Bias_overall, Bias_start, Bias_end,
								current_chromosome, output_path, HIST_BINS,
								HIST_START, HIST_WIDTH);
						}
					}
					if (cov) {
						LB.notice("The coverage at " + min_observed + "x is : " + Chr.coverage(min_observed));
					}
					if (snp_process) {
						LB.notice("Looking for snps now.");
						snp_processing();
					}
					Chr.destroy();
					Chr = null;
				}
				Chromosome_name = Utilities.translate_Current_Chromosome(x.get_chromosome());
				if (Const.index_chromosomes(Chromosome_name) >=0) {
					LB.notice("Retrieving canonical sequence for chromosome: " + Chromosome_name);	
					String ffile = Const.getFastaFilename(Chromosome_name, prepend);
					Chr = new_chr_from_fasta_file(ffile, Chromosome_name, min_base_quality);	
				}
			}
			try {
				if (Chr != null) {
					if (x.get_identity() == 130 && x.get_maq_indel_len() != 0) {
						Chr.addGappedRawBaseCount(x, 1, false);
					} else {
						Chr.addSimpleAlignedReadBaseCount(x.toSimpleAlignedRead(), 1);
					}
					number_of_added_reads++;
				}
			} catch (DoesNotMatchException dnme) {
				LB.warning("Failed to Parse Maq Read: " + dnme.getMessage());
				LB.warning(x.toString());
			} catch (OverflowException oe) {
				LB.warning(oe.getMessage());
				LB.warning(x.toString());
			}
//			current_reads.addLast(x);
			last_chromosome = x.get_chromosome();
//			LB.notice(x.get_chromosome() + "\t" + x.get_sequence() + "\t" + x.get_name() + "\t" + x.get_direction());
//			StringBuffer qual = new StringBuffer();
//			for (int g = 0; g < x.get_alignLength(); g++) {
//				qual.append(x.get_quality(g) + " ");
//			}
//			LB.notice(qual.toString());
		}
		//
		if (Chr != null) {
			current_chromosome = Const.index_chromosomes(Utilities.translate_Current_Chromosome(last_chromosome));
			if (current_chromosome >= 0) {	
				if (junctions) {
					LB.notice("Adding in mapped Spanning reads");
					number_of_added_reads += add_spanned_reads_to_chr(mapped_junctions, last_chromosome);
				}
				LB.notice("Looking for snps now.");
				if (transcript_profile || process_exons) {
					Location loc = new Location("chromosome", Const.get_chromosome(current_chromosome));
					List<Transcript> list = Ensembl.get_ta(loc);
					if (process_exons) {
						Process_Exons.process_exons(LB, Const, Chr, list,
							current_chromosome, input_species, output_path,
							min_percent, min_observed);
					}
					if (transcript_profile) {
						Transcript_Bias.check_bias(LB, Const, Chr, list,
							Bias_overall, Bias_start, Bias_end,
							current_chromosome, output_path, HIST_BINS,
							HIST_START, HIST_WIDTH);
					}
				}
				if (cov) {
					LB.notice("The coverage at " + min_observed + "x is : " + Chr.coverage(min_observed));
				}
				if (snp_process) {
					LB.notice("Looking for snps now.");
					snp_processing();
				}
				if (wig_file) {
					LB.notice("Writing Wig File...");
					Chr.generate_wig_file(output_path, "chr");
					LB.notice("Done");
				}
				if (cov) {
					LB.notice("The coverage at " + min_observed + "x is : " + Chr.coverage(min_observed));
				}
				Chr.destroy();
				Chr = null;
			}
		}
		return number_of_added_reads;
	}
	
	//TODO: Code copied over, needs rebuild.
	
	private static int sam_Process(){
		int number_of_added_reads=0;
	
		if (transcript_profile) {
			LB.notice("Setting up to process Transcript bias");
			Bias_start = new int[end_bias_size];
			Bias_end = new int[end_bias_size];
			Bias_overall = new Histogram(LB, HIST_BINS, HIST_START, HIST_WIDTH, false);
		}
		SAMIterator iterator =new SAMIterator(LB,"source", input_file, 0, min_aln_quality, SAMIterator.ALLOWS_SPLIT_READ);
		String last_chromosome="";
		String Chromosome_name = "";
		while (iterator.hasNext()) {
			AlignedRead alnrd = iterator.next();
			if (!last_chromosome.equals(alnrd.get_chromosome())) {
				current_chromosome = Const.index_chromosomes(Utilities.translate_Current_Chromosome(last_chromosome));
				if (current_chromosome >= 0) {	
					LB.notice("Looking for snps now.");
					if (transcript_profile) {
						Location loc = new Location("chromosome", Const.get_chromosome(current_chromosome));
						List<Transcript> list = Ensembl.get_ta(loc);
						Transcript_Bias.check_bias(LB, Const, Chr, list,
								Bias_overall, Bias_start, Bias_end,
								current_chromosome, output_path, HIST_BINS,
								HIST_START, HIST_WIDTH);
						Process_Exons.process_exons(LB, Const, Chr, list, 
								current_chromosome, input_species, output_path, min_percent, min_observed);
					} else {
						Process_Exons.process_exons(LB, map_transcript_exon, Const,
								Chr, current_chromosome, input_species, aligner,
								output_path, min_percent, min_observed);
					}
					
					Chr.destroy();
					Chr = null;
				}
				Chromosome_name = Utilities.translate_Current_Chromosome(alnrd.get_chromosome());
				if (Const.index_chromosomes(Chromosome_name) >=0) {
					LB.notice("Retrieving canonical sequence for chromosome: " + Chromosome_name);	
					String ffile = Const.getFastaFilename(Chromosome_name, prepend);
					Chr = new_chr_from_fasta_file(ffile, Chromosome_name, min_aln_quality);	
				}
			}
			try {
				if (Chr != null) {
					Chr.addSimpleAlignedReadBaseCount(alnrd.toSimpleAlignedRead(), 1);
					number_of_added_reads++;
				}
			} catch (DoesNotMatchException dnme) {
				LB.warning("Failed to Parse Sam Read: " + dnme.getMessage());
				LB.warning(alnrd.toString());
			} catch (OverflowException oe) {
				LB.warning(oe.getMessage());
				LB.warning(alnrd.toString());
			}
			last_chromosome = alnrd.get_chromosome();
		}
		return number_of_added_reads;
	}
	
	/**
	 * This function processes SNPs, by retrieving all known snps for a given
	 * chromsome, before getting all observed snps (using a CLI passed
	 * variable). These two lists are then compared using a binary search to
	 * find the snps, and report on whether they're known, novel, or new for a
	 * given position
	 */
	private static void snp_processing() {

		BufferedWriter snpfile = null;

		try {
			snpfile = new BufferedWriter(new FileWriter(output_path
					+ Const.get_chromosome(current_chromosome) + ".snps"));
		} catch (IOException io) {
			LB.error("Error creating SNPs files.");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}

		assert (snpfile != null);
		
		
		LB.notice("Retrieving all known SNPs from Ensembl variation db for chromosome... ");
		SNPDB[] SNP_list = null;
		List<VariationFeature> variations_list = Ensembl.get_vfa(new Location(
				"chromosome", Const.get_chromosome(current_chromosome)));
		SNP_list = new SNPDB[variations_list.size()];
		for (int v = 0; v < variations_list.size(); v++) {
			VariationFeature A = variations_list.get(v);
			SNP_list[v] = new SNPDB();
			SNP_list[v].set_details(A.getAlleleString().toString());
			SNP_list[v].set_start(A.getLocation().getStart());
		}
		variations_list.clear();
		LB.notice("Done");

		LB.notice("Processing Simple SNPS in Chromosome...");
		ArrayList<SNP> ALL_snps = new ArrayList<SNP>();
		ALL_snps = Chr.get_all_SNPs(min_percent, min_observed);
		String bedfile = output_path + Const.get_chromosome(current_chromosome)
				+ ".SNP.bed.gz";
		Bedwriter bed = new Bedwriter(LB, bedfile);
		bed.BedHeader("SNPs", "SNPs found", false);
		int snpcnt = 0;
		try {
			for(SNP base : ALL_snps) {
				snpcnt++;
				int pos = base.get_position();
				char alt_base = base.get_new_base();
				float score = ((((float) base.get_coverage_snp()) / ((float) base
						.get_total_coverage())) * Constants.PERCENT_100);
				/* wig files are 1 based, bed files are zero based.*/
				snpfile.write(Const.get_chromosome(current_chromosome) + ","
						+ (pos + 1) + ",");
				snpfile.write(base.get_coverage_snp() + "," + base.get_total_coverage() + ","
						+ alt_base + ",");
				bed.writelineSNP("chr" + Const.get_chromosome(current_chromosome),
						pos, alt_base, (int) score);
				
				int index = SNPDB.SNPbinarySearch(SNP_list, pos + 1); 	// check if in SNP_list
				if (index != -1) {
					String Allele = SNP_list[index].get_details();
					if (Allele.length() < 3) {
						LB.warning("Allele found, no SNP! :" + Allele);
						snpfile.write("novel(nosnp)\n");
					} else {									// else, does not match - no known snp.
						snpfile.write(Utilities.is_expected_base(Allele,
								Chr.get_base_at(pos), alt_base));
						
					}
				} else {
					snpfile.write("novel\n");
				}
			}
			
		} catch (IOException io) {
			LB.error("Can't write snp files");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		ALL_snps.clear();
		LB.notice("Done");
		LB.notice(snpcnt + " SNPS found");

		try {
			snpfile.close();
		} catch (IOException io) {
			LB.warning(io.getStackTrace().toString());
			LB.warning("Warning: Could not close buffered writer");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		bed.close();
	}

	/**
	 * Main function for processing Transcriptome data.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
		Thread th = new Thread(LB);
		th.start();
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}
		parse_input(Variables);									//interprets command line args.

		new CurrentVersion(LB);
		LB.Version("GenomeAlignmentAnalysis", "$Revision: 1702 $");

		Const = Ensembl.init(LB, input_species, conf_file, input_chr);// build the Ensembl interface 		
		mysql = mysql_wrapper.init(LB);
		LB.notice("Retrieving Ensembl Transcript-Exon Mappings...                        ");
		try {
			map_transcript_exon = mysql.get_exon_transcript_mapings();
		} catch (CanNotConnectException cnce) {
			LB.error(cnce.getMessage());
			LB.die();
		}
		mysql.destroy();
		mysql = null;
		
		if (aligner.equalsIgnoreCase(Constants.FILE_TYPE_ELAND)) {
			if (transcript_profile) {
				LB.notice("Setting up to process Transcript bias");
				Bias_start = new int[end_bias_size];
				Bias_end = new int[end_bias_size];
				Bias_overall = new Histogram(LB, HIST_BINS, HIST_START, HIST_WIDTH, false);
			}
			for (current_chromosome = 0; current_chromosome < Const.get_number_of_chromosomes(); current_chromosome++) {
				LB.notice("*** Begin Processing Chromosome " + Const.get_chromosome(current_chromosome));
				LB.notice("Creating Chromosome.");
				Chr = new_chr_from_fasta_file(Const, current_chromosome, min_aln_quality, prepend);
				String elandfile = aligned_file_path + Const.get_chr_filename(current_chromosome) + ".part.eland.gz";
				reads_used += ReducedAlignedReads.LoadElandReads(LB, elandfile, Chr, Const, current_chromosome);

				Location loc = new Location("chromosome", Const.get_chromosome(current_chromosome));
				List<Transcript> list = Ensembl.get_ta(loc);
				if (process_exons) {
					Process_Exons.process_exons(LB, Const, Chr, list,
						current_chromosome, input_species, output_path,
						min_percent, min_observed);
				}
				list.clear();
				if (snp_process) {
					snp_processing();
				}
				if (transcript_profile) {
					Bias_start = new int[end_bias_size];
					Bias_end = new int[end_bias_size];
					Bias_overall = new Histogram(LB, HIST_BINS, HIST_START, HIST_WIDTH, false);
					Transcript_Bias.check_bias(LB, Const, Chr, list,
							Bias_overall, Bias_start, Bias_end,
							current_chromosome, output_path, HIST_BINS,
							HIST_START, HIST_WIDTH);
				}
				if (cov) {
					LB.notice("The coverage at " + min_observed + "x is : " + Chr.coverage(min_observed));
				}
				Chr.destroy();
				Chr = null;
			} 														// end chromosome
		} else if (aligner.equals("maq")) {
			reads_used = Maq_process();
		} else if (aligner.equals("sam")){
			reads_used = sam_Process();
		}
		
		if (transcript_profile && (Const.get_number_of_chromosomes() > 1)) {
			LB.notice("Writing Complete Transcriptome files...");
			Transcript_Bias.write_whole_transcript_bias(LB, Bias_overall, Bias_start,
					Bias_end, end_bias_size, output_path);
			LB.notice("Done");
		}														// end chromosome
		Const.destroy();
		Const = null;
		map_transcript_exon = null;		
		LB.notice ("Statistics:");
		LB.notice ("Total sequence reads used:" + reads_used);
		LB.close();
	}

}
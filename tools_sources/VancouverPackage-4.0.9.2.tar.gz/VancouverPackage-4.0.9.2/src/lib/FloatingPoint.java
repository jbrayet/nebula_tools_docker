package src.lib;

/**
 * @version $Revision: 320 $
 * @author 
 */
public class FloatingPoint {
	
	private FloatingPoint() {}
	
	
	private static final double EPSILON = 0.0000001;
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static boolean are_values_equal(double a, double b) {
		return Math.abs(a - b) < EPSILON;
	}
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static boolean are_values_equal(float a, float b) {
		return Math.abs(a - b) < EPSILON;
	}

	/**
 	 * Get the smaller of two floats. If they're the same, return the first.
 	 * @param a
 	 * @param b
 	 * @return smaller of two floats.
 	 */
	public static final float smallest(float a, float b) {
		if (b < a) {
			return b;
		} else {
			return a;
		}
	}
	
	/**
	 * This function gives k! (factorial)
	 * 
	 * This is Matthew's naive implementation. From research on the web, it's
	 * pretty obvious that this method is only reasonably fast for values of k
	 * under ~20. After that, much more efficient methods are suggested.
	 * 
	 * @param k
	 * @return Factorial value of k
	 * @deprecated
	 */
	public static double bang(int k) {
		double k_factorial = 1;
		for (int j = 1; j <= k; j++) {
			k_factorial *= j;
		}
		return k_factorial;
	}

	
}

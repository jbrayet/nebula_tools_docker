package src.lib.Error_handling;

/**
 * @author GPL Software
 * @version "$Revision: 410 $"
 */

public class UnexpectedCharacterException extends Exception {
       
	/**
	 *	Generated serial Version - I'm not sure how this works 
	 */
	private static final long serialVersionUID = 7928319722378803166L;

	public UnexpectedCharacterException(String message) {
		super(message);
	}
	
}

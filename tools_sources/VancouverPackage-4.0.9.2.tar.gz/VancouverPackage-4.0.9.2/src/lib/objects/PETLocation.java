package src.lib.objects;


/**
 * @version $Revision: 463 $
 * @author 
 */
public class PETLocation {
	private String contig_f = null;
	private int position_f = 0;
	private boolean direction_f = true;
	private short length_f = 0;
	
	private String contig_r = null;
	private int position_r = 0;
	private boolean direction_r = false;
	private short length_r = 0;
	
	public String get_contig_f() {
		return this.contig_f;
	}
	
	public int get_position_f() {
		return this.position_f;
	}
	
	public boolean get_direction_f() {
		return this.direction_f;
	}
	
	public short get_length_f() {
		return this.length_f;
	}
	
	
	public String get_contig_r() {
		return this.contig_r;
	}
	
	public int get_position_r() {
		return this.position_r;
	}
	
	public boolean get_direction_r() {
		return this.direction_r;
	}
	
	public short get_length_r() {
		return this.length_r;
	}
	
	public void set_f(String cf, int pf, boolean df, short lf) {
		this.contig_f = cf;
		this.position_f = pf;
		this.direction_f = df;
		this.length_f = lf;
		
	}
	
	public void set_r(String cr, int pr, boolean df, short lf) {
		this.contig_r = cr;
		this.position_r = pr;
		this.direction_r = df;
		this.length_r = lf;
	}
	
}

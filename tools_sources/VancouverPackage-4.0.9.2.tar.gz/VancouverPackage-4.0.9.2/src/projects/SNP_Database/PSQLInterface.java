package src.projects.SNP_Database;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.UUID;

import src.lib.Error_handling.CanNotConnectException;
import src.lib.Error_handling.PSQLInterfaceException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;
import src.projects.SNP_Database.objects.Library;

/**
 * @version $Revision: 1672 $
 * @author 
 */
public class PSQLInterface {

	private static Log_Buffer LB;
	private static boolean display_version = true;

	private static boolean initialized;
	private static Connection PSQLInterface2;
	
	private static Hashtable<String, String> Variables = new Hashtable<String, String>();

	/* Information on the psql driver
	 * http://jdbc.postgresql.org/documentation/84/index.html
	 */
	
	public void destroy() {
		PSQLInterface2 = null;
		initialized = false;
	}
	
	
	public static PSQLInterface init(Log_Buffer logbuffer, String const_file) {
		PSQLInterface m = new PSQLInterface(logbuffer, const_file);
		return m;
	}
	

	/**
	 * 
	 * @return
	 */
	private static String get_sql_connect_string() {
		String sql_con = "jdbc:postgresql://";
		/*sql_con += "afejes02.phage.bcgsc.ca:5432/GSCvariation?user=afejes&password=" + password;*/
		
		
		sql_con += Variables.get("host") + ":"; 
		sql_con += Variables.get("port") + "/"; 
		sql_con += Variables.get("dbName") + "?user="; 
		sql_con += Variables.get("user") + "&password=";
		sql_con += Variables.get("password");
		
		/*LB.warning("connection string: " +sql_con);*/
		return sql_con;
	}
	

	public PSQLInterface(Log_Buffer logbuffer, String const_file) {
		LB = logbuffer; 
		if (display_version) {
			LB.Version("PSQLInterface", "$Revision: 1672 $");
			display_version = false;
		}
		
		get_ext_constants(const_file);

		
		String sql_con = get_sql_connect_string();
		try {
			Class.forName("org.postgresql.Driver").newInstance();	
		} catch (IllegalAccessException iae) {
			LB.error("Failed to load psql jdbc driver");
			LB.error("Message thrown by Java environment (may be null):" + iae.getMessage());
			LB.die();	
		} catch (InstantiationException ie) {
			LB.error("Failed to instantiate psql jdbc driver");
			LB.error("Message thrown by Java environment (may be null):" + ie.getMessage());
			LB.die();	
		} catch (ClassNotFoundException cnfe) {
			LB.error("Could not find psql jdbc driver class");
			LB.error("Message thrown by Java environment (may be null):" + cnfe.getMessage());
			LB.die();	
		}

		try {
			PSQLInterface2 =  DriverManager.getConnection(sql_con);
		} catch (SQLException ex) {	
			LB.error("SQLException: " + ex.getMessage());
			LB.error("SQLState: " + ex.getSQLState());
			LB.error("VendorError: " + ex.getErrorCode());
			LB.die();
		}
		initialized = true;
	}
	
	/**
	 * Use this for Insert, update and delete 
	 * @param s
	 * @return
	 */
	private static int run_query(String s) {
		int r = 0;
		try {
			Statement s_1 = PSQLInterface2.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_UPDATABLE);
			r = s_1.executeUpdate(s);
			s_1.close();
		} catch (SQLException se) {
			LB.error("Broken SQL: " + s);
			LB.error(se.getMessage());
			LB.error(se.getSQLState());
			LB.error(se.fillInStackTrace().toString());
			LB.error("Error code " + se.getErrorCode());
			LB.die();
		}
		return r;
	}
	
	
	/**
	 * Use this for select; 
	 * @param s
	 * @return
	 */
	private static ResultSet run_select(String s) {
		ResultSet r = null;
		try {
			Statement s_1 = PSQLInterface2.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_UPDATABLE);
			r = s_1.executeQuery(s);
		} catch (SQLException se) {
			LB.error(se.getMessage());
			LB.error(se.getSQLState());
			LB.error(se.fillInStackTrace().toString());
			LB.error("Error code " + se.getErrorCode());
			LB.die();
		}
		return r;
	}
	
	
	
	/**
	 * This function creates a temporary table with snps in it for further
	 * querying.
	 * 
	 * @param snps
	 *            list of snps to be queried
	 * @param table_name
	 *            name of temporary table
	 * @param genome
	 *            the genome designation, eg hg19
	 * 
	 * @return int Number of records placed in temp table.
	 */
	private static int create_and_import(ArrayList<SNP> snps, String table_name, String genome) {
		/* create temp table*/
		String q1 = "CREATE TABLE " + table_name + " (" + 
				"chromosome text, " + 
				"position integer, " + 
				"genome text, " +
				"canonical char, " +
				"observed char, " +
				"coverage integer, " +
				"canonical_obs integer, " +
				"variation_obs integer, " +
				"quality double precision, " +
				"Homozygous integer)";
		run_query(q1);

		/*copy all snps into the table*/
		boolean first = true;
		
		StringBuffer q_1 = new StringBuffer();
		q_1.append("INSERT INTO " + table_name + " (chromosome, position, genome, canonical, observed, coverage, " +
				"canonical_obs, variation_obs, quality, Homozygous) VALUES ");
		
		for (SNP s : snps) { 
			if (first) {
				first = false;
			} else {
				q_1.append(",");
			} 
			
			q_1.append("('" + s.get_chromosome() + "','" +
					s.get_position() + "','" +
					genome + "','" +
					s.get_snp_cannonical() + "','" +
					s.get_new_base() + "','" +
					s.get_total_coverage() + "','" +
					s.get_coverage_ref() + "','" +
					s.get_coverage_snp() + "','" +
					s.get_quality() + "','" +
					s.get_hetrozygous() + "')");
		}
		int rows = run_query(q_1.toString());
		return rows;
	}
	
	
	
	
	
	public static String search_SNPs(ArrayList<SNP> snps, String genome) throws PSQLInterfaceException {
	
		if (!initialized) {
			throw new PSQLInterfaceException("attempted to use insert_SNPs without initializing interface");
		}


		String uuid = UUID.randomUUID().toString();				//Generate random session id to be used as a random table name
		uuid = uuid.replace("-", "");
		String table_name = "tbl_" + uuid;
		int r = create_and_import(snps, table_name, genome);
		LB.notice(r + " snps imported for querying.");
		String results = null;											//perform query
		
		
		String q = "Select a.genome, a.chromosome, a.position, a.observed, a.canonical, c.dbSNP, c.dbSNP_id, d.library_id " +
				"d.snp_id, d.coverage, d.canonical_obs, d.variation_obs, d.quality, d.Homozygous " +
				"from " + table_name + " as a, snps as b " +
				"left join annotation as c on (b.snp_id = c.snp_id) " +
				"left join observation as d on (b.snp_id = d.snp_id)" +
				"where a.genome = b.genome " +
				"AND a.chromosome = b.chromosome " +
				"AND a.position = b.position " +
				"AND a.observed = b.observed ";
		
		ResultSet rs = run_select(q);
		
		try {
			while (rs.next()) {
				LB.notice(rs.getString("genome") + rs.getString("chromosome") 
						+ rs.getString("position") + rs.getString("observed"));
			}
		} catch (SQLException sqle) {
			//do something
			LB.error(sqle.getMessage());
		}
			
		
	
		
		
		//TODO: return results of query as a report
		
		return results;
	}
	
	
	
	
	
	
	// ESCA-JAVA0138:
	public static void insert_SNPs(ArrayList<SNP> snps, String genome,
			String library, int min_aln_qual, int min_base_qual, String aligner, String aligner_ver,
			String snp_caller, String snp_caller_ver)
			throws PSQLInterfaceException {
		if (!initialized) {
			throw new PSQLInterfaceException("attempted to use insert_SNPs without initializing interface");
		}

		int library_ins = 0;
		int aligner_p_ins = 0;
		int snp_ins = 0;
		int obs_ins = 0;

		LB.notice(snps.size() + " snps to process");
		
		LB.notice("Create temporary table with all SNPs.");
		String table_name = "tmp_snp_tbl_" + library;   //tmp_snp_tbl_na06985

		int temp_rows = create_and_import(snps, table_name, genome);
				
		LB.notice("Pushed " + temp_rows + " rows into temporary storage");
		
		LB.notice("indexing table...");
		String idx_tmp = "create index " + table_name + "_gcp on " + table_name + " (genome,chromosome,position);";
		run_query(idx_tmp);		
		idx_tmp = "create index " + table_name + "_cp on " + table_name + " (chromosome,position);";
		run_query(idx_tmp);
		
		LB.notice("Checking to see if a new library entry must be made...");
		int library_id = -1;
		try {
			Statement stmt0 = null;
			stmt0 = PSQLInterface2.createStatement(			//Get the Lane ID
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);		
			String query0 = "SELECT library_id FROM library WHERE name = '" + library + "'";
			ResultSet r0 = stmt0.executeQuery(query0);
		
			if (!r0.next()) {	 									//if it doesn't exist yet
				String ins0 = "INSERT INTO library (name) VALUES ('" + library + "')";
				Statement stmt1 = PSQLInterface2.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_UPDATABLE);
				library_ins += 1;
				stmt1.executeUpdate(ins0);
				stmt1.close();
				
				String query1 = "SELECT library_id FROM library WHERE name = '" + library + "'";
				Statement stmt2 = PSQLInterface2.createStatement(		// Get the Lane ID
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_UPDATABLE); 
				ResultSet r1 = stmt2.executeQuery(query1);
				r1.next();
				library_id = r1.getInt("library_id");
				stmt2.close();
				r1.close();
			} else {
				library_id = r0.getInt("library_id");			
			}
			stmt0.close();
			r0.close();
		} catch (SQLException sqle) {
			LB.error("while identifying/setting library id");
			LB.error(sqle.getMessage());
			LB.error(sqle.getSQLState());
			LB.error(sqle.fillInStackTrace().toString());
			LB.error("Error code " + sqle.getErrorCode());
			LB.die();
		}		
		LB.notice("total libraries inserted :        " + library_ins);
		
		LB.notice("Checking to see if a new aligner entry must be made...");
		int aligner_id = -1;
		try {
			Statement stmt0 = null;
			stmt0 = PSQLInterface2.createStatement(			//Get the Lane ID
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);		
			String query0 = "SELECT aligner_id FROM aligner_param WHERE " +
					"aligner = '" 		+ aligner 		 + "' AND " + 
					"aligner_ver = '" 	+ aligner_ver	 + "' AND " +
					"snp_caller = '" 	+ snp_caller	 + "' AND " + 
					"snp_caller_ver = '"+ snp_caller_ver + "' AND " +
					"min_aln_qual_used = '" + min_aln_qual + "' AND " +
					"min_base_qual_used = '" + min_base_qual + "'";
			
			ResultSet r0 = stmt0.executeQuery(query0);	
		
			if (! r0.next()) {	 									//if it doesn't exist yet
				String ins0 = "INSERT INTO aligner_param (aligner, aligner_ver, snp_caller, " +
						"snp_caller_ver, min_aln_qual_used, min_base_qual_used) VALUES ('" + aligner +
						"','" + aligner_ver +
						"','" + snp_caller +
						"','" + snp_caller_ver +
						"','" + min_aln_qual +
						"','" + min_base_qual + "')";
				aligner_p_ins += 1;
						
				Statement stmt1 = PSQLInterface2.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_UPDATABLE);		
				stmt1.executeUpdate(ins0);
				stmt1.close();
				String query1 = "SELECT aligner_id FROM aligner_param WHERE " +
							"aligner = '" 		+ aligner 		 + "' AND " + 
							"aligner_ver = '" 	+ aligner_ver	 + "' AND " +
							"snp_caller = '" 	+ snp_caller	 + "' AND " + 
							"snp_caller_ver = '"+ snp_caller_ver + "' AND " +
							"min_aln_qual_used = '" + min_aln_qual	 + "' AND " +
							"min_base_qual_used = '" + min_base_qual + "'";
				
				Statement stmt2 = PSQLInterface2.createStatement(		// Get the Lane ID
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_UPDATABLE); 
				
				ResultSet r1 = stmt2.executeQuery(query1);
				r1.next();
				aligner_id = r1.getInt("aligner_id");
				stmt2.close();
				r1.close();
			} else {
				aligner_id = r0.getInt("aligner_id");
			}
			stmt0.close();
			r0.close();
		} catch (SQLException sqle) {
			LB.error("Occured while retrieving/inserting aligner id");
			LB.error(sqle.getMessage());
			LB.error(sqle.getSQLState());
			LB.error(sqle.fillInStackTrace().toString());
			LB.error("Error code " + sqle.getErrorCode());
			LB.die();
		}		
		LB.notice("total aligner parms inserted :    " + aligner_p_ins);
		
		LB.notice("Set Begin work...");
		String w = "BEGIN WORK";
		run_query(w);
		
		LB.notice("Lock table exclusive...");
		w = "LOCK TABLE snp";
		run_query(w);
		
		LB.notice("looking for new snp entries...");
		
		String s2 = "INSERT INTO snp (chromosome, position, genome, canonical, observed) (" +
				"SELECT DISTINCT a.chromosome, a.position, a.genome, a.canonical, a.observed FROM " + table_name + " as a " +
				"LEFT JOIN snp as b on (a.chromosome = b.chromosome AND a.genome = b.genome AND a.position = b.position " +
				"AND a.canonical = b.canonical AND a.observed = b.observed ) " +
				"WHERE b.snp_id is null)";
		snp_ins = run_query(s2);	
		LB.notice("total new snp rows inserted :     " + snp_ins);
	
		LB.notice ("inserting new obesrvations...");	
		String s3 = "INSERT INTO observations (snp_id, library_id, coverage, canonical_obs, variation_obs, " +
				"quality, Homozygous, aligner_id) (SELECT a.snp_id, '" + library_id + "', b.coverage, " +
				"b.canonical_obs, b.variation_obs, b.quality, b.homozygous, '" + aligner_id + "' FROM snp as a, " +
				table_name + " as b WHERE a.chromosome = b.chromosome AND a.genome = b.genome " +
				"AND a.position = b.position AND a.canonical = b.canonical AND a.observed = b.observed )";
		obs_ins = run_query(s3);
		LB.notice("total new observations inserted : " + obs_ins);
		
		LB.notice("End (commit) work...");
		w = "COMMIT WORK";
		run_query(w);
		
		LB.notice("dropping temporary table...");
		String s4 = "DROP TABLE " + table_name;
		run_query(s4);
	}
	
	
	public static void vacuum_db() {
		String v1 = "Vacuum";
		run_query(v1);
	}
	

	
	
	// ESCA-JAVA0138:
	public static void insert_dbSNP(ArrayList<SNP> snps, String genome)
			throws PSQLInterfaceException {
		if (!initialized) {
			throw new PSQLInterfaceException("attempted to use insert_SNPs without initializing interface");
		}

		LB.notice(snps.size() + " snps to process");
		int tmp_rec_ins = 0;
		LB.notice("Create temporary table with all SNPs."); 
		String table_name = "tmp_snp_tbl_dbSNP_import";
		String q1 = "CREATE TABLE " + table_name + " (" + 
			"chromosome text, " + 
			"position integer, " + 
			"genome text, " +
			"canonical char, " +
			"observed char, " +
			"misc text)";
		run_query(q1);
		
		boolean first = true;
		
		StringBuffer q_1 = new StringBuffer();
		q_1.append("INSERT INTO " + table_name + " (chromosome, position, genome, canonical, observed, misc) VALUES ");
		
		for (SNP s : snps) { 
			if (first) {
				first = false;
			} else {
				q_1.append(",");
			} 
			
			q_1.append("('" + s.get_chromosome() + "','" +
					s.get_position() + "','" +
					genome + "','" +
					s.get_snp_cannonical() + "','" +
					s.get_new_base() + "','" +
					s.get_id() + "')");
					tmp_rec_ins +=1;
		}
		int temp_rows = run_query(q_1.toString());
				
		LB.notice("Pushed " + temp_rows + " rows into temporary storage");
		
		LB.notice("indexing table...");
		String idx_tmp = "create index " + table_name + "_gcp on " + table_name + " (genome,chromosome,position);";
		run_query(idx_tmp);		
		idx_tmp = "create index " + table_name + "_cp on " + table_name + " (chromosome,position);";
		run_query(idx_tmp);
		
		
		
		LB.notice("Set Begin work...");
		String w = "BEGIN WORK";
		run_query(w);
		
		LB.notice("Lock table exclusive...");
		w = "LOCK TABLE snp";
		run_query(w);
		
		
		LB.notice("looking for new snp entries");
		String s2 = "INSERT INTO snp (chromosome, position, genome, canonical, observed) (" +
				"SELECT DISTINCT a.chromosome, a.position, a.genome, a.canonical, a.observed FROM " + table_name + " as a " +
				"LEFT JOIN snp as b on (a.chromosome = b.chromosome AND a.genome = b.genome AND a.position = b.position " +
				"AND a.canonical = b.canonical AND a.observed = b.observed ) " +
				"WHERE b.snp_id is null)";
		int snp_ins = run_query(s2);	
		
		LB.notice ("updating old observations");
		
		String s3 = "UPDATE annotation SET snp_id = a.snp_id, strand = True, dbSNP = 'Y', " +
				"dbSNP_id = annotation.dbSNP_id || ' ' || b.misc " +
				"FROM snp as a, " + table_name + " as b "+
				"WHERE a.chromosome = b.chromosome AND a.genome = b.genome AND a.position = b.position " +
				"AND a.canonical = b.canonical AND a.observed = b.observed " +
				"AND annotation.snp_id = a.snp_id";
		int ann_upd = run_query(s3);
		
		LB.notice ("inserting new annotations");
		String s4 = "INSERT INTO annotation (snp_id, strand, dbSNP, dbSNP_id) " +
				"(SELECT a.snp_id, 'True', 'Y', b.misc " +
				"FROM " + table_name + " as b, snp as a LEFT JOIN annotation as c on (a.snp_id = c.snp_id) " +
				"WHERE a.chromosome = b.chromosome AND a.genome = b.genome AND a.position = b.position " +
				"AND a.canonical = b.canonical AND a.observed = b.observed AND c.annotation_id IS NULL)";
		int ann_ins = run_query(s4);
		
		LB.notice("End (commit) work...");
		w = "COMMIT WORK";
		run_query(w);
		
		
		LB.notice("dropping temporary table...");
		String s5 = "DROP TABLE " + table_name;
		run_query(s5);
	
		
				
		//print out information
		LB.notice("total snps inserted :             " + snp_ins);
		LB.notice("total annotations updated :       " + ann_upd);
		LB.notice("total annotations inserted :      " + ann_ins);
		
		
	}
	
	
	
	
	
	
		///********************* Functions for retrieving information **********************/
 
	
	
	
	public static Library get_library_info(String library_name) {
		
		String query = "SELECT * FROM library WHERE name = '" + library_name + "'";
		Library n  =  null;
		try {
			Statement stmt = PSQLInterface2.createStatement(
					// Get the Lane ID
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			ResultSet r1 = stmt.executeQuery(query);
			boolean found = r1.next();
			if (!found) {
				LB.error("Could not find library : " + library_name);
				LB.error("Please check that the library exists in the database.");
				System.exit(0);
			}
			n = new Library(r1.getInt("library_id"), r1.getString("name"), 
					r1.getString("seq_type"), r1.getInt("read_length"), 
					r1.getInt("read_length_alt"), r1.getString("sample_type"), 
					r1.getString("sample_desc"), r1.getString("sample_organ"), 
					r1.getString("sample_notes"), r1.getString("sample_cell_type"));
			
			if (r1.next()) {
				LB.error("too many rows with the same library name.");
				System.exit(0);
			}
			stmt.close();
			r1.close();
		} catch (SQLException sqle) {
			LB.error(sqle.getMessage());
			System.exit(0);
		}
		return n;		
	}
	
	public static boolean set_library_info(Library l) {
		
		String query = "UPDATE library SET name = '" + l.get_Name() + 
				"', seq_type = '" + l.get_Seq_type() +
				"', read_length = '" + l.get_Read_length() + 
				"', read_length_alt = '" + l.get_Read_length_alt() +
				"', sample_type = '" + l.get_Sample_type() + 
				"', sample_desc = '" + l.get_Sample_desc() +
				"', sample_organ = '" + l.get_Sample_organ() +
				"', sample_notes = '" + l.get_Sample_notes() +
				"', sample_cell_type= '" + l.get_Sample_cell_type() +
				"' WHERE library_id = '" + l.get_Library_id() + "'";
		int rows = run_query(query);
		if (rows == 1) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	public static ResultSet get_library_rs(String library_name) {
		
		String query = "SELECT library_id FROM library WHERE name = '" + library_name + "'";
		ResultSet r1  = null;
		try {
			Statement stmt = PSQLInterface2.createStatement(
					// Get the Lane ID
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			r1 = stmt.executeQuery(query);
			r1.close();
		} catch (SQLException sqle) {
			LB.error(sqle.getMessage());
		}	
		return r1;		
	}
	
	
	
	public void get_ext_constants(String file) {	
		BufferedReader br = null;
		String line = "";
		try {													//open file
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException fnf) {
			LB.error("Could not find file: " + file);
			LB.die();
		}
		assert (br != null);
		
		try {													//find Connection section in file		
			while (!line.trim().equalsIgnoreCase("[SNP_Database]")) {
				line = br.readLine();							
			}
			line = br.readLine().trim();
			while (!line.startsWith("[") && (br.ready())) {  	//iterate until line starts with "[" or end of file
				if (!line.startsWith("#") && line.trim().length() > 0 ) {
					String[] st = line.split("=");
					Variables.put(st[0], st[1]);
				}
				line = br.readLine(); 
			}
			br.close();
				
		} catch (IOException io) {
			LB.error("Error while reading constants. line = " + line);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}	
	}
	
	
	
	
	/**
	 * 
	 * @return result set as a hash table, string and integer of exon to transcript mappings.
	 * @throws CanNotConnectException
	 */
	public HashMap<String, Integer> get_exon_transcript_mapings() throws CanNotConnectException {
		if (!initialized) {
			throw new CanNotConnectException("attempted to use get_exon_transcript_mapings without initializing connection first");
		}
		ResultSet rs = null;
		HashMap<String, Integer> map = new HashMap<String, Integer>();
	    String key = null;
	    Integer value = 0;
		
		try {
			Statement stmt = PSQLInterface2.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
		    String query = "SELECT exon_id, transcript_id, rank FROM exon_transcript";
			rs = stmt.executeQuery(query);
			while (rs.next()) {
		    	key = rs.getInt("transcript_id") + "-" + rs.getInt("rank");
		    	value = rs.getInt("exon_id");
		    	map.put(key, value);
		    }
			stmt.close();
			rs.close();
		} catch (SQLException sql) {
			throw new CanNotConnectException(sql.getMessage());
		}
		
   	    return map;
	}		

	
}


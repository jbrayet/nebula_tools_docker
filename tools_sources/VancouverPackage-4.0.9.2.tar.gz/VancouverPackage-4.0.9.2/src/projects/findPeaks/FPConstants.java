package src.projects.findPeaks;

/**
 * @version $Revision: 1784 $
 * @author 
 */
public class FPConstants {

	private FPConstants() {}
	
	//CONSTANTS:
	/** Sizes for max_ext_lengths - triangle mode*/
	public static final int XSET_MODE_1_MAX = 2000;
	/** Sizes for max_ext_lengths - adaptive mode*/
	public static final int XSET_MODE_2 = 500;
	
	/** min batch size to process reads*/
	public static final int MIN_BATCH = 100;
	
	/** default window size for compare */
	public static final int DEFAULT_WINDOW_SIZE = 400;
	public static final int MINIMUM_WINDOW_SIZE = 10;
	
	
	/** print constants */
	public static final int TENS = 10;
	/** print constants */
	public static final int BASE_TEN = 10;
	/** print constants */
	public static final int FIELD_WIDTH_1 = 12;
	/** print constants */
	public static final int FIELD_WIDTH_2 = 19;
	/** print constants */
	public static final int FIELD_WIDTH_3 = 15;
	/** print constants */
	public static final int FIELD_WIDTH_4 = 10;
	/** print constants */
	public static final int DECIMAL_PLACES_8 = 8;
	
	/** triangle distribution (low= 100) */
	public static final int TRIANGLE_LOW = 100;
	/** triangle distribution (high = 300)_*/
	public static final int TRIANGLE_HIGH = 300;
	/** triangle distribution */
	public static final int TRIANGLE_DEFAULT_MEDIAN = 200;
	
	/**buffer to end of chromosome*/
	public static final int BUFFER_ZONE = 2000;
	
	/**percentage*/
	public static final int PERCENTAGE = 100;

	public static final double DOUBLE_TOLERANCE = 0.0001;
	public static final double FLOAT_TOLERANCE = 0.0001f;
	
}

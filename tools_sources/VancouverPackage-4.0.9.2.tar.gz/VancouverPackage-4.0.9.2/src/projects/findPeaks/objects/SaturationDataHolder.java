package src.projects.findPeaks.objects;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Vector;

import src.lib.Histogram;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Tuple;

/**
 * @version $Revision: 1423 $
 * @author
 */
public class SaturationDataHolder implements Runnable {

	private class bundle {
		private final MinPeakDesc p;
		private final float f;
		private final int i;
		private final Tuple<Integer, Integer> LW;
		
		
		protected bundle(MinPeakDesc p, float f, int i, Tuple<Integer, Integer> LW) {
			this.p = p;
			this.f = f;
			this.i = i;
			this.LW = LW;
		}
		
		/**
		 * Use upper 16 bits to store the float idx, use lower 16 bits to store the 
		 * iterator idx.  Together, that makes a unique 32 bit int key that can be 
		 * used in the mainstore as an index.
		 * 
		 * @return
		 */
		public final int get_key() { 
			return ((values_idx.get(this.f)) << HALF_INT_SIZE) + this.i;
		}
		
		//getters
//		public MinPeakDesc get_peak()	{ return this.p; }
//		public float get_treshold() 	{ return this.f; }
//		public int get_iteration() 		{ return this.i; }
	}
	
	private	static final int HALF_INT_SIZE = 16;
	
	public final int get_key(float f, int i) { 
		return ((values_idx.get(f)) << HALF_INT_SIZE) + i;
	}
	
	
	private float regenerate_threshold(int key) {
		return this.values[key >>> HALF_INT_SIZE];
	}
		
	private static int regenerate_iteration(int key) {
		return key & 0x0000FFFF;
	}
	
	/**
	 * Single instance of the SaturationDataHolder
	 */
	private static Log_Buffer LB;
	HashMap<Integer, Vector<MinPeakDesc>> main_store = null;	//array storing the peak data for all saturation runs. 
														//stored by [saturation index][iteration]
	HashMap<Integer, Tuple<Integer, Integer>> LW_stats;
	HashMap<Integer, Integer> Reads_used;
	private Vector<bundle> buffer = new Vector<bundle>();		//buffer to hold incoming peak descriptions.  FILO
	private HashMap<Float, Integer> values_idx;
	private boolean terminate = false;
	private final float[] values;
	private final int values_size;
	private final int iterations;
	private Integer finished_threads = 0;
	
	
	public SaturationDataHolder(Log_Buffer logbuffer, float[] val, int it) {
		LB = logbuffer;
		this.values_size = val.length;
		this.iterations = it;
		this.values = new float[this.values_size];
		System.arraycopy(val, 0, this.values, 0, this.values_size);			
		main_store = new HashMap<Integer, Vector<MinPeakDesc>>(this.values_size * this.iterations);
		LW_stats = new HashMap<Integer, Tuple<Integer, Integer>>();
		Reads_used = new HashMap<Integer, Integer>();
		values_idx = new HashMap<Float,Integer>(this.values_size);
		int x=0;
		for (float f : val) {
			values_idx.put(f, x);
			x++;
		}
	}

	public void recover_data() {
		//not really sure yet.
	}
	

	/**
	 * 
	 * @return true if there are more messages, else: false
	 */
	public boolean has_peaks() {
//		synchronized (buffer) {
			if (buffer.size() == 0) {
				return false;
			}
//		}
		return true;
	}

/*	*//**
	 * 
	 * @param p
	 * @param threshold
	 * @param iteration
	 *//*
	public void new_peak(MinPeakDesc p, float threshold, int iteration) {
		synchronized (buffer) {
			buffer.add(new bundle(p, threshold, iteration));
			buffer.notifyAll();
		}
	}*/
	
	
	/**
	 * 
	 * @param p
	 * @param threshold
	 * @param iteration
	 * @param LW Tuple<int, int> holding number of LW singles and doubles
	 */
	public void new_peak(Vector<MinPeakDesc> p, float threshold, int iteration, Tuple<Integer, Integer>LW) {
		synchronized (buffer) {
			for (MinPeakDesc m : p) {
				buffer.add(new bundle(m, threshold, iteration, LW));
			}
			buffer.notifyAll();
		}
	}
	
	
	
	/**
	 * 
	 */
	public void run() {
		LB.Version("Starting Saturation Data Holder", "$Revision: 1423 $");
		while (!terminate) {
			try {
				synchronized (buffer) {
					buffer.wait();
				}
			} catch (InterruptedException e) {
				LB.error("Something went bad in the wait state - SaturationDataHolder.");
				LB.error(e.getMessage());
			}
			if (this.has_peaks()) {
				clear_buffer();
			}
		}
		if (this.has_peaks()) {
			clear_buffer();
		}
	}


	private void process_array(bundle[] elements) {
		for (bundle b: elements) {
			if (main_store.containsKey(b.get_key())) {
				int key = b.get_key();
				(main_store.get(key)).add(b.p);
				Tuple<Integer, Integer> i = LW_stats.get(key);
				i.set_first(i.get_first() + b.LW.get_first());
				i.set_second(i.get_second() + b.LW.get_second());
			} else {
				Vector<MinPeakDesc> t = new Vector<MinPeakDesc>();
				t.add(b.p);
				int key = b.get_key();
				main_store.put(key, t);
				LW_stats.put(key, b.LW);
			}
		}
	}
	
	public void process_reads_used (int ru, float f, int i) {
		synchronized(Reads_used) {
			Reads_used.put(get_key(f,i), ru);
		}
	}
	
	
	
	/**
	 * 
	 */
	private void clear_buffer() {
		while (this.has_peaks()) {
			bundle[] elements = null;
			synchronized (buffer) {			//synchronize the buffer
				elements = buffer.toArray(new bundle[buffer.size()]);					//make a copy of the buffer
				buffer.clear();				//reset the buffer
			}								//release the buffer
			process_array(elements);		//process 
		}
	}


	public MinPeakDesc[][][] get_arrays_of_desc() {
	
		Integer[] a = new Integer[main_store.size()];
		a = main_store.keySet().toArray(a);
		Arrays.sort(a);
				
		MinPeakDesc[][][] results = new MinPeakDesc[this.values_size][this.iterations][];
		for (Integer n : a) {
			float x = regenerate_threshold(n);
			int y = regenerate_iteration(n);
			int x2 = values_idx.get(x);
			results[x2][y] = main_store.get(n).toArray(new MinPeakDesc[main_store.get(n).size()]);
		}
		return results;
	}

	
	public int[][] get_coverages() {
		
		Integer[] a = new Integer[main_store.size()];
		a = main_store.keySet().toArray(a);
		Arrays.sort(a);
				
		int[][] results = new int[this.values_size][this.iterations];
		for (Integer n : a) {
			float x = regenerate_threshold(n);
			int y = regenerate_iteration(n);
			int x2 = values_idx.get(x);
			Vector<MinPeakDesc> mpd = main_store.get(n);
			for (MinPeakDesc p : mpd) {
				results[x2][y] += p.get_length();
			}
		}
		return results;
	}
	


	public Histogram[][] reduce_to_hist(int histogram_size, int precision) {
		
		Integer[] a = new Integer[main_store.size()];
		a = main_store.keySet().toArray(a);
		Arrays.sort(a);
		
		
		
		Histogram[][] results = new Histogram[this.values_size][this.iterations];
		for (Integer n : a) {
			//regenerate info from key
			float x = regenerate_threshold(n);
			int y = regenerate_iteration(n);
			int x2 = values_idx.get(x);
			results[x2][y] = new Histogram(LB, histogram_size*precision, 0, histogram_size, false);
			Vector<MinPeakDesc> mpd = main_store.get(n);
			for (MinPeakDesc p : mpd) {
				results[x2][y].bin_value(p.get_height());
			}
		}		
		return results;
	}
	
	
	public Tuple<int[][], int[][]> return_LW_stats() {
		Integer[] a = new Integer[main_store.size()];
		a = main_store.keySet().toArray(a);
		Arrays.sort(a);
		
		int[][] fir = new int[this.values_size][this.iterations];
		int[][] sec = new int[this.values_size][this.iterations];
		Tuple<Integer, Integer> t = null;
		for (Integer n : a) {
			//regenerate info from key
			float x = regenerate_threshold(n);
			int y = regenerate_iteration(n);
			int x2 = values_idx.get(x);
			t = LW_stats.get(n);
			fir[x2][y] = t.get_first();
			sec[x2][y] = t.get_second();
		}
		return new Tuple<int[][], int[][]>(fir, sec);
		
	}
	
	public int[][] return_reads_used() {
		Integer[] a = new Integer[main_store.size()];
		a = main_store.keySet().toArray(a);
		Arrays.sort(a);	
		int[][] results = new int[this.values_size][this.iterations];
		for (Integer n : a) {
			//regenerate info from key
			float x = regenerate_threshold(n);
			int y = regenerate_iteration(n);
			int x2 = values_idx.get(x);
			results[x2][y] = Reads_used.get(n);
		}		
		return results;
	}
	
	
	
	public void signal_complete() {
		synchronized (finished_threads) {
			finished_threads += 1;
		}
		
	}
	
	public int get_count_finished_threads() {
		synchronized (finished_threads) {
			return this.finished_threads;
		}
	}
	
	
	/**
	 * Close the LogBuffer.
	 */
	public void close() {
		terminate = true;
		synchronized (buffer) {
			buffer.notifyAll();
		}
	}

	/**
	 * Unsupported Object method clone
	 * 
	 * @return
	 * @throws CloneNotSupportedException
	 */
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException(); // Can't clone a Singleton
	}

}

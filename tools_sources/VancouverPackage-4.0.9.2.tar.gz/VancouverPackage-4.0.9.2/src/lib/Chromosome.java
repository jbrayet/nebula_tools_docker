package src.lib;

import java.util.ArrayList;

import src.lib.Error_handling.DoesNotMatchException;
import src.lib.Error_handling.OverflowException;
import src.lib.Error_handling.UnexpectedCharacterException;

import src.lib.ioInterfaces.Log_Buffer;
import src.lib.ioInterfaces.WigwriterBuffered;

import src.lib.objects.AlignedRead;
import src.lib.objects.SNP;
import src.lib.objects.SimpleAlignedRead;


// ESCA-JAVA0100:
// ESCA-JAVA0136:
/**
 * The Chromosome object holds a representation of a full chromosome in memory,
 * such that alignments can be made against it, and SNPs can be located within.
 * @version $Revision: 1766 $
 * @author Genome Sciences Centre 
 */
public class Chromosome {
	/**
	 * The allowed bases, it's useful for a couple of things.  Not sure an enumerated type would be any better, but maybe.
	 * The last base is the deletion base to discover genomic deletions.
	 */
	private static final char[] BASES = { 'A', 'C', 'G', 'T', '+', '-' };
	private static final int NUM_BASES = 4;						//number of canonical bases (4)
	private static final int INIT_SIZE = 10;					//size to initialize arrays/vectors
	
	private static final float MIN_COVERAGE = 0.001f;
	
	private static final float MAX_MISMATCH = .20f;  			// maximum permissable number of mismatches (percent)
	private String canonicalSequence; 							// A string of the canonical (accepted
																// standard) bases for a particular
																// chromosome.
	private static int min_base_quality = 0;  			// base quality must be greater to add base to chromosome.
	private static Log_Buffer LB;
	private static boolean display_version = true;
	
	/**
	 * A score for each base in the canonical sequence, for each of the possible
	 * Chromosome.BASES. The dimensions are
	 * [Chromosome.BASES.length][canonicalSequence.length()] - this is the
	 * opposite of what you'd expect. But this way we only pay for the array
	 * overhead 5 times, instead of 200 million times. The score can be
	 * anything, but it will likely either be: 1) The count of that base 2a) The
	 * probability of that base (sum-quality) 2b) The probability of that base -
	 * but every base will be filled in for every sequence (i.e. 4 quality score
	 * for every position in the read)
	 * 
	 */
	private int[][] baseScore;

	private char[] readStartCount; // A count of how many reads start at a
									// particular point. I'd be very surprised
									// if this ever exceeded ~20, however, we
									// may want to use a short instead of a
									// char.
	private int numReads; 			// The total number of aligned reads. Will likely be
									// 		useful for calculating the expected coverage.
	private final String name; 			// The name of this Chromosome
	private short[] mappability; 	// The map describing how likely each base
									// 		is to be able to be sequenced using a
									// 		given length of read.
	private static boolean force32 = false; // If you need to force 32 bit alignments, when longer are
											// 		provided, set this to true. Used for Ryan and Malachi's data sets,
											// 		so far.

	/**
	 * Construct a new Chromosome.
	 * 
	 * @param logbuffer
	 * @param canonSeq
	 * @param min_base_qual
	 * @param n
	 */
	public Chromosome(Log_Buffer logbuffer, String canonSeq, String n, int min_base_qual) {
		LB = logbuffer;
		if (display_version) {
			LB.Version("Chromosome", "$Revision: 1766 $");
			display_version = false;
		}
		if (n.indexOf("CHR") == 0) {
			this.name = n.substring(3);
		} else if (n.indexOf("chr") == 0) {
			this.name = n.substring(3);
		} else {
			this.name = n;
		}
		min_base_quality = min_base_qual;
		canonicalSequence = canonSeq;
		baseScore = new int[BASES.length][canonSeq.length()];
		readStartCount = new char[canonSeq.length()];
	}

	public boolean destroy() {
		for (int b = 0; b < BASES.length; b++) {
			baseScore[b] = null;
		}
		readStartCount = null;
		canonicalSequence = null;
		mappability = null;
		LB = null;
		return true;
	}

	

	public String writeCoverageWig(int length) {
		return writeCoverageWig(0, canonicalSequence.length(), length);
	}

	/**
	 * Return a "wig" style string of the coverage in a particular region.
	 * 
	 * @param start
	 *            The starting point of the wig
	 * @param end
	 *            The ending point of the the
	 * @param length
	 *            The expected length of the reads (or equivalent)
	 * @return A single wig entry (not a track)
	 */
	public String writeCoverageWig(int start, int end, int length) {
		if (start < length) {
			start = length;
		}
		if (end > this.canonicalSequence.length()) {
			end = this.canonicalSequence.length();
		}
		short[] cov = getCov(start, end, length); // new short[end - start];
		StringBuffer wig = new StringBuffer(60 + 3 * (end - start));
		wig.append("fixedStep chrom=chr" + name + " start=" + start
				+ " step=1\n");
		for (int i : cov) {
			wig.append(i + "\n");
		}
		return wig.toString();
	}

	/**
	 * 
	 * @param start
	 * @param end
	 * @param length
	 * @return
	 */
	public short[] getCov(int start, int end, int length) {
		short[] cov = new short[end - start];

		for (int i = 0; i < cov.length; i++) {
			for (int j = start + i - length; j < start + i; j++) {
				cov[i] += this.readStartCount[j];
			}
		}
		return cov;
	}

	/**
	 * Returns the highest count character at a given position (golden path
	 * character) Should probably write this to return UPAC symbols
	 * 
	 * @param pos
	 *            The position to return
	 * @return The golden path character
	 * 
	 */
	public char getGoldenChar(int pos) {
		int dex = -1;
		int count = -1;
		for (int i = 0; i < NUM_BASES; i++) {
			if ((short) baseScore[i][pos] > count) {
				count = baseScore[i][pos];
				dex = i;
			}
		}
		if (count > 0) {
			return Chromosome.BASES[dex];
		} else {
			return ' ';
		}
	}

	/**
	 * This function initialises the mappability portion of the chromosome
	 * object.
	 * 
	 * @param seq -
	 *            the sequence portion of the mappability fastafile
	 */
	public void InitMap(String seq) {
		int length = canonicalSequence.length();
		if (length != (seq.length() / 2)) {
			LB.error("Mappability input does not match chromosome length: "
							+ length + ", " + (seq.length() / 2));
			LB.die();
		}
		mappability = new short[length];
		for (int q = 2; q < length; q += 2) {
			mappability[q] = Short.valueOf(seq.substring(q, q + 2));
		}
	}

	/**
	 * This function merges a Bac into a chromosome merge(X, Y, Z) will move X
	 * into Y, at position Z. Function tests to ensure the sequence of X matches
	 * Y at Z.
	 * @param Bac
	 * @param offset
	 * @throws Exception
	 */
	public void merge(Chromosome Bac, int offset)
			throws Exception {
		/* error checking 1:*/
		if (offset + Bac.canonicalSequence.length() > this.canonicalSequence
				.length()) {
			throw new Exception(
					"Error - Bac and offset will extend past the chromosome end.  Merging Chromosome object will *not* proceed!");
		}
		if (Bac.canonicalSequence.length() < 0) {
			throw new Exception(
					"Error - Bac is not valid.  Merging Chromosome object will *not* proceed!");
		}

		if (this.canonicalSequence.length() < 0) {
			throw new Exception(
					"Error - Chromosome is not valid.  Merging Chromosome object will *not* proceed!");
		}
		if (offset < 0) {
			throw new Exception(
					"Error - offset is negative.  Merging Chromosome object will *not* proceed!");
		}
		LB.notice("Passed Test 1 of 2...");
		/* error checking 2:*/
		for (int i = 0; i < Bac.canonicalSequence.length(); i++) {
			if (Bac.canonicalSequence.charAt(i) != this.canonicalSequence
					.charAt(i + offset)) {
				throw new Exception(
						"Offset is incorrect, or canonical sequences do not match! Merging Chromosome object will *not* proceed!");
			}
		}
		LB.notice("Passed Test 2 of 2...");

		for (int i = 0; i < Bac.canonicalSequence.length(); i++) { // loop over all bases in Bac
			/* move each Bac chromosome datum to the Chromosome (base+ offset)
			for each base.*/
			for (int j = 0; j < BASES.length; j++) {
				this.baseScore[j][i + offset] += Bac.baseScore[j][i];
			}
		}
		LB.notice("Merge Complete.");
	}

	/**
	 * Adds a hit to the chromosome. The score added to the baseScore array is
	 * the raw base count. There will need to be multiple versions of this
	 * method that can add in abritrary scores and qaulity scores.
	 * returns false if unsuccessful (skipped or failed) returns true if
	 * successful
	 * @param alnrd
	 * @param score
	 * @param quiet
	 * @return
	 * @throws DoesNotMatchException
	 * @throws OverflowException
	 */
	public boolean addHitRawBaseCount(AlignedRead alnrd, int score,
			boolean quiet) throws DoesNotMatchException, OverflowException {
		int start = alnrd.get_alignStart() - 1;
		String querySeq = alnrd.get_sequence();
		String verifySeq = alnrd.get_alignseq();

		if (querySeq.indexOf('.') != -1) {
			if (!quiet) {
				LB.warning("Skipping a CHP with a . character:  "
						+ querySeq);
			}
			return false;
		}

		if (querySeq.length() != verifySeq.length()) {
			throw new DoesNotMatchException("Query sequence length " + querySeq.length()
					+ " is not the same as the genomic sequence length "
					+ verifySeq.length());
		}

		if ((start + querySeq.length()) >= canonicalSequence.length()) {
			throw new DoesNotMatchException(
					"Query length "
							+ querySeq.length()
							+ " plus alignment start "
							+ start
							+ " is too close to the end of the sequence "
							+ canonicalSequence.length()
							+ "\n"
							+ "this may legitimately be caused by an insertion near the end of the chromosome.");
		}

		/*
		 * We trundel along the alignment.  At each position we either:
		 * 1) Add genomic insertion data (and we do not change the position in the chromosome that we are referencing)
		 * 2) Add base data (inc. dleetions) into the baseScore array.
		 */

		/* if you have a reverse strand seq, you need the rev. compliment.  
		 * SNPs are already handled correctly in ElandIterator. */
		if (Chromosome.force32) { //if necessary to force only 32 base alignments
			if (alnrd.get_direction() == '-') {
				querySeq = querySeq.substring(0, Constants.ILLUMINA_BASE_MAX_32);
				verifySeq = verifySeq.substring(0, Constants.ILLUMINA_BASE_MAX_32);
				try {
					querySeq = Utilities.reverseCompliment(querySeq);
					verifySeq = Utilities.reverseCompliment(verifySeq);
				} catch (UnexpectedCharacterException uce) {
					LB.error(uce.getMessage());
				}
			} else {
				querySeq = querySeq.substring(0, Constants.ILLUMINA_BASE_MAX_32);
				verifySeq = verifySeq.substring(0, Constants.ILLUMINA_BASE_MAX_32);
			}
		} else {
			if (alnrd.get_direction() == '-') { //not forcing 32 base alignments - most cases
				try {
					querySeq = Utilities.reverseCompliment(querySeq);
					verifySeq = Utilities.reverseCompliment(verifySeq);
				} catch (UnexpectedCharacterException uce) {
					LB.error(uce.getMessage());
				}	
			}
		}

		readStartCount[start]++;
		numReads++;
		short score_short = (short) score;
		int chromIndex = start;

		for (int i = 0; i < querySeq.length(); i++) {

			char vChar = verifySeq.charAt(i); //verify Seq already has the chars substituted back 
			char qChar = querySeq.charAt(i); //in so that it can match against chromosomeal DNA sequences.

			/* TODO: will eventually insert code for gaps here */
			if (vChar != canonicalSequence.charAt(chromIndex)) {
				String s = "The " + (i) + "th character in " + verifySeq + ", "
						+ vChar
						+ ", is not equal to the char in the chromosome, "
						+ canonicalSequence.charAt(chromIndex) + "\n";
				/*if there's a problem, print out 10 bases to each side of the error base.
				 */s += canonicalSequence.substring(start, chromIndex
						+ querySeq.length());
				throw new DoesNotMatchException(s);
			}
			int baseDex = -1; 
			try {
				baseDex = Utilities.getIndexForBase(qChar);
			} catch (UnexpectedCharacterException uce) {
				LB.error(uce.getMessage());
				baseDex = -1;
			}
			if ((baseDex > NUM_BASES) || (baseDex < 0)) {
				LB.error("Character " + qChar + " @ position "
						+ i + " found in sequence: " + querySeq);
			}
			baseScore[baseDex][chromIndex] += score_short;
			if (baseScore[baseDex][chromIndex] < 0) {
				throw new OverflowException("Overflow error!");
			}
			chromIndex++;
		}
		try {
			if (alnrd.get_direction() == '+') { //keep track of starts and ends
				baseScore[Utilities.getIndexForBase('+')][alnrd.get_alignStart() - 1]++;
			} else if (alnrd.get_direction() == '-') {
				baseScore[Utilities.getIndexForBase('-')][alnrd.get_alignEnd() - 1]++;
			}
		} catch (UnexpectedCharacterException uce) {
			LB.error(uce.getMessage());
			LB.debug("x1");
			LB.die();
		}
		
		return true;
	}

	
	private void add_position(int position, char base, int score) throws UnexpectedCharacterException, OverflowException {
		int baseDex = Utilities.getIndexForBase(base);
		if ((baseDex > NUM_BASES) || (baseDex < 0)) {
			throw new UnexpectedCharacterException("Character " + base + " found");
		}
		baseScore[baseDex][position] += score;
		if (baseScore[baseDex][position] < 0) {
			throw new OverflowException("Overflow error!");
		}
	}
	
	
	
	/**
	 * Adds a hit to the chromosome. The score added to the baseScore array is
	 * the raw base count. There will need to be multiple versions of this
	 * method that can add in abritrary scores and qaulity scores.
	 * returns false if unsuccessful (skipped or failed) returns true if
	 * successful
	 * @param alnrd
	 * @param score
	 * @param quiet
	 * @return
	 * @throws DoesNotMatchException
	 * @throws OverflowException
	 */
	public boolean addGappedRawBaseCount(AlignedRead alnrd, int score,
			boolean quiet) throws DoesNotMatchException, OverflowException {
		int start = alnrd.get_alignStart() - 1;
		int indel_loc = alnrd.get_maq_indel_loc();
		int indel_len = alnrd.get_maq_indel_len();
				
		String querySeq = alnrd.get_sequence();
		
		if ((start + querySeq.length()) >= canonicalSequence.length()) {
			throw new DoesNotMatchException("Query length "	+ querySeq.length()
						+ " plus alignment start " + start
						+ " is too close to the end of the sequence " + canonicalSequence.length()
						+ "\n" + "this may legitimately be caused by an insertion near the end of the chromosome.");
		}
		
		String verifySeq = canonicalSequence.substring(start, start + querySeq.length());
		
		/*if (indel_len > 0) {  //this is corect - we'll leave it for debugging.
			LB.notice("query:   " + querySeq);
			StringBuffer sb = new StringBuffer();
			sb.append("genomic: ");
			sb.append(verifySeq.subSequence(0, indel_loc));
			for (int x = 0; x < indel_len; x++) {
				sb.append("N");
			}
			sb.append(verifySeq.substring(indel_loc));
			LB.notice(sb.toString());
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append("query:   ");
			sb.append(querySeq.subSequence(0, indel_loc));
			//for (int x = 0; x < Math.abs(indel_len); x++) { // seems to be a MAQ error - they're not showing
			//	sb.append("N");								// the deletion in the query string.
			//}
			sb.append(querySeq.substring(indel_loc));
			LB.notice(sb.toString());
			LB.notice("genomic: " + querySeq);
		}*/

		
		//TODO Create a function that tests if strings are the same, except for N positions.

		readStartCount[start]++;
		numReads++;
		
		int mismatches = 0;
//		StringBuffer a = new StringBuffer();
//		StringBuffer b = new StringBuffer();
		if (indel_len > 0) {
			for (int i = 0; i < indel_loc && i < alnrd.get_alignLength() ; i++) {
				try {
//					a.append(querySeq.charAt(i));
//					b.append(canonicalSequence.charAt(start+i));
					if (alnrd.get_quality(i) > min_base_quality) { 
						add_position(start+i, querySeq.charAt(i), score);
					}
				} catch (UnexpectedCharacterException uce) {
					mismatches++;
				}
			} 
			for (int i = 0; i < indel_len; i++) {
				//TODO: File new insertion report here
				
//				char q = querySeq.charAt(indel_loc + i);
//				char v = ' ';
			}
			for (int i = indel_loc; i < querySeq.length() - indel_len; i++) {
				try {
//					a.append(querySeq.charAt(i + indel_len));
//					b.append(canonicalSequence.charAt(start+i));
					if (alnrd.get_quality(i + indel_len) > min_base_quality) { 
						add_position(start+i, querySeq.charAt(i + indel_len), score);
					}
				} catch (UnexpectedCharacterException uce) {
					//	TODO: fill in.
					mismatches++;
				}				
			}
		} else {
			
			//TODO: bug in MAQ - can't really handle these yet.
			
		}
//		LB.notice("Query inserted: " + a.toString());
//		LB.notice("Canonoical pos: " + b.toString());
		
		if (mismatches > 4 && !quiet) {
			LB.warning(mismatches + " mismatches observed on gapped alignment:");
			if (indel_len > 0) {  
				LB.warning("query:   " + querySeq);
				StringBuffer sb = new StringBuffer();
				sb.append("genomic: ");
				sb.append(verifySeq.subSequence(0, indel_loc));
				for (int x = 0; x < indel_len; x++) {
					sb.append("N");
				}
				sb.append(verifySeq.substring(indel_loc));
				LB.warning(sb.toString());
			}
		}
		
		
		try {
			if (alnrd.get_direction() == '+') { //keep track of starts and ends
				baseScore[Utilities.getIndexForBase('+')][start]++;
			} else if (alnrd.get_direction() == '-') {
				baseScore[Utilities.getIndexForBase('-')][start + querySeq.length() - indel_len]++;
			}
		} catch (UnexpectedCharacterException uce) {
			LB.error(uce.getMessage());
			LB.debug("x2");
			LB.die();
		}
		return true;
	}
	
	
	
	/**
	 * Adds a hit to the chromosome. The score added to the baseScore array is
	 * the raw base count. There will need to be multiple versions of this
	 * method that can add in abritrary scores and qaulity scores.
	 * returns false if unsuccessful (skipped or failed) returns true if
	 * successful
	 * @param alnrd
	 * @param score
	 * @return
	 * @throws DoesNotMatchException
	 * @throws OverflowException
	 */
	public boolean addSimpleAlignedReadBaseCount(SimpleAlignedRead alnrd, int score) 
					throws DoesNotMatchException, OverflowException {
		/*System.out.println("Start position: " + alnrd.get_start());
		System.out.println("End position:   " + alnrd.get_end());
		System.out.println("Sequence:       " + alnrd.get_seq());
		System.out.println("Direction:      " + ((alnrd.get_direction()) ? "fw" : "rev"));
		System.out.println("Probabilities:  " + alnrd.get_prb_string());*/
		int start = alnrd.get_start() -1;
		byte[] prb = alnrd.get_prb_byte();			//don't need to reverse the probabilities.
		String Sequence = alnrd.get_seq();			//don't need to rev. compliment the sequences... I don't know why.
		if ((start + Sequence.length()) >= canonicalSequence.length()) {
			throw new DoesNotMatchException(
					"Query length "
							+ Sequence.length()
							+ " plus alignment start "
							+ start
							+ " is too close to the end of the sequence "
							+ canonicalSequence.length()
							+ "\n"
							+ "this may legitimately be caused by an insertion near the end of the chromosome.");
		}
		/*
		 * We trundel along the alignment.  At each position we either:
		 * 1) Add genomic insertion data (and we do not change the position in the chromosome that we are referencing)
		 * 2) Add base data (inc. dleetions) into the baseScore array.
		 */
		int mismatches = 0;		//Pretest sequence to check how many mismatches there are over prb threshold.
		String SUpcase = Sequence.toUpperCase();
		for (int x = 0; x < Sequence.length(); x++) { 
			if (prb[x] > min_base_quality && SUpcase.charAt(x) != canonicalSequence.charAt(start + x)) {
				mismatches++;
			}
		}
		
		if (mismatches > 4) {
			LB.warning(mismatches + " mismatches found in String of " + Sequence.length() + " characters");
			LB.warning("alnrd (chr, start, direction):" + alnrd.get_chr() + " " + alnrd.get_start() + " " + alnrd.get_direction());
			String l = "";
			for (int x = 0; x < Sequence.length(); x++) {
				l = l.concat(Sequence.charAt(x) + "  ");
			}
			LB.warning(l);
			l = "";
			for (int x = 0; x < Sequence.length(); x++) {
				l = l.concat(canonicalSequence.charAt(start+x) + "  ");
			}
			LB.warning(l);
			l = "";
			for (int x = 0; x < Sequence.length(); x++) {
				String g = prb[x] +" ";
				if (g.length() < 3) {
					l = l.concat(g + " ");
				} else {
					l = l.concat(g);
				}
			}
			LB.warning(l);
			if ((float)mismatches/Sequence.length() > MAX_MISMATCH) {
				LB.warning("Skipping this read.");
				return false;
			}
		}
		
		readStartCount[start]++;
		numReads++;
		short score_short = (short) score;
		int chromIndex = start;
		for (int i = 0; i < Sequence.length(); i++) {
			if (prb[i] > min_base_quality) { 
				char vChar = Sequence.charAt(i); //verify Seq already has the chars substituted back 
				/* TODO: will eventually insert code for gaps here */
				int baseDex = -1;
				try {
					baseDex = Utilities.getIndexForBase(vChar);
				} catch (UnexpectedCharacterException uce) {
					LB.error(uce.getMessage());
				}
				if ((baseDex > NUM_BASES) || (baseDex < 0)) {
					LB.error("Character " + vChar + " @ position "
							+ i + " found in sequence: " + Sequence);
				} else {
					baseScore[baseDex][chromIndex] += score_short;
					if (baseScore[baseDex][chromIndex] < 0) {
						throw new OverflowException("Overflow error!");
					}
				}
				
			}
			chromIndex++;
		}
		 
		try {
			if (alnrd.get_direction()) { //keep track of starts and ends
				baseScore[Utilities.getIndexForBase('+')][alnrd.get_start() - 1]++;
			} else {
				baseScore[Utilities.getIndexForBase('-')][alnrd.get_end() - 1]++;
			}
		} catch (UnexpectedCharacterException uce) {
			LB.error(uce.getMessage());
			LB.die();
		}
		return true;
	}
	
	/**
	 * This function simply runs over a chromosome and tells you the number of
	 * bases with occupancy > depth. Assumes chromosome was built with a score
	 * of 1 for each base observed.
	 *            the depth for coverage required. If unsure, you probably want
	 *            1x.

	 * @param depth
	 * @return
	 */
	public int coverage(int depth) {
		int i = 0;
		int x = 0;
		int test_base = 0;
		int non_zero = 0;

		while (i < canonicalSequence.length()) { 		//iterate over every base in canonical sequence
			test_base = 0; 								//holds coverage for each base (assuming scores of 1 were used
			for (x = 0; x < NUM_BASES; x++) { 			//iterate over each possible base.
				if ((short) baseScore[x][i] > 0) { 		//if score is greater than 0, add it up
					test_base += (short) baseScore[x][i];
				}
			}
			if (test_base > depth) { 					//if sum of scores is greater than the depth required,
				non_zero++; 							//then this base has coverage at that depth.
			}
			i++;										//move to next base
		}
		return non_zero;
	}

	/**
	 * Quick utility to report the occupancy of a position in the genome. 
	 * Assumes 4 bases + forward and reverse. only want 4 bases
	 * @param x
	 * @return
	 */
	public final int occupancy(int x) {
		return baseScore[0][x] + baseScore[1][x] + baseScore[2][x]
				+ baseScore[3][x];
	}

	/**
	 * 
	 * @param first
	 * @param last
	 * @return
	 */
	public float get_coverage_sum(int first, int last) {
		int y = 0;
		for (int x = first - 1; x < last - 1; x++) {
			y += baseScore[0][x] + baseScore[1][x] + baseScore[2][x]
					+ baseScore[3][x];
		}
		return (float) y / (float) (last - first);
	}

	/**
	 * 
	 * @param first
	 * @param last
	 * @return
	 */
	public float get_coverage(int first, int last) {
		int y = 0;
		for (int x = first - 1; x < last - 1; x++) {
			if (baseScore[0][x] + baseScore[1][x] + baseScore[2][x]
					+ baseScore[3][x] > 0) {
				y++;
			}
		}
		return (float) y / (float) (last - first);
	}

	/**
	 * get number of sequence beginnings and endings.
	 * Corrects for zero based array
	 * 
	 * @param first
	 * @param last
	 * @return number of starts and ends at a given position.
	 */
	public int get_starts_and_ends(int first, int last) {

		int y = 0; 										//4 and 5 are positions of "+" and "-" 
		for (int x = first - 1; x <= last - 1; x++) { 	//in the BASES array respectively
			y += baseScore[4][x] + baseScore[5][x];
		}
		return y;
	}

	/**
	 * return the number of starts at a given position
	 * @param x
	 * @return
	 */
	public final int get_forward_start_at_pos(int x) {
		return baseScore[4][x];
	}
	

	/**
	 * return the number of starts at a given position
	 * @param x
	 * @return
	 */
	public final int get_reverse_start_at_pos(int x) {
		return baseScore[5][x];
	}

	public final int get_canonical_sequence_length() {
		return this.canonicalSequence.length();
	}
	
	public final char get_base_at(int x) {
		return this.canonicalSequence.charAt(x);
	}

	/* **************************SNP CODE ******************************* */

	/**
	 * Find SNPs in a given region - position returned matches with (1-based)
	 * ensembl data, not with chromosome object
	 * @param
	 * @param first
	 * @param last
	 * @param min_percent
	 * @param minCoverageScore
	 * @return ALsnp
	 */
	public ArrayList<SNP> get_local_SNPs(int first, int last,
			float min_percent, int minCoverageScore) {
		ArrayList<SNP> ALsnp = new ArrayList<SNP>(INIT_SIZE);
		
		for (int x = first - 1; x <= last - 1; x++) {
			char CanSeq = canonicalSequence.charAt(x);
			if (CanSeq != 'N') {
				int CanBase = -1; 
				try {
					CanBase = Utilities.getIndexForBase(CanSeq);
				} catch (UnexpectedCharacterException uce) {
					LB.error(uce.getMessage());
					LB.die();
				}
				int total = occupancy(x);
				if (total > minCoverageScore) {					//if coverage is zero, don't bother.
					ArrayList<SNP> as = create_snps(CanBase, x, min_percent, total, CanSeq);
					if (as.size() > 0) { 
						ALsnp.addAll(as);
					}
				}
			}
		}
		return ALsnp;
	}

	
	private ArrayList<SNP> create_snps(int CanBase, int x, float min_percent, int total, char CanSeq) {
		ArrayList<SNP> tmp_snp_list = new ArrayList<SNP>(3);
		if (total != baseScore[CanBase][x]) {		//must be some variation
			for (short y = 0; y < NUM_BASES; y++) {			
				if (y != CanBase) {
					float q = ((float) baseScore[y][x]) / ((float) total);
					if (q > min_percent) {
						/*chromosome object is zero based, convert back to 1 based by adding 1.*/
						SNP s = new SNP(name, x+1, BASES[y], CanSeq,
								baseScore[y][x], baseScore[CanBase][x], total, 0, -1, -1,
								null);
						tmp_snp_list.add(s);
					}
				}
			}
		}
		return tmp_snp_list;		
	}
	
	
	/**
	 * Find SNPs over the whole chromosome - position returned matches chromosome object, not Ensemble Database 
	 * 	@param min_percent
	 * 	@param minCoverageScore
	 * @return
	 */
	public ArrayList<SNP> get_all_SNPs(float min_percent, int minCoverageScore) {
		ArrayList<SNP> ALsnp = new ArrayList<SNP>(INIT_SIZE);
		for (int x = 0; x < canonicalSequence.length(); x++) {
			char CanSeq = canonicalSequence.charAt(x);
			if (CanSeq != 'N') {
				int CanBase = -1; 
				try {
					CanBase = Utilities.getIndexForBase(CanSeq);
				} catch (UnexpectedCharacterException uce) {
					LB.error(uce.getMessage());
					LB.die();
				}
				int total = occupancy(x);
				if (total >= minCoverageScore) { 				//if coverage is zero, don't bother.
					
					ArrayList<SNP> as = create_snps(CanBase, x, min_percent, total, CanSeq);
					if (as.size() > 0) { 
						ALsnp.addAll(as);
					}
				}
			}
		}
		return ALsnp;
	}
	
	
	// ******************* wig file generator *****************************/
	
	/**
	 * 
	 * @param output_path
	 * @param prepend
	 */
	public void generate_wig_file(String output_path, String prepend) {
		WigwriterBuffered wgw = new WigwriterBuffered(LB, output_path + this.name + ".Trans.wig.gz", prepend, 1, MIN_COVERAGE);
		wgw.header("Transcriptome", "Genomic_alignment");		// header:
		int limit = get_canonical_sequence_length();		// crawl through chromosome
		boolean writing = false;
		int occ = 0;

		for (int g = 0; g < limit; g++) {
			occ = this.occupancy(g);
			if (writing) {
				if (occ == 0) {
					writing = false;
				} else {
					wgw.writeln(occ);
				}
			} else {
				if (occ > 0) {
					wgw.section_header(prepend + this.name, g+1);
					writing = true;
					wgw.writeln(this.occupancy(g));
				}
			}
		}
		wgw.close();
	}
	
	
	

	/**
	 * 
	 * @return
	 */
	public static final boolean get_force32() {
		return force32;
	}

	/**
	 * 
	 * @param value
	 */
	public static final void set_force32(boolean value) {
		force32 = value;
	}

}

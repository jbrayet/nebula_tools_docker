package src.projects.findPeaks;

import src.lib.Utilities;
import src.lib.Error_handling.UnexpectedResultException;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.Tuple;

import src.projects.findPeaks.objects.Parameters;
import src.projects.findPeaks.objects.PeakStore;
import src.projects.findPeaks.objects.Peakdesc;

public class PeakLocator {
	
	private PeakLocator (){}		
	
	// ESCA-JAVA0138:
	/**
	 * Peak Locator for integer based array.
	 * @param LB  
	 * @param param
	 * @param coverage_array
	 * @param offset
	 * @param end
	 * @param subpeaks
	 * @param mapkey
	 * @return
	 */
	public static PeakStore process(
			Log_Buffer LB,
			Parameters param,
			int[] coverage_array,
			int offset,
			int end,
			boolean subpeaks, 
			int mapkey) {
		
		PeakStore ps = new PeakStore(LB);
		if (!subpeaks) {
			Tuple<Integer,Integer> max_ht_loc = Functions.maximum_and_location(coverage_array); // the max ht of the area
			Peakdesc p = new Peakdesc (offset, end-offset, max_ht_loc.get_second(), max_ht_loc.get_first(), mapkey);
			ps.add(p);
		} else { 											//sub peaks on.
			float min_valley = 			param.get_subpeaks_parm();
			float variability =  		param.get_trimpeaks_parm();
			boolean trim_peaks = 		param.get_trim();
			try {
				ps.merge(process_subpeaks_on(LB, coverage_array, min_valley,
						variability, offset, trim_peaks, mapkey));
			} catch (UnexpectedResultException ure) {
				LB.warning("Could not find any peaks in area already identified as a peak.");
				LB.warning("this is indicative of much greater problems.  Will terminate.");
				LB.die();
			}
		}
		return ps;
	}
	
	// ESCA-JAVA0138:
	/**
	 * Peak Locator for float based array.
	 * @param LB  
	 * @param param
	 * @param coverage_array
	 * @param offset
	 * @param end
	 * @param subpeaks
	 * @param mapkey
	 * @return
	 */
	public static PeakStore process(
			Log_Buffer LB,
			Parameters param,
			float[] coverage_array,
			int offset,
			int end,
			boolean subpeaks,
			int mapkey) {
		
		PeakStore ps = new PeakStore(LB);
		if (!subpeaks) {
			Tuple<Float, Integer> max_ht_loc = Functions.maximum_and_location(coverage_array); // the max ht of the area
			Peakdesc p = new Peakdesc (offset, end-offset, max_ht_loc.get_second(), max_ht_loc.get_first(), mapkey);
			ps.add(p);
		} else { 											//sub peaks on.
			float min_valley = 			param.get_subpeaks_parm();
			float variability =  		param.get_trimpeaks_parm();
			boolean trim_peaks = 		param.get_trim();
			try {
				ps.merge(process_subpeaks_on(LB, coverage_array, min_valley,
						variability, offset, trim_peaks, mapkey));
			} catch (UnexpectedResultException ure) {
				LB.warning("Could not find any peaks in area already identified as a peak.");
				LB.warning("this is indicative of much greater problems.  Will terminate.");
				LB.die();
			}
		}
		return ps;
	}	

	// ESCA-JAVA0138:
	private static PeakStore process_subpeaks_on(
			Log_Buffer LB,
			float[] coverage_array, 
			float min_valley,
			float variability,
			int offset,
			boolean trim_peaks, 
			int mapkey) 
	throws UnexpectedResultException {
		
		Tuple<Float, Integer>[] pk_maxima = Functions.all_maxima_and_location(coverage_array, min_valley); 
		PeakStore peaks = new PeakStore(LB);
		
		int last_boundary = 0; 
		for (int v = 0; v < pk_maxima.length; v++) {			//initialise objects
			int boundary = (v != pk_maxima.length -1) ?			//last_boundary to end of range
					Utilities.findmin(coverage_array, pk_maxima[v].get_second(), pk_maxima[v+1].get_second()) :
					(coverage_array.length -1);
			if (trim_peaks) {
				int start = trim_peak_start(coverage_array, last_boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				int length = trim_peak_end(coverage_array, boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				peaks.add(new Peakdesc(offset + start, 
						length - start,			// length is the distance from the start of the array, so must be converted
						pk_maxima[v].get_second() - start,		//the max_loc must be converted relative to the start position.
						pk_maxima[v].get_first(), mapkey));
			} else {					
				peaks.add(new Peakdesc(offset + last_boundary, boundary - last_boundary, 
						pk_maxima[v].get_second() - last_boundary,
						pk_maxima[v].get_first(), mapkey));
			}
			last_boundary = boundary;
		}	
		return peaks;
	}

	// ESCA-JAVA0138:
	private static PeakStore process_subpeaks_on(
			Log_Buffer LB,
			int[] coverage_array, 
			float min_valley,
			float variability,
			int offset,
			boolean trim_peaks,
			int mapkey) 
	throws UnexpectedResultException {
		
		Tuple<Integer, Integer>[] pk_maxima = Functions.all_maxima_and_location(coverage_array, min_valley); 
		PeakStore peaks = new PeakStore(LB);
		
		int last_boundary = 0; 
		for (int v = 0; v < pk_maxima.length; v++) {			//initialise objects
			int boundary = (v != pk_maxima.length -1) ?			//last_boundary to end of range
					Utilities.findmin(coverage_array, pk_maxima[v].get_second(), pk_maxima[v+1].get_second()) :
					(coverage_array.length -1); 
			if (trim_peaks) {
				int start = trim_peak_start(coverage_array, last_boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				int length = trim_peak_end(coverage_array, boundary,
						pk_maxima[v].get_second(), pk_maxima[v].get_first(),
						variability);
				peaks.add(new Peakdesc(start + offset,
						length - start,
						pk_maxima[v].get_second() - start,
						pk_maxima[v].get_first(), mapkey));
			} else {
				peaks.add(new Peakdesc(last_boundary + offset, 
						boundary -last_boundary, 
						pk_maxima[v].get_second()-last_boundary,
						pk_maxima[v].get_first(), mapkey));
			}
			last_boundary = boundary;
		}			
		return peaks;
	}

	private static int trim_peak_start(float[] coverageHeights, int pk_start, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j > pk_start) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j--;
		}
		return pk_start;
	}
	
	private static int trim_peak_start(int[] coverageHeights, int pk_start, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j > pk_start) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j--;
		}
		return pk_start;
	}
	
	private static int trim_peak_end(float[] coverageHeights, int pk_end, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j < pk_end) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j++;
		}
		return pk_end;
	}
	
	private static int trim_peak_end(int[] coverageHeights, int pk_end, int max_loc, float height, float variability) {
		float threshold = height * variability;					//find real peak start
		int j = max_loc;
		while (j < pk_end) {
			if (coverageHeights[j-1] < threshold) {
				return j;
			}
			j++;
		}
		return pk_end;
	}

}

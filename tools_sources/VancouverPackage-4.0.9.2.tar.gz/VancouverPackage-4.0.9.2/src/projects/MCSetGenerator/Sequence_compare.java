package src.projects.MCSetGenerator;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import src.lib.CommandLine;
import src.lib.CurrentVersion;
import src.lib.IterableIterator;
import src.lib.Utilities;
import src.lib.Error_handling.CommandLineProcessingException;
import src.lib.Error_handling.UnexpectedCharacterException;
import src.lib.ioInterfaces.Generic_AlignRead_Iterator;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.AlignedRead;


public class Sequence_compare {

	private Sequence_compare() {}
	
	private static Log_Buffer LB;
	
	private static final String FILTER_QUAL_PARAM = "qualityfilter";
	private static final int ROWS_TO_DISPLAY = 1000;
	private static final int KMER_SIZE = 27;
	
	
	private static String file1;
	private static String file2;
	private static String aligner;
	private static int qualityfilter;  
	private static int maq_read_size;
	

	public static void usage() {
		LB.notice("no help currently available");
		LB.die();
	}
	
	
	private static void parse_input(HashMap<String, String> Variables) {
		if (Variables == null) {
			usage();
		}
		assert (Variables != null);

		if (Variables.containsKey("help")) {
			usage();
		}

		if (Variables.containsKey("file1")) {
			CommandLine.test_parameter_count(LB, "file1", Variables.get("file1"), 1);
			file1 = Variables.get("file1");
			LB.notice(" * Input file        : " + file1);
		} else { 
			LB.error("An input file must be supplied with the -file1 flag" );
			usage();
		}
		
		if (Variables.containsKey("file2")) {
			CommandLine.test_parameter_count(LB, "input_file", Variables.get("file2"), 1);
			file2 = Variables.get("file2");
			LB.notice(" * Input file        : " + file2);
		} else { 
			LB.error("An input file must be supplied with the -file2 flag" );
			usage();
		}
				
		
		if (Variables.containsKey("aligner")) {		
			CommandLine.test_parameter_count_min(LB, "aligner", Variables.get("aligner"), 1);
			aligner = Variables.get("aligner");
			LB.notice(" * Input aligner     : " + aligner);
		} else {
			LB.error("aligner must be supplied with -aligner flag");
			usage();
		}
		
		if (aligner.equals("maq")) {
			if (Variables.containsKey("maq_read_size")) {
				CommandLine.test_parameter_count(LB, "maq_read_size", Variables.get("maq_read_size"), 1);
				maq_read_size = Integer.valueOf(Variables.get("maq_read_size"));
				LB.notice(" * Maq read size     : " + maq_read_size);
			} else {
				LB.error("Must specify list of size of the maq reads with the -maq_read_size flag."
						+ " Use 64 for maq 0.6.x use 128 for maq 0.7+");
				usage();
			}
		}
		
		if (Variables.containsKey(FILTER_QUAL_PARAM)) {
			CommandLine.test_parameter_count(LB, FILTER_QUAL_PARAM, Variables.get(FILTER_QUAL_PARAM), 1);
			qualityfilter = Integer.parseInt(Variables.get(FILTER_QUAL_PARAM));
			LB.notice(" * Filter quality min: On ("+ qualityfilter + ")");
		} else {
			qualityfilter = 0;
			LB.notice(" * Filter quality    : Off");
		}
		
		Variables.remove("file1");
		Variables.remove("file2");
		Variables.remove(FILTER_QUAL_PARAM);
		Variables.remove("maq_read_size");
		Variables.remove("aligner");
		Variables.remove("help");

		Iterator<String> keys = Variables.keySet().iterator();
		if (keys.hasNext()) {
			LB.error("Could not process the following flags:");
			for (String k : new IterableIterator<String>(keys)) {
				LB.error("  * " + k);
			}
			LB.die();
		}
		
		
		
	}
	
	
	
	private static String[] make_kmers(String a, int z) {
		if (a.length() < z) {
			return null;
		}
		//LB.debug ("a.length() : " + a.length() + "\tz : " + z);
		int number = a.length() - z + 1;
		String[] s = new String[number];
		for (int x = 0; x < number; x++) {
			s[x] = a.substring(x, z + x);
		}
		return s;
	}
	
	
	
	
	public static void main(String[] args) { 
		
		/* bootstrap log file parameter: */
		LB=Log_Buffer.getLogBufferInstance();
		// ESCA-JAVA0266:
		LB.addPrintStream(System.out);
			
		Thread th = new Thread(LB);
		th.start();
		new CurrentVersion(LB);
		LB.Version("Sequence_Compare", "$Revision: 1656 $");		
		HashMap<String, String> Variables = null;
		try {
			 Variables = CommandLine.process_CLI(args);
		} catch (CommandLineProcessingException CLPE) {
			LB.error(CLPE.getMessage());
			LB.die();
		}	
		
		parse_input(Variables);					//interprets command line args.
		
		
		
		//create three Vectors
		HashSet<String> ds1_reads = new HashSet<String>();
		HashSet<String> ds2_reads = new HashSet<String>();
		HashSet<String> void_reads = new HashSet<String>();
			
		//open dataset 1
		Generic_AlignRead_Iterator it1 = new Generic_AlignRead_Iterator(LB, 
				aligner, "dataset1", file1, qualityfilter, maq_read_size, null,	0,false);
		
		
		//open dataset 2
		
		Generic_AlignRead_Iterator it2 = new Generic_AlignRead_Iterator(LB, 
				aligner, "dataset2", file2, qualityfilter, maq_read_size, null,	0,false);
		

		int count = 0;
		AlignedRead ar = null;
		String r  = null;
		// ESCA-JAVA0049:
		while (it1.hasNext() || it2.hasNext()) {
			count +=1;
			if (count %1000000 == 0) {
				LB.notice("count is : " + count);
				LB.notice("v: " + void_reads.size() + "\tds1: " + ds1_reads.size() + "\tds2: " + ds2_reads.size() );
			}
			if (it1.hasNext()) {
				ar = it1.next();
				if (ar.get_direction() != '+') {
					ar = ar.clone_rc();
				}
				if (ar != null) {
					String seq = ar.get_sequence().toUpperCase();
					String[] seqs = make_kmers(seq, KMER_SIZE);
					if (seqs != null) {
						for (String s : seqs) {
							if (s.contains("N")) {
								continue;
							}
							try { 
								r = Utilities.reverseCompliment(s);
							} catch (UnexpectedCharacterException uce) {
								LB.error(uce.getMessage());
							}
							if (void_reads.contains(s) ||  void_reads.contains(r)) {
								//do nothing
							} else if (ds2_reads.remove(s)) {		//returns true only if element existed
								void_reads.add(s);
							} else if (ds2_reads.remove(r)) {		//returns true only if element existed
								void_reads.add(r);
							} else if (!ds1_reads.contains(s) && !ds1_reads.contains(r)){
								ds1_reads.add(s);
							}
						}
					}
				}
			}
			if (it2.hasNext()) {
				ar = it2.next();
				if (ar.get_direction() != '+') {
					ar = ar.clone_rc();
				}
				if (ar != null) {
					String seq = ar.get_sequence().toUpperCase();
					String[] seqs = make_kmers(seq, KMER_SIZE);
					if (seqs != null) {
						for (String s : seqs) {
							if (s.contains("N")) {
								continue;
							}
							try { 
								r = Utilities.reverseCompliment(s);
							} catch (UnexpectedCharacterException uce) {
								LB.error(uce.getMessage());
							}
							if (void_reads.contains(s) || void_reads.contains(r)) {
								//do nothing
							} else if (ds1_reads.remove(s)) {		//returns true only if element existed
								void_reads.add(s);
							} else if (ds1_reads.remove(r)) {		//returns true only if element existed
								void_reads.add(r);
							} else if (!ds2_reads.contains(s) &&  !ds2_reads.contains(r)){
								ds2_reads.add(s);
							}
						}
					}
				}
			}
		}
		LB.notice("DONE!");
		
		
		
		String[] ds1_r  = new String[ds1_reads.size()];
		ds1_r = ds1_reads.toArray(ds1_r);
		Arrays.sort(ds1_r);
		
		String[] ds2_r  = new String[ds2_reads.size()];
		ds2_r = ds2_reads.toArray(ds2_r);
		Arrays.sort(ds2_r);
		
		
		
		
		for (int x = 0; x < ROWS_TO_DISPLAY; x++) {
			LB.notice("1: " + ds1_r[x]);
		}
		
		for (int x = 0; x < ROWS_TO_DISPLAY; x++) {
			LB.notice("2: " + ds2_r[x]);
		}
		
		
		LB.notice("void_reads: " + void_reads.size() + " records");
		LB.notice("ds1_reads:  " + ds1_reads.size() + " records");
		LB.notice("ds2_reads:  " + ds2_reads.size() + " records");
		
		LB.close();
		
	}
	
	
	
	
}

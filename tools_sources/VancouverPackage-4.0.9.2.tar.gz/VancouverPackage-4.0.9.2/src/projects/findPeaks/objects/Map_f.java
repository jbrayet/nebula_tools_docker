package src.projects.findPeaks.objects;

public class Map_f {

	private float[] map = null;
	private int location;
	
	public Map_f(float[] m, int loc) {
		this.map = new float[m.length];
		System.arraycopy(m, 0, this.map, 0, m.length);
		this.location = loc;
	}
	
	public float[] get_map() {
		float[] tmp = new float[this.map.length];
		System.arraycopy(this.map, 0, tmp, 0, this.map.length);
		return tmp;
	}
	
	public int get_loc() {
		return this.location;
	}
	
	
	
}

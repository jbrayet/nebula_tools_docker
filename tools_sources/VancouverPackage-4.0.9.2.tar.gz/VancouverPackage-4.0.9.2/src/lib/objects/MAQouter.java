package src.lib.objects;

/**
 * @version $Revision: 320 $
 * @author 
 */
public class MAQouter {

	
	public static final int MAQMAP_FORMAT_NEW = -1;				//maqmap.h: #define MAQMAP_FORMAT_NEW -1
	
	private final int format;
	private final int n_ref;
	private final char[][] refname;
	private final long n_mapped_reads;
	
	/*private MAQinner mapped_read;*/							//this is never read by MAQ - I don't know why it's declared.
	
	public MAQouter(int n_ref, char[][] refname, long n_mapped_reads) {
		this.format = MAQMAP_FORMAT_NEW;						
		this.n_ref = n_ref;
		this.refname = refname.clone();
		this.n_mapped_reads = n_mapped_reads; 			//unsigned long long
		/*original object has a pointer  to a MAQinner object*/
	}
	
	public final int get_format() 				{ return this.format; }
	public final int get_n_ref() 				{ return this.n_ref; }
	public final long get_n_mapped_reads()	 	{ return this.n_mapped_reads; }
	public final int get_count_of_refnames()	{ return this.refname.length; }
	public final char[] get_refname(int x) 		{ return this.refname[x]; }
	
}

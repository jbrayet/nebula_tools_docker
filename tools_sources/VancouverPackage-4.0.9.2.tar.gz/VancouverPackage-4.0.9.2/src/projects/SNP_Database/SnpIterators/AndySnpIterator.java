package src.projects.SNP_Database.SnpIterators;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import src.lib.Constants;
import src.lib.Utilities;
import src.lib.ioInterfaces.Log_Buffer;
import src.lib.objects.SNP;

/**
 * @version $Revision: 1612 $
 * @author 
 */
public class AndySnpIterator implements Iterator<SNP>, SNPIterator {
	private static boolean display_version = true;
	private static Log_Buffer LB;

	BufferedReader br = null;
	int linecount = 0;
	final String filename;
	Vector<SNP> buffer;
	
	public AndySnpIterator(Log_Buffer logbuffer, String source_file) {
		LB = logbuffer;
		this.filename = source_file;
		if (display_version) {
			LB.Version("AndySnpIterator", "$Revision: 1612 $");
			display_version = false;
		}
		try {
			br = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException e) {
			LB.error("Can't find file " + filename);
			LB.die();
		}
		buffer = new Vector<SNP>();
	}
	
	public boolean mark() {
		try {
			br.mark(Constants.MARK_BUFFER_SIZE);
			return true;
		} catch (IOException ioe) {
			LB.error("Could not mark Input file for read buffer.");
			return false;
		}
	}
	
	public void remove() { 
	    throw new UnsupportedOperationException(); 
	}
	
	public void close(boolean verbose) {
		try {
			this.br.close();
		} catch (IOException io) {
			LB.warning("Could not close file");
			LB.warning("Message thrown by Java environment (may be null):" + io.getMessage());
		}
		LB.notice(filename + " closed successfully");
		
	}
	
	
	/** 
	 * Read in next line of the SNP file
	 * 
	 * Expected format:
	 * chromosome      position ref    consen  qual    depth   hits    max q.  min q.  other  log lik. other.
	 * 1:6176211       T       G       54      9       2.00    51      54      HOM
	 * 1:26328578      T       G       78      17      1.44    45      62      HOM
	 * 1:91625699      A       C       168     47      1.12    63      62      HOM
	 * 1:107914620     A       G       63      14      1.00    45      62      HOM
	 * 
	 * @return SNP object
	 */
	public SNP next() {
		String line = null;
		Vector<SNP> S =  new Vector<SNP>();
		if (buffer.size() > 0) {
			return buffer.remove(0);
		}
		try {
			if ((line = br.readLine()) != null) {
				this.linecount++;	
				
				String[] elements = line.split("\t");				
				if (elements.length < 9) {
					LB.error("Lack of fields in SNP file provided");
					LB.die();
				}
				String[] tmp = elements[0].split(":");
				String chromosome 	= tmp[0];
				int position 		= Integer.valueOf(tmp[1]);
				char ref 			= elements[1].charAt(0);		
				char obs			= elements[2].charAt(0);
				int qual			= Integer.valueOf(elements[3]);
				int depth			= Integer.valueOf(elements[4]);
				float hits			= Float.valueOf(elements[5]);
				//int maxq			= Integer.valueOf(elements[6]);
				//int min_q			= Integer.valueOf(elements[7]);
				String heterozy		= elements[8];

				char[] snps = Utilities.non_canonical_expansion(obs);
				for (char o : snps) {
					if (o != ref) {
						S.add(new SNP(chromosome, position, o, ref, Math.round(hits), 
								 depth - Math.round(hits), depth, -1, Float.valueOf(qual),
								 (heterozy.compareTo("HET")==0 ) ? 1 : 0,
								 null));
					}
				}
			} else {
				throw new NoSuchElementException("Could not get any more reads.");
			}
		} catch (IOException io) {
			LB.error("Error occured on line " + this.linecount);
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		if (S.size() > 1) {
			SNP first_snp = S.remove(0);
			buffer.addAll(S);
			return first_snp;
		} else {
			return S.firstElement();
		}
	}
	
	public boolean hasNext() {
		try {
			return br.ready();
		} catch (IOException io){
			LB.error("Could not determine status of SNPIterator");
			LB.error("Message thrown by Java environment (may be null):" + io.getMessage());
			LB.die();
		}
		return false;
	}

}

		